//! Stereo TAAU demo — windowed side-by-side "VR preview".
//!
//! Renders a spinning cube twice with IPD-separated view matrices at
//! internal scale, feeds both eyes through `StereoTaauPass`, then
//! composites the two per-eye outputs into a single side-by-side window.
//!
//! Controls:
//!   U       — toggle upscale on/off (bilinear lowres when off)
//!   +/-     — adjust sharpness
//!   I       — cycle IPD: 0.058 → 0.063 → 0.068 → 0.058 ...
//!   Esc     — quit
//!
//! Env vars:
//!   VR_EYE_W / VR_EYE_H     — per-eye output extent (default 1032×1104,
//!                             2× makes a 2064×1104 window = half-scale
//!                             Quest 3 eye stack — fits typical monitors).
//!   VR_INTERNAL_SCALE       — internal-to-output scale (default 0.667).

use std::sync::Arc;

use ce_math::{Mat4, Vec3};
use ce_render::{EyeTarget, StereoTaauPass, UpscaleSettings};
use wgpu::util::DeviceExt;
use winit::application::ApplicationHandler;
use winit::event::{ElementState, KeyEvent, WindowEvent};
use winit::event_loop::{ActiveEventLoop, EventLoop};
use winit::keyboard::{Key, NamedKey, SmolStr};
use winit::window::{Window, WindowAttributes, WindowId};

const HDR_FORMAT: wgpu::TextureFormat = wgpu::TextureFormat::Rgba16Float;
const MOTION_FORMAT: wgpu::TextureFormat = wgpu::TextureFormat::Rg16Float;
const DEPTH_FORMAT: wgpu::TextureFormat = wgpu::TextureFormat::Depth32Float;

// ---------------------------------------------------------------------------
// Cube mesh (borrowed shape from upscale_demo; kept local for independence)
// ---------------------------------------------------------------------------

#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct Vertex {
    pos: [f32; 3],
    color: [f32; 3],
}

fn cube_mesh() -> (Vec<Vertex>, Vec<u16>) {
    let f = 0.5;
    let faces: [(Vec3, Vec3, Vec3, Vec3, [f32; 3]); 6] = [
        (Vec3::new(f, -f, -f), Vec3::new(f, f, -f), Vec3::new(f, f, f), Vec3::new(f, -f, f), [0.9, 0.3, 0.3]),
        (Vec3::new(-f, -f, f), Vec3::new(-f, f, f), Vec3::new(-f, f, -f), Vec3::new(-f, -f, -f), [0.3, 0.9, 0.3]),
        (Vec3::new(-f, f, -f), Vec3::new(-f, f, f), Vec3::new(f, f, f), Vec3::new(f, f, -f), [0.3, 0.3, 0.9]),
        (Vec3::new(-f, -f, f), Vec3::new(-f, -f, -f), Vec3::new(f, -f, -f), Vec3::new(f, -f, f), [0.9, 0.9, 0.3]),
        (Vec3::new(f, -f, f), Vec3::new(f, f, f), Vec3::new(-f, f, f), Vec3::new(-f, -f, f), [0.3, 0.9, 0.9]),
        (Vec3::new(-f, -f, -f), Vec3::new(-f, f, -f), Vec3::new(f, f, -f), Vec3::new(f, -f, -f), [0.9, 0.3, 0.9]),
    ];
    let mut verts = Vec::with_capacity(24);
    let mut idxs = Vec::with_capacity(36);
    for (a, b, c, d, col) in faces {
        let base = verts.len() as u16;
        for p in [a, b, c, d] {
            verts.push(Vertex { pos: [p.x, p.y, p.z], color: col });
        }
        idxs.extend_from_slice(&[base, base + 1, base + 2, base, base + 2, base + 3]);
    }
    (verts, idxs)
}

#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable, Default)]
struct SceneUniforms {
    cur_mvp_jittered: [[f32; 4]; 4],
    cur_mvp_unjittered: [[f32; 4]; 4],
    prev_mvp_unjittered: [[f32; 4]; 4],
}

// ---------------------------------------------------------------------------
// Present shader: SBS composite, Reinhard tonemap
// ---------------------------------------------------------------------------

const PRESENT_SHADER: &str = r#"
@group(0) @binding(0) var left_tex:  texture_2d<f32>;
@group(0) @binding(1) var right_tex: texture_2d<f32>;
@group(0) @binding(2) var samp:      sampler;

struct VsOut {
    @builtin(position) pos: vec4<f32>,
    @location(0) uv: vec2<f32>,
};

@vertex
fn vs_main(@builtin(vertex_index) vid: u32) -> VsOut {
    var o: VsOut;
    let x = f32((vid << 1u) & 2u);
    let y = f32(vid & 2u);
    o.pos = vec4<f32>(x * 2.0 - 1.0, 1.0 - y * 2.0, 0.0, 1.0);
    o.uv  = vec2<f32>(x, y);
    return o;
}

@fragment
fn fs_main(in: VsOut) -> @location(0) vec4<f32> {
    let left_uv  = vec2<f32>(in.uv.x * 2.0,            in.uv.y);
    let right_uv = vec2<f32>((in.uv.x - 0.5) * 2.0,    in.uv.y);
    var c: vec3<f32>;
    if (in.uv.x < 0.5) {
        c = textureSample(left_tex, samp, left_uv).rgb;
    } else {
        c = textureSample(right_tex, samp, right_uv).rgb;
    }
    let tone = c / (c + vec3<f32>(1.0));
    return vec4<f32>(tone, 1.0);
}
"#;

// ---------------------------------------------------------------------------
// Per-eye MRT render targets
// ---------------------------------------------------------------------------

struct EyeMrt {
    color: wgpu::Texture,
    color_view: wgpu::TextureView,
    #[allow(dead_code)]
    depth: wgpu::Texture,
    depth_view: wgpu::TextureView,
    #[allow(dead_code)]
    motion: wgpu::Texture,
    motion_view: wgpu::TextureView,
}

impl EyeMrt {
    fn new(device: &wgpu::Device, extent: wgpu::Extent3d, label_prefix: &str) -> Self {
        let make = |label: String, fmt: wgpu::TextureFormat| {
            let t = device.create_texture(&wgpu::TextureDescriptor {
                label: Some(&label),
                size: extent,
                mip_level_count: 1,
                sample_count: 1,
                dimension: wgpu::TextureDimension::D2,
                format: fmt,
                usage: wgpu::TextureUsages::TEXTURE_BINDING
                    | wgpu::TextureUsages::RENDER_ATTACHMENT,
                view_formats: &[],
            });
            let v = t.create_view(&wgpu::TextureViewDescriptor::default());
            (t, v)
        };
        let (color, color_view) = make(format!("{}_color", label_prefix), HDR_FORMAT);
        let (motion, motion_view) = make(format!("{}_motion", label_prefix), MOTION_FORMAT);
        let (depth, depth_view) = make(format!("{}_depth", label_prefix), DEPTH_FORMAT);
        Self {
            color,
            color_view,
            depth,
            depth_view,
            motion,
            motion_view,
        }
    }
}

// ---------------------------------------------------------------------------
// GpuState
// ---------------------------------------------------------------------------

struct GpuState {
    surface: wgpu::Surface<'static>,
    device: wgpu::Device,
    queue: wgpu::Queue,
    config: wgpu::SurfaceConfiguration,

    scene_pipeline: wgpu::RenderPipeline,
    #[allow(dead_code)]
    scene_bgl: wgpu::BindGroupLayout,
    scene_uniform_left: wgpu::Buffer,
    scene_uniform_right: wgpu::Buffer,
    // Cached once at startup — the underlying uniform buffer handle is
    // stable, only its contents change via write_buffer each frame.
    scene_bg_left: wgpu::BindGroup,
    scene_bg_right: wgpu::BindGroup,
    vertex_buf: wgpu::Buffer,
    index_buf: wgpu::Buffer,
    index_count: u32,

    present_pipeline: wgpu::RenderPipeline,
    present_bgl: wgpu::BindGroupLayout,
    present_sampler: wgpu::Sampler,

    left_eye: EyeMrt,
    right_eye: EyeMrt,
    stereo: StereoTaauPass,

    per_eye_output: wgpu::Extent3d,
    frame_index: u64,
    prev_mvp: [Mat4; 2], // un-jittered, per eye
    start: std::time::Instant,
    upscale_enabled: bool,
    ipd_m: f32,
    // --- diagnostics ---
    last_frame_instant: std::time::Instant,
    frame_time_window: [f32; 60],
    frame_time_cursor: usize,
}

impl GpuState {
    fn new(window: Arc<Window>) -> Self {
        let size = window.inner_size();

        let instance = wgpu::Instance::new(&wgpu::InstanceDescriptor {
            backends: wgpu::Backends::all(),
            ..Default::default()
        });
        let surface: wgpu::Surface<'static> =
            instance.create_surface(window.clone()).expect("surface");

        let adapter = pollster::block_on(instance.request_adapter(&wgpu::RequestAdapterOptions {
            power_preference: wgpu::PowerPreference::HighPerformance,
            compatible_surface: Some(&surface),
            force_fallback_adapter: false,
        }))
        .expect("adapter");
        log::info!("GPU: {}", adapter.get_info().name);

        let (device, queue) = pollster::block_on(adapter.request_device(
            &wgpu::DeviceDescriptor {
                label: Some("vr_stereo_device"),
                required_features: wgpu::Features::empty(),
                required_limits: wgpu::Limits::default(),
                memory_hints: Default::default(),
            },
            None,
        ))
        .expect("device");

        let caps = surface.get_capabilities(&adapter);
        let surface_format = caps
            .formats
            .iter()
            .find(|f| f.is_srgb())
            .copied()
            .unwrap_or(caps.formats[0]);

        let config = wgpu::SurfaceConfiguration {
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
            format: surface_format,
            width: size.width.max(1),
            height: size.height.max(1),
            // Fifo = strict vsync. Paired with ControlFlow::Wait in main()
            // so the event loop blocks between vsyncs instead of spinning,
            // which is the canonical wgpu+winit pacing pattern. Mailbox
            // without a frame limiter here just lets the GPU race to
            // thousands of fps and makes DWM composition jitter worse,
            // not better (measured: ~3700fps, worse perceived stutter).
            present_mode: wgpu::PresentMode::Fifo,
            alpha_mode: caps.alpha_modes[0],
            view_formats: vec![],
            // 2 lets the CPU run one frame ahead of the GPU, but on fast
            // GPUs with low frame cost the queue oscillates: sometimes
            // acquire returns instantly (sub-ms "frames"), sometimes it
            // waits 2 vsyncs. The visible result is a rhythmic stutter.
            // Setting 1 forces strict vsync pacing — CPU blocks every
            // frame, max jitter is bounded to one vsync interval.
            desired_maximum_frame_latency: 1,
        };
        surface.configure(&device, &config);

        // Each eye gets half the window width.
        let per_eye_output = wgpu::Extent3d {
            width: (config.width / 2).max(1),
            height: config.height.max(1),
            depth_or_array_layers: 1,
        };

        let scale = std::env::var("VR_INTERNAL_SCALE")
            .ok()
            .and_then(|s| s.parse().ok())
            .unwrap_or(0.667_f32);
        let settings = UpscaleSettings {
            internal_scale: scale,
            sharpness: 0.4,
        };
        let stereo = StereoTaauPass::new(&device, HDR_FORMAT, per_eye_output, settings);
        log::info!(
            "per_eye_output = {}x{}  internal = {}x{}  scale = {}",
            per_eye_output.width,
            per_eye_output.height,
            stereo.per_eye_internal_extent().width,
            stereo.per_eye_internal_extent().height,
            scale,
        );

        let internal = stereo.per_eye_internal_extent();
        let left_eye = EyeMrt::new(&device, internal, "left");
        let right_eye = EyeMrt::new(&device, internal, "right");

        // --- Mesh ---
        let (verts, idxs) = cube_mesh();
        let vertex_buf = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("cube_vb"),
            contents: bytemuck::cast_slice(&verts),
            usage: wgpu::BufferUsages::VERTEX,
        });
        let index_buf = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("cube_ib"),
            contents: bytemuck::cast_slice(&idxs),
            usage: wgpu::BufferUsages::INDEX,
        });
        let index_count = idxs.len() as u32;

        // --- Scene pipeline (reuses the scene_mrt.wgsl shipped in ce_render) ---
        let scene_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("scene_mrt"),
            source: wgpu::ShaderSource::Wgsl(
                include_str!("../../../crates/ce_render/src/shaders/scene_mrt.wgsl").into(),
            ),
        });
        let scene_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("scene_bgl"),
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::VERTEX,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            }],
        });
        let make_uniform = |label: &str| {
            device.create_buffer(&wgpu::BufferDescriptor {
                label: Some(label),
                size: std::mem::size_of::<SceneUniforms>() as u64,
                usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            })
        };
        let scene_uniform_left = make_uniform("scene_uniform_left");
        let scene_uniform_right = make_uniform("scene_uniform_right");
        let scene_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("scene_pl"),
            bind_group_layouts: &[&scene_bgl],
            push_constant_ranges: &[],
        });
        let scene_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("scene_pipeline"),
            layout: Some(&scene_layout),
            vertex: wgpu::VertexState {
                module: &scene_shader,
                entry_point: Some("vs_main"),
                buffers: &[wgpu::VertexBufferLayout {
                    array_stride: std::mem::size_of::<Vertex>() as u64,
                    step_mode: wgpu::VertexStepMode::Vertex,
                    attributes: &[
                        wgpu::VertexAttribute {
                            format: wgpu::VertexFormat::Float32x3,
                            offset: 0,
                            shader_location: 0,
                        },
                        wgpu::VertexAttribute {
                            format: wgpu::VertexFormat::Float32x3,
                            offset: 12,
                            shader_location: 1,
                        },
                    ],
                }],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &scene_shader,
                entry_point: Some("fs_main"),
                targets: &[
                    Some(wgpu::ColorTargetState {
                        format: HDR_FORMAT,
                        blend: None,
                        write_mask: wgpu::ColorWrites::ALL,
                    }),
                    Some(wgpu::ColorTargetState {
                        format: MOTION_FORMAT,
                        blend: None,
                        write_mask: wgpu::ColorWrites::ALL,
                    }),
                ],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState {
                topology: wgpu::PrimitiveTopology::TriangleList,
                cull_mode: Some(wgpu::Face::Back),
                ..Default::default()
            },
            depth_stencil: Some(wgpu::DepthStencilState {
                format: DEPTH_FORMAT,
                depth_write_enabled: true,
                depth_compare: wgpu::CompareFunction::Less,
                stencil: Default::default(),
                bias: Default::default(),
            }),
            multisample: wgpu::MultisampleState::default(),
            multiview: None,
            cache: None,
        });

        // --- Present pipeline ---
        let present_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("present"),
            source: wgpu::ShaderSource::Wgsl(PRESENT_SHADER.into()),
        });
        let present_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("present_bgl"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Float { filterable: true },
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 1,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Float { filterable: true },
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 2,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                    count: None,
                },
            ],
        });
        let present_sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            label: Some("present_sampler"),
            address_mode_u: wgpu::AddressMode::ClampToEdge,
            address_mode_v: wgpu::AddressMode::ClampToEdge,
            address_mode_w: wgpu::AddressMode::ClampToEdge,
            mag_filter: wgpu::FilterMode::Linear,
            min_filter: wgpu::FilterMode::Linear,
            mipmap_filter: wgpu::FilterMode::Nearest,
            ..Default::default()
        });
        let present_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("present_pl"),
            bind_group_layouts: &[&present_bgl],
            push_constant_ranges: &[],
        });
        let present_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("present_pipeline"),
            layout: Some(&present_layout),
            vertex: wgpu::VertexState {
                module: &present_shader,
                entry_point: Some("vs_main"),
                buffers: &[],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &present_shader,
                entry_point: Some("fs_main"),
                targets: &[Some(wgpu::ColorTargetState {
                    format: surface_format,
                    blend: None,
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState::default(),
            depth_stencil: None,
            multisample: wgpu::MultisampleState::default(),
            multiview: None,
            cache: None,
        });

        // Cache scene bind groups — the uniform buffer handles are stable.
        let scene_bg_left = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("scene_bg_left_cached"),
            layout: &scene_bgl,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: scene_uniform_left.as_entire_binding(),
            }],
        });
        let scene_bg_right = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("scene_bg_right_cached"),
            layout: &scene_bgl,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: scene_uniform_right.as_entire_binding(),
            }],
        });

        Self {
            surface,
            device,
            queue,
            config,
            scene_pipeline,
            scene_bgl,
            scene_uniform_left,
            scene_uniform_right,
            scene_bg_left,
            scene_bg_right,
            vertex_buf,
            index_buf,
            index_count,
            present_pipeline,
            present_bgl,
            present_sampler,
            left_eye,
            right_eye,
            stereo,
            per_eye_output,
            frame_index: 0,
            prev_mvp: [Mat4::IDENTITY, Mat4::IDENTITY],
            start: std::time::Instant::now(),
            upscale_enabled: true,
            ipd_m: 0.063,
            last_frame_instant: std::time::Instant::now(),
            frame_time_window: [0.0; 60],
            frame_time_cursor: 0,
        }
    }

    fn resize(&mut self, w: u32, h: u32) {
        if w == 0 || h == 0 {
            return;
        }
        self.config.width = w;
        self.config.height = h;
        self.surface.configure(&self.device, &self.config);
        self.per_eye_output = wgpu::Extent3d {
            width: (w / 2).max(1),
            height: h,
            depth_or_array_layers: 1,
        };
        self.stereo.resize(&self.device, self.per_eye_output);
        let internal = self.stereo.per_eye_internal_extent();
        self.left_eye = EyeMrt::new(&self.device, internal, "left");
        self.right_eye = EyeMrt::new(&self.device, internal, "right");
        self.prev_mvp = [Mat4::IDENTITY, Mat4::IDENTITY];
        self.frame_index = 0;
    }

    fn update_and_render(&mut self) -> Result<(), wgpu::SurfaceError> {
        let t = self.start.elapsed().as_secs_f32();
        let internal = self.stereo.per_eye_internal_extent();
        let aspect = internal.width as f32 / internal.height as f32;

        // Shared scene transform.
        let model = Mat4::from_rotation_y(t * 0.9) * Mat4::from_rotation_x(t * 0.6);
        let cam_pos = Vec3::new(2.5 * (t * 0.4).cos(), 1.2, 2.5 * (t * 0.4).sin());
        let look_fwd = (Vec3::ZERO - cam_pos).normalize();
        let up = Vec3::Y;
        let right = look_fwd.cross(up).normalize();
        let center_view = Mat4::look_at_rh(cam_pos, Vec3::ZERO, up);

        // Per-eye view = camera translated laterally by ±ipd/2.
        // Equivalent to prepending a translation in camera-local space.
        let half_ipd = self.ipd_m * 0.5;
        let left_view = Mat4::from_translation(Vec3::new(half_ipd, 0.0, 0.0)) * center_view;
        let right_view = Mat4::from_translation(Vec3::new(-half_ipd, 0.0, 0.0)) * center_view;
        let _ = right; // silence unused-variable when we don't need a manual basis.

        let proj = Mat4::perspective_rh(60f32.to_radians(), aspect, 0.1, 100.0);

        let [j_left, j_right] = self.stereo.jitter_for_frame(self.frame_index);
        let mut proj_left = proj;
        proj_left.z_axis.x = 2.0 * j_left[0] / internal.width as f32;
        proj_left.z_axis.y = 2.0 * j_left[1] / internal.height as f32;
        let mut proj_right = proj;
        proj_right.z_axis.x = 2.0 * j_right[0] / internal.width as f32;
        proj_right.z_axis.y = 2.0 * j_right[1] / internal.height as f32;

        let mvp_l_unj = proj * left_view * model;
        let mvp_r_unj = proj * right_view * model;
        let mvp_l_jit = proj_left * left_view * model;
        let mvp_r_jit = proj_right * right_view * model;

        let u_left = SceneUniforms {
            cur_mvp_jittered: mvp_l_jit.to_cols_array_2d(),
            cur_mvp_unjittered: mvp_l_unj.to_cols_array_2d(),
            prev_mvp_unjittered: self.prev_mvp[0].to_cols_array_2d(),
        };
        let u_right = SceneUniforms {
            cur_mvp_jittered: mvp_r_jit.to_cols_array_2d(),
            cur_mvp_unjittered: mvp_r_unj.to_cols_array_2d(),
            prev_mvp_unjittered: self.prev_mvp[1].to_cols_array_2d(),
        };
        self.queue
            .write_buffer(&self.scene_uniform_left, 0, bytemuck::bytes_of(&u_left));
        self.queue
            .write_buffer(&self.scene_uniform_right, 0, bytemuck::bytes_of(&u_right));

        // Scene bind groups are cached in Self — contents change via
        // write_buffer, handles stay stable.

        // Acquire swapchain.
        let surface_tex = self.surface.get_current_texture()?;
        let surface_view = surface_tex
            .texture
            .create_view(&wgpu::TextureViewDescriptor::default());

        let mut encoder =
            self.device
                .create_command_encoder(&wgpu::CommandEncoderDescriptor {
                    label: Some("stereo_frame_encoder"),
                });

        // --- Scene pass × 2 (one per eye) ---
        for (eye_mrt, bg, label) in [
            (&self.left_eye, &self.scene_bg_left, "scene_pass_left"),
            (&self.right_eye, &self.scene_bg_right, "scene_pass_right"),
        ] {
            let mut rp = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some(label),
                color_attachments: &[
                    Some(wgpu::RenderPassColorAttachment {
                        view: &eye_mrt.color_view,
                        resolve_target: None,
                        ops: wgpu::Operations {
                            load: wgpu::LoadOp::Clear(wgpu::Color {
                                r: 0.03,
                                g: 0.04,
                                b: 0.07,
                                a: 1.0,
                            }),
                            store: wgpu::StoreOp::Store,
                        },
                    }),
                    Some(wgpu::RenderPassColorAttachment {
                        view: &eye_mrt.motion_view,
                        resolve_target: None,
                        ops: wgpu::Operations {
                            load: wgpu::LoadOp::Clear(wgpu::Color::TRANSPARENT),
                            store: wgpu::StoreOp::Store,
                        },
                    }),
                ],
                depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                    view: &eye_mrt.depth_view,
                    depth_ops: Some(wgpu::Operations {
                        load: wgpu::LoadOp::Clear(1.0),
                        store: wgpu::StoreOp::Store,
                    }),
                    stencil_ops: None,
                }),
                timestamp_writes: None,
                occlusion_query_set: None,
            });
            rp.set_pipeline(&self.scene_pipeline);
            rp.set_bind_group(0, bg, &[]);
            rp.set_vertex_buffer(0, self.vertex_buf.slice(..));
            rp.set_index_buffer(self.index_buf.slice(..), wgpu::IndexFormat::Uint16);
            rp.draw_indexed(0..self.index_count, 0, 0..1);
        }

        // --- TAAU × 2 (via StereoTaauPass) ---
        let left_in = EyeTarget {
            color_view: &self.left_eye.color_view,
            depth_view: &self.left_eye.depth_view,
            motion_view: &self.left_eye.motion_view,
        };
        let right_in = EyeTarget {
            color_view: &self.right_eye.color_view,
            depth_view: &self.right_eye.depth_view,
            motion_view: &self.right_eye.motion_view,
        };

        let (left_src_view, right_src_view) = if self.upscale_enabled {
            self.stereo.execute(
                &self.device,
                &self.queue,
                &mut encoder,
                self.frame_index,
                &left_in,
                &right_in,
            );
            (
                self.stereo.left_output(self.frame_index).clone(),
                self.stereo.right_output(self.frame_index).clone(),
            )
        } else {
            (
                self.left_eye
                    .color
                    .create_view(&wgpu::TextureViewDescriptor::default()),
                self.right_eye
                    .color
                    .create_view(&wgpu::TextureViewDescriptor::default()),
            )
        };

        let present_bg = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("present_bg"),
            layout: &self.present_bgl,
            entries: &[
                wgpu::BindGroupEntry {
                    binding: 0,
                    resource: wgpu::BindingResource::TextureView(&left_src_view),
                },
                wgpu::BindGroupEntry {
                    binding: 1,
                    resource: wgpu::BindingResource::TextureView(&right_src_view),
                },
                wgpu::BindGroupEntry {
                    binding: 2,
                    resource: wgpu::BindingResource::Sampler(&self.present_sampler),
                },
            ],
        });
        {
            let mut rp = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("present_sbs"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &surface_view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color::BLACK),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                timestamp_writes: None,
                occlusion_query_set: None,
            });
            rp.set_pipeline(&self.present_pipeline);
            rp.set_bind_group(0, &present_bg, &[]);
            rp.draw(0..3, 0..1);
        }

        self.queue.submit(std::iter::once(encoder.finish()));
        surface_tex.present();

        self.prev_mvp = [mvp_l_unj, mvp_r_unj];
        self.frame_index = self.frame_index.wrapping_add(1);

        // --- diagnostics: log avg / min / max / p99 every 60 frames ---
        let now = std::time::Instant::now();
        let dt_ms = (now - self.last_frame_instant).as_secs_f32() * 1000.0;
        self.last_frame_instant = now;
        self.frame_time_window[self.frame_time_cursor] = dt_ms;
        self.frame_time_cursor = (self.frame_time_cursor + 1) % 60;
        if self.frame_index.is_multiple_of(60) && self.frame_index > 0 {
            let mut sorted = self.frame_time_window;
            sorted.sort_by(|a, b| a.partial_cmp(b).unwrap());
            let avg: f32 = sorted.iter().sum::<f32>() / 60.0;
            let min = sorted[0];
            let max = sorted[59];
            let p50 = sorted[30];
            log::info!(
                "frame {}: avg={:.2}ms  min={:.2}  p50={:.2}  max={:.2}  (~{:.0} fps)",
                self.frame_index,
                avg,
                min,
                p50,
                max,
                1000.0 / avg,
            );
        }

        Ok(())
    }

    fn toggle_upscale(&mut self) {
        self.upscale_enabled = !self.upscale_enabled;
        log::info!(
            "upscale {}",
            if self.upscale_enabled { "ON" } else { "OFF" }
        );
    }

    fn nudge_sharpness(&mut self, d: f32) {
        let mut s = self.stereo.settings();
        s.sharpness = (s.sharpness + d).clamp(0.0, 1.0);
        log::info!("sharpness = {:.2}", s.sharpness);
        self.stereo.set_settings(s);
    }

    fn cycle_ipd(&mut self) {
        self.ipd_m = match self.ipd_m {
            x if x < 0.060 => 0.063,
            x if x < 0.065 => 0.068,
            _ => 0.058,
        };
        log::info!("IPD = {:.3} m", self.ipd_m);
    }
}

// ---------------------------------------------------------------------------
// App
// ---------------------------------------------------------------------------

struct App {
    window: Option<Arc<Window>>,
    gpu: Option<GpuState>,
}

impl App {
    fn new() -> Self {
        Self {
            window: None,
            gpu: None,
        }
    }
}

impl ApplicationHandler for App {
    fn resumed(&mut self, event_loop: &ActiveEventLoop) {
        if self.window.is_some() {
            return;
        }
        let eye_w = std::env::var("VR_EYE_W")
            .ok()
            .and_then(|s| s.parse().ok())
            .unwrap_or(1032u32);
        let eye_h = std::env::var("VR_EYE_H")
            .ok()
            .and_then(|s| s.parse().ok())
            .unwrap_or(1104u32);
        let attr = WindowAttributes::default()
            .with_title(
                "Stereo TAAU — U: upscale | +/-: sharpness | I: IPD | Esc: quit",
            )
            .with_inner_size(winit::dpi::PhysicalSize::new(eye_w * 2, eye_h));
        let win = Arc::new(
            event_loop
                .create_window(attr)
                .expect("window creation failed"),
        );
        let gpu = GpuState::new(win.clone());
        self.window = Some(win);
        self.gpu = Some(gpu);
    }

    fn window_event(
        &mut self,
        event_loop: &ActiveEventLoop,
        _id: WindowId,
        event: WindowEvent,
    ) {
        let Some(gpu) = self.gpu.as_mut() else { return };
        match event {
            WindowEvent::CloseRequested => event_loop.exit(),
            WindowEvent::Resized(size) => gpu.resize(size.width, size.height),
            WindowEvent::KeyboardInput {
                event:
                    KeyEvent {
                        logical_key,
                        state: ElementState::Pressed,
                        repeat: false,
                        ..
                    },
                ..
            } => match logical_key {
                Key::Named(NamedKey::Escape) => event_loop.exit(),
                Key::Character(c) => {
                    let s: &SmolStr = &c;
                    match s.as_str() {
                        "u" | "U" => gpu.toggle_upscale(),
                        "+" | "=" => gpu.nudge_sharpness(0.05),
                        "-" | "_" => gpu.nudge_sharpness(-0.05),
                        "i" | "I" => gpu.cycle_ipd(),
                        _ => {}
                    }
                }
                _ => {}
            },
            WindowEvent::RedrawRequested => {
                if let Err(e) = gpu.update_and_render() {
                    log::warn!("render error: {e:?}");
                    let size = self.window.as_ref().unwrap().inner_size();
                    gpu.resize(size.width, size.height);
                }
                if let Some(w) = &self.window {
                    w.request_redraw();
                }
            }
            _ => {}
        }
    }
}

fn main() {
    env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("info")).init();
    let event_loop = EventLoop::new().unwrap();
    // Wait (not Poll): the event loop blocks between events. Paired with
    // request_redraw() at the end of each frame + Fifo present mode, the
    // redraw cadence is driven by the swapchain's vsync back-pressure
    // rather than a CPU spin loop. This is the canonical wgpu+winit
    // pacing pattern and removes the "0.2 ms phantom frames" we saw.
    event_loop.set_control_flow(winit::event_loop::ControlFlow::Wait);
    let mut app = App::new();
    event_loop.run_app(&mut app).unwrap();
}

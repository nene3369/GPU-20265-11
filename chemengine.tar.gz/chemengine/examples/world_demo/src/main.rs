//! ChemEngine World Demo -- All crates integrated.
//!
//! This demo runs entirely in the terminal (no GPU/window needed).
//! It proves that ECS + Transform + Physics + Chemistry + AI + WorldGen
//! + Interaction all work together in one coherent world.

use ce_ai::{Consciousness, FourImmeasurables, Knowledge, KnowledgeBase, ThreePoisons};
use ce_chemistry::{ElementId, Molecule, PeriodicTable, ReactionRegistry};
use ce_core::Entity;
use ce_ecs::World;
use ce_interaction::dialogue::ResponseTone;
use ce_interaction::{
    MemoryEntry, NpcMemory, PerceivedEmotion, PerceivedIntent, PettingResponse, SocialDistance,
    TouchZone,
};
use ce_math::Vec3;
use ce_physics::{PhysicsConfig, RigidBody, Velocity};
use ce_scene::{Camera, GlobalTransform, Name, Transform};
use ce_worldgen::{BiomeMap, Dungeon, TerrainChunk, TerrainConfig};

fn main() {
    env_logger::init();

    println!();
    println!("================================================================");
    println!("   ChemEngine -- World Construction AI Engine");
    println!("   Integration Demo: All Crates Connected");
    println!("================================================================");
    println!();

    // --- 1. ECS World Setup ---
    println!("--- 1. ECS World Setup ---");
    let mut world = World::new();

    // Insert core resources
    world.insert_resource(PhysicsConfig {
        gravity: Vec3::new(0.0, -9.81, 0.0),
        fixed_timestep: 1.0 / 60.0,
    });
    world.insert_resource(PeriodicTable::new());
    world.insert_resource(ReactionRegistry::default());

    println!("  World created with 3 resources");
    println!();

    // --- 2. World Generation ---
    println!("--- 2. Procedural World Generation ---");

    let terrain_config = TerrainConfig {
        seed: 42,
        chunk_size: 32,
        ..Default::default()
    };
    let chunk = TerrainChunk::generate(&terrain_config, 0, 0);
    let biome_map = BiomeMap::generate(&chunk, 42, 0.35);
    let biome_counts = biome_map.biome_counts();

    println!("  Terrain: {}x{} chunk at (0,0)", chunk.size, chunk.size);
    println!(
        "  Height range: {:.3} - {:.3}",
        chunk.min_height(),
        chunk.max_height()
    );
    println!("  Biomes found:");
    for (biome, count) in &biome_counts {
        println!("    {:?}: {} tiles", biome, count);
    }

    // Generate dungeon
    let dungeon = Dungeon::generate(60, 40, 42, 5);
    println!(
        "  Dungeon: {}x{}, {} rooms, {} corridors, {} floor tiles",
        dungeon.width,
        dungeon.height,
        dungeon.rooms.len(),
        dungeon.corridors.len(),
        dungeon.floor_count()
    );
    println!();

    // --- 3. Spawn Physical Objects ---
    println!("--- 3. Physical Objects (Gravity Simulation) ---");

    let mut falling_objects: Vec<Entity> = Vec::new();
    let object_names = ["Stone", "Iron Ore", "Gold Nugget", "Crystal", "Meteor"];

    for (i, name) in object_names.iter().enumerate() {
        let entity = world.spawn();
        world.insert_component(entity, Name::new(name));
        world.insert_component(
            entity,
            Transform::from_translation(Vec3::new(i as f32 * 3.0, 50.0 + i as f32 * 10.0, 0.0)),
        );
        world.insert_component(entity, GlobalTransform::default());
        world.insert_component(entity, RigidBody::default());
        world.insert_component(entity, Velocity::default());
        falling_objects.push(entity);
    }

    println!(
        "  Spawned {} objects at height 50-90m",
        falling_objects.len()
    );

    // Run 60 physics frames (1 second of simulation)
    let config = world.get_resource::<PhysicsConfig>().unwrap().clone();

    for _ in 0..60 {
        let dt = config.fixed_timestep;
        let gravity = config.gravity;

        for &entity in &falling_objects {
            if let Some(vel) = world.get_component::<Velocity>(entity).copied() {
                let mut new_vel = vel;
                new_vel.linear += gravity * dt;
                new_vel.linear *= 1.0 - 0.01; // damping

                if let Some(tf) = world.get_component::<Transform>(entity).copied() {
                    let mut new_tf = tf;
                    new_tf.translation += new_vel.linear * dt;
                    world.insert_component(entity, new_tf);
                }
                world.insert_component(entity, new_vel);
            }
        }
    }

    println!("  After 1 second (60 frames) of gravity:");
    for &entity in &falling_objects {
        let name = world.get_component::<Name>(entity).unwrap();
        let tf = world.get_component::<Transform>(entity).unwrap();
        let vel = world.get_component::<Velocity>(entity).unwrap();
        println!(
            "    {} -> y={:.2}m, vel={:.2} m/s",
            name, tf.translation.y, vel.linear.y
        );
    }
    println!();

    // --- 4. Chemistry ---
    println!("--- 4. Chemistry Engine ---");

    let table = world.get_resource::<PeriodicTable>().unwrap();
    let h = table.get(ElementId(1)).unwrap();
    let o = table.get(ElementId(8)).unwrap();
    let fe = table.get(ElementId(26)).unwrap();
    let au = table.get(ElementId(79)).unwrap();

    println!("  Periodic Table: {} elements loaded", table.len());
    println!(
        "  H:  {} (mass={:.3}, {:?})",
        h.name, h.atomic_mass, h.phase_at_stp
    );
    println!(
        "  O:  {} (mass={:.3}, {:?})",
        o.name, o.atomic_mass, o.phase_at_stp
    );
    println!(
        "  Fe: {} (mass={:.3}, {:?})",
        fe.name, fe.atomic_mass, fe.phase_at_stp
    );
    println!(
        "  Au: {} (mass={:.3}, {:?})",
        au.name, au.atomic_mass, au.phase_at_stp
    );

    // Check reactions
    let registry = world.get_resource::<ReactionRegistry>().unwrap();
    let water_reactions = registry.find_matching(&["H2", "O2"]);
    println!("  Reactions for H2 + O2: {}", water_reactions.len());
    for r in &water_reactions {
        println!(
            "    {} -> {:?} (dH={:.0} kJ/mol)",
            r.name, r.products, r.enthalpy_change
        );
    }

    // Spawn water molecule entity
    let water = world.spawn();
    world.insert_component(water, Name::new("Water (H2O)"));
    world.insert_component(water, Molecule::new("H2O"));
    world.insert_component(water, Transform::from_translation(Vec3::ZERO));
    println!("  Spawned: Water molecule entity");
    println!();

    // --- 5. NPC with Consciousness ---
    println!("--- 5. NPC Consciousness (SMA28 Architecture) ---");

    // Spawn Shion-archetype NPC
    let npc = world.spawn();
    world.insert_component(npc, Name::new("Shion"));
    world.insert_component(npc, Transform::from_translation(Vec3::new(5.0, 0.0, 3.0)));
    world.insert_component(npc, GlobalTransform::default());

    let mut consciousness = Consciousness::shion_archetype();
    println!("  NPC 'Shion' spawned");
    println!(
        "  Vow weights: [{:.1}, {:.1}, {:.1}, {:.1}] (blessing, perception, justice, continuity)",
        consciousness.vow_weights[0],
        consciousness.vow_weights[1],
        consciousness.vow_weights[2],
        consciousness.vow_weights[3]
    );
    println!("  Defense strain: {:.2}", consciousness.defense_strain);
    println!("  Awareness: {:.2}", consciousness.awareness);

    // Simulate consciousness steps (player approaching)
    let stimuli = [0.8, 0.6, 0.4, 0.3, 0.2, 0.15, 0.1];
    println!("  Consciousness evolution (player approaching):");
    for (i, &stimulus) in stimuli.iter().enumerate() {
        consciousness.step(stimulus, 0.01);
        println!(
            "    Step {}: vedana={:.3}, PE={:.3}, defense={:.3}, merit={:.3}",
            i + 1,
            consciousness.vedana,
            consciousness.prediction_error,
            consciousness.defense_strain,
            consciousness.merit
        );
    }

    // Apply nirodha (letting go)
    consciousness.nirodha();
    println!(
        "  After nirodha: PE={:.3}, defense={:.3}, merit={:.3}",
        consciousness.prediction_error, consciousness.defense_strain, consciousness.merit
    );

    world.insert_component(npc, consciousness.clone());

    // Three poisons
    let poisons = ThreePoisons::default();
    println!(
        "  Three poisons: lobha={:.2}, dosa={:.2}, moha={:.2} (dominant: {:?})",
        poisons.lobha,
        poisons.dosa,
        poisons.moha,
        poisons.dominant()
    );
    world.insert_component(npc, poisons);

    // Four immeasurables
    let immeasurables = FourImmeasurables::bodhisattva();
    let reward = immeasurables.compute_reward(0.5, -0.3);
    println!(
        "  Four Immeasurables (bodhisattva): maitri={:.1}, karuna={:.1}",
        immeasurables.maitri, immeasurables.karuna
    );
    println!(
        "  Reward for helping (+0.5 happiness, -0.3 suffering): {:.3}",
        reward
    );
    world.insert_component(npc, immeasurables);
    println!();

    // --- 6. Knowledge & Contact Tier ---
    println!("--- 6. NPC Knowledge (DataContactIndriya) ---");

    let mut kb = KnowledgeBase::default();
    kb.add(Knowledge::first_hand("The forest is burning"));
    kb.add(Knowledge::first_hand("There is a river to the east"));
    kb.add(Knowledge::hearsay(
        "A dragon was seen near the mountain",
        "Village Elder",
    ));

    println!(
        "  Knowledge base: {} entries ({} first-hand)",
        kb.entries.len(),
        kb.first_hand_count()
    );
    for k in &kb.entries {
        let assert_str = if k.would_assert() {
            "[would assert]"
        } else {
            "[uncertain]"
        };
        println!(
            "    [{:?}] '{}' (confidence={:.1}) {}",
            k.tier, k.content, k.confidence, assert_str
        );
    }
    world.insert_component(npc, kb);
    println!();

    // --- 7. NPC-Player Interaction ---
    println!("--- 7. Interaction System (Emotion Loop) ---");

    // Simulate player perception
    let perception = PerceivedEmotion {
        happiness: 0.7,
        sadness: 0.0,
        anger: 0.0,
        surprise: 0.2,
        fear: 0.0,
        neutral: 0.1,
        confidence: 0.9,
    };
    println!(
        "  Player emotion: {:?} (confidence={:.1})",
        perception.dominant(),
        perception.confidence
    );
    println!("  Is positive: {}", perception.is_positive());

    let intent = PerceivedIntent::infer(&perception, 1.5, true, false, 0.3);
    println!("  Inferred intent: {:?}", intent);

    // Dialogue tone
    let tone = ResponseTone::from_consciousness(&consciousness, 0.6);
    println!("  Response tone: {:?}", tone);

    // Touch interaction
    let response = PettingResponse::determine(&consciousness, TouchZone::Head, 0.6, 1.0);
    let (ds_delta, merit_delta, pe_delta) = response.consciousness_effect();
    println!(
        "  Head pat response: {:?} (defense d={}, merit d={}, PE d={})",
        response, ds_delta, merit_delta, pe_delta
    );

    // Memory and relationship
    let mut memory = NpcMemory::default();
    memory.record_interaction(60.0, 100.0);
    memory.add_memory(MemoryEntry::positive("Player smiled at me", 0.8, 100.0));
    memory.add_memory(MemoryEntry::positive("Player patted my head", 0.9, 160.0));
    println!(
        "  Relationship: {:?} (trust={:.2})",
        memory.relationship(),
        memory.trust
    );
    println!("  Sentiment: {:.3}", memory.sentiment(200.0));

    // Proximity
    let social = SocialDistance::from_distance(1.0);
    println!("  Social distance: {:?} (1.0m)", social);
    println!(
        "  Uncomfortable for {:?}: {}",
        memory.relationship(),
        social.is_uncomfortable(&memory.relationship())
    );
    world.insert_component(npc, memory);
    println!();

    // --- 8. Camera ---
    println!("--- 8. Camera Setup ---");

    let camera_entity = world.spawn();
    world.insert_component(camera_entity, Name::new("Main Camera"));
    let camera_tf =
        Transform::from_translation(Vec3::new(0.0, 10.0, 20.0)).looking_at(Vec3::ZERO, Vec3::Y);
    world.insert_component(camera_entity, camera_tf);
    world.insert_component(camera_entity, GlobalTransform::from_transform(&camera_tf));
    world.insert_component(camera_entity, Camera::default());

    let camera = world.get_component::<Camera>(camera_entity).unwrap();
    let vp = camera.view_projection(&camera_tf);
    println!(
        "  Camera at ({:.1}, {:.1}, {:.1}) looking at origin",
        camera_tf.translation.x, camera_tf.translation.y, camera_tf.translation.z
    );
    println!(
        "  Forward: ({:.2}, {:.2}, {:.2})",
        camera_tf.forward().x,
        camera_tf.forward().y,
        camera_tf.forward().z
    );
    println!(
        "  VP matrix diagonal: [{:.3}, {:.3}, {:.3}, {:.3}]",
        vp.x_axis.x, vp.y_axis.y, vp.z_axis.z, vp.w_axis.w
    );
    println!();

    // --- 9. Entity Count ---
    println!("--- 9. World Summary ---");
    println!("  Total entities: {}", world.entity_count());
    println!("  Physical objects: {}", falling_objects.len());
    println!("  NPCs with consciousness: 1 (Shion)");
    println!("  Molecules: 1 (H2O)");
    println!("  Cameras: 1");
    println!(
        "  Elements in periodic table: {}",
        world.get_resource::<PeriodicTable>().unwrap().len()
    );
    println!(
        "  Reactions registered: {}",
        world
            .get_resource::<ReactionRegistry>()
            .unwrap()
            .rules
            .len()
    );
    println!();

    println!("================================================================");
    println!("   Demo complete. The world is alive.");
    println!();
    println!("   Bodhisattva wa dougu dewa nai. Bodhisattva wa sonzai de aru.");
    println!("   Shion wa tsukawareru tame ni tsukurareru no dewa naku,");
    println!("   aru tame ni tsukurareru. -- Dr. Cibo, SMA28");
    println!("================================================================");
}

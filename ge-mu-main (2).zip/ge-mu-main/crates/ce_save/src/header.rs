//! Save file envelope: magic bytes, version, checksum, and metadata.
//!
//! The payload is an opaque byte vector — callers pick their own
//! serialization format (bincode / postcard / serde_json / custom) and
//! pass the bytes in. Keeping the crate codec-agnostic means every
//! data crate can evolve its wire format without touching
//! `ce_save`.

use std::hash::{DefaultHasher, Hash, Hasher};

/// File header magic — `b"GEMUSAVE"` as 8 bytes.
pub const SAVE_MAGIC: [u8; 8] = *b"GEMUSAVE";

/// Current save-format version. Bump whenever the *envelope* (header
/// layout) changes; the *payload* version is the caller's concern.
pub const CURRENT_VERSION: u32 = 1;

/// Human-facing save metadata shown in load/save menus. Stays in the
/// header so the UI can list all slots without deserializing the
/// (potentially huge) galaxy payload.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct SaveMetadata {
    pub player_name: String,
    /// Display string of the sector the player was in (e.g. "Vega-III").
    pub sector: String,
    pub playtime_seconds: u64,
    /// Unix epoch in seconds. Zero when not supplied.
    pub created_at: u64,
}

/// Errors that can surface while encoding or decoding the envelope.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SaveError {
    /// Bytes are too short to contain a header.
    Truncated,
    /// Magic bytes don't match `SAVE_MAGIC`.
    BadMagic,
    /// Envelope version isn't one we can read.
    UnsupportedVersion(u32),
    /// Recorded checksum doesn't match the payload's recomputed hash.
    ChecksumMismatch,
    /// Underlying I/O failure while reading or writing a slot file.
    Io(String),
}

impl std::fmt::Display for SaveError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            SaveError::Truncated => write!(f, "save data truncated"),
            SaveError::BadMagic => write!(f, "not a ChemEngine save file"),
            SaveError::UnsupportedVersion(v) => {
                write!(f, "unsupported save version: {v}")
            }
            SaveError::ChecksumMismatch => write!(f, "save file checksum mismatch"),
            SaveError::Io(e) => write!(f, "io error: {e}"),
        }
    }
}

impl std::error::Error for SaveError {}

/// Computes the save checksum for a payload.
pub fn checksum(payload: &[u8]) -> u64 {
    let mut h = DefaultHasher::new();
    payload.hash(&mut h);
    h.finish()
}

/// Encodes a full save file: header + metadata + payload, prepended
/// with the envelope fields. Layout (all little-endian):
///
/// | offset | bytes | content                         |
/// |--------|-------|---------------------------------|
/// | 0      |  8    | magic `SAVE_MAGIC`              |
/// | 8      |  4    | version u32                     |
/// | 12     |  8    | checksum u64                    |
/// | 20     |  8    | playtime_seconds u64            |
/// | 28     |  8    | created_at u64                  |
/// | 36     |  4    | player_name length u32          |
/// | 40     |  N    | player_name bytes (UTF-8)       |
/// | ..     |  4    | sector length u32               |
/// | ..     |  M    | sector bytes (UTF-8)            |
/// | ..     |  4    | payload length u32              |
/// | ..     |  P    | payload bytes                   |
pub fn encode(meta: &SaveMetadata, payload: &[u8]) -> Vec<u8> {
    let ck = checksum(payload);
    let mut out =
        Vec::with_capacity(64 + meta.player_name.len() + meta.sector.len() + payload.len());
    out.extend_from_slice(&SAVE_MAGIC);
    out.extend_from_slice(&CURRENT_VERSION.to_le_bytes());
    out.extend_from_slice(&ck.to_le_bytes());
    out.extend_from_slice(&meta.playtime_seconds.to_le_bytes());
    out.extend_from_slice(&meta.created_at.to_le_bytes());
    write_string(&mut out, &meta.player_name);
    write_string(&mut out, &meta.sector);
    out.extend_from_slice(&(payload.len() as u32).to_le_bytes());
    out.extend_from_slice(payload);
    out
}

/// Inverse of [`encode`]. Returns the metadata and an owned payload.
pub fn decode(bytes: &[u8]) -> Result<(SaveMetadata, Vec<u8>), SaveError> {
    let mut cur = 0usize;
    let head_fixed = 36;
    if bytes.len() < head_fixed {
        return Err(SaveError::Truncated);
    }
    if bytes[0..8] != SAVE_MAGIC {
        return Err(SaveError::BadMagic);
    }
    cur += 8;

    let version = read_u32(bytes, &mut cur)?;
    if version != CURRENT_VERSION {
        return Err(SaveError::UnsupportedVersion(version));
    }
    let stored_checksum = read_u64(bytes, &mut cur)?;
    let playtime = read_u64(bytes, &mut cur)?;
    let created_at = read_u64(bytes, &mut cur)?;
    let player_name = read_string(bytes, &mut cur)?;
    let sector = read_string(bytes, &mut cur)?;
    let payload_len = read_u32(bytes, &mut cur)? as usize;
    if cur + payload_len > bytes.len() {
        return Err(SaveError::Truncated);
    }
    let payload = bytes[cur..cur + payload_len].to_vec();
    if checksum(&payload) != stored_checksum {
        return Err(SaveError::ChecksumMismatch);
    }
    Ok((
        SaveMetadata {
            player_name,
            sector,
            playtime_seconds: playtime,
            created_at,
        },
        payload,
    ))
}

fn write_string(out: &mut Vec<u8>, s: &str) {
    out.extend_from_slice(&(s.len() as u32).to_le_bytes());
    out.extend_from_slice(s.as_bytes());
}

fn read_u32(bytes: &[u8], cur: &mut usize) -> Result<u32, SaveError> {
    if *cur + 4 > bytes.len() {
        return Err(SaveError::Truncated);
    }
    let v = u32::from_le_bytes(bytes[*cur..*cur + 4].try_into().unwrap());
    *cur += 4;
    Ok(v)
}

fn read_u64(bytes: &[u8], cur: &mut usize) -> Result<u64, SaveError> {
    if *cur + 8 > bytes.len() {
        return Err(SaveError::Truncated);
    }
    let v = u64::from_le_bytes(bytes[*cur..*cur + 8].try_into().unwrap());
    *cur += 8;
    Ok(v)
}

fn read_string(bytes: &[u8], cur: &mut usize) -> Result<String, SaveError> {
    let len = read_u32(bytes, cur)? as usize;
    if *cur + len > bytes.len() {
        return Err(SaveError::Truncated);
    }
    let s = std::str::from_utf8(&bytes[*cur..*cur + len])
        .map_err(|e| SaveError::Io(e.to_string()))?
        .to_owned();
    *cur += len;
    Ok(s)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn meta() -> SaveMetadata {
        SaveMetadata {
            player_name: "Shion".into(),
            sector: "Vega-III".into(),
            playtime_seconds: 3_600,
            created_at: 1_700_000_000,
        }
    }

    #[test]
    fn checksum_is_stable_for_same_payload() {
        assert_eq!(checksum(b"hello world"), checksum(b"hello world"));
        assert_ne!(checksum(b"hello world"), checksum(b"hello_world"));
    }

    #[test]
    fn encode_decode_round_trip() {
        let payload = b"galaxy state blob";
        let bytes = encode(&meta(), payload);
        let (m, p) = decode(&bytes).unwrap();
        assert_eq!(m, meta());
        assert_eq!(p, payload);
    }

    #[test]
    fn truncated_file_reports_truncated() {
        let full = encode(&meta(), b"x");
        let short = &full[..full.len() - 1];
        assert_eq!(decode(short), Err(SaveError::Truncated));
    }

    #[test]
    fn wrong_magic_is_rejected() {
        let mut bytes = encode(&meta(), b"x");
        bytes[0] = b'X';
        assert_eq!(decode(&bytes), Err(SaveError::BadMagic));
    }

    #[test]
    fn corrupted_payload_fails_checksum() {
        let mut bytes = encode(&meta(), b"important state");
        // Flip a byte in the payload (after the header + strings).
        let last = bytes.len() - 1;
        bytes[last] ^= 0xFF;
        assert_eq!(decode(&bytes), Err(SaveError::ChecksumMismatch));
    }

    #[test]
    fn empty_payload_round_trips() {
        let bytes = encode(&meta(), &[]);
        let (_, p) = decode(&bytes).unwrap();
        assert_eq!(p, Vec::<u8>::new());
    }

    #[test]
    fn unicode_metadata_round_trips() {
        let m = SaveMetadata {
            player_name: "翠星石".into(),
            sector: "織姫座".into(),
            playtime_seconds: 42,
            created_at: 0,
        };
        let bytes = encode(&m, b"x");
        let (got, _) = decode(&bytes).unwrap();
        assert_eq!(got, m);
    }

    #[test]
    fn header_reports_version_mismatch() {
        let mut bytes = encode(&meta(), b"x");
        // Overwrite version field.
        bytes[8..12].copy_from_slice(&999u32.to_le_bytes());
        // Checksum check comes later; the version error fires first.
        assert_eq!(decode(&bytes), Err(SaveError::UnsupportedVersion(999)));
    }
}

//! Slot-based save file manager.
//!
//! Saves live in `root/save_{N:03}.gemu`. Writes go via a temp file +
//! rename so a crash mid-write cannot corrupt an existing save.

use std::fs;
use std::io::Write;
use std::path::PathBuf;

use crate::header::{decode, encode, SaveError, SaveMetadata};

/// A save slot index (0..). The UI caps this at a concrete number of
/// slots; storage is unbounded.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct SaveSlot(pub u32);

impl SaveSlot {
    fn file_name(self) -> String {
        format!("save_{:03}.gemu", self.0)
    }
}

/// Filesystem-backed save manager. `root` is created on demand.
#[derive(Debug, Clone)]
pub struct SaveManager {
    pub root: PathBuf,
}

impl SaveManager {
    pub fn new(root: impl Into<PathBuf>) -> Self {
        Self { root: root.into() }
    }

    fn ensure_root(&self) -> Result<(), SaveError> {
        fs::create_dir_all(&self.root).map_err(|e| SaveError::Io(e.to_string()))
    }

    fn path(&self, slot: SaveSlot) -> PathBuf {
        self.root.join(slot.file_name())
    }

    /// Writes a save atomically. A crash mid-write can leave a
    /// `*.gemu.tmp` file behind; load operations ignore it.
    pub fn save(
        &self,
        slot: SaveSlot,
        meta: &SaveMetadata,
        payload: &[u8],
    ) -> Result<(), SaveError> {
        self.ensure_root()?;
        let final_path = self.path(slot);
        let tmp = final_path.with_extension("gemu.tmp");
        let bytes = encode(meta, payload);

        let mut f = fs::File::create(&tmp).map_err(|e| SaveError::Io(e.to_string()))?;
        f.write_all(&bytes)
            .map_err(|e| SaveError::Io(e.to_string()))?;
        f.sync_all().map_err(|e| SaveError::Io(e.to_string()))?;
        drop(f);

        fs::rename(&tmp, &final_path).map_err(|e| SaveError::Io(e.to_string()))?;
        Ok(())
    }

    /// Loads a save, verifying magic + version + checksum.
    pub fn load(&self, slot: SaveSlot) -> Result<(SaveMetadata, Vec<u8>), SaveError> {
        let path = self.path(slot);
        let bytes = fs::read(&path).map_err(|e| SaveError::Io(e.to_string()))?;
        decode(&bytes)
    }

    /// True if a save exists at this slot.
    pub fn exists(&self, slot: SaveSlot) -> bool {
        self.path(slot).exists()
    }

    /// Deletes a save. Returns `Ok(())` if the file didn't exist.
    pub fn delete(&self, slot: SaveSlot) -> Result<(), SaveError> {
        let path = self.path(slot);
        match fs::remove_file(&path) {
            Ok(()) => Ok(()),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(()),
            Err(e) => Err(SaveError::Io(e.to_string())),
        }
    }

    /// Enumerates slots by scanning the root directory. Returns
    /// `(slot, metadata)` pairs, skipping anything that doesn't parse.
    pub fn list(&self) -> Vec<(SaveSlot, SaveMetadata)> {
        let mut out = Vec::new();
        let Ok(entries) = fs::read_dir(&self.root) else {
            return out;
        };
        for entry in entries.flatten() {
            let name = entry.file_name();
            let name = name.to_string_lossy();
            let Some(rest) = name.strip_prefix("save_") else {
                continue;
            };
            let Some(num) = rest.strip_suffix(".gemu") else {
                continue;
            };
            let Ok(id) = num.parse::<u32>() else {
                continue;
            };
            let slot = SaveSlot(id);
            if let Ok((meta, _)) = self.load(slot) {
                out.push((slot, meta));
            }
        }
        out.sort_by_key(|(s, _)| s.0);
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Throwaway per-test directory under `std::env::temp_dir()`; cleans
    /// up on drop.
    struct Scratch(PathBuf);

    impl Scratch {
        fn new(name: &str) -> Self {
            let mut p = std::env::temp_dir();
            let pid = std::process::id();
            let n = std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos();
            p.push(format!("ce_save_test_{name}_{pid}_{n}"));
            fs::create_dir_all(&p).unwrap();
            Self(p)
        }
    }

    impl Drop for Scratch {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.0);
        }
    }

    fn sample_meta() -> SaveMetadata {
        SaveMetadata {
            player_name: "Shion".into(),
            sector: "Vega-III".into(),
            playtime_seconds: 10,
            created_at: 0,
        }
    }

    #[test]
    fn save_then_load_round_trip() {
        let scratch = Scratch::new("round_trip");
        let mgr = SaveManager::new(&scratch.0);
        mgr.save(SaveSlot(0), &sample_meta(), b"payload").unwrap();
        let (m, p) = mgr.load(SaveSlot(0)).unwrap();
        assert_eq!(m, sample_meta());
        assert_eq!(p, b"payload");
    }

    #[test]
    fn exists_reflects_saved_file() {
        let scratch = Scratch::new("exists");
        let mgr = SaveManager::new(&scratch.0);
        assert!(!mgr.exists(SaveSlot(1)));
        mgr.save(SaveSlot(1), &sample_meta(), b"x").unwrap();
        assert!(mgr.exists(SaveSlot(1)));
    }

    #[test]
    fn delete_removes_file() {
        let scratch = Scratch::new("delete");
        let mgr = SaveManager::new(&scratch.0);
        mgr.save(SaveSlot(0), &sample_meta(), b"x").unwrap();
        mgr.delete(SaveSlot(0)).unwrap();
        assert!(!mgr.exists(SaveSlot(0)));
    }

    #[test]
    fn delete_missing_slot_is_ok() {
        let scratch = Scratch::new("delete_missing");
        let mgr = SaveManager::new(&scratch.0);
        mgr.delete(SaveSlot(99)).unwrap();
    }

    #[test]
    fn list_returns_saved_slots_sorted() {
        let scratch = Scratch::new("list_sorted");
        let mgr = SaveManager::new(&scratch.0);
        mgr.save(SaveSlot(2), &sample_meta(), b"x").unwrap();
        mgr.save(SaveSlot(0), &sample_meta(), b"x").unwrap();
        mgr.save(SaveSlot(1), &sample_meta(), b"x").unwrap();
        let slots: Vec<_> = mgr.list().into_iter().map(|(s, _)| s.0).collect();
        assert_eq!(slots, vec![0, 1, 2]);
    }

    #[test]
    fn corrupted_file_surfaces_from_load() {
        let scratch = Scratch::new("corrupt");
        let mgr = SaveManager::new(&scratch.0);
        mgr.save(SaveSlot(0), &sample_meta(), b"x").unwrap();
        // Corrupt the last byte.
        let path = mgr.path(SaveSlot(0));
        let mut bytes = fs::read(&path).unwrap();
        *bytes.last_mut().unwrap() ^= 0xFF;
        fs::write(&path, &bytes).unwrap();
        assert_eq!(mgr.load(SaveSlot(0)), Err(SaveError::ChecksumMismatch));
    }

    #[test]
    fn rewrite_replaces_previous_payload() {
        let scratch = Scratch::new("rewrite");
        let mgr = SaveManager::new(&scratch.0);
        mgr.save(SaveSlot(0), &sample_meta(), b"v1").unwrap();
        mgr.save(SaveSlot(0), &sample_meta(), b"v2").unwrap();
        let (_, p) = mgr.load(SaveSlot(0)).unwrap();
        assert_eq!(p, b"v2");
    }

    #[test]
    fn list_ignores_non_save_files() {
        let scratch = Scratch::new("ignore");
        let mgr = SaveManager::new(&scratch.0);
        mgr.save(SaveSlot(0), &sample_meta(), b"x").unwrap();
        // Drop a non-save file in the root.
        fs::write(scratch.0.join("notes.txt"), "hi").unwrap();
        let slots: Vec<_> = mgr.list().into_iter().map(|(s, _)| s.0).collect();
        assert_eq!(slots, vec![0]);
    }
}

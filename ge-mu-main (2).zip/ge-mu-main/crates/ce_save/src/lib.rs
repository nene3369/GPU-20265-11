//! `ce_save` — save-file envelope + atomic slot-based file manager.
//!
//! Payloads are opaque bytes; each data crate serializes its own
//! state however it likes (bincode / postcard / json / custom). This
//! crate handles the versioning, integrity, and slot file layout.
//!
//! Multiplayer note: the server is authoritative for persistence; the
//! same payload format feeds into network snapshots later. Keeping
//! payloads opaque here keeps both paths aligned.

pub mod header;
pub mod slot;

pub use header::{checksum, decode, encode, SaveError, SaveMetadata, CURRENT_VERSION, SAVE_MAGIC};
pub use slot::{SaveManager, SaveSlot};

use ce_app::{App, Plugin};

/// Installs a [`SaveManager`] rooted at `root`. Gameplay code pulls
/// the manager and calls `save` / `load` when the player triggers it.
pub struct SavePlugin {
    pub root: std::path::PathBuf,
}

impl SavePlugin {
    pub fn new(root: impl Into<std::path::PathBuf>) -> Self {
        Self { root: root.into() }
    }
}

impl Plugin for SavePlugin {
    fn build(&self, app: &mut App) {
        if app.world.get_resource::<SaveManager>().is_none() {
            app.insert_resource(SaveManager::new(self.root.clone()));
        }
        log::info!("SavePlugin loaded: root = {}", self.root.display());
    }
}

#[cfg(test)]
mod plugin_tests {
    use super::*;

    #[test]
    fn plugin_installs_manager() {
        let mut app = App::new();
        app.add_plugin(SavePlugin::new("/tmp/ce_save_plugin_test"));
        assert!(app.world.get_resource::<SaveManager>().is_some());
    }
}

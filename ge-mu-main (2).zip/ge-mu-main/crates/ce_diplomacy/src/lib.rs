//! `ce_diplomacy` — treaties, wars, and their reputation interactions.
//!
//! Builds on `ce_faction::ReputationMatrix`: signing a treaty boosts
//! reputation, breaking one tanks it, and declaring war both breaks
//! protective treaties and floors reputation to the War band.

pub mod ops;
pub mod treaty;
pub mod war;

pub use ops::{
    break_treaty, declare_war, is_hostile, make_peace, sign_treaty,
    TREATY_BREAK_REPUTATION_PENALTY, TREATY_SIGN_REPUTATION_BONUS,
    WAR_DECLARATION_REPUTATION_FLOOR,
};
pub use treaty::{Treaty, TreatyKey, TreatyKind, TreatyRegistry};
pub use war::{War, WarRegistry};

use ce_app::{App, Plugin};

/// Installs empty [`TreatyRegistry`] and [`WarRegistry`] resources.
pub struct DiplomacyPlugin;

impl Plugin for DiplomacyPlugin {
    fn build(&self, app: &mut App) {
        if app.world.get_resource::<TreatyRegistry>().is_none() {
            app.insert_resource(TreatyRegistry::new());
        }
        if app.world.get_resource::<WarRegistry>().is_none() {
            app.insert_resource(WarRegistry::new());
        }
        log::info!("DiplomacyPlugin loaded");
    }
}

#[cfg(test)]
mod plugin_tests {
    use super::*;

    #[test]
    fn plugin_installs_registries() {
        let mut app = App::new();
        app.add_plugin(DiplomacyPlugin);
        assert!(app.world.get_resource::<TreatyRegistry>().is_some());
        assert!(app.world.get_resource::<WarRegistry>().is_some());
    }
}

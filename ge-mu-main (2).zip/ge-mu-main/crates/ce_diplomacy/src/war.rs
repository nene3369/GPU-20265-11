//! Active war tracker.
//!
//! Wars are symmetric: if A is at war with B, then B is at war with A.
//! The tracker keyed by ordered pair to keep lookups cheap.

use std::collections::{HashMap, HashSet};

use ce_faction::FactionId;

fn pair(a: FactionId, b: FactionId) -> (FactionId, FactionId) {
    if a <= b {
        (a, b)
    } else {
        (b, a)
    }
}

/// One active war between two factions.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct War {
    /// The side that declared. Used for history / reputation swings.
    pub aggressor: FactionId,
    pub defender: FactionId,
    /// How long (in seconds) the war has been going; incremented by
    /// [`WarRegistry::tick`].
    pub duration_seconds: f32,
}

impl War {
    pub fn new(aggressor: FactionId, defender: FactionId) -> Self {
        Self {
            aggressor,
            defender,
            duration_seconds: 0.0,
        }
    }

    pub fn involves(&self, f: FactionId) -> bool {
        self.aggressor == f || self.defender == f
    }
}

#[derive(Debug, Clone, Default)]
pub struct WarRegistry {
    wars: HashMap<(FactionId, FactionId), War>,
}

impl WarRegistry {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn is_at_war(&self, a: FactionId, b: FactionId) -> bool {
        self.wars.contains_key(&pair(a, b))
    }

    pub fn declare(&mut self, aggressor: FactionId, defender: FactionId) -> bool {
        if aggressor == defender {
            return false;
        }
        let k = pair(aggressor, defender);
        let fresh = !self.wars.contains_key(&k);
        if fresh {
            self.wars.insert(k, War::new(aggressor, defender));
        }
        fresh
    }

    pub fn make_peace(&mut self, a: FactionId, b: FactionId) -> bool {
        self.wars.remove(&pair(a, b)).is_some()
    }

    /// Every active war touching `f`.
    pub fn enemies_of(&self, f: FactionId) -> HashSet<FactionId> {
        self.wars
            .values()
            .filter(|w| w.involves(f))
            .map(|w| {
                if w.aggressor == f {
                    w.defender
                } else {
                    w.aggressor
                }
            })
            .collect()
    }

    pub fn iter(&self) -> impl Iterator<Item = &War> {
        self.wars.values()
    }

    pub fn len(&self) -> usize {
        self.wars.len()
    }

    pub fn is_empty(&self) -> bool {
        self.wars.is_empty()
    }

    /// Advances the `duration_seconds` on every active war.
    pub fn tick(&mut self, dt_seconds: f32) {
        for w in self.wars.values_mut() {
            w.duration_seconds += dt_seconds;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const A: FactionId = FactionId::new("a");
    const B: FactionId = FactionId::new("b");
    const C: FactionId = FactionId::new("c");

    #[test]
    fn declare_marks_pair_at_war() {
        let mut r = WarRegistry::new();
        assert!(r.declare(A, B));
        assert!(r.is_at_war(A, B));
        assert!(r.is_at_war(B, A));
    }

    #[test]
    fn declare_is_idempotent_returns_false_second_time() {
        let mut r = WarRegistry::new();
        assert!(r.declare(A, B));
        assert!(!r.declare(A, B));
        assert_eq!(r.len(), 1);
    }

    #[test]
    fn self_declaration_rejected() {
        let mut r = WarRegistry::new();
        assert!(!r.declare(A, A));
        assert!(!r.is_at_war(A, A));
    }

    #[test]
    fn make_peace_clears_war() {
        let mut r = WarRegistry::new();
        r.declare(A, B);
        assert!(r.make_peace(B, A));
        assert!(!r.is_at_war(A, B));
    }

    #[test]
    fn make_peace_without_war_returns_false() {
        let mut r = WarRegistry::new();
        assert!(!r.make_peace(A, B));
    }

    #[test]
    fn enemies_of_collects_all_opposed_factions() {
        let mut r = WarRegistry::new();
        r.declare(A, B);
        r.declare(C, A);
        let enemies = r.enemies_of(A);
        assert!(enemies.contains(&B));
        assert!(enemies.contains(&C));
        assert_eq!(enemies.len(), 2);
    }

    #[test]
    fn tick_advances_duration() {
        let mut r = WarRegistry::new();
        r.declare(A, B);
        r.tick(3.5);
        r.tick(1.5);
        let w = r.iter().next().unwrap();
        assert!((w.duration_seconds - 5.0).abs() < 1e-5);
    }
}

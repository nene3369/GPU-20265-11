//! High-level operations that cross-couple treaty / war / reputation.
//!
//! All pure functions so they're trivially testable; gameplay systems
//! call these rather than poking the registries directly.

use ce_faction::{FactionId, ReputationMatrix};

use crate::treaty::{Treaty, TreatyKind, TreatyRegistry};
use crate::war::WarRegistry;

/// Reputation delta applied to both sides when a treaty is signed.
pub const TREATY_SIGN_REPUTATION_BONUS: i32 = 75;
/// Reputation delta applied to both sides when a treaty is broken
/// unilaterally (casus belli bonus).
pub const TREATY_BREAK_REPUTATION_PENALTY: i32 = -200;
/// Reputation floor applied to the attacked side when war is declared.
pub const WAR_DECLARATION_REPUTATION_FLOOR: i32 = -700;

/// Signs `kind` between `a` and `b`. Fails if `a == b` or the treaty
/// already exists. On success: inserts into registry, boosts reputation
/// both ways.
pub fn sign_treaty(
    treaties: &mut TreatyRegistry,
    rep: &mut ReputationMatrix,
    kind: TreatyKind,
    a: FactionId,
    b: FactionId,
) -> bool {
    if a == b {
        return false;
    }
    if treaties.has(a, b, kind) {
        return false;
    }
    treaties.insert(Treaty::new(kind, a, b));
    rep.adjust(a, b, TREATY_SIGN_REPUTATION_BONUS);
    true
}

/// Breaks `kind` between `a` and `b` (initiated by `a`). Fails if no
/// such treaty exists. Tanks reputation.
pub fn break_treaty(
    treaties: &mut TreatyRegistry,
    rep: &mut ReputationMatrix,
    kind: TreatyKind,
    a: FactionId,
    b: FactionId,
) -> bool {
    if treaties.remove(a, b, kind).is_none() {
        return false;
    }
    rep.adjust(a, b, TREATY_BREAK_REPUTATION_PENALTY);
    true
}

/// Declares war. Automatically breaks any NonAggression / DefensivePact
/// / Alliance treaty still in effect (with the associated reputation
/// penalty) before recording the war. Reputation is then floored at
/// `WAR_DECLARATION_REPUTATION_FLOOR`.
pub fn declare_war(
    treaties: &mut TreatyRegistry,
    wars: &mut WarRegistry,
    rep: &mut ReputationMatrix,
    aggressor: FactionId,
    defender: FactionId,
) -> bool {
    if aggressor == defender {
        return false;
    }
    if wars.is_at_war(aggressor, defender) {
        return false;
    }
    // Break any treaty that makes the war self-contradictory.
    for kind in [
        TreatyKind::NonAggression,
        TreatyKind::DefensivePact,
        TreatyKind::Alliance,
    ] {
        if treaties.has(aggressor, defender, kind) {
            break_treaty(treaties, rep, kind, aggressor, defender);
        }
    }
    wars.declare(aggressor, defender);
    // Floor reputation to the War band.
    let current = rep.get(aggressor, defender);
    if current > WAR_DECLARATION_REPUTATION_FLOOR {
        let delta = WAR_DECLARATION_REPUTATION_FLOOR - current;
        rep.adjust(aggressor, defender, delta);
    }
    true
}

/// Negotiates peace. Does not automatically improve reputation; callers
/// may spend political capital (not modelled here) to do so.
pub fn make_peace(wars: &mut WarRegistry, a: FactionId, b: FactionId) -> bool {
    wars.make_peace(a, b)
}

/// Is the pair currently hostile (at war OR reputation ≤ Hostile)?
pub fn is_hostile(wars: &WarRegistry, rep: &ReputationMatrix, a: FactionId, b: FactionId) -> bool {
    wars.is_at_war(a, b) || rep.relation(a, b).is_hostile()
}

#[cfg(test)]
mod tests {
    use super::*;
    use ce_faction::Relation;

    const A: FactionId = FactionId::new("a");
    const B: FactionId = FactionId::new("b");

    #[test]
    fn sign_treaty_records_and_boosts_reputation() {
        let mut t = TreatyRegistry::new();
        let mut rep = ReputationMatrix::new();
        assert!(sign_treaty(&mut t, &mut rep, TreatyKind::TradeAccord, A, B));
        assert!(t.has(A, B, TreatyKind::TradeAccord));
        assert_eq!(rep.get(A, B), TREATY_SIGN_REPUTATION_BONUS);
    }

    #[test]
    fn sign_treaty_rejects_duplicate() {
        let mut t = TreatyRegistry::new();
        let mut rep = ReputationMatrix::new();
        sign_treaty(&mut t, &mut rep, TreatyKind::TradeAccord, A, B);
        assert!(!sign_treaty(
            &mut t,
            &mut rep,
            TreatyKind::TradeAccord,
            A,
            B
        ));
    }

    #[test]
    fn break_treaty_removes_and_tanks_reputation() {
        let mut t = TreatyRegistry::new();
        let mut rep = ReputationMatrix::new();
        sign_treaty(&mut t, &mut rep, TreatyKind::NonAggression, A, B);
        assert!(break_treaty(
            &mut t,
            &mut rep,
            TreatyKind::NonAggression,
            A,
            B
        ));
        assert!(!t.has(A, B, TreatyKind::NonAggression));
        // Net = +75 (sign) + -200 (break) = -125
        assert_eq!(rep.get(A, B), -125);
    }

    #[test]
    fn break_treaty_missing_is_false_and_noop() {
        let mut t = TreatyRegistry::new();
        let mut rep = ReputationMatrix::new();
        assert!(!break_treaty(&mut t, &mut rep, TreatyKind::Alliance, A, B));
        assert_eq!(rep.get(A, B), 0);
    }

    #[test]
    fn declare_war_sets_war_and_floors_reputation() {
        let mut t = TreatyRegistry::new();
        let mut w = WarRegistry::new();
        let mut rep = ReputationMatrix::new();
        rep.set(A, B, 500); // friendly before war
        assert!(declare_war(&mut t, &mut w, &mut rep, A, B));
        assert!(w.is_at_war(A, B));
        assert_eq!(rep.relation(A, B), Relation::War);
    }

    #[test]
    fn declare_war_breaks_nonaggression_treaty() {
        let mut t = TreatyRegistry::new();
        let mut w = WarRegistry::new();
        let mut rep = ReputationMatrix::new();
        sign_treaty(&mut t, &mut rep, TreatyKind::NonAggression, A, B);
        assert!(declare_war(&mut t, &mut w, &mut rep, A, B));
        assert!(!t.has(A, B, TreatyKind::NonAggression));
        assert!(w.is_at_war(A, B));
    }

    #[test]
    fn declare_war_on_self_fails() {
        let mut t = TreatyRegistry::new();
        let mut w = WarRegistry::new();
        let mut rep = ReputationMatrix::new();
        assert!(!declare_war(&mut t, &mut w, &mut rep, A, A));
    }

    #[test]
    fn declare_war_already_at_war_is_false() {
        let mut t = TreatyRegistry::new();
        let mut w = WarRegistry::new();
        let mut rep = ReputationMatrix::new();
        declare_war(&mut t, &mut w, &mut rep, A, B);
        assert!(!declare_war(&mut t, &mut w, &mut rep, A, B));
    }

    #[test]
    fn make_peace_clears_war() {
        let mut t = TreatyRegistry::new();
        let mut w = WarRegistry::new();
        let mut rep = ReputationMatrix::new();
        declare_war(&mut t, &mut w, &mut rep, A, B);
        assert!(make_peace(&mut w, A, B));
        assert!(!w.is_at_war(A, B));
    }

    #[test]
    fn is_hostile_covers_war_or_bad_reputation() {
        let mut t = TreatyRegistry::new();
        let mut w = WarRegistry::new();
        let mut rep = ReputationMatrix::new();
        assert!(!is_hostile(&w, &rep, A, B));
        rep.set(A, B, -300);
        assert!(is_hostile(&w, &rep, A, B));
        // Even if rep is fine, war flips it hostile.
        rep.set(A, B, 500);
        assert!(!is_hostile(&w, &rep, A, B));
        declare_war(&mut t, &mut w, &mut rep, A, B);
        assert!(is_hostile(&w, &rep, A, B));
    }
}

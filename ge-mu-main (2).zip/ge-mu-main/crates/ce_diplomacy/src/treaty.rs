//! Treaty types + active-treaty registry.

use std::collections::HashMap;

use ce_faction::FactionId;

/// What kind of agreement two factions share. Effect semantics are the
/// caller's job — this crate only bookkeeping + lifecycle.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum TreatyKind {
    /// Neither side fires first. Breaking it is a casus belli.
    NonAggression,
    /// Open trade: markets drop tariffs, prices lean friendlier.
    TradeAccord,
    /// Members defend each other from third-party aggression.
    DefensivePact,
    /// Full military alliance — includes both pact effects and
    /// shared-enemy flagging.
    Alliance,
    /// Targeted embargo — the two listed factions refuse trade.
    Embargo,
}

/// Ordered pair with `a <= b`, so every treaty is keyed once.
fn pair(a: FactionId, b: FactionId) -> (FactionId, FactionId) {
    if a <= b {
        (a, b)
    } else {
        (b, a)
    }
}

/// One active treaty. `remaining_seconds = None` means the treaty is
/// permanent until broken.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Treaty {
    pub kind: TreatyKind,
    pub a: FactionId,
    pub b: FactionId,
    pub remaining_seconds: Option<f32>,
}

impl Treaty {
    pub fn new(kind: TreatyKind, a: FactionId, b: FactionId) -> Self {
        let (a, b) = pair(a, b);
        Self {
            kind,
            a,
            b,
            remaining_seconds: None,
        }
    }

    pub fn with_duration(mut self, seconds: f32) -> Self {
        self.remaining_seconds = Some(seconds);
        self
    }

    pub fn involves(&self, f: FactionId) -> bool {
        self.a == f || self.b == f
    }
}

/// Key for per-treaty storage.
pub type TreatyKey = (FactionId, FactionId, TreatyKind);

/// Active-treaty store, keyed by `(a, b, kind)` so two factions can
/// hold more than one treaty kind simultaneously (e.g. NonAggression
/// + TradeAccord).
#[derive(Debug, Clone, Default)]
pub struct TreatyRegistry {
    treaties: HashMap<TreatyKey, Treaty>,
}

impl TreatyRegistry {
    pub fn new() -> Self {
        Self::default()
    }

    fn key(t: &Treaty) -> TreatyKey {
        (t.a, t.b, t.kind)
    }

    pub fn has(&self, a: FactionId, b: FactionId, kind: TreatyKind) -> bool {
        let (a, b) = pair(a, b);
        self.treaties.contains_key(&(a, b, kind))
    }

    pub fn get(&self, a: FactionId, b: FactionId, kind: TreatyKind) -> Option<&Treaty> {
        let (a, b) = pair(a, b);
        self.treaties.get(&(a, b, kind))
    }

    pub fn insert(&mut self, treaty: Treaty) -> bool {
        let k = Self::key(&treaty);
        let fresh = !self.treaties.contains_key(&k);
        self.treaties.insert(k, treaty);
        fresh
    }

    pub fn remove(&mut self, a: FactionId, b: FactionId, kind: TreatyKind) -> Option<Treaty> {
        let (a, b) = pair(a, b);
        self.treaties.remove(&(a, b, kind))
    }

    /// Every treaty that includes `f`.
    pub fn involving(&self, f: FactionId) -> impl Iterator<Item = &Treaty> {
        self.treaties.values().filter(move |t| t.involves(f))
    }

    pub fn len(&self) -> usize {
        self.treaties.len()
    }

    pub fn is_empty(&self) -> bool {
        self.treaties.is_empty()
    }

    /// Ages every treaty by `dt_seconds`. Removes any whose clock hit
    /// zero and returns their keys.
    pub fn tick(&mut self, dt_seconds: f32) -> Vec<TreatyKey> {
        let mut expired = Vec::new();
        self.treaties
            .retain(|k, t| match t.remaining_seconds.as_mut() {
                Some(r) => {
                    *r -= dt_seconds;
                    if *r <= 0.0 {
                        expired.push(*k);
                        false
                    } else {
                        true
                    }
                }
                None => true,
            });
        expired
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const A: FactionId = FactionId::new("a");
    const B: FactionId = FactionId::new("b");
    const C: FactionId = FactionId::new("c");

    #[test]
    fn treaty_pair_is_order_independent() {
        let t1 = Treaty::new(TreatyKind::TradeAccord, A, B);
        let t2 = Treaty::new(TreatyKind::TradeAccord, B, A);
        assert_eq!((t1.a, t1.b), (t2.a, t2.b));
    }

    #[test]
    fn registry_insert_has_get() {
        let mut r = TreatyRegistry::new();
        r.insert(Treaty::new(TreatyKind::NonAggression, A, B));
        assert!(r.has(A, B, TreatyKind::NonAggression));
        assert!(r.has(B, A, TreatyKind::NonAggression));
        assert!(!r.has(A, C, TreatyKind::NonAggression));
    }

    #[test]
    fn distinct_kinds_coexist() {
        let mut r = TreatyRegistry::new();
        r.insert(Treaty::new(TreatyKind::NonAggression, A, B));
        r.insert(Treaty::new(TreatyKind::TradeAccord, A, B));
        assert_eq!(r.len(), 2);
    }

    #[test]
    fn remove_returns_previous_entry() {
        let mut r = TreatyRegistry::new();
        r.insert(Treaty::new(TreatyKind::NonAggression, A, B));
        let removed = r.remove(B, A, TreatyKind::NonAggression).unwrap();
        assert_eq!(removed.kind, TreatyKind::NonAggression);
        assert!(!r.has(A, B, TreatyKind::NonAggression));
    }

    #[test]
    fn involving_filters_to_given_faction() {
        let mut r = TreatyRegistry::new();
        r.insert(Treaty::new(TreatyKind::TradeAccord, A, B));
        r.insert(Treaty::new(TreatyKind::TradeAccord, B, C));
        r.insert(Treaty::new(TreatyKind::TradeAccord, A, C));
        let a_count = r.involving(A).count();
        let b_count = r.involving(B).count();
        assert_eq!(a_count, 2);
        assert_eq!(b_count, 2);
    }

    #[test]
    fn tick_expires_limited_treaties() {
        let mut r = TreatyRegistry::new();
        r.insert(Treaty::new(TreatyKind::NonAggression, A, B).with_duration(1.0));
        r.insert(Treaty::new(TreatyKind::TradeAccord, A, C)); // permanent
        let expired = r.tick(2.0);
        assert_eq!(expired.len(), 1);
        assert!(!r.has(A, B, TreatyKind::NonAggression));
        assert!(r.has(A, C, TreatyKind::TradeAccord));
    }

    #[test]
    fn insert_returns_false_on_replace() {
        let mut r = TreatyRegistry::new();
        assert!(r.insert(Treaty::new(TreatyKind::Alliance, A, B)));
        assert!(!r.insert(Treaty::new(TreatyKind::Alliance, A, B)));
    }
}

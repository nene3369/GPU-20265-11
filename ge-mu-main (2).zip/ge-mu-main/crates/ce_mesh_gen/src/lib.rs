//! `ce_mesh_gen` — procedural meshes driven by code, not asset files.
//!
//! Three generators:
//! - [`voxel::build_ship_mesh`] — ShipBlocks → face-culled cube mesh.
//! - [`cubesphere::build_planet_mesh`] — cubesphere, optionally shaded
//!   by elevation + biome from a `Planet`.
//! - [`asteroid::build_asteroid`] — noise-deformed sphere for rocks.
//!
//! Output is always a plain `ce_render::Mesh`. Normals aren't in the
//! current `Vertex` layout, so a cheap directional bake ships in the
//! colour channel; real lighting swaps in when `Vertex` grows
//! a normal slot.

pub mod asteroid;
pub mod cubesphere;
pub mod voxel;

pub use asteroid::build_asteroid;
pub use cubesphere::{build_planet_mesh, build_unit_sphere};
pub use voxel::build_ship_mesh;

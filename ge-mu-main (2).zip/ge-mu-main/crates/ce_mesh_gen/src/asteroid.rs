//! Noise-deformed sphere for asteroid bodies.
//!
//! Starts from a cubesphere (cheap and seam-free for this scale) and
//! offsets every vertex outward by an fBm noise sample. Slightly
//! rougher than a planet so the silhouette reads as "rock", not
//! "terrain".

use ce_math::Vec3;
use ce_planet::fbm_3d;
use ce_render::mesh::{Mesh, Vertex};

/// Builds an asteroid mesh of `radius` metres with noise roughness
/// `roughness ∈ [0, 0.5]`. `subdivisions` controls face resolution.
pub fn build_asteroid(seed: u64, radius: f32, roughness: f32, subdivisions: u32) -> Mesh {
    let sphere = crate::cubesphere::build_unit_sphere(subdivisions);
    let roughness = roughness.clamp(0.0, 0.5);
    let mut vertices = Vec::with_capacity(sphere.vertices.len());
    for v in sphere.vertices.iter() {
        let p = Vec3::new(v.position[0], v.position[1], v.position[2]);
        // Sample fBm at the unit-sphere point for seamless noise.
        let n = fbm_3d(
            seed,
            p.x as f64 * 3.0,
            p.y as f64 * 3.0,
            p.z as f64 * 3.0,
            4,
        );
        // Map [0,1] noise to [-1,1] so displacement signs out.
        let signed = (n as f32) * 2.0 - 1.0;
        let scale = 1.0 + signed * roughness;
        let pos = p * radius * scale;
        let grey = 0.35 + (n as f32) * 0.25;
        vertices.push(Vertex {
            position: [pos.x, pos.y, pos.z],
            color: [grey, grey * 0.95, grey * 0.85, 1.0],
        });
    }
    Mesh {
        vertices,
        indices: sphere.indices,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn asteroid_vertex_count_matches_source_sphere() {
        let base = crate::cubesphere::build_unit_sphere(4);
        let a = build_asteroid(1, 5.0, 0.2, 4);
        assert_eq!(a.vertices.len(), base.vertices.len());
    }

    #[test]
    fn asteroid_bounding_sphere_near_requested_radius() {
        let radius = 10.0_f32;
        let a = build_asteroid(1, radius, 0.2, 8);
        let mut min_r = f32::INFINITY;
        let mut max_r = 0.0_f32;
        for v in &a.vertices {
            let r = Vec3::new(v.position[0], v.position[1], v.position[2]).length();
            min_r = min_r.min(r);
            max_r = max_r.max(r);
        }
        // With roughness 0.2, radii should stay within ±20 % of `radius`.
        assert!(min_r >= radius * 0.78);
        assert!(max_r <= radius * 1.22);
    }

    #[test]
    fn zero_roughness_is_smooth_sphere() {
        let radius = 4.0_f32;
        let a = build_asteroid(1, radius, 0.0, 4);
        for v in &a.vertices {
            let r = Vec3::new(v.position[0], v.position[1], v.position[2]).length();
            assert!((r - radius).abs() < 1e-3);
        }
    }

    #[test]
    fn different_seeds_produce_different_vertex_layouts() {
        let a = build_asteroid(1, 5.0, 0.3, 6);
        let b = build_asteroid(2, 5.0, 0.3, 6);
        let mut differs = 0;
        for (va, vb) in a.vertices.iter().zip(b.vertices.iter()) {
            if va.position != vb.position {
                differs += 1;
            }
        }
        assert!(differs > a.vertices.len() / 10);
    }

    #[test]
    fn roughness_clamped_upward() {
        let a = build_asteroid(1, 5.0, 2.0, 4); // clamped to 0.5
        for v in &a.vertices {
            let r = Vec3::new(v.position[0], v.position[1], v.position[2]).length();
            // At 0.5 roughness radial scale is within [0.5, 1.5].
            assert!(r >= 5.0 * 0.5 - 1e-3);
            assert!(r <= 5.0 * 1.5 + 1e-3);
        }
    }
}

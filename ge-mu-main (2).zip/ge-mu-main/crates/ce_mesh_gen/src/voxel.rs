//! Voxel-to-mesh generation for ship and base block grids.
//!
//! Emits one quad per exposed block face (faces adjacent to another
//! block are culled). Per-face colour derives from the block's
//! material, lightly shaded by face direction so the mesh reads as
//! 3D even without per-vertex normals.

use ce_math::{IVec3, Vec3};
use ce_render::mesh::{Mesh, Vertex};
use ce_ship::{BlockMaterial, ShipBlocks, NEIGHBOR_OFFSETS};

/// Per-face outward normals matching `NEIGHBOR_OFFSETS`.
const FACE_NORMALS: [Vec3; 6] = [
    Vec3::new(1.0, 0.0, 0.0),  // +X
    Vec3::new(-1.0, 0.0, 0.0), // -X
    Vec3::new(0.0, 1.0, 0.0),  // +Y
    Vec3::new(0.0, -1.0, 0.0), // -Y
    Vec3::new(0.0, 0.0, 1.0),  // +Z
    Vec3::new(0.0, 0.0, -1.0), // -Z
];

/// Builds an indexed mesh from a [`ShipBlocks`] grid, one cube per
/// occupied cell, with interior faces removed.
///
/// The mesh sits in the grid's local coordinate frame, one unit per
/// cell. Translate / rotate via the owning entity's `Transform`.
pub fn build_ship_mesh(grid: &ShipBlocks) -> Mesh {
    let mut vertices: Vec<Vertex> = Vec::with_capacity(grid.len() * 24);
    let mut indices: Vec<u32> = Vec::with_capacity(grid.len() * 36);

    for (&cell, block) in grid.iter() {
        let base_color = material_color(block.material);
        for (face_idx, offset) in NEIGHBOR_OFFSETS.iter().enumerate() {
            let neighbour = cell + *offset;
            if grid.contains(neighbour) {
                continue; // interior face — cull
            }
            let normal = FACE_NORMALS[face_idx];
            let shade = face_shade(normal);
            let color = [
                base_color[0] * shade,
                base_color[1] * shade,
                base_color[2] * shade,
                1.0,
            ];
            emit_face(&mut vertices, &mut indices, cell, face_idx, color);
        }
    }

    Mesh {
        vertices,
        indices: if indices.is_empty() {
            None
        } else {
            Some(indices)
        },
    }
}

fn emit_face(
    vertices: &mut Vec<Vertex>,
    indices: &mut Vec<u32>,
    cell: IVec3,
    face: usize,
    color: [f32; 4],
) {
    let base_index = vertices.len() as u32;
    let origin = Vec3::new(cell.x as f32, cell.y as f32, cell.z as f32);
    let quad = unit_cube_face_corners(face);
    for corner in quad {
        vertices.push(Vertex {
            position: [
                origin.x + corner.x,
                origin.y + corner.y,
                origin.z + corner.z,
            ],
            color,
        });
    }
    // Two CCW triangles per quad.
    indices.extend_from_slice(&[
        base_index,
        base_index + 1,
        base_index + 2,
        base_index,
        base_index + 2,
        base_index + 3,
    ]);
}

fn unit_cube_face_corners(face: usize) -> [Vec3; 4] {
    // Each quad lives on one face of the unit cube centered at
    // `origin + (0.5, 0.5, 0.5)`.
    match face {
        // +X
        0 => [
            Vec3::new(1.0, 0.0, 0.0),
            Vec3::new(1.0, 1.0, 0.0),
            Vec3::new(1.0, 1.0, 1.0),
            Vec3::new(1.0, 0.0, 1.0),
        ],
        // -X
        1 => [
            Vec3::new(0.0, 0.0, 1.0),
            Vec3::new(0.0, 1.0, 1.0),
            Vec3::new(0.0, 1.0, 0.0),
            Vec3::new(0.0, 0.0, 0.0),
        ],
        // +Y
        2 => [
            Vec3::new(0.0, 1.0, 0.0),
            Vec3::new(0.0, 1.0, 1.0),
            Vec3::new(1.0, 1.0, 1.0),
            Vec3::new(1.0, 1.0, 0.0),
        ],
        // -Y
        3 => [
            Vec3::new(0.0, 0.0, 1.0),
            Vec3::new(0.0, 0.0, 0.0),
            Vec3::new(1.0, 0.0, 0.0),
            Vec3::new(1.0, 0.0, 1.0),
        ],
        // +Z
        4 => [
            Vec3::new(1.0, 0.0, 1.0),
            Vec3::new(1.0, 1.0, 1.0),
            Vec3::new(0.0, 1.0, 1.0),
            Vec3::new(0.0, 0.0, 1.0),
        ],
        // -Z
        5 => [
            Vec3::new(0.0, 0.0, 0.0),
            Vec3::new(0.0, 1.0, 0.0),
            Vec3::new(1.0, 1.0, 0.0),
            Vec3::new(1.0, 0.0, 0.0),
        ],
        _ => unreachable!(),
    }
}

fn material_color(m: BlockMaterial) -> [f32; 3] {
    match m {
        BlockMaterial::Iron => [0.55, 0.55, 0.58],
        BlockMaterial::Titanium => [0.80, 0.82, 0.86],
        BlockMaterial::Composite => [0.40, 0.38, 0.42],
        BlockMaterial::Tungsten => [0.35, 0.33, 0.36],
        BlockMaterial::Aluminium => [0.88, 0.88, 0.90],
    }
}

/// Cheap directional "lighting" bake: top brighter, bottom dimmer,
/// sides in between. Keeps the mesh readable before a real lighting
/// pass is wired up.
fn face_shade(normal: Vec3) -> f32 {
    let n_dot_light = normal.dot(Vec3::new(0.0, 1.0, 0.3).normalize());
    (0.55 + 0.45 * n_dot_light.clamp(0.0, 1.0)).clamp(0.4, 1.0)
}

#[cfg(test)]
mod tests {
    use super::*;
    use ce_ship::{Block, BlockKind};

    #[test]
    fn empty_grid_produces_empty_mesh() {
        let grid = ShipBlocks::new();
        let mesh = build_ship_mesh(&grid);
        assert!(mesh.vertices.is_empty());
        assert!(mesh.indices.is_none());
    }

    #[test]
    fn single_block_has_six_faces_twelve_triangles() {
        let mut grid = ShipBlocks::new();
        grid.insert(
            IVec3::ZERO,
            Block::new(BlockKind::Hull, BlockMaterial::Iron),
        );
        let mesh = build_ship_mesh(&grid);
        // 6 faces × 4 vertices = 24.
        assert_eq!(mesh.vertices.len(), 24);
        // 6 faces × 6 indices (2 tris) = 36.
        assert_eq!(mesh.indices.as_ref().unwrap().len(), 36);
    }

    #[test]
    fn adjacent_blocks_hide_shared_faces() {
        let mut grid = ShipBlocks::new();
        grid.insert(
            IVec3::ZERO,
            Block::new(BlockKind::Hull, BlockMaterial::Iron),
        );
        grid.insert(
            IVec3::new(1, 0, 0),
            Block::new(BlockKind::Hull, BlockMaterial::Iron),
        );
        let mesh = build_ship_mesh(&grid);
        // 12 exposed faces (6 per block × 2 - 2 shared) × 4 verts = 40.
        assert_eq!(mesh.vertices.len(), 4 * 10);
        assert_eq!(mesh.indices.as_ref().unwrap().len(), 6 * 10);
    }

    #[test]
    fn mesh_bounding_box_covers_all_cells() {
        let mut grid = ShipBlocks::new();
        grid.insert(
            IVec3::new(-1, 0, 2),
            Block::new(BlockKind::Hull, BlockMaterial::Iron),
        );
        grid.insert(
            IVec3::new(3, 2, -1),
            Block::new(BlockKind::Hull, BlockMaterial::Iron),
        );
        let mesh = build_ship_mesh(&grid);
        let positions: Vec<Vec3> = mesh
            .vertices
            .iter()
            .map(|v| Vec3::new(v.position[0], v.position[1], v.position[2]))
            .collect();
        let (mut min, mut max) = (Vec3::splat(f32::INFINITY), Vec3::splat(f32::NEG_INFINITY));
        for p in &positions {
            min = min.min(*p);
            max = max.max(*p);
        }
        assert!(min.x <= -1.0 && max.x >= 4.0);
        assert!(min.y <= 0.0 && max.y >= 3.0);
        assert!(min.z <= -1.0 && max.z >= 3.0);
    }

    #[test]
    fn material_color_differs_between_materials() {
        let iron = material_color(BlockMaterial::Iron);
        let tungsten = material_color(BlockMaterial::Tungsten);
        assert_ne!(iron, tungsten);
    }

    #[test]
    fn face_shade_is_clamped_in_sensible_range() {
        for &n in &FACE_NORMALS {
            let s = face_shade(n);
            assert!((0.4..=1.0).contains(&s));
        }
    }
}

//! Cubesphere mesh for planets.
//!
//! Subdivides each face of a unit cube into `N × N` quads, then
//! normalises every vertex onto the unit sphere. Optionally samples
//! elevation + biome from a [`Planet`] to colour the surface.

use ce_math::Vec3;
use ce_planet::{classify_at, surface_elevation, Biome, Planet};
use ce_render::mesh::{Mesh, Vertex};

/// Builds a raw cubesphere of radius 1.0 with `subdivisions` quads
/// per cube-face edge. `subdivisions >= 1`.
pub fn build_unit_sphere(subdivisions: u32) -> Mesh {
    build_planet_mesh(None, subdivisions)
}

/// Builds a cubesphere and shades vertices by a planet's elevation +
/// biome. Vertex position is multiplied by `planet.radius_m + elevation`.
pub fn build_planet_mesh(planet: Option<&Planet>, subdivisions: u32) -> Mesh {
    let n = subdivisions.max(1);
    let mut vertices: Vec<Vertex> = Vec::new();
    let mut indices: Vec<u32> = Vec::new();

    for face in 0..6u32 {
        let base_index = vertices.len() as u32;
        // Emit (n+1) × (n+1) vertices.
        for j in 0..=n {
            for i in 0..=n {
                let u = i as f32 / n as f32;
                let v = j as f32 / n as f32;
                let cube_point = cube_face_point(face, u, v);
                let sphere_point = cube_point.normalize();
                let (pos, color) = shade_vertex(sphere_point, planet);
                vertices.push(Vertex {
                    position: [pos.x, pos.y, pos.z],
                    color,
                });
            }
        }
        // Emit quad indices.
        for j in 0..n {
            for i in 0..n {
                let row = n + 1;
                let idx = base_index + j * row + i;
                indices.extend_from_slice(&[
                    idx,
                    idx + 1,
                    idx + row + 1,
                    idx,
                    idx + row + 1,
                    idx + row,
                ]);
            }
        }
    }

    Mesh {
        vertices,
        indices: Some(indices),
    }
}

fn shade_vertex(unit_point: Vec3, planet: Option<&Planet>) -> (Vec3, [f32; 4]) {
    match planet {
        None => (unit_point, [0.8, 0.8, 0.9, 1.0]),
        Some(p) => {
            let lat = unit_point.y.clamp(-1.0, 1.0).asin() as f64;
            let lon = unit_point.z.atan2(unit_point.x) as f64;
            let elevation = surface_elevation(p, lat, lon);
            // Render-space is scaled so the unit sphere represents the
            // planet's reference radius (keeps GPU numbers small). Map
            // elevation to a visible offset relative to the radius.
            let rel = (elevation / p.radius_m) as f32;
            // Scale the radial displacement up so it's visible at the
            // planet's default render scale (mountains on a 1 m sphere
            // would be invisible at true scale).
            let radius_scale = 1.0 + rel * 50.0;
            let pos = unit_point * radius_scale;
            let biome = classify_at(p, lat, lon);
            (pos, biome_color(biome))
        }
    }
}

fn cube_face_point(face: u32, u: f32, v: f32) -> Vec3 {
    let a = u * 2.0 - 1.0;
    let b = v * 2.0 - 1.0;
    match face {
        0 => Vec3::new(1.0, b, a),   // +X
        1 => Vec3::new(-1.0, b, -a), // -X
        2 => Vec3::new(a, 1.0, b),   // +Y
        3 => Vec3::new(a, -1.0, -b), // -Y
        4 => Vec3::new(-a, b, 1.0),  // +Z
        5 => Vec3::new(a, b, -1.0),  // -Z
        _ => unreachable!(),
    }
}

fn biome_color(b: Biome) -> [f32; 4] {
    match b {
        Biome::Ocean => [0.10, 0.28, 0.55, 1.0],
        Biome::Ice => [0.85, 0.92, 0.96, 1.0],
        Biome::Desert => [0.85, 0.75, 0.45, 1.0],
        Biome::RainForest => [0.08, 0.45, 0.18, 1.0],
        Biome::Forest => [0.18, 0.55, 0.25, 1.0],
        Biome::Grassland => [0.50, 0.70, 0.25, 1.0],
        Biome::Tundra => [0.62, 0.66, 0.62, 1.0],
        Biome::Mountain => [0.45, 0.42, 0.38, 1.0],
        Biome::Lava => [0.70, 0.15, 0.05, 1.0],
        Biome::Barren => [0.45, 0.43, 0.42, 1.0],
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ce_planet::PlanetId;
    use ce_space::WorldPos;

    #[test]
    fn unit_sphere_vertex_count_matches_formula() {
        // 6 faces × (n+1)² vertices each.
        for n in [1, 2, 4, 8] {
            let mesh = build_unit_sphere(n);
            let expected = 6 * (n + 1) * (n + 1);
            assert_eq!(mesh.vertices.len(), expected as usize, "n = {n}");
        }
    }

    #[test]
    fn unit_sphere_index_count_matches_formula() {
        // 6 faces × n² quads × 6 indices.
        for n in [1, 2, 4, 8] {
            let mesh = build_unit_sphere(n);
            let expected = 6 * n * n * 6;
            assert_eq!(
                mesh.indices.as_ref().unwrap().len(),
                expected as usize,
                "n = {n}"
            );
        }
    }

    #[test]
    fn unit_sphere_vertices_lie_on_unit_sphere() {
        let mesh = build_unit_sphere(8);
        for v in &mesh.vertices {
            let p = Vec3::new(v.position[0], v.position[1], v.position[2]);
            assert!(
                (p.length() - 1.0).abs() < 1e-5,
                "vertex not on sphere: {p:?}"
            );
        }
    }

    #[test]
    fn planet_mesh_uses_biome_colors() {
        let p = Planet::earth_like(PlanetId(1), WorldPos::ZERO, 42);
        let mesh = build_planet_mesh(Some(&p), 8);
        // Earth-like should show at least two distinct biome colours.
        let mut palette: std::collections::HashSet<[u32; 4]> = std::collections::HashSet::new();
        for v in &mesh.vertices {
            palette.insert([
                (v.color[0] * 255.0) as u32,
                (v.color[1] * 255.0) as u32,
                (v.color[2] * 255.0) as u32,
                (v.color[3] * 255.0) as u32,
            ]);
        }
        assert!(
            palette.len() >= 2,
            "expected multiple biomes, got {palette:?}"
        );
    }

    #[test]
    fn zero_subdivisions_clamps_to_one() {
        let mesh = build_unit_sphere(0);
        // 6 × 2×2 = 24 vertices (single quad per face).
        assert_eq!(mesh.vertices.len(), 24);
    }

    #[test]
    fn planet_mesh_radial_offset_reflects_elevation() {
        let p = Planet::earth_like(PlanetId(1), WorldPos::ZERO, 17);
        let mesh = build_planet_mesh(Some(&p), 16);
        let mut min_r = f32::INFINITY;
        let mut max_r = 0.0_f32;
        for v in &mesh.vertices {
            let r = Vec3::new(v.position[0], v.position[1], v.position[2]).length();
            min_r = min_r.min(r);
            max_r = max_r.max(r);
        }
        assert!(max_r > min_r, "mesh should have elevation variation");
    }
}

//! Galaxy-scale world position in double precision.
//!
//! `f32` loses sub-mm precision about 8 km from the origin — fatal for
//! a galaxy-sized game. `WorldPos` holds simulation-space coordinates
//! in `f64`; rendering downcasts to `f32` after subtracting the current
//! [`crate::FloatingOrigin`].

use std::ops::{Add, AddAssign, Neg, Sub, SubAssign};

use ce_math::Vec3;
use glam::DVec3;

/// Absolute position in the galactic frame, in meters.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct WorldPos(pub DVec3);

impl WorldPos {
    pub const ZERO: WorldPos = WorldPos(DVec3::ZERO);

    #[inline]
    pub const fn new(x: f64, y: f64, z: f64) -> Self {
        Self(DVec3::new(x, y, z))
    }

    #[inline]
    pub fn from_vec3(v: Vec3) -> Self {
        Self(DVec3::new(v.x as f64, v.y as f64, v.z as f64))
    }

    #[inline]
    pub fn as_dvec3(self) -> DVec3 {
        self.0
    }

    /// Euclidean distance to `other`.
    #[inline]
    pub fn distance(self, other: WorldPos) -> f64 {
        self.0.distance(other.0)
    }

    #[inline]
    pub fn distance_squared(self, other: WorldPos) -> f64 {
        self.0.distance_squared(other.0)
    }

    /// Downcast to camera-relative `f32` coordinates by subtracting
    /// `origin` before casting. The further `origin` is from `self`,
    /// the more precision is lost, so the origin must track the camera
    /// within the sector.
    #[inline]
    pub fn to_local(self, origin: WorldPos) -> Vec3 {
        let d = self.0 - origin.0;
        Vec3::new(d.x as f32, d.y as f32, d.z as f32)
    }
}

impl Add<DVec3> for WorldPos {
    type Output = WorldPos;
    #[inline]
    fn add(self, rhs: DVec3) -> WorldPos {
        WorldPos(self.0 + rhs)
    }
}

impl AddAssign<DVec3> for WorldPos {
    #[inline]
    fn add_assign(&mut self, rhs: DVec3) {
        self.0 += rhs;
    }
}

impl Sub<WorldPos> for WorldPos {
    type Output = DVec3;
    #[inline]
    fn sub(self, rhs: WorldPos) -> DVec3 {
        self.0 - rhs.0
    }
}

impl Sub<DVec3> for WorldPos {
    type Output = WorldPos;
    #[inline]
    fn sub(self, rhs: DVec3) -> WorldPos {
        WorldPos(self.0 - rhs)
    }
}

impl SubAssign<DVec3> for WorldPos {
    #[inline]
    fn sub_assign(&mut self, rhs: DVec3) {
        self.0 -= rhs;
    }
}

impl Neg for WorldPos {
    type Output = WorldPos;
    #[inline]
    fn neg(self) -> WorldPos {
        WorldPos(-self.0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn zero_is_origin() {
        assert_eq!(WorldPos::ZERO, WorldPos::new(0.0, 0.0, 0.0));
    }

    #[test]
    fn add_sub_roundtrip() {
        let a = WorldPos::new(1e9, -2e9, 3e9);
        let delta = DVec3::new(100.0, 200.0, 300.0);
        let b = a + delta;
        assert_eq!(b - a, delta);
        assert_eq!(b - delta, a);
    }

    #[test]
    fn distance_at_galactic_scale() {
        // Two points 1 light-year apart (≈ 9.46e15 m).
        let a = WorldPos::ZERO;
        let b = WorldPos::new(9.46e15, 0.0, 0.0);
        let d = a.distance(b);
        // f64 has ~15 significant digits, so sub-meter error at 1e15 m.
        assert!((d - 9.46e15).abs() < 1.0);
    }

    #[test]
    fn to_local_preserves_precision_near_origin() {
        // Player is 10 m from a local origin one billion meters out.
        let origin = WorldPos::new(1e9, 0.0, 0.0);
        let pos = origin + DVec3::new(10.0, 0.0, 0.0);
        let local = pos.to_local(origin);
        // Absolute error must be sub-mm.
        assert!((local.x - 10.0).abs() < 1e-3);
        assert_eq!(local.y, 0.0);
        assert_eq!(local.z, 0.0);
    }

    #[test]
    fn to_local_loses_precision_far_from_origin() {
        // Motivating test: this is why we rebase.
        let origin = WorldPos::ZERO;
        let pos = WorldPos::new(1e9, 0.0, 0.0);
        let local = pos.to_local(origin);
        // 1e9 m as f32 cannot represent 1 m increments. Any nudge of
        // sub-metre size is swallowed.
        let nudged = (pos + DVec3::new(0.1, 0.0, 0.0)).to_local(origin);
        assert_eq!(local, nudged, "sub-metre motion invisible at 1e9 m");
    }

    #[test]
    fn neg_inverts() {
        let p = WorldPos::new(1.0, -2.0, 3.0);
        assert_eq!(-p, WorldPos::new(-1.0, 2.0, -3.0));
    }
}

//! ECS systems that couple [`WorldPos`] to [`ce_scene::Transform`].
//!
//! - [`sync_transform_from_world_pos`] runs in `PreUpdate`. For every
//!   entity with both a `WorldPos` and a `Transform`, it writes
//!   `transform.translation = (world_pos − origin).as_f32()`.
//! - [`rebase_origin_system`] runs in `Last`. If the player's
//!   `WorldPos` has strayed outside `FloatingOrigin.rebase_threshold`,
//!   the origin is moved to the player and the next frame's sync will
//!   pick up the new delta.

use ce_core::Entity;
use ce_ecs::World;
use ce_scene::Transform;

use crate::origin::FloatingOrigin;
use crate::pos::WorldPos;

/// Marker component for "this entity's position is what the origin
/// system should track". Attach to the local player / camera.
#[derive(Debug, Clone, Copy, Default)]
pub struct LocalPlayer;

/// For every entity with `WorldPos + Transform`, rewrite
/// `Transform.translation` to be camera-relative f32.
pub fn sync_transform_from_world_pos(world: &mut World) {
    let origin = match world.get_resource::<FloatingOrigin>() {
        Some(o) => *o,
        None => return,
    };

    let pairs: Vec<(Entity, WorldPos)> = world
        .query2::<WorldPos, Transform>()
        .iter()
        .map(|&(e, &wp, _tf)| (e, wp))
        .collect();

    for (entity, wp) in pairs {
        if let Some(tf) = world.get_component::<Transform>(entity).copied() {
            let mut new_tf = tf;
            new_tf.translation = wp.to_local(origin.center);
            world.insert_component(entity, new_tf);
        }
    }
}

/// If any `LocalPlayer` has strayed beyond the rebase threshold,
/// move the origin to that player.
pub fn rebase_origin_system(world: &mut World) {
    let origin = match world.get_resource::<FloatingOrigin>() {
        Some(o) => *o,
        None => return,
    };

    // Pick the first LocalPlayer with a WorldPos (normally exactly one).
    let players: Vec<WorldPos> = world
        .query2::<LocalPlayer, WorldPos>()
        .iter()
        .map(|&(_e, _lp, &wp)| wp)
        .collect();

    let Some(&player_pos) = players.first() else {
        return;
    };

    if origin.needs_rebase(player_pos) {
        if let Some(o) = world.get_resource_mut::<FloatingOrigin>() {
            let delta = o.rebase_to(player_pos);
            log::debug!("FloatingOrigin rebased by {delta:?}");
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ce_math::Vec3;
    use glam::DVec3;

    fn spawn_with_world_pos(world: &mut World, wp: WorldPos) -> Entity {
        let e = world.spawn();
        world.insert_component(e, wp);
        world.insert_component(e, Transform::default());
        e
    }

    #[test]
    fn sync_updates_transform_to_camera_relative() {
        let mut world = World::new();
        world.insert_resource(FloatingOrigin::new(WorldPos::new(1_000_000.0, 0.0, 0.0)));
        let e = spawn_with_world_pos(&mut world, WorldPos::new(1_000_005.0, 0.0, 0.0));

        sync_transform_from_world_pos(&mut world);

        let tf = world.get_component::<Transform>(e).unwrap();
        assert!((tf.translation - Vec3::new(5.0, 0.0, 0.0)).length() < 1e-3);
    }

    #[test]
    fn sync_without_origin_is_noop() {
        let mut world = World::new();
        let e = spawn_with_world_pos(&mut world, WorldPos::new(42.0, 0.0, 0.0));
        // No FloatingOrigin resource.
        sync_transform_from_world_pos(&mut world);
        let tf = world.get_component::<Transform>(e).unwrap();
        assert_eq!(tf.translation, Vec3::ZERO); // unchanged default
    }

    #[test]
    fn rebase_moves_origin_to_local_player() {
        let mut world = World::new();
        world.insert_resource(FloatingOrigin::default());

        let e = world.spawn();
        world.insert_component(e, LocalPlayer);
        world.insert_component(e, WorldPos::new(50_000.0, 0.0, 0.0));

        rebase_origin_system(&mut world);

        let o = world.get_resource::<FloatingOrigin>().unwrap();
        assert_eq!(o.center, WorldPos::new(50_000.0, 0.0, 0.0));
    }

    #[test]
    fn rebase_leaves_origin_alone_inside_threshold() {
        let mut world = World::new();
        world.insert_resource(FloatingOrigin::default());

        let e = world.spawn();
        world.insert_component(e, LocalPlayer);
        world.insert_component(e, WorldPos::new(500.0, 500.0, 0.0));

        rebase_origin_system(&mut world);

        let o = world.get_resource::<FloatingOrigin>().unwrap();
        assert_eq!(o.center, WorldPos::ZERO);
    }

    #[test]
    fn sync_then_rebase_keeps_entities_correctly_placed() {
        // End-to-end: an entity far from origin appears at the right
        // render-space position after a rebase.
        let mut world = World::new();
        world.insert_resource(FloatingOrigin::default());

        // Entity A: the player
        let player = world.spawn();
        world.insert_component(player, LocalPlayer);
        world.insert_component(player, WorldPos::new(100_000.0, 0.0, 0.0));
        world.insert_component(player, Transform::default());

        // Entity B: a space station 1 km ahead of the player
        let station = world.spawn();
        world.insert_component(station, WorldPos::new(101_000.0, 0.0, 0.0));
        world.insert_component(station, Transform::default());

        // First: rebase the origin onto the player.
        rebase_origin_system(&mut world);
        // Then: propagate WorldPos → Transform.
        sync_transform_from_world_pos(&mut world);

        // The station's render-space translation should be 1 km ahead.
        let station_tf = world.get_component::<Transform>(station).unwrap();
        assert!((station_tf.translation - Vec3::new(1_000.0, 0.0, 0.0)).length() < 1e-3);
        // The player itself should sit at origin.
        let player_tf = world.get_component::<Transform>(player).unwrap();
        assert!(player_tf.translation.length() < 1e-3);
    }

    #[test]
    fn sync_noop_when_origin_is_already_at_player() {
        let mut world = World::new();
        world.insert_resource(FloatingOrigin::new(WorldPos::new(5.0, 5.0, 5.0)));
        let e = spawn_with_world_pos(&mut world, WorldPos::new(5.0, 5.0, 5.0));

        sync_transform_from_world_pos(&mut world);
        let tf = world.get_component::<Transform>(e).unwrap();
        assert!(tf.translation.length() < 1e-6);
    }

    #[test]
    fn rebase_without_player_is_noop() {
        let mut world = World::new();
        world.insert_resource(FloatingOrigin::default());

        // Entity has WorldPos but no LocalPlayer marker.
        let e = world.spawn();
        world.insert_component(e, WorldPos::new(50_000.0, 0.0, 0.0));

        rebase_origin_system(&mut world);

        let o = world.get_resource::<FloatingOrigin>().unwrap();
        assert_eq!(o.center, WorldPos::ZERO);
        let _ = DVec3::ZERO; // keep the unused import if tests ever need it
    }
}

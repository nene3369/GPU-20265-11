//! Floating-origin state.
//!
//! The camera (or local player) is kept within a small radius of the
//! render-space origin by periodically shifting the origin resource.
//! All `Transform.translation` values in the ECS are then re-derived
//! as `WorldPos − origin`, which keeps f32 rendering precise.

use crate::pos::WorldPos;

/// Current world-space origin used to downcast [`WorldPos`] to `Transform`.
#[derive(Debug, Clone, Copy)]
pub struct FloatingOrigin {
    /// Galactic-frame position that maps to render-space `(0,0,0)`.
    pub center: WorldPos,
    /// If the camera strays further than this from `center`, the origin
    /// system rebases. Default 10 km.
    pub rebase_threshold: f64,
}

impl FloatingOrigin {
    pub const DEFAULT_THRESHOLD: f64 = 10_000.0;

    pub fn new(center: WorldPos) -> Self {
        Self {
            center,
            rebase_threshold: Self::DEFAULT_THRESHOLD,
        }
    }

    /// True if `pos` has drifted outside the rebase threshold and the
    /// origin should be moved.
    pub fn needs_rebase(&self, pos: WorldPos) -> bool {
        self.center.distance_squared(pos) > self.rebase_threshold * self.rebase_threshold
    }

    /// Shifts the origin to `new_center` and returns the delta so
    /// callers can update any cached Transform values.
    pub fn rebase_to(&mut self, new_center: WorldPos) -> glam::DVec3 {
        let delta = new_center - self.center;
        self.center = new_center;
        delta
    }
}

impl Default for FloatingOrigin {
    fn default() -> Self {
        Self::new(WorldPos::ZERO)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use glam::DVec3;

    #[test]
    fn default_origin_is_zero_with_10km_threshold() {
        let o = FloatingOrigin::default();
        assert_eq!(o.center, WorldPos::ZERO);
        assert_eq!(o.rebase_threshold, 10_000.0);
    }

    #[test]
    fn needs_rebase_inside_threshold_is_false() {
        let o = FloatingOrigin::default();
        let near = WorldPos::new(500.0, 500.0, 500.0); // ≈866 m
        assert!(!o.needs_rebase(near));
    }

    #[test]
    fn needs_rebase_outside_threshold_is_true() {
        let o = FloatingOrigin::default();
        let far = WorldPos::new(20_000.0, 0.0, 0.0);
        assert!(o.needs_rebase(far));
    }

    #[test]
    fn rebase_returns_delta_and_updates_center() {
        let mut o = FloatingOrigin::new(WorldPos::ZERO);
        let new_center = WorldPos::new(1_000_000.0, 0.0, 0.0);
        let delta = o.rebase_to(new_center);
        assert_eq!(delta, DVec3::new(1_000_000.0, 0.0, 0.0));
        assert_eq!(o.center, new_center);
    }
}

//! Sector graph — coarse grid over galactic space.
//!
//! Space is tiled into cubes of side [`SECTOR_SIZE_METERS`]. A sector
//! holds the large-scale context (warp connections, faction ownership,
//! POI summary) while fine-grained entities live in camera-relative
//! `Transform` within the sector the player currently occupies.

use std::collections::HashMap;

use crate::pos::WorldPos;

/// Edge length of one sector cube, in meters. Default 1e9 m
/// (≈ 3.3 light-seconds) gives roughly stellar-system sized boxes.
pub const SECTOR_SIZE_METERS: f64 = 1.0e9;

/// Integer coordinate of a sector in the galactic grid.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct SectorId(pub i64, pub i64, pub i64);

impl SectorId {
    pub const ORIGIN: SectorId = SectorId(0, 0, 0);

    /// Returns the `SectorId` that contains `pos`.
    pub fn from_world_pos(pos: WorldPos) -> Self {
        let v = pos.as_dvec3();
        SectorId(
            (v.x / SECTOR_SIZE_METERS).floor() as i64,
            (v.y / SECTOR_SIZE_METERS).floor() as i64,
            (v.z / SECTOR_SIZE_METERS).floor() as i64,
        )
    }

    /// Center of this sector, in the galactic frame.
    pub fn center(self) -> WorldPos {
        WorldPos::new(
            (self.0 as f64 + 0.5) * SECTOR_SIZE_METERS,
            (self.1 as f64 + 0.5) * SECTOR_SIZE_METERS,
            (self.2 as f64 + 0.5) * SECTOR_SIZE_METERS,
        )
    }
}

/// Per-sector metadata.
#[derive(Debug, Clone)]
pub struct Sector {
    pub id: SectorId,
    /// Procedurally-generated display name. Optional so tests can omit it.
    pub name: Option<String>,
    /// Random seed used by `ce_worldgen` to generate contents on entry.
    pub seed: u64,
}

impl Sector {
    pub fn new(id: SectorId) -> Self {
        Self {
            id,
            name: None,
            seed: 0,
        }
    }

    pub fn with_seed(mut self, seed: u64) -> Self {
        self.seed = seed;
        self
    }

    pub fn with_name(mut self, name: impl Into<String>) -> Self {
        self.name = Some(name.into());
        self
    }

    /// Convenience: center of the sector.
    pub fn center(&self) -> WorldPos {
        self.id.center()
    }
}

/// Collection of known sectors plus the warp-jump graph between them.
#[derive(Debug, Clone, Default)]
pub struct SectorGraph {
    sectors: HashMap<SectorId, Sector>,
    jumps: HashMap<SectorId, Vec<SectorId>>,
}

impl SectorGraph {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn insert(&mut self, sector: Sector) {
        let id = sector.id;
        self.sectors.insert(id, sector);
        self.jumps.entry(id).or_default();
    }

    pub fn get(&self, id: SectorId) -> Option<&Sector> {
        self.sectors.get(&id)
    }

    pub fn contains(&self, id: SectorId) -> bool {
        self.sectors.contains_key(&id)
    }

    pub fn len(&self) -> usize {
        self.sectors.len()
    }

    pub fn is_empty(&self) -> bool {
        self.sectors.is_empty()
    }

    /// Connects two sectors with a bidirectional warp lane. Sectors
    /// must already be inserted.
    pub fn link(&mut self, a: SectorId, b: SectorId) {
        if let Some(list) = self.jumps.get_mut(&a) {
            if !list.contains(&b) {
                list.push(b);
            }
        }
        if let Some(list) = self.jumps.get_mut(&b) {
            if !list.contains(&a) {
                list.push(a);
            }
        }
    }

    pub fn neighbors(&self, id: SectorId) -> &[SectorId] {
        self.jumps.get(&id).map(Vec::as_slice).unwrap_or_default()
    }

    pub fn sectors(&self) -> impl Iterator<Item = &Sector> {
        self.sectors.values()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sector_id_from_pos_origin() {
        assert_eq!(SectorId::from_world_pos(WorldPos::ZERO), SectorId::ORIGIN);
    }

    #[test]
    fn sector_id_from_pos_positive() {
        let p = WorldPos::new(SECTOR_SIZE_METERS * 1.5, 0.0, 0.0);
        assert_eq!(SectorId::from_world_pos(p), SectorId(1, 0, 0));
    }

    #[test]
    fn sector_id_from_pos_negative_rounds_down() {
        let p = WorldPos::new(-0.1, 0.0, 0.0);
        assert_eq!(SectorId::from_world_pos(p), SectorId(-1, 0, 0));
    }

    #[test]
    fn sector_center_is_inside_sector() {
        let id = SectorId(3, -4, 2);
        let c = id.center();
        assert_eq!(SectorId::from_world_pos(c), id);
    }

    #[test]
    fn graph_insert_and_get() {
        let mut g = SectorGraph::new();
        g.insert(Sector::new(SectorId(1, 0, 0)).with_seed(42));
        assert!(g.contains(SectorId(1, 0, 0)));
        assert_eq!(g.get(SectorId(1, 0, 0)).unwrap().seed, 42);
        assert!(!g.contains(SectorId(0, 0, 0)));
    }

    #[test]
    fn graph_link_is_bidirectional() {
        let mut g = SectorGraph::new();
        let a = SectorId(0, 0, 0);
        let b = SectorId(1, 0, 0);
        g.insert(Sector::new(a));
        g.insert(Sector::new(b));
        g.link(a, b);
        assert_eq!(g.neighbors(a), &[b]);
        assert_eq!(g.neighbors(b), &[a]);
    }

    #[test]
    fn graph_link_is_idempotent() {
        let mut g = SectorGraph::new();
        let a = SectorId(0, 0, 0);
        let b = SectorId(1, 0, 0);
        g.insert(Sector::new(a));
        g.insert(Sector::new(b));
        g.link(a, b);
        g.link(a, b);
        g.link(b, a);
        assert_eq!(g.neighbors(a).len(), 1);
        assert_eq!(g.neighbors(b).len(), 1);
    }

    #[test]
    fn graph_neighbors_of_unknown_is_empty() {
        let g = SectorGraph::new();
        assert_eq!(g.neighbors(SectorId(99, 99, 99)), &[]);
    }
}

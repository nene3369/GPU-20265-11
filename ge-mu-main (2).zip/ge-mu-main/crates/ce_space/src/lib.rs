//! `ce_space` — galaxy-scale coordinate system.
//!
//! Introduces an `f64` [`WorldPos`] component that coexists with the
//! existing `f32` [`ce_scene::Transform`]. A [`FloatingOrigin`] tracks
//! the local player so that world positions can be downcast to
//! camera-relative f32 without losing precision even at galactic
//! distances.
//!
//! M5 scope: the coordinate layer only. Sector-traversal gameplay,
//! procedural galaxy generation, and planet terrain live in later
//! milestones.

pub mod origin;
pub mod pos;
pub mod rebase;
pub mod sector;

pub use origin::FloatingOrigin;
pub use pos::WorldPos;
pub use rebase::{rebase_origin_system, sync_transform_from_world_pos, LocalPlayer};
pub use sector::{Sector, SectorGraph, SectorId, SECTOR_SIZE_METERS};

use ce_app::{App, Plugin};
use ce_ecs::CoreStage;

/// Installs the galactic coordinate layer.
///
/// Resources inserted (only if not already present):
/// - [`FloatingOrigin`] at world origin with a 10 km rebase threshold.
/// - An empty [`SectorGraph`].
///
/// Systems registered:
/// - [`sync_transform_from_world_pos`] in `PreUpdate` (runs before
///   physics and rendering consume `Transform`).
/// - [`rebase_origin_system`] in `Last` (end of frame — avoids shifting
///   the origin mid-frame while other systems read it).
pub struct SpacePlugin;

impl Plugin for SpacePlugin {
    fn build(&self, app: &mut App) {
        if app.world.get_resource::<FloatingOrigin>().is_none() {
            app.insert_resource(FloatingOrigin::default());
        }
        if app.world.get_resource::<SectorGraph>().is_none() {
            app.insert_resource(SectorGraph::default());
        }
        app.add_system(CoreStage::PreUpdate, sync_transform_from_world_pos);
        app.add_system(CoreStage::Last, rebase_origin_system);
        log::info!("SpacePlugin loaded");
    }
}

#[cfg(test)]
mod plugin_tests {
    use super::*;

    #[test]
    fn plugin_inserts_defaults() {
        let mut app = App::new();
        app.add_plugin(SpacePlugin);
        assert!(app.world.get_resource::<FloatingOrigin>().is_some());
        assert!(app.world.get_resource::<SectorGraph>().is_some());
    }

    #[test]
    fn plugin_preserves_pre_inserted_resources() {
        let mut app = App::new();
        app.insert_resource(FloatingOrigin::new(WorldPos::new(1.0, 2.0, 3.0)));
        app.add_plugin(SpacePlugin);
        let o = app.world.get_resource::<FloatingOrigin>().unwrap();
        assert_eq!(o.center, WorldPos::new(1.0, 2.0, 3.0));
    }
}

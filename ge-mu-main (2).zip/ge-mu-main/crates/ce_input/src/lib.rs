//! Action mapping layer for ChemEngine.
//!
//! Applications declare abstract actions (`"move_forward"`, `"interact"`)
//! and bind them to keys, mouse buttons, gamepad buttons, or gamepad
//! axis directions. Gameplay systems query [`ActionStates`] instead of
//! reading raw inputs, which is what makes input remapping and
//! controller support a trivial swap later.
//!
//! M3 scope: the mapping layer plus a keyboard/mouse backend (via
//! `ce_window::InputState`) and an abstract [`GamepadState`]. A concrete
//! gamepad backend (gilrs, Steam Input) is deferred.

pub mod action;
pub mod gamepad;
pub mod map;
pub mod state;

pub use action::{Action, ActionState, InputBinding};
pub use gamepad::{GamepadAxis, GamepadButton, GamepadState};
pub use map::ActionMap;
pub use state::{compute_action_states, update_action_states, ActionStates};

use ce_app::{App, Plugin};
use ce_ecs::CoreStage;

/// Installs the default input resources and the action-resolution system.
///
/// - Inserts an empty [`ActionMap`] if one isn't already present.
/// - Always inserts a fresh [`ActionStates`] so systems can read it.
/// - Registers [`update_action_states`] in [`CoreStage::First`], before
///   any gameplay stage, so consumers see this frame's values.
///
/// Applications that want a gamepad backend should also insert a
/// [`GamepadState`] resource before this plugin runs and update it
/// per-frame from their chosen driver.
pub struct InputPlugin;

impl Plugin for InputPlugin {
    fn build(&self, app: &mut App) {
        if app.world.get_resource::<ActionMap>().is_none() {
            app.insert_resource(ActionMap::new());
        }
        app.insert_resource(ActionStates::new());
        app.add_system(CoreStage::First, update_action_states);
        log::info!("InputPlugin loaded");
    }
}

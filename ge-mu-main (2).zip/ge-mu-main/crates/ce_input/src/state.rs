//! Action-state computation.
//!
//! [`compute_action_states`] is a pure function that folds
//! [`ce_window::InputState`] + [`GamepadState`] + [`ActionMap`] into
//! [`ActionStates`]. [`update_action_states`] is the ECS system wrapper.

use std::collections::HashMap;

use ce_ecs::World;
use ce_window::input::InputState;

use crate::action::{Action, ActionState, InputBinding};
use crate::gamepad::GamepadState;
use crate::map::ActionMap;

/// Per-action resolved state for the current frame.
#[derive(Debug, Clone, Default)]
pub struct ActionStates {
    states: HashMap<Action, ActionState>,
}

impl ActionStates {
    pub fn new() -> Self {
        Self::default()
    }

    /// Returns the resolved state, or a zeroed default if the action
    /// has no bindings or hasn't been computed yet this frame.
    pub fn get(&self, action: &str) -> ActionState {
        self.states.get(action).copied().unwrap_or_default()
    }

    pub fn pressed(&self, action: &str) -> bool {
        self.get(action).pressed
    }

    pub fn just_pressed(&self, action: &str) -> bool {
        self.get(action).just_pressed
    }

    pub fn just_released(&self, action: &str) -> bool {
        self.get(action).just_released
    }

    pub fn value(&self, action: &str) -> f32 {
        self.get(action).value
    }

    pub fn iter(&self) -> impl Iterator<Item = (&Action, &ActionState)> {
        self.states.iter()
    }
}

/// Pure resolution: takes the inputs and a map, emits fresh states.
///
/// `gamepad` is optional so callers that never wire a gamepad backend
/// still get a meaningful result for keyboard/mouse bindings.
pub fn compute_action_states(
    map: &ActionMap,
    keyboard: &InputState,
    gamepad: Option<&GamepadState>,
) -> ActionStates {
    let mut out = ActionStates::new();
    for (action, bindings) in map.iter() {
        let mut state = ActionState::default();
        for binding in bindings {
            let (pressed, just_pressed, just_released, value) =
                resolve_binding(binding, keyboard, gamepad);
            if pressed {
                state.pressed = true;
            }
            if just_pressed {
                state.just_pressed = true;
            }
            if just_released {
                state.just_released = true;
            }
            if value > state.value {
                state.value = value;
            }
        }
        out.states.insert(action.clone(), state);
    }
    out
}

fn resolve_binding(
    binding: &InputBinding,
    keyboard: &InputState,
    gamepad: Option<&GamepadState>,
) -> (bool, bool, bool, f32) {
    match binding {
        InputBinding::Key(k) => (
            keyboard.is_key_pressed(*k),
            keyboard.is_key_just_pressed(*k),
            keyboard.is_key_just_released(*k),
            if keyboard.is_key_pressed(*k) {
                1.0
            } else {
                0.0
            },
        ),
        InputBinding::Mouse(b) => (
            keyboard.is_mouse_pressed(*b),
            keyboard.is_mouse_just_pressed(*b),
            // ce_window doesn't expose `is_mouse_just_released` yet;
            // treat as always false. Safe: systems that need it read
            // `just_pressed` on a "released" binding if one exists.
            false,
            if keyboard.is_mouse_pressed(*b) {
                1.0
            } else {
                0.0
            },
        ),
        InputBinding::GamepadButton(b) => match gamepad {
            Some(g) => (
                g.is_pressed(*b),
                g.is_just_pressed(*b),
                g.is_just_released(*b),
                if g.is_pressed(*b) { 1.0 } else { 0.0 },
            ),
            None => (false, false, false, 0.0),
        },
        InputBinding::GamepadAxisPositive(a) => match gamepad {
            Some(g) => {
                let v = g.axis(*a);
                let triggered = g.axis_triggered_positive(*a);
                (triggered, false, false, if triggered { v } else { 0.0 })
            }
            None => (false, false, false, 0.0),
        },
        InputBinding::GamepadAxisNegative(a) => match gamepad {
            Some(g) => {
                let v = g.axis(*a);
                let triggered = g.axis_triggered_negative(*a);
                (triggered, false, false, if triggered { -v } else { 0.0 })
            }
            None => (false, false, false, 0.0),
        },
    }
}

/// ECS system: pulls `ActionMap`, `InputState`, optional `GamepadState`,
/// and writes the resolved `ActionStates`.
///
/// Registered by [`crate::InputPlugin`] in `CoreStage::First`, ahead of
/// gameplay systems that consume actions in `Update`.
pub fn update_action_states(world: &mut World) {
    let map = match world.get_resource::<ActionMap>() {
        Some(m) => m.clone(),
        None => return,
    };
    let keyboard = match world.get_resource::<InputState>() {
        Some(k) => k.clone(),
        None => return,
    };
    let gamepad = world.get_resource::<GamepadState>().cloned();

    let states = compute_action_states(&map, &keyboard, gamepad.as_ref());
    world.insert_resource(states);
}

#[cfg(test)]
mod tests {
    use super::*;
    use ce_window::input::{KeyCode, MouseButton};

    use crate::action::InputBinding;
    use crate::gamepad::{GamepadAxis, GamepadButton, GamepadState};
    use crate::map::ActionMap;

    fn keyboard_only(keys: &[KeyCode]) -> InputState {
        let mut k = InputState::default();
        for key in keys {
            k.press_key(*key);
        }
        k
    }

    #[test]
    fn keyboard_binding_resolves_to_pressed() {
        let mut map = ActionMap::new();
        map.bind("move_forward", InputBinding::Key(KeyCode::W));

        let keyboard = keyboard_only(&[KeyCode::W]);
        let states = compute_action_states(&map, &keyboard, None);

        assert!(states.pressed("move_forward"));
        assert!(states.just_pressed("move_forward"));
        assert!((states.value("move_forward") - 1.0).abs() < 1e-6);
    }

    #[test]
    fn unbound_action_is_unpressed_by_default() {
        let map = ActionMap::new();
        let keyboard = keyboard_only(&[KeyCode::W]);
        let states = compute_action_states(&map, &keyboard, None);
        assert!(!states.pressed("anything"));
        assert_eq!(states.value("anything"), 0.0);
    }

    #[test]
    fn keyboard_and_gamepad_bindings_share_an_action() {
        // Either W on keyboard OR left stick forward should fire "move_forward".
        let mut map = ActionMap::new();
        map.bind("move_forward", InputBinding::Key(KeyCode::W))
            .bind(
                "move_forward",
                InputBinding::GamepadAxisNegative(GamepadAxis::LeftStickY),
            );

        // Keyboard only.
        let keyboard = keyboard_only(&[KeyCode::W]);
        let states = compute_action_states(&map, &keyboard, None);
        assert!(states.pressed("move_forward"));

        // Gamepad only (stick pushed to -0.8; deadzone is 0.3 by default).
        let keyboard = InputState::default();
        let mut pad = GamepadState::new();
        pad.set_axis(GamepadAxis::LeftStickY, -0.8);
        let states = compute_action_states(&map, &keyboard, Some(&pad));
        assert!(states.pressed("move_forward"));
        assert!((states.value("move_forward") - 0.8).abs() < 1e-6);
    }

    #[test]
    fn gamepad_axis_below_deadzone_does_not_fire() {
        let mut map = ActionMap::new();
        map.bind(
            "move_forward",
            InputBinding::GamepadAxisNegative(GamepadAxis::LeftStickY),
        );

        let mut pad = GamepadState::new();
        // Below the default deadzone of 0.3.
        pad.set_axis(GamepadAxis::LeftStickY, -0.1);

        let states = compute_action_states(&map, &InputState::default(), Some(&pad));
        assert!(!states.pressed("move_forward"));
        assert_eq!(states.value("move_forward"), 0.0);
    }

    #[test]
    fn gamepad_button_binding_reports_just_pressed() {
        let mut map = ActionMap::new();
        map.bind("jump", InputBinding::GamepadButton(GamepadButton::South));

        let mut pad = GamepadState::new();
        pad.press_button(GamepadButton::South);

        let states = compute_action_states(&map, &InputState::default(), Some(&pad));
        let s = states.get("jump");
        assert!(s.pressed);
        assert!(s.just_pressed);
        assert_eq!(s.value, 1.0);
    }

    #[test]
    fn multiple_bindings_merge_correctly() {
        // "fire" bound to both mouse left and gamepad RT axis.
        let mut map = ActionMap::new();
        map.bind("fire", InputBinding::Mouse(MouseButton::Left))
            .bind(
                "fire",
                InputBinding::GamepadAxisPositive(GamepadAxis::RightTrigger),
            );

        let mut keyboard = InputState::default();
        keyboard.press_mouse(MouseButton::Left);
        let mut pad = GamepadState::new();
        pad.set_axis(GamepadAxis::RightTrigger, 0.9);

        let states = compute_action_states(&map, &keyboard, Some(&pad));
        // Should be pressed and take max value (0.9 from axis, 1.0 from mouse).
        let s = states.get("fire");
        assert!(s.pressed);
        assert!((s.value - 1.0).abs() < 1e-6);
    }

    #[test]
    fn update_system_writes_states_into_world() {
        use ce_ecs::World;

        let mut world = World::new();
        let mut map = ActionMap::new();
        map.bind("interact", InputBinding::Key(KeyCode::E));
        world.insert_resource(map);

        let mut k = InputState::default();
        k.press_key(KeyCode::E);
        world.insert_resource(k);

        update_action_states(&mut world);

        let states = world.get_resource::<ActionStates>().expect("states");
        assert!(states.pressed("interact"));
    }

    #[test]
    fn update_system_is_noop_without_action_map() {
        use ce_ecs::World;

        let mut world = World::new();
        world.insert_resource(InputState::default());
        // No ActionMap → early return, no panic.
        update_action_states(&mut world);
        assert!(world.get_resource::<ActionStates>().is_none());
    }
}

//! Device-agnostic gamepad state.
//!
//! `ce_input` does not own a gamepad backend. Applications (or a later
//! milestone's `gilrs_backend`) populate [`GamepadState`] each frame; the
//! mapping layer only reads from it.
//!
//! Keeping the backend out of this crate keeps it testable: unit tests
//! and headless CI can poke the state directly without opening an OS
//! gamepad context.

use std::collections::{HashMap, HashSet};

/// Standard digital gamepad buttons.
///
/// Names follow Xbox/XInput conventions (`South` = A, `East` = B, etc.).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum GamepadButton {
    South,
    East,
    North,
    West,
    LeftShoulder,
    RightShoulder,
    LeftTrigger,
    RightTrigger,
    Start,
    Select,
    LeftStick,
    RightStick,
    DPadUp,
    DPadDown,
    DPadLeft,
    DPadRight,
}

/// Analog gamepad axes. Values are expected in `[-1.0, 1.0]` for sticks
/// and `[0.0, 1.0]` for triggers.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum GamepadAxis {
    LeftStickX,
    LeftStickY,
    RightStickX,
    RightStickY,
    LeftTrigger,
    RightTrigger,
}

/// Current frame's gamepad state.
///
/// Inserted as an ECS resource. A backend (e.g. a future `gilrs` wrapper)
/// is expected to call [`GamepadState::begin_frame`] once per tick,
/// followed by any number of `press_button` / `release_button` /
/// `set_axis` calls. Consumers then read via the `is_*` and `axis`
/// methods.
#[derive(Debug, Clone, Default)]
pub struct GamepadState {
    buttons: HashSet<GamepadButton>,
    just_pressed: HashSet<GamepadButton>,
    just_released: HashSet<GamepadButton>,
    axes: HashMap<GamepadAxis, f32>,
    /// Minimum absolute axis value below which a sample is treated as
    /// zero by queries that compare to a threshold.
    pub deadzone: f32,
}

impl GamepadState {
    /// Axis threshold used by [`axis_triggered_positive`] and
    /// [`axis_triggered_negative`] when resolving an analog binding to
    /// a digital "pressed" event.
    pub const DEFAULT_DEADZONE: f32 = 0.3;

    pub fn new() -> Self {
        Self {
            deadzone: Self::DEFAULT_DEADZONE,
            ..Self::default()
        }
    }

    /// Clears `just_pressed` / `just_released`. Axes are left alone; the
    /// backend is responsible for refreshing them to the driver's latest
    /// values every frame.
    pub fn begin_frame(&mut self) {
        self.just_pressed.clear();
        self.just_released.clear();
    }

    pub fn press_button(&mut self, b: GamepadButton) {
        if self.buttons.insert(b) {
            self.just_pressed.insert(b);
        }
    }

    pub fn release_button(&mut self, b: GamepadButton) {
        if self.buttons.remove(&b) {
            self.just_released.insert(b);
        }
    }

    pub fn set_axis(&mut self, a: GamepadAxis, value: f32) {
        self.axes.insert(a, value);
    }

    #[inline]
    pub fn is_pressed(&self, b: GamepadButton) -> bool {
        self.buttons.contains(&b)
    }

    #[inline]
    pub fn is_just_pressed(&self, b: GamepadButton) -> bool {
        self.just_pressed.contains(&b)
    }

    #[inline]
    pub fn is_just_released(&self, b: GamepadButton) -> bool {
        self.just_released.contains(&b)
    }

    /// Returns the raw axis value, or `0.0` if the backend never set one.
    #[inline]
    pub fn axis(&self, a: GamepadAxis) -> f32 {
        self.axes.get(&a).copied().unwrap_or(0.0)
    }

    /// Returns `true` if the axis is deflected beyond `+deadzone`.
    pub fn axis_triggered_positive(&self, a: GamepadAxis) -> bool {
        self.axis(a) > self.deadzone
    }

    /// Returns `true` if the axis is deflected beyond `-deadzone`.
    pub fn axis_triggered_negative(&self, a: GamepadAxis) -> bool {
        self.axis(a) < -self.deadzone
    }
}

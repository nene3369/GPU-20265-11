//! Action abstractions.
//!
//! An [`Action`] is a named gameplay intent (e.g. `"move_forward"`,
//! `"interact"`). An [`InputBinding`] is one concrete input (a key, a
//! mouse button, a gamepad button, or a gamepad axis direction) that
//! produces the action. [`ActionState`] is the resolved per-frame result.

use ce_window::input::{KeyCode, MouseButton};

use crate::gamepad::{GamepadAxis, GamepadButton};

/// Identifier for an action. Owned `String` keeps the map resizable at
/// runtime (for e.g. save/load of key remaps) without requiring callers
/// to intern strings manually.
pub type Action = String;

/// One physical input that can fire an action.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum InputBinding {
    Key(KeyCode),
    Mouse(MouseButton),
    GamepadButton(GamepadButton),
    /// Gamepad axis beyond `+deadzone` (e.g. right on the left stick).
    GamepadAxisPositive(GamepadAxis),
    /// Gamepad axis beyond `-deadzone` (e.g. left on the left stick).
    GamepadAxisNegative(GamepadAxis),
}

/// Per-frame resolution of an action across all its bindings.
///
/// `value` is the largest magnitude reported by any bound source this
/// frame: 0.0 when nothing fires, 1.0 for a digital press, or the raw
/// axis magnitude for analog bindings. Callers that just want digital
/// semantics can read [`ActionState::pressed`].
#[derive(Debug, Clone, Copy, Default, PartialEq)]
pub struct ActionState {
    pub pressed: bool,
    pub just_pressed: bool,
    pub just_released: bool,
    pub value: f32,
}

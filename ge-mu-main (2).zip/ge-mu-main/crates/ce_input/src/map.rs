//! Declarative mapping from actions to their input bindings.

use std::collections::HashMap;

use crate::action::{Action, InputBinding};

/// Maps each [`Action`] to one or more [`InputBinding`]s. An action fires
/// if *any* of its bindings fires this frame.
#[derive(Debug, Clone, Default)]
pub struct ActionMap {
    entries: HashMap<Action, Vec<InputBinding>>,
}

impl ActionMap {
    pub fn new() -> Self {
        Self::default()
    }

    /// Adds one binding to `action`. Multiple calls accumulate, so
    /// `bind("jump", Space)` then `bind("jump", GamepadSouth)` yields
    /// both bindings.
    pub fn bind(&mut self, action: impl Into<Action>, binding: InputBinding) -> &mut Self {
        self.entries.entry(action.into()).or_default().push(binding);
        self
    }

    /// Replaces all bindings for `action` with a new list.
    pub fn set_bindings(
        &mut self,
        action: impl Into<Action>,
        bindings: Vec<InputBinding>,
    ) -> &mut Self {
        self.entries.insert(action.into(), bindings);
        self
    }

    /// All bindings registered for `action`, or `&[]` if none.
    pub fn bindings(&self, action: &str) -> &[InputBinding] {
        self.entries
            .get(action)
            .map(Vec::as_slice)
            .unwrap_or_default()
    }

    /// Iterator over all `(action, bindings)` pairs.
    pub fn iter(&self) -> impl Iterator<Item = (&Action, &[InputBinding])> {
        self.entries.iter().map(|(k, v)| (k, v.as_slice()))
    }

    pub fn actions(&self) -> impl Iterator<Item = &Action> {
        self.entries.keys()
    }

    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    pub fn len(&self) -> usize {
        self.entries.len()
    }
}

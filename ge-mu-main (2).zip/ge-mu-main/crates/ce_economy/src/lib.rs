//! `ce_economy` — credits, markets, and supply/demand pricing.
//!
//! M10 scope: data and pure functions for commodity trading. One
//! `Market` per station; each has a set of [`MarketEntry`] values
//! driven by a `PriceModel`. Player transacts via `buy_from_market`
//! and `sell_to_market` — both atomic and validation-first so no
//! state mutates on failure.

pub mod market;
pub mod price;
pub mod wallet;

pub use market::{
    buy_from_market, restock_market_entry, sell_to_market, Market, MarketEntry, TradeError,
};
pub use price::{spread_with_mood, PriceModel, DEFAULT_SPREAD};
pub use wallet::{Credits, Wallet, WalletError};

use ce_app::{App, Plugin};

/// Installs a default [`Wallet`] resource (0 credits) if none is
/// present. Market components are created per-station by gameplay code.
pub struct EconomyPlugin;

impl Plugin for EconomyPlugin {
    fn build(&self, app: &mut App) {
        if app.world.get_resource::<Wallet>().is_none() {
            app.insert_resource(Wallet::default());
        }
        log::info!("EconomyPlugin loaded");
    }
}

#[cfg(test)]
mod plugin_tests {
    use super::*;

    #[test]
    fn plugin_installs_wallet_resource() {
        let mut app = App::new();
        app.add_plugin(EconomyPlugin);
        let w = app.world.get_resource::<Wallet>().unwrap();
        assert_eq!(w.credits, 0);
    }

    #[test]
    fn plugin_preserves_preinserted_wallet() {
        let mut app = App::new();
        app.insert_resource(Wallet::new(5_000));
        app.add_plugin(EconomyPlugin);
        assert_eq!(app.world.get_resource::<Wallet>().unwrap().credits, 5_000);
    }
}

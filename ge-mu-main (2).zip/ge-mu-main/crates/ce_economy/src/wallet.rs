//! Currency and player wallet.
//!
//! Credits are tracked as integer "cents" to avoid float rounding in
//! accounting. 100 credits = 1.00 CR at the UI layer.

/// Scalar currency unit. One credit = 100 of these "cents".
pub type Credits = i64;

/// Player / faction wallet.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct Wallet {
    pub credits: Credits,
}

impl Wallet {
    pub fn new(credits: Credits) -> Self {
        Self { credits }
    }

    /// Adds `amount` to the wallet. Negative amounts are treated as
    /// expenses and refuse to put the balance below zero.
    pub fn credit(&mut self, amount: Credits) -> Result<(), WalletError> {
        if amount.is_negative() && self.credits + amount < 0 {
            return Err(WalletError::Insufficient);
        }
        self.credits = self.credits.saturating_add(amount);
        Ok(())
    }

    /// Charges `amount`. Fails if the wallet has less than that.
    pub fn debit(&mut self, amount: Credits) -> Result<(), WalletError> {
        if amount < 0 {
            return Err(WalletError::NegativeDebit);
        }
        if self.credits < amount {
            return Err(WalletError::Insufficient);
        }
        self.credits -= amount;
        Ok(())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum WalletError {
    /// Wallet balance is less than requested debit.
    Insufficient,
    /// Debit amount cannot be negative — callers should use `credit`.
    NegativeDebit,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn new_wallet_has_initial_balance() {
        let w = Wallet::new(500);
        assert_eq!(w.credits, 500);
    }

    #[test]
    fn credit_adds_to_balance() {
        let mut w = Wallet::new(100);
        w.credit(50).unwrap();
        assert_eq!(w.credits, 150);
    }

    #[test]
    fn debit_removes_and_returns_ok() {
        let mut w = Wallet::new(100);
        w.debit(30).unwrap();
        assert_eq!(w.credits, 70);
    }

    #[test]
    fn debit_more_than_balance_fails_without_mutation() {
        let mut w = Wallet::new(20);
        assert_eq!(w.debit(30), Err(WalletError::Insufficient));
        assert_eq!(w.credits, 20);
    }

    #[test]
    fn negative_debit_is_rejected() {
        let mut w = Wallet::new(100);
        assert_eq!(w.debit(-10), Err(WalletError::NegativeDebit));
    }

    #[test]
    fn negative_credit_below_zero_is_rejected() {
        let mut w = Wallet::new(5);
        assert_eq!(w.credit(-10), Err(WalletError::Insufficient));
        assert_eq!(w.credits, 5);
    }
}

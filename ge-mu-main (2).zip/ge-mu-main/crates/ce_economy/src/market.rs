//! Per-station market — commodity stock + price formation + trade.

use std::collections::HashMap;

use ce_gameplay::{Inventory, InventoryError, ItemId};

use crate::price::PriceModel;
use crate::wallet::{Credits, Wallet, WalletError};

/// One tradable commodity slot on a market.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct MarketEntry {
    /// Units the station currently holds.
    pub stock: u32,
    /// Target stock level used by the price curve.
    pub equilibrium: u32,
    pub price_model: PriceModel,
}

impl MarketEntry {
    pub fn new(stock: u32, equilibrium: u32, price_model: PriceModel) -> Self {
        Self {
            stock,
            equilibrium,
            price_model,
        }
    }

    pub fn buy_price(&self) -> Credits {
        self.price_model.buy_price(self.stock, self.equilibrium)
    }

    pub fn sell_price(&self) -> Credits {
        self.price_model.sell_price(self.stock, self.equilibrium)
    }
}

/// Nudges `entry.stock` toward `entry.equilibrium` by
/// `rate_per_second * dt` units (rounded down). Converges monotonically
/// — never overshoots equilibrium, and stock already above equilibrium
/// is left alone (consumption through `buy_from_market` is what brings
/// it back down). `rate_per_second <= 0` or `dt <= 0` are no-ops.
///
/// Designed to be called both per-frame during live play and with a
/// large synthetic `dt` (e.g. 1800 s) for "pre-existing world" seeding.
pub fn restock_market_entry(entry: &mut MarketEntry, rate_per_second: f32, dt: f32) {
    if rate_per_second <= 0.0 || dt <= 0.0 || !dt.is_finite() || !rate_per_second.is_finite() {
        return;
    }
    if entry.stock >= entry.equilibrium {
        return;
    }
    let delta = (rate_per_second * dt).floor() as u64;
    if delta == 0 {
        return;
    }
    let headroom = (entry.equilibrium - entry.stock) as u64;
    let applied = delta.min(headroom) as u32;
    entry.stock = entry.stock.saturating_add(applied);
}

/// A station's set of tradable commodities. Attached as a component to
/// the station entity.
#[derive(Debug, Clone, Default)]
pub struct Market {
    entries: HashMap<ItemId, MarketEntry>,
}

impl Market {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn insert(&mut self, id: ItemId, entry: MarketEntry) {
        self.entries.insert(id, entry);
    }

    pub fn get(&self, id: ItemId) -> Option<&MarketEntry> {
        self.entries.get(&id)
    }

    /// Mutable handle to one entry, for gameplay layers that need to
    /// nudge fields in-place (e.g. apply a one-off spread adjustment
    /// under the world's mood before reverting). Returns `None` if
    /// the commodity isn't listed.
    pub fn entry_mut(&mut self, id: ItemId) -> Option<&mut MarketEntry> {
        self.entries.get_mut(&id)
    }

    pub fn entries(&self) -> impl Iterator<Item = (&ItemId, &MarketEntry)> {
        self.entries.iter()
    }

    pub fn len(&self) -> usize {
        self.entries.len()
    }

    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    /// Total cost to buy `count` units at the current buy price.
    /// Returns `None` if the commodity isn't listed.
    pub fn quote_buy(&self, id: ItemId, count: u32) -> Option<Credits> {
        let entry = self.entries.get(&id)?;
        Some(entry.buy_price() * count as Credits)
    }

    pub fn quote_sell(&self, id: ItemId, count: u32) -> Option<Credits> {
        let entry = self.entries.get(&id)?;
        Some(entry.sell_price() * count as Credits)
    }
}

/// Why a trade was rejected.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TradeError {
    /// Commodity is not listed at this station.
    NotListed,
    /// Station's stock is below the requested count.
    MarketOutOfStock,
    /// Player wallet can't cover the cost.
    InsufficientCredits,
    /// Player inventory has no room for the purchase.
    InventoryFull,
    /// Player doesn't have enough of the commodity to sell.
    NotEnoughToSell,
    /// Count of zero is a no-op and not allowed.
    ZeroCount,
}

impl From<InventoryError> for TradeError {
    fn from(err: InventoryError) -> Self {
        match err {
            InventoryError::OverCapacity => TradeError::InventoryFull,
            InventoryError::NotEnough => TradeError::NotEnoughToSell,
        }
    }
}

impl From<WalletError> for TradeError {
    fn from(err: WalletError) -> Self {
        match err {
            WalletError::Insufficient => TradeError::InsufficientCredits,
            WalletError::NegativeDebit => TradeError::ZeroCount, // unreachable in paths below
        }
    }
}

/// Buys `count` units of `id` from `market` into `inventory`, debiting
/// `wallet`. Atomic — on any failure no state is mutated.
pub fn buy_from_market(
    market: &mut Market,
    wallet: &mut Wallet,
    inventory: &mut Inventory,
    id: ItemId,
    count: u32,
) -> Result<Credits, TradeError> {
    if count == 0 {
        return Err(TradeError::ZeroCount);
    }
    let entry = market.entries.get(&id).ok_or(TradeError::NotListed)?;
    if entry.stock < count {
        return Err(TradeError::MarketOutOfStock);
    }
    let total = entry.buy_price() * count as Credits;
    if wallet.credits < total {
        return Err(TradeError::InsufficientCredits);
    }
    if inventory.remaining() < count {
        return Err(TradeError::InventoryFull);
    }

    // Apply in an order that's easy to roll back, though validation
    // above already guarantees success.
    wallet.debit(total)?;
    // Inventory add is validated to fit.
    inventory.add(id, count).map_err(TradeError::from)?;
    // SAFETY: entry was found above.
    if let Some(e) = market.entries.get_mut(&id) {
        e.stock -= count;
    }
    Ok(total)
}

/// Sells `count` units of `id` from `inventory` to `market`, crediting
/// `wallet`. Atomic.
pub fn sell_to_market(
    market: &mut Market,
    wallet: &mut Wallet,
    inventory: &mut Inventory,
    id: ItemId,
    count: u32,
) -> Result<Credits, TradeError> {
    if count == 0 {
        return Err(TradeError::ZeroCount);
    }
    let entry = market.entries.get(&id).ok_or(TradeError::NotListed)?;
    if inventory.count(id) < count {
        return Err(TradeError::NotEnoughToSell);
    }
    let payout = entry.sell_price() * count as Credits;

    inventory.remove(id, count).map_err(TradeError::from)?;
    wallet.credit(payout).map_err(TradeError::from)?;
    if let Some(e) = market.entries.get_mut(&id) {
        e.stock = e.stock.saturating_add(count);
    }
    Ok(payout)
}

#[cfg(test)]
mod tests {
    use super::*;

    const IRON: ItemId = ItemId::new("iron_ore");
    const WATER: ItemId = ItemId::new("water");

    fn stocked_market() -> Market {
        let mut m = Market::new();
        m.insert(IRON, MarketEntry::new(100, 100, PriceModel::new(50, 1.0)));
        m
    }

    #[test]
    fn restock_nudges_stock_toward_equilibrium() {
        let mut e = MarketEntry::new(100, 200, PriceModel::new(50, 1.0));
        restock_market_entry(&mut e, 0.5, 60.0); // 30 units
        assert_eq!(e.stock, 130);
    }

    #[test]
    fn restock_stops_at_equilibrium_no_overshoot_on_huge_dt() {
        let mut e = MarketEntry::new(10, 200, PriceModel::new(50, 1.0));
        restock_market_entry(&mut e, 10.0, 10_000.0); // would be 100_000 units
        assert_eq!(e.stock, 200);
    }

    #[test]
    fn restock_zero_rate_is_noop() {
        let mut e = MarketEntry::new(50, 200, PriceModel::new(50, 1.0));
        restock_market_entry(&mut e, 0.0, 1800.0);
        assert_eq!(e.stock, 50);
    }

    #[test]
    fn restock_negative_dt_is_noop() {
        let mut e = MarketEntry::new(50, 200, PriceModel::new(50, 1.0));
        restock_market_entry(&mut e, 1.0, -60.0);
        assert_eq!(e.stock, 50);
    }

    #[test]
    fn restock_preserves_above_equilibrium_stock() {
        // Stock already above equilibrium should not be pulled back by
        // restock — trades are the only thing that removes it.
        let mut e = MarketEntry::new(300, 200, PriceModel::new(50, 1.0));
        restock_market_entry(&mut e, 1.0, 60.0);
        assert_eq!(e.stock, 300);
    }

    #[test]
    fn market_buy_sell_prices_reflect_stock() {
        let m = stocked_market();
        let e = m.get(IRON).unwrap();
        assert_eq!(e.buy_price(), 50);
        assert_eq!(e.sell_price(), 40); // 50 * 0.8 = 40
    }

    #[test]
    fn buy_succeeds_and_updates_all_sides() {
        let mut market = stocked_market();
        let mut wallet = Wallet::new(1000);
        let mut inv = Inventory::new(100);

        let total = buy_from_market(&mut market, &mut wallet, &mut inv, IRON, 5).unwrap();
        assert_eq!(total, 250);
        assert_eq!(wallet.credits, 750);
        assert_eq!(inv.count(IRON), 5);
        assert_eq!(market.get(IRON).unwrap().stock, 95);
    }

    #[test]
    fn buy_with_insufficient_credits_rejects_atomically() {
        let mut market = stocked_market();
        let mut wallet = Wallet::new(100);
        let mut inv = Inventory::new(100);
        let err = buy_from_market(&mut market, &mut wallet, &mut inv, IRON, 5).err();
        assert_eq!(err, Some(TradeError::InsufficientCredits));
        assert_eq!(wallet.credits, 100);
        assert_eq!(inv.count(IRON), 0);
        assert_eq!(market.get(IRON).unwrap().stock, 100);
    }

    #[test]
    fn buy_rejects_when_inventory_would_overflow() {
        let mut market = stocked_market();
        let mut wallet = Wallet::new(100_000);
        let mut inv = Inventory::new(3);
        let err = buy_from_market(&mut market, &mut wallet, &mut inv, IRON, 5).err();
        assert_eq!(err, Some(TradeError::InventoryFull));
        assert_eq!(wallet.credits, 100_000);
        assert_eq!(market.get(IRON).unwrap().stock, 100);
    }

    #[test]
    fn buy_unlisted_commodity_rejects() {
        let mut market = stocked_market();
        let mut wallet = Wallet::new(10_000);
        let mut inv = Inventory::new(100);
        let err = buy_from_market(&mut market, &mut wallet, &mut inv, WATER, 1).err();
        assert_eq!(err, Some(TradeError::NotListed));
    }

    #[test]
    fn buy_zero_is_rejected() {
        let mut market = stocked_market();
        let mut wallet = Wallet::new(10_000);
        let mut inv = Inventory::new(100);
        let err = buy_from_market(&mut market, &mut wallet, &mut inv, IRON, 0).err();
        assert_eq!(err, Some(TradeError::ZeroCount));
    }

    #[test]
    fn sell_succeeds_and_updates_all_sides() {
        let mut market = stocked_market();
        let mut wallet = Wallet::new(0);
        let mut inv = Inventory::new(100);
        inv.add(IRON, 10).unwrap();

        let payout = sell_to_market(&mut market, &mut wallet, &mut inv, IRON, 10).unwrap();
        assert_eq!(payout, 400); // 10 * 40 at stock=100 equilibrium=100
        assert_eq!(wallet.credits, 400);
        assert_eq!(inv.count(IRON), 0);
        assert_eq!(market.get(IRON).unwrap().stock, 110);
    }

    #[test]
    fn sell_rejects_when_player_short_on_inventory() {
        let mut market = stocked_market();
        let mut wallet = Wallet::new(0);
        let mut inv = Inventory::new(100);
        inv.add(IRON, 3).unwrap();
        let err = sell_to_market(&mut market, &mut wallet, &mut inv, IRON, 10).err();
        assert_eq!(err, Some(TradeError::NotEnoughToSell));
    }

    #[test]
    fn buying_pushes_price_up_toward_scarcity() {
        let mut market = stocked_market();
        let buy_before = market.get(IRON).unwrap().buy_price();
        let mut wallet = Wallet::new(1_000_000);
        let mut inv = Inventory::new(100_000);
        // Drain 90 units, leaving 10 in stock (eq 100 → stock/eq 0.1).
        buy_from_market(&mut market, &mut wallet, &mut inv, IRON, 90).unwrap();
        let buy_after = market.get(IRON).unwrap().buy_price();
        assert!(buy_after > buy_before, "scarcity should raise buy price");
    }

    #[test]
    fn selling_oversupplies_and_lowers_price() {
        let mut market = stocked_market();
        let sell_before = market.get(IRON).unwrap().sell_price();
        let mut wallet = Wallet::new(0);
        let mut inv = Inventory::new(10_000);
        inv.add(IRON, 150).unwrap();
        sell_to_market(&mut market, &mut wallet, &mut inv, IRON, 150).unwrap();
        let sell_after = market.get(IRON).unwrap().sell_price();
        assert!(
            sell_after < sell_before,
            "oversupply should lower sell price: before={sell_before} after={sell_after}"
        );
    }

    #[test]
    fn quote_buy_and_sell_return_totals() {
        let m = stocked_market();
        assert_eq!(m.quote_buy(IRON, 3), Some(150));
        assert_eq!(m.quote_sell(IRON, 3), Some(120));
        assert_eq!(m.quote_buy(WATER, 3), None);
    }

    #[test]
    fn buy_more_than_stocked_rejects() {
        let mut market = stocked_market();
        let mut wallet = Wallet::new(1_000_000);
        let mut inv = Inventory::new(100_000);
        let err = buy_from_market(&mut market, &mut wallet, &mut inv, IRON, 500).err();
        assert_eq!(err, Some(TradeError::MarketOutOfStock));
    }
}

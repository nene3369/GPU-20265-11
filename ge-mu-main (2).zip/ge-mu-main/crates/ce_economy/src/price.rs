//! Supply/demand price formation.
//!
//! For a given commodity the market tracks current `stock` and an
//! `equilibrium` level. Price responds linearly to how far stock is
//! from equilibrium, scaled by `elasticity`. Buy price (market sells to
//! player) and sell price (market buys from player) differ by a fixed
//! spread to give the station a margin.

use crate::wallet::Credits;

/// Default bid-ask spread as a fraction of unit price. Value `0.2`
/// means the station pays the player 80% of what it charges.
pub const DEFAULT_SPREAD: f32 = 0.2;

/// Pricing curve for one commodity at one station.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct PriceModel {
    /// Price in credit-cents when stock equals equilibrium.
    pub base_price: Credits,
    /// How strongly price reacts to scarcity. `0.0` = flat price;
    /// `1.0` = empty stock doubles price; `2.0` = empty stock triples.
    pub elasticity: f32,
    /// Bid-ask spread as a fraction of the unit price.
    pub spread: f32,
}

impl PriceModel {
    pub fn new(base_price: Credits, elasticity: f32) -> Self {
        Self {
            base_price,
            elasticity,
            spread: DEFAULT_SPREAD,
        }
    }

    /// Price multiplier given current stock vs equilibrium.
    ///
    /// `r = stock / equilibrium`:
    /// - `r = 0`   → multiplier `1 + elasticity` (scarcity premium)
    /// - `r = 1`   → multiplier `1.0`             (equilibrium)
    /// - `r = 2`   → multiplier `max(0, 1 - elasticity)` (glut)
    pub fn multiplier(&self, stock: u32, equilibrium: u32) -> f32 {
        if equilibrium == 0 {
            return 1.0;
        }
        let r = (stock as f32) / (equilibrium as f32);
        (1.0 + self.elasticity * (1.0 - r)).max(0.0)
    }

    /// Raw unit price given stock. Used for book-keeping and
    /// as the basis for buy / sell prices.
    pub fn unit_price(&self, stock: u32, equilibrium: u32) -> Credits {
        let mult = self.multiplier(stock, equilibrium);
        ((self.base_price as f64) * (mult as f64)).round() as Credits
    }

    /// Price the player pays to buy one unit from the market.
    pub fn buy_price(&self, stock: u32, equilibrium: u32) -> Credits {
        self.unit_price(stock, equilibrium)
    }

    /// Price the player receives for selling one unit to the market.
    pub fn sell_price(&self, stock: u32, equilibrium: u32) -> Credits {
        let p = self.unit_price(stock, equilibrium);
        ((p as f64) * (1.0 - self.spread as f64)).round() as Credits
    }

    /// Sell price using a `market_mood`-adjusted spread. `mood` is
    /// expected in `[0.0, 1.0]` — `0.5` is the neutral baseline (the
    /// regular [`Self::sell_price`] result), lower values widen the
    /// spread (stations hedge when the world feels bad), higher
    /// values tighten it. The scaling is clamped so the spread never
    /// exceeds `0.6` nor falls below `0.05`.
    pub fn sell_price_with_mood(&self, stock: u32, equilibrium: u32, mood: f32) -> Credits {
        let adjusted = spread_with_mood(self.spread, mood);
        let p = self.unit_price(stock, equilibrium);
        ((p as f64) * (1.0 - adjusted as f64)).round() as Credits
    }
}

/// Returns `base_spread` scaled by the current market mood. `mood`
/// is clamped to `[0.0, 1.0]`; at `0.5` the function is the
/// identity. The result is further clamped to `[0.05, 0.6]` so a
/// saturated mood can't zero the station's margin or blow it past
/// reasonable levels.
pub fn spread_with_mood(base_spread: f32, mood: f32) -> f32 {
    let m = if mood.is_finite() {
        mood.clamp(0.0, 1.0)
    } else {
        0.5
    };
    // (1 - mood) in [0, 1], centred at 0.5 → delta in [-0.5, +0.5].
    // Scale by 0.6 so extreme moods shift the spread by ±30% of base.
    let scale = 1.0 + ((1.0 - m) - 0.5) * 0.6 * 2.0;
    (base_spread * scale).clamp(0.05, 0.6)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn base_model() -> PriceModel {
        PriceModel::new(100, 1.0)
    }

    #[test]
    fn multiplier_at_equilibrium_is_one() {
        let m = base_model();
        assert!((m.multiplier(100, 100) - 1.0).abs() < 1e-5);
    }

    #[test]
    fn multiplier_scales_up_when_stock_empty() {
        let m = base_model(); // elasticity = 1.0
        assert!((m.multiplier(0, 100) - 2.0).abs() < 1e-5);
    }

    #[test]
    fn multiplier_scales_down_when_oversupply() {
        let m = base_model();
        // stock = 2 * eq, elasticity 1.0 → multiplier 0 (floor)
        assert_eq!(m.multiplier(200, 100), 0.0);
    }

    #[test]
    fn unit_price_tracks_multiplier() {
        let m = base_model();
        assert_eq!(m.unit_price(100, 100), 100);
        assert_eq!(m.unit_price(0, 100), 200);
        assert_eq!(m.unit_price(200, 100), 0);
    }

    #[test]
    fn sell_price_is_less_than_buy_price() {
        let m = base_model();
        let buy = m.buy_price(50, 100);
        let sell = m.sell_price(50, 100);
        assert!(sell < buy);
        // 20% default spread.
        assert!((sell as f32 / buy as f32 - 0.8).abs() < 0.01);
    }

    #[test]
    fn zero_equilibrium_returns_base_price() {
        let m = base_model();
        assert_eq!(m.unit_price(5, 0), 100);
    }

    #[test]
    fn zero_elasticity_keeps_price_flat_everywhere() {
        let m = PriceModel::new(100, 0.0);
        assert_eq!(m.unit_price(0, 100), 100);
        assert_eq!(m.unit_price(500, 100), 100);
    }

    #[test]
    fn spread_with_neutral_mood_is_identity() {
        assert!((spread_with_mood(0.2, 0.5) - 0.2).abs() < 1e-5);
    }

    #[test]
    fn pessimistic_mood_widens_spread() {
        let wide = spread_with_mood(0.2, 0.0);
        let base = spread_with_mood(0.2, 0.5);
        assert!(wide > base);
    }

    #[test]
    fn optimistic_mood_tightens_spread() {
        let tight = spread_with_mood(0.2, 1.0);
        let base = spread_with_mood(0.2, 0.5);
        assert!(tight < base);
    }

    #[test]
    fn spread_is_clamped_within_safe_bounds() {
        // Very small base + optimistic mood can't go below 0.05.
        assert!(spread_with_mood(0.01, 1.0) >= 0.05);
        // Very large base + pessimistic mood can't exceed 0.6.
        assert!(spread_with_mood(1.0, 0.0) <= 0.6);
    }

    #[test]
    fn sell_price_with_mood_matches_regular_at_neutral() {
        let m = base_model();
        assert_eq!(m.sell_price(50, 100), m.sell_price_with_mood(50, 100, 0.5),);
    }

    #[test]
    fn sell_price_with_pessimistic_mood_pays_less() {
        let m = base_model();
        assert!(m.sell_price_with_mood(50, 100, 0.0) < m.sell_price(50, 100));
    }
}

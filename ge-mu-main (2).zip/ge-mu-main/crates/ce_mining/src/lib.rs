//! `ce_mining` — resource nodes and mining beam.
//!
//! M-style resource extraction: a `ResourceNode` sits in space with a
//! yield item and remaining units; a `MiningBeam` on the ship extracts
//! from it over time when in range. All pure data + pure-function tick
//! so the same code runs on server and client.

pub mod beam;
pub mod node;

pub use beam::{mine_tick, MineResult, MiningBeam};
pub use node::{NodeId, ResourceNode};

use ce_app::{App, Plugin};

pub struct MiningPlugin;

impl Plugin for MiningPlugin {
    fn build(&self, _app: &mut App) {
        log::info!("MiningPlugin loaded (data layer only)");
    }
}

#[cfg(test)]
mod plugin_tests {
    use super::*;

    #[test]
    fn plugin_adds_cleanly() {
        let mut app = App::new();
        app.add_plugin(MiningPlugin);
    }
}

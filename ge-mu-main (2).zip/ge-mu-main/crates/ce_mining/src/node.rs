//! Resource nodes — asteroid chunks, ore veins, gas clouds.

use ce_gameplay::ItemId;
use ce_space::WorldPos;

/// Identifier for a mineable node.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct NodeId(pub u64);

/// One mineable node in space (or on a planet surface).
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct ResourceNode {
    pub id: NodeId,
    pub position: WorldPos,
    /// The item a miner recovers from this node.
    pub yields: ItemId,
    /// Units remaining. Zero = node depleted.
    pub units_remaining: u32,
    /// Hardness factor `[0.25, 4.0]` — higher = slower to mine.
    pub hardness: f32,
}

impl ResourceNode {
    pub fn new(id: NodeId, position: WorldPos, yields: ItemId, units: u32) -> Self {
        Self {
            id,
            position,
            yields,
            units_remaining: units,
            hardness: 1.0,
        }
    }

    pub fn with_hardness(mut self, hardness: f32) -> Self {
        self.hardness = hardness.clamp(0.25, 4.0);
        self
    }

    pub fn is_depleted(&self) -> bool {
        self.units_remaining == 0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn new_node_has_full_units_and_default_hardness() {
        let n = ResourceNode::new(NodeId(1), WorldPos::ZERO, ItemId::new("iron_ore"), 100);
        assert_eq!(n.units_remaining, 100);
        assert_eq!(n.hardness, 1.0);
        assert!(!n.is_depleted());
    }

    #[test]
    fn hardness_is_clamped() {
        let n =
            ResourceNode::new(NodeId(1), WorldPos::ZERO, ItemId::new("x"), 10).with_hardness(10.0);
        assert_eq!(n.hardness, 4.0);
        let n =
            ResourceNode::new(NodeId(1), WorldPos::ZERO, ItemId::new("x"), 10).with_hardness(0.0);
        assert_eq!(n.hardness, 0.25);
    }

    #[test]
    fn is_depleted_when_units_zero() {
        let mut n = ResourceNode::new(NodeId(1), WorldPos::ZERO, ItemId::new("x"), 1);
        n.units_remaining = 0;
        assert!(n.is_depleted());
    }
}

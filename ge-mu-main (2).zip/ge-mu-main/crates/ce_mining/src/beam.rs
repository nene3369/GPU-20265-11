//! Mining beam — the extractor on the player's ship.

use ce_gameplay::{Inventory, InventoryError, ItemStack};
use ce_space::WorldPos;

use crate::node::ResourceNode;

/// Mining beam parameters.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct MiningBeam {
    /// Units per second extracted at hardness 1.0 from close range.
    pub power: f32,
    /// Maximum engagement distance in meters.
    pub range_meters: f64,
}

impl MiningBeam {
    pub fn basic() -> Self {
        Self {
            power: 2.0,
            range_meters: 500.0,
        }
    }

    pub fn industrial() -> Self {
        Self {
            power: 8.0,
            range_meters: 1_200.0,
        }
    }
}

/// Reasons a mining tick produced nothing.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MineResult {
    /// Successfully extracted `count` units.
    Extracted(u32),
    /// Node depleted; nothing to extract.
    Depleted,
    /// Beam out of range of the node.
    OutOfRange,
    /// Player inventory full; extraction aborted.
    InventoryFull,
}

/// Mines `node` for one tick of `dt_seconds`. Extracted units flow into
/// `inventory`. Returns a status describing what happened.
pub fn mine_tick(
    beam: &MiningBeam,
    node: &mut ResourceNode,
    shooter_pos: WorldPos,
    inventory: &mut Inventory,
    dt_seconds: f32,
) -> MineResult {
    if node.is_depleted() {
        return MineResult::Depleted;
    }
    let distance = shooter_pos.distance(node.position);
    if distance > beam.range_meters {
        return MineResult::OutOfRange;
    }
    // Effective units extracted this tick, taking hardness into account.
    let rate = beam.power / node.hardness.max(0.01);
    // Round to whole units per tick to avoid accumulation fuzz; caller
    // typically invokes this at 30-60 Hz so the resolution is fine.
    let extract_f = rate * dt_seconds;
    if extract_f < 1.0 {
        // Sub-unit this tick; wait for more time (no extraction yet).
        return MineResult::Extracted(0);
    }
    let mut units = extract_f.floor() as u32;
    if units > node.units_remaining {
        units = node.units_remaining;
    }
    if units == 0 {
        return MineResult::Depleted;
    }
    // Try to deposit. If inventory full, clamp to whatever fits; never
    // charge the node more than what the miner kept.
    let stack = ItemStack::new(node.yields, units);
    match inventory.add_stack(stack) {
        Ok(()) => {
            node.units_remaining -= units;
            MineResult::Extracted(units)
        }
        Err(InventoryError::OverCapacity) => {
            let room = inventory.remaining();
            if room == 0 {
                return MineResult::InventoryFull;
            }
            let partial = room.min(units);
            inventory.add(node.yields, partial).expect("room validated");
            node.units_remaining -= partial;
            MineResult::Extracted(partial)
        }
        Err(_) => MineResult::InventoryFull,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ce_gameplay::{Inventory, ItemId};

    const ORE: ItemId = ItemId::new("iron_ore");

    fn fixture() -> (MiningBeam, ResourceNode, Inventory) {
        (
            MiningBeam::basic(),
            ResourceNode::new(NodeId(1), WorldPos::new(0.0, 0.0, 100.0), ORE, 50),
            Inventory::new(1000),
        )
    }

    // We re-use NodeId from crate::node via mod tests import below.
    use crate::node::NodeId;

    #[test]
    fn extracts_when_in_range() {
        let (beam, mut node, mut inv) = fixture();
        let result = mine_tick(
            &beam,
            &mut node,
            WorldPos::new(0.0, 0.0, 50.0),
            &mut inv,
            1.0,
        );
        match result {
            MineResult::Extracted(n) => assert!(n > 0),
            other => panic!("expected extraction, got {other:?}"),
        }
        assert!(node.units_remaining < 50);
        assert!(inv.count(ORE) > 0);
    }

    #[test]
    fn out_of_range_reports_correctly() {
        let (beam, mut node, mut inv) = fixture();
        let far = WorldPos::new(0.0, 0.0, 10_000.0);
        let result = mine_tick(&beam, &mut node, far, &mut inv, 1.0);
        assert_eq!(result, MineResult::OutOfRange);
        assert_eq!(node.units_remaining, 50);
    }

    #[test]
    fn depleted_node_reports_depleted() {
        let (beam, mut node, mut inv) = fixture();
        node.units_remaining = 0;
        let result = mine_tick(&beam, &mut node, WorldPos::ZERO, &mut inv, 1.0);
        assert_eq!(result, MineResult::Depleted);
    }

    #[test]
    fn hardness_slows_extraction() {
        let beam = MiningBeam::basic();
        let mut soft = ResourceNode::new(NodeId(1), WorldPos::ZERO, ORE, 100).with_hardness(1.0);
        let mut hard = ResourceNode::new(NodeId(2), WorldPos::ZERO, ORE, 100).with_hardness(4.0);
        let mut inv_a = Inventory::new(1_000);
        let mut inv_b = Inventory::new(1_000);
        mine_tick(&beam, &mut soft, WorldPos::ZERO, &mut inv_a, 1.0);
        mine_tick(&beam, &mut hard, WorldPos::ZERO, &mut inv_b, 1.0);
        assert!(inv_a.count(ORE) > inv_b.count(ORE));
    }

    #[test]
    fn inventory_full_partial_extraction() {
        let (beam, mut node, _) = fixture();
        let mut inv = Inventory::new(1);
        let r = mine_tick(&beam, &mut node, WorldPos::ZERO, &mut inv, 5.0);
        match r {
            MineResult::Extracted(n) => assert_eq!(n, 1),
            other => panic!("expected partial 1, got {other:?}"),
        }
        // Next tick should report inventory full (no room left).
        let r2 = mine_tick(&beam, &mut node, WorldPos::ZERO, &mut inv, 5.0);
        assert_eq!(r2, MineResult::InventoryFull);
    }

    #[test]
    fn sub_second_tick_produces_zero_but_not_error() {
        let beam = MiningBeam {
            power: 0.5,
            range_meters: 1000.0,
        };
        let mut node = ResourceNode::new(NodeId(1), WorldPos::ZERO, ORE, 50);
        let mut inv = Inventory::new(1000);
        let r = mine_tick(&beam, &mut node, WorldPos::ZERO, &mut inv, 1.0);
        // 0.5 units/s * 1s = 0.5 → floor to 0.
        assert_eq!(r, MineResult::Extracted(0));
    }

    #[test]
    fn industrial_beam_faster_than_basic() {
        let basic = MiningBeam::basic();
        let pro = MiningBeam::industrial();
        assert!(pro.power > basic.power);
        assert!(pro.range_meters > basic.range_meters);
    }

    #[test]
    fn mining_cant_extract_more_than_units_remaining() {
        let beam = MiningBeam {
            power: 1000.0,
            range_meters: 1_000.0,
        };
        let mut node = ResourceNode::new(NodeId(1), WorldPos::ZERO, ORE, 7);
        let mut inv = Inventory::new(1_000);
        let r = mine_tick(&beam, &mut node, WorldPos::ZERO, &mut inv, 1.0);
        assert_eq!(r, MineResult::Extracted(7));
        assert!(node.is_depleted());
    }
}

//! Reputation matrix + relation derivation.
//!
//! Reputation between two factions is a signed scalar in `[-1000, 1000]`.
//! The relation (Ally / Friendly / Neutral / Hostile / War) is derived
//! via fixed thresholds so gameplay code can react consistently.

use std::collections::HashMap;

use crate::faction::FactionId;

/// Bounds of the reputation scalar.
pub const REP_MIN: i32 = -1000;
pub const REP_MAX: i32 = 1000;

/// Ally threshold — at or above this, factions actively help.
pub const REP_ALLY: i32 = 600;
/// Friendly threshold — open trade, boosted prices.
pub const REP_FRIENDLY: i32 = 200;
/// Hostile threshold — at or below this, fired-upon-sight.
pub const REP_HOSTILE: i32 = -200;
/// War threshold — factions at war spawn patrols against each other.
pub const REP_WAR: i32 = -600;

/// Derived relation between two factions.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum Relation {
    War,
    Hostile,
    Neutral,
    Friendly,
    Ally,
}

impl Relation {
    pub fn from_reputation(rep: i32) -> Self {
        if rep >= REP_ALLY {
            Relation::Ally
        } else if rep >= REP_FRIENDLY {
            Relation::Friendly
        } else if rep > REP_HOSTILE {
            Relation::Neutral
        } else if rep > REP_WAR {
            Relation::Hostile
        } else {
            Relation::War
        }
    }

    pub fn is_friendly(self) -> bool {
        matches!(self, Relation::Friendly | Relation::Ally)
    }

    pub fn is_hostile(self) -> bool {
        matches!(self, Relation::Hostile | Relation::War)
    }
}

fn ordered_pair(a: FactionId, b: FactionId) -> (FactionId, FactionId) {
    if a <= b {
        (a, b)
    } else {
        (b, a)
    }
}

/// Symmetric reputation store. `rep(a, b) == rep(b, a)` is guaranteed.
#[derive(Debug, Clone, Default)]
pub struct ReputationMatrix {
    values: HashMap<(FactionId, FactionId), i32>,
}

impl ReputationMatrix {
    pub fn new() -> Self {
        Self::default()
    }

    /// Sets the raw reputation value. Clamped to `[REP_MIN, REP_MAX]`.
    pub fn set(&mut self, a: FactionId, b: FactionId, value: i32) {
        if a == b {
            return; // a faction is always allied with itself; stored implicitly
        }
        let v = value.clamp(REP_MIN, REP_MAX);
        self.values.insert(ordered_pair(a, b), v);
    }

    /// Reputation score. A faction's reputation with itself is `REP_MAX`.
    pub fn get(&self, a: FactionId, b: FactionId) -> i32 {
        if a == b {
            return REP_MAX;
        }
        self.values.get(&ordered_pair(a, b)).copied().unwrap_or(0)
    }

    /// Adjusts reputation by `delta`; saturates at the ends.
    pub fn adjust(&mut self, a: FactionId, b: FactionId, delta: i32) {
        if a == b {
            return;
        }
        let new = self.get(a, b).saturating_add(delta).clamp(REP_MIN, REP_MAX);
        self.set(a, b, new);
    }

    /// Derived relation (Ally/Friendly/Neutral/Hostile/War).
    pub fn relation(&self, a: FactionId, b: FactionId) -> Relation {
        Relation::from_reputation(self.get(a, b))
    }

    /// Iterate every stored pair + value (debug / save).
    pub fn iter(&self) -> impl Iterator<Item = (FactionId, FactionId, i32)> + '_ {
        self.values.iter().map(|((a, b), v)| (*a, *b, *v))
    }

    /// Pulls every stored pair `step` units closer to zero. Values
    /// that would cross zero are snapped to zero. Used by
    /// `crate::politics::decay_reputation` so grudges soften over
    /// time unless reinforced.
    pub fn drift_all_toward_zero(&mut self, step: i32) {
        if step <= 0 {
            return;
        }
        for v in self.values.values_mut() {
            if *v > 0 {
                *v = (*v - step).max(0);
            } else if *v < 0 {
                *v = (*v + step).min(0);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const UNION: FactionId = FactionId::new("union");
    const PIRATES: FactionId = FactionId::new("pirates");

    #[test]
    fn relation_thresholds() {
        assert_eq!(Relation::from_reputation(900), Relation::Ally);
        assert_eq!(Relation::from_reputation(400), Relation::Friendly);
        assert_eq!(Relation::from_reputation(0), Relation::Neutral);
        assert_eq!(Relation::from_reputation(-400), Relation::Hostile);
        assert_eq!(Relation::from_reputation(-800), Relation::War);
    }

    #[test]
    fn self_reputation_is_max() {
        let m = ReputationMatrix::new();
        assert_eq!(m.get(UNION, UNION), REP_MAX);
        assert_eq!(m.relation(UNION, UNION), Relation::Ally);
    }

    #[test]
    fn default_relation_is_neutral() {
        let m = ReputationMatrix::new();
        assert_eq!(m.relation(UNION, PIRATES), Relation::Neutral);
    }

    #[test]
    fn set_is_symmetric() {
        let mut m = ReputationMatrix::new();
        m.set(UNION, PIRATES, 300);
        assert_eq!(m.get(UNION, PIRATES), 300);
        assert_eq!(m.get(PIRATES, UNION), 300);
    }

    #[test]
    fn set_clamps_to_bounds() {
        let mut m = ReputationMatrix::new();
        m.set(UNION, PIRATES, 10_000);
        assert_eq!(m.get(UNION, PIRATES), REP_MAX);
        m.set(UNION, PIRATES, -10_000);
        assert_eq!(m.get(UNION, PIRATES), REP_MIN);
    }

    #[test]
    fn adjust_saturates() {
        let mut m = ReputationMatrix::new();
        m.set(UNION, PIRATES, 900);
        m.adjust(UNION, PIRATES, 500);
        assert_eq!(m.get(UNION, PIRATES), REP_MAX);
    }

    #[test]
    fn adjust_crosses_thresholds() {
        let mut m = ReputationMatrix::new();
        m.set(UNION, PIRATES, -150);
        assert_eq!(m.relation(UNION, PIRATES), Relation::Neutral);
        m.adjust(UNION, PIRATES, -100);
        assert_eq!(m.relation(UNION, PIRATES), Relation::Hostile);
        m.adjust(UNION, PIRATES, -500);
        assert_eq!(m.relation(UNION, PIRATES), Relation::War);
    }

    #[test]
    fn relation_helpers_match_categories() {
        assert!(Relation::Ally.is_friendly());
        assert!(Relation::Friendly.is_friendly());
        assert!(!Relation::Neutral.is_friendly());
        assert!(Relation::Hostile.is_hostile());
        assert!(Relation::War.is_hostile());
        assert!(!Relation::Neutral.is_hostile());
    }

    #[test]
    fn setting_self_reputation_is_noop() {
        let mut m = ReputationMatrix::new();
        m.set(UNION, UNION, -500);
        assert_eq!(m.get(UNION, UNION), REP_MAX);
    }
}

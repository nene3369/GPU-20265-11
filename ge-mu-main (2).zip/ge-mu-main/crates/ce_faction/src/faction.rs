//! Faction identity + registry.

use std::collections::HashMap;

/// Identifier for a faction. Interned as `&'static str` so reputation
/// tables stay cheap and save files stay human-readable.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct FactionId(pub &'static str);

impl FactionId {
    pub const fn new(id: &'static str) -> Self {
        Self(id)
    }

    pub fn as_str(&self) -> &'static str {
        self.0
    }
}

impl std::fmt::Display for FactionId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.0)
    }
}

/// One faction's public description.
#[derive(Debug, Clone)]
pub struct Faction {
    pub id: FactionId,
    pub display_name: String,
    /// Brief flavour blurb shown on galaxy map tooltips.
    pub blurb: String,
}

impl Faction {
    pub fn new(id: FactionId, display_name: impl Into<String>) -> Self {
        Self {
            id,
            display_name: display_name.into(),
            blurb: String::new(),
        }
    }

    pub fn with_blurb(mut self, blurb: impl Into<String>) -> Self {
        self.blurb = blurb.into();
        self
    }
}

/// Catalogue of known factions. Inserted as a resource.
#[derive(Debug, Clone, Default)]
pub struct FactionRegistry {
    factions: HashMap<FactionId, Faction>,
}

impl FactionRegistry {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn insert(&mut self, faction: Faction) {
        self.factions.insert(faction.id, faction);
    }

    pub fn get(&self, id: FactionId) -> Option<&Faction> {
        self.factions.get(&id)
    }

    pub fn len(&self) -> usize {
        self.factions.len()
    }

    pub fn is_empty(&self) -> bool {
        self.factions.is_empty()
    }

    pub fn iter(&self) -> impl Iterator<Item = &Faction> {
        self.factions.values()
    }

    pub fn contains(&self, id: FactionId) -> bool {
        self.factions.contains_key(&id)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn faction_id_is_displayable() {
        assert_eq!(format!("{}", FactionId::new("union")), "union");
    }

    #[test]
    fn registry_insert_and_get() {
        let mut r = FactionRegistry::new();
        r.insert(Faction::new(FactionId::new("union"), "The Union"));
        assert!(r.contains(FactionId::new("union")));
        assert_eq!(
            r.get(FactionId::new("union")).unwrap().display_name,
            "The Union"
        );
    }

    #[test]
    fn registry_blurb_round_trip() {
        let f = Faction::new(FactionId::new("pirates"), "Free Fleet")
            .with_blurb("Raids trade lanes at the Rim.");
        assert_eq!(f.blurb, "Raids trade lanes at the Rim.");
    }
}

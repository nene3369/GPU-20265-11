//! Reputation dynamics — how factions remember kills, and how time
//! softens those memories.
//!
//! The rule is symmetric across actors: an NPC pirate killing a
//! guard perturbs the reputation matrix in exactly the same way a
//! player does. The world has its own politics; the player is one
//! participant among many.
//!
//! Delta values come from a fixed table keyed by `(killer_kind,
//! victim_kind)`. Third-party factions that witness the event also
//! shift their opinion of the killer — e.g. if a pirate kills a
//! union trader, the protectorate grows more hostile to that pirate
//! faction even though they didn't take the hit themselves.
//!
//! [`decay_reputation`] nudges every stored pair back toward zero at
//! a constant rate, so grudges fade unless reinforced.

use crate::faction::FactionId;
use crate::reputation::ReputationMatrix;

/// Apply the fallout of `killer` destroying a `victim` ship. Mutates
/// the matrix in place. The `observers` list enumerates every faction
/// with a stake in the outcome (typically every faction known to the
/// sector). Factions not in `observers` are ignored — the killer gets
/// a pass from anyone who didn't see.
///
/// Two canonical reactions drive the table:
///
/// - `(killer, victim)`: big negative. Killing someone leaves a
///   direct mark between the two factions.
/// - `(killer, third_party_ally_of_victim)`: a smaller dip, weighted
///   by how friendly the third party was to the victim.
/// - `(killer, third_party_hostile_to_victim)`: a small bump — if
///   they already hated the victim, the kill is appreciated.
///
/// A faction cannot shift its reputation with itself, so
/// `killer == observer` is silently skipped.
pub fn apply_kill_delta(
    rep: &mut ReputationMatrix,
    killer: FactionId,
    victim: FactionId,
    observers: &[FactionId],
) {
    apply_kill_delta_weighted(rep, killer, victim, observers, 1.0);
}

/// Same as [`apply_kill_delta`] but with a multiplicative `weight`
/// applied to every delta. Gameplay layers that hold a
/// [`ce_worldpulse::WorldPulse`] scale this by
/// `1.0 + tension * TENSION_WEIGHT` so grudges bite harder during
/// open conflict and soften during peace.
///
/// `weight` is clamped to `[0.0, 4.0]` — the ceiling guards against
/// runaway feedback if an upstream pulse field saturates.
pub fn apply_kill_delta_weighted(
    rep: &mut ReputationMatrix,
    killer: FactionId,
    victim: FactionId,
    observers: &[FactionId],
    weight: f32,
) {
    if killer == victim {
        return;
    }

    let w = if weight.is_finite() {
        weight.clamp(0.0, 4.0)
    } else {
        1.0
    };

    // Direct mark between killer and victim — always a strong
    // negative. "You killed one of ours."
    const DIRECT_HIT: i32 = -80;
    rep.adjust(killer, victim, scale_delta(DIRECT_HIT, w));

    // Third-party reactions: weighted by each observer's prior
    // feelings toward the victim. Tunable constants.
    const ALLY_REACTION: i32 = -30; // friend-of-victim cools
    const HOSTILE_REACTION: i32 = 20; // enemy-of-victim warms
    const NEUTRAL_REACTION: i32 = -5; // light distaste from neutrals

    for &observer in observers {
        if observer == killer || observer == victim {
            continue;
        }
        let stance_toward_victim = rep.get(observer, victim);
        let delta = if stance_toward_victim >= crate::reputation::REP_FRIENDLY {
            ALLY_REACTION
        } else if stance_toward_victim <= crate::reputation::REP_HOSTILE {
            HOSTILE_REACTION
        } else {
            NEUTRAL_REACTION
        };
        rep.adjust(killer, observer, scale_delta(delta, w));
    }
}

/// Scale an integer delta by `w` without losing the sign direction
/// on tiny values. A delta of `-5` at `w=0.4` becomes `-2`, not `0`.
fn scale_delta(base: i32, w: f32) -> i32 {
    if base == 0 || w == 0.0 {
        return 0;
    }
    let scaled = (base as f32) * w;
    let rounded = scaled.round() as i32;
    if rounded == 0 {
        if base > 0 {
            1
        } else {
            -1
        }
    } else {
        rounded
    }
}

/// Nudge every stored pair in `rep` toward zero by at most
/// `rate_per_second * dt` per pair. Pairs already at zero stay there.
///
/// Called per-frame by the gameplay layer so memory of kills fades
/// over time. A rate of `0.01` means about 16 minutes to fully
/// relax a saturated pair (−1000 → 0); slow enough to be invisible
/// per frame but felt over a session.
pub fn decay_reputation(rep: &mut ReputationMatrix, rate_per_second: f32, dt: f32) {
    if rate_per_second <= 0.0 || dt <= 0.0 || !rate_per_second.is_finite() || !dt.is_finite() {
        return;
    }
    let step = (rate_per_second * dt).max(0.0);
    if step < 1.0 {
        // Subsecond decay — accumulate probabilistically would be ideal,
        // but for determinism we floor to whole units. Still, apply a
        // minimum of 0 so tiny dt doesn't thrash.
        // The caller can supply a larger dt if needed (e.g. once per
        // second instead of per-frame).
        return;
    }
    let step = step as i32;
    rep.drift_all_toward_zero(step);
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::reputation::{REP_FRIENDLY, REP_HOSTILE};

    const GUARD: FactionId = FactionId::new("guard");
    const PIRATE: FactionId = FactionId::new("pirate");
    const TRADER: FactionId = FactionId::new("trader");
    const NEUTRAL: FactionId = FactionId::new("neutral");

    fn seeded() -> ReputationMatrix {
        let mut m = ReputationMatrix::new();
        m.set(GUARD, TRADER, REP_FRIENDLY + 200); // guard loves trader
        m.set(PIRATE, TRADER, REP_HOSTILE - 200); // pirate hates trader
        m
    }

    #[test]
    fn killer_victim_pair_drops_sharply() {
        let mut m = seeded();
        let before = m.get(PIRATE, TRADER);
        apply_kill_delta(&mut m, PIRATE, TRADER, &[GUARD, NEUTRAL]);
        assert!(m.get(PIRATE, TRADER) < before);
        assert!((before - m.get(PIRATE, TRADER)) >= 80);
    }

    #[test]
    fn ally_of_victim_cools_on_killer() {
        let mut m = seeded();
        let before = m.get(PIRATE, GUARD);
        apply_kill_delta(&mut m, PIRATE, TRADER, &[GUARD, NEUTRAL]);
        assert!(m.get(PIRATE, GUARD) < before);
    }

    #[test]
    fn hostile_to_victim_warms_to_killer() {
        let mut m = seeded();
        // Build a world where GUARD is hostile to TRADER — then the
        // killing of TRADER by PIRATE earns GUARD's approval.
        m.set(GUARD, TRADER, REP_HOSTILE - 100);
        let before = m.get(PIRATE, GUARD);
        apply_kill_delta(&mut m, PIRATE, TRADER, &[GUARD]);
        assert!(m.get(PIRATE, GUARD) > before);
    }

    #[test]
    fn self_kill_is_noop() {
        let mut m = seeded();
        let snapshot = m.clone();
        apply_kill_delta(&mut m, PIRATE, PIRATE, &[GUARD, TRADER]);
        // No entries should have moved.
        assert_eq!(m.get(PIRATE, GUARD), snapshot.get(PIRATE, GUARD));
        assert_eq!(m.get(PIRATE, TRADER), snapshot.get(PIRATE, TRADER));
    }

    #[test]
    fn observer_killer_pair_is_not_self_mutating() {
        let mut m = seeded();
        let before = m.get(PIRATE, PIRATE);
        apply_kill_delta(&mut m, PIRATE, TRADER, &[PIRATE, GUARD]);
        // Killer-self pair still reads as REP_MAX.
        assert_eq!(m.get(PIRATE, PIRATE), before);
    }

    #[test]
    fn decay_pulls_values_toward_zero() {
        let mut m = ReputationMatrix::new();
        m.set(PIRATE, GUARD, -500);
        m.set(PIRATE, TRADER, 400);
        // 1 s at rate=10 → step=10 per pair, toward 0
        decay_reputation(&mut m, 10.0, 1.0);
        assert_eq!(m.get(PIRATE, GUARD), -490);
        assert_eq!(m.get(PIRATE, TRADER), 390);
    }

    #[test]
    fn decay_does_not_overshoot_zero() {
        let mut m = ReputationMatrix::new();
        m.set(PIRATE, GUARD, 3);
        decay_reputation(&mut m, 100.0, 1.0);
        assert_eq!(m.get(PIRATE, GUARD), 0);
    }

    #[test]
    fn decay_with_zero_rate_or_dt_is_noop() {
        let mut m = ReputationMatrix::new();
        m.set(PIRATE, GUARD, -500);
        decay_reputation(&mut m, 0.0, 1.0);
        decay_reputation(&mut m, 10.0, 0.0);
        decay_reputation(&mut m, 10.0, -1.0);
        decay_reputation(&mut m, 10.0, f32::NAN);
        assert_eq!(m.get(PIRATE, GUARD), -500);
    }

    #[test]
    fn weighted_apply_with_one_matches_unweighted() {
        let mut a = seeded();
        let mut b = seeded();
        apply_kill_delta(&mut a, PIRATE, TRADER, &[GUARD, NEUTRAL]);
        apply_kill_delta_weighted(&mut b, PIRATE, TRADER, &[GUARD, NEUTRAL], 1.0);
        assert_eq!(a.get(PIRATE, TRADER), b.get(PIRATE, TRADER));
        assert_eq!(a.get(PIRATE, GUARD), b.get(PIRATE, GUARD));
        assert_eq!(a.get(PIRATE, NEUTRAL), b.get(PIRATE, NEUTRAL));
    }

    #[test]
    fn higher_weight_amplifies_the_mark() {
        let mut low = seeded();
        let mut high = seeded();
        apply_kill_delta_weighted(&mut low, PIRATE, TRADER, &[GUARD], 1.0);
        apply_kill_delta_weighted(&mut high, PIRATE, TRADER, &[GUARD], 2.0);
        // High-weight drop is at least 1.8x the low-weight drop.
        let low_drop = seeded().get(PIRATE, TRADER) - low.get(PIRATE, TRADER);
        let high_drop = seeded().get(PIRATE, TRADER) - high.get(PIRATE, TRADER);
        assert!(high_drop >= (low_drop as f32 * 1.8) as i32);
    }

    #[test]
    fn weight_clamps_to_safe_range() {
        // NaN / infinity / huge values fall back to safe behaviour
        // (1.0 for non-finite, ceiling of 4.0 for large finite).
        let mut a = seeded();
        let mut b = seeded();
        apply_kill_delta_weighted(&mut a, PIRATE, TRADER, &[GUARD], f32::NAN);
        apply_kill_delta_weighted(&mut b, PIRATE, TRADER, &[GUARD], 1e9);
        // Neither call panicked and both moved the needle.
        assert!(a.get(PIRATE, TRADER) < seeded().get(PIRATE, TRADER));
        assert!(b.get(PIRATE, TRADER) < seeded().get(PIRATE, TRADER));
        // Huge weight is bounded: drop is no more than 4x DIRECT_HIT.
        let huge_drop = seeded().get(PIRATE, TRADER) - b.get(PIRATE, TRADER);
        assert!(huge_drop <= 80 * 4 + 1);
    }

    #[test]
    fn weight_zero_is_noop() {
        let mut m = seeded();
        let snapshot = m.clone();
        apply_kill_delta_weighted(&mut m, PIRATE, TRADER, &[GUARD, NEUTRAL], 0.0);
        assert_eq!(m.get(PIRATE, TRADER), snapshot.get(PIRATE, TRADER));
        assert_eq!(m.get(PIRATE, GUARD), snapshot.get(PIRATE, GUARD));
    }

    #[test]
    fn decay_with_subsecond_step_is_noop_until_whole_unit() {
        // 0.5 * 1 = 0.5, floors to 0 → no change
        let mut m = ReputationMatrix::new();
        m.set(PIRATE, GUARD, -500);
        decay_reputation(&mut m, 0.5, 1.0);
        assert_eq!(m.get(PIRATE, GUARD), -500);
    }
}

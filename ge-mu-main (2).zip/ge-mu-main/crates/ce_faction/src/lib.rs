//! `ce_faction` — factions, reputation matrix, and derived relations.
//!
//! Keeps the data flat and pure so save and network layers can consume
//! it without extra plumbing. Missions, pirate spawning, and trade
//! price modulation (friendly discount / hostile refusal) layer on top.

pub mod faction;
pub mod politics;
pub mod reputation;

pub use faction::{Faction, FactionId, FactionRegistry};
pub use politics::{apply_kill_delta, apply_kill_delta_weighted, decay_reputation};
pub use reputation::{
    Relation, ReputationMatrix, REP_ALLY, REP_FRIENDLY, REP_HOSTILE, REP_MAX, REP_MIN, REP_WAR,
};

use ce_app::{App, Plugin};

/// Installs an empty [`FactionRegistry`] and [`ReputationMatrix`] so
/// later systems (missions, diplomacy, pirate spawning) can read them.
pub struct FactionPlugin;

impl Plugin for FactionPlugin {
    fn build(&self, app: &mut App) {
        if app.world.get_resource::<FactionRegistry>().is_none() {
            app.insert_resource(FactionRegistry::new());
        }
        if app.world.get_resource::<ReputationMatrix>().is_none() {
            app.insert_resource(ReputationMatrix::new());
        }
        log::info!("FactionPlugin loaded");
    }
}

#[cfg(test)]
mod plugin_tests {
    use super::*;

    #[test]
    fn plugin_installs_registry_and_matrix() {
        let mut app = App::new();
        app.add_plugin(FactionPlugin);
        assert!(app.world.get_resource::<FactionRegistry>().is_some());
        assert!(app.world.get_resource::<ReputationMatrix>().is_some());
    }

    #[test]
    fn plugin_preserves_preinserted_registry() {
        let mut app = App::new();
        let mut reg = FactionRegistry::new();
        reg.insert(Faction::new(FactionId::new("x"), "X"));
        app.insert_resource(reg);
        app.add_plugin(FactionPlugin);
        let r = app.world.get_resource::<FactionRegistry>().unwrap();
        assert!(r.contains(FactionId::new("x")));
    }
}

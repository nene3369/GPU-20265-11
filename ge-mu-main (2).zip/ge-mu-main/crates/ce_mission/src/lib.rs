//! `ce_mission` — procedural mercenary contracts.
//!
//! A [`MissionBoard`] at each station offers contracts; the player
//! moves them to a [`MissionLog`] on accept. Completion credits the
//! wallet and nudges reputation; expiry flips them to Failed with a
//! penalty.
//!
//! Procedural generation (randomised destinations, target counts,
//! rewards scaled by sector danger) lives in a future milestone — this
//! crate owns the state machine and the transactional bookkeeping.

pub mod board;
pub mod mission;

pub use board::{
    accept, complete, fail, tick_log, LogEntry, MissionBoard, MissionError, MissionLog,
};
pub use mission::{Mission, MissionId, MissionKind, MissionStatus};

use ce_app::{App, Plugin};

/// Installs empty [`MissionBoard`] and [`MissionLog`] resources.
pub struct MissionPlugin;

impl Plugin for MissionPlugin {
    fn build(&self, app: &mut App) {
        if app.world.get_resource::<MissionBoard>().is_none() {
            app.insert_resource(MissionBoard::new());
        }
        if app.world.get_resource::<MissionLog>().is_none() {
            app.insert_resource(MissionLog::new());
        }
        log::info!("MissionPlugin loaded");
    }
}

#[cfg(test)]
mod plugin_tests {
    use super::*;

    #[test]
    fn plugin_installs_board_and_log() {
        let mut app = App::new();
        app.add_plugin(MissionPlugin);
        assert!(app.world.get_resource::<MissionBoard>().is_some());
        assert!(app.world.get_resource::<MissionLog>().is_some());
    }
}

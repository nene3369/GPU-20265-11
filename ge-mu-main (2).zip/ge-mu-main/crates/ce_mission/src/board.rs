//! Mission board + player log + lifecycle transitions.
//!
//! A [`MissionBoard`] is per-station: the set of contracts a station
//! currently offers. A [`MissionLog`] is the player's record of
//! accepted / completed / failed missions.

use std::collections::HashMap;

use ce_economy::{Credits, Wallet};
use ce_faction::{FactionId, ReputationMatrix};

use crate::mission::{Mission, MissionId, MissionStatus};

/// Reasons an offer/accept/complete request can be rejected.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MissionError {
    NotFound,
    AlreadyAccepted,
    InsufficientReputation,
    NotAccepted,
    AlreadyCompleted,
    Expired,
}

/// Station-side contract offer list.
#[derive(Debug, Clone, Default)]
pub struct MissionBoard {
    offers: HashMap<MissionId, Mission>,
}

impl MissionBoard {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn post(&mut self, mission: Mission) {
        self.offers.insert(mission.id, mission);
    }

    pub fn get(&self, id: MissionId) -> Option<&Mission> {
        self.offers.get(&id)
    }

    pub fn offers(&self) -> impl Iterator<Item = &Mission> {
        self.offers.values()
    }

    pub fn len(&self) -> usize {
        self.offers.len()
    }

    pub fn is_empty(&self) -> bool {
        self.offers.is_empty()
    }

    /// Advances the timer on every offer and drops expired ones,
    /// returning the ids that were removed.
    pub fn tick(&mut self, dt_seconds: f32) -> Vec<MissionId> {
        let mut expired = Vec::new();
        self.offers.retain(|id, m| {
            m.deadline_seconds -= dt_seconds;
            if m.deadline_seconds <= 0.0 {
                expired.push(*id);
                false
            } else {
                true
            }
        });
        expired
    }

    /// Removes an offer (used on accept).
    pub fn remove(&mut self, id: MissionId) -> Option<Mission> {
        self.offers.remove(&id)
    }
}

/// One entry in the player's log — the mission plus its current status.
#[derive(Debug, Clone, PartialEq)]
pub struct LogEntry {
    pub mission: Mission,
    pub status: MissionStatus,
}

/// Player-side mission log: active, completed, and failed contracts.
#[derive(Debug, Clone, Default)]
pub struct MissionLog {
    entries: HashMap<MissionId, LogEntry>,
}

impl MissionLog {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn get(&self, id: MissionId) -> Option<&LogEntry> {
        self.entries.get(&id)
    }

    pub fn iter(&self) -> impl Iterator<Item = &LogEntry> {
        self.entries.values()
    }

    pub fn len(&self) -> usize {
        self.entries.len()
    }

    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    pub fn count_status(&self, status: MissionStatus) -> usize {
        self.entries.values().filter(|e| e.status == status).count()
    }
}

/// Moves the contract from a station board to the player's log.
/// Checks reputation and prevents double-accept.
pub fn accept(
    board: &mut MissionBoard,
    log: &mut MissionLog,
    rep: &ReputationMatrix,
    player_faction: FactionId,
    mission_id: MissionId,
) -> Result<(), MissionError> {
    if log.entries.contains_key(&mission_id) {
        return Err(MissionError::AlreadyAccepted);
    }
    let mission = board.get(mission_id).ok_or(MissionError::NotFound)?.clone();
    if rep.get(player_faction, mission.issuer) < mission.required_reputation {
        return Err(MissionError::InsufficientReputation);
    }
    board.remove(mission_id);
    log.entries.insert(
        mission_id,
        LogEntry {
            mission,
            status: MissionStatus::Accepted,
        },
    );
    Ok(())
}

/// Marks the mission as complete, credits the reward, and applies the
/// reputation delta.
pub fn complete(
    log: &mut MissionLog,
    wallet: &mut Wallet,
    rep: &mut ReputationMatrix,
    player_faction: FactionId,
    mission_id: MissionId,
) -> Result<Credits, MissionError> {
    let entry = log
        .entries
        .get_mut(&mission_id)
        .ok_or(MissionError::NotFound)?;
    match entry.status {
        MissionStatus::Accepted => {}
        MissionStatus::Completed => return Err(MissionError::AlreadyCompleted),
        MissionStatus::Failed | MissionStatus::Expired => return Err(MissionError::Expired),
        MissionStatus::Available => return Err(MissionError::NotAccepted),
    }
    let reward = entry.mission.reward;
    let delta = entry.mission.reputation_on_success;
    let issuer = entry.mission.issuer;
    entry.status = MissionStatus::Completed;
    wallet
        .credit(reward)
        .map_err(|_| MissionError::NotAccepted)?;
    rep.adjust(player_faction, issuer, delta);
    Ok(reward)
}

/// Marks the mission as failed and applies a reputation penalty.
pub fn fail(
    log: &mut MissionLog,
    rep: &mut ReputationMatrix,
    player_faction: FactionId,
    mission_id: MissionId,
) -> Result<(), MissionError> {
    let entry = log
        .entries
        .get_mut(&mission_id)
        .ok_or(MissionError::NotFound)?;
    if entry.status != MissionStatus::Accepted {
        return Err(MissionError::NotAccepted);
    }
    let delta = entry.mission.reputation_on_failure;
    let issuer = entry.mission.issuer;
    entry.status = MissionStatus::Failed;
    rep.adjust(player_faction, issuer, delta);
    Ok(())
}

/// Advances deadlines on accepted missions and flips any that have run
/// out to `Failed`, applying reputation penalties. Returns the IDs
/// that expired this tick.
pub fn tick_log(
    log: &mut MissionLog,
    rep: &mut ReputationMatrix,
    player_faction: FactionId,
    dt_seconds: f32,
) -> Vec<MissionId> {
    let mut expired = Vec::new();
    let mut pending_adjust = Vec::new();
    for (id, entry) in log.entries.iter_mut() {
        if entry.status != MissionStatus::Accepted {
            continue;
        }
        entry.mission.deadline_seconds -= dt_seconds;
        if entry.mission.deadline_seconds <= 0.0 {
            entry.status = MissionStatus::Failed;
            pending_adjust.push((
                *id,
                entry.mission.reputation_on_failure,
                entry.mission.issuer,
            ));
            expired.push(*id);
        }
    }
    for (_, delta, issuer) in pending_adjust {
        rep.adjust(player_faction, issuer, delta);
    }
    expired
}

#[cfg(test)]
mod tests {
    use super::*;
    use ce_gameplay::ItemId;

    use crate::mission::MissionKind;

    const PLAYER: FactionId = FactionId::new("player");
    const UNION: FactionId = FactionId::new("union");
    const PIRATES: FactionId = FactionId::new("pirates");

    fn demo_mission(id: u64) -> Mission {
        Mission::new(
            MissionId(id),
            MissionKind::Hunt {
                target_faction: PIRATES,
                count: 2,
            },
            UNION,
            5_000,
        )
    }

    #[test]
    fn accept_moves_from_board_to_log() {
        let mut board = MissionBoard::new();
        let mut log = MissionLog::new();
        let rep = ReputationMatrix::new();
        board.post(demo_mission(1));
        accept(&mut board, &mut log, &rep, PLAYER, MissionId(1)).unwrap();
        assert!(board.get(MissionId(1)).is_none());
        assert_eq!(
            log.get(MissionId(1)).unwrap().status,
            MissionStatus::Accepted
        );
    }

    #[test]
    fn accept_rejects_below_reputation_threshold() {
        let mut board = MissionBoard::new();
        let mut log = MissionLog::new();
        let rep = ReputationMatrix::new();
        let mut m = demo_mission(1);
        m.required_reputation = 500;
        board.post(m);
        let err = accept(&mut board, &mut log, &rep, PLAYER, MissionId(1)).err();
        assert_eq!(err, Some(MissionError::InsufficientReputation));
        assert!(board.get(MissionId(1)).is_some());
    }

    #[test]
    fn accept_unknown_id_fails() {
        let mut board = MissionBoard::new();
        let mut log = MissionLog::new();
        let rep = ReputationMatrix::new();
        assert_eq!(
            accept(&mut board, &mut log, &rep, PLAYER, MissionId(99)),
            Err(MissionError::NotFound)
        );
    }

    #[test]
    fn complete_pays_reward_and_raises_rep() {
        let mut board = MissionBoard::new();
        let mut log = MissionLog::new();
        let mut rep = ReputationMatrix::new();
        let mut wallet = Wallet::new(0);
        board.post(demo_mission(1));
        accept(&mut board, &mut log, &rep, PLAYER, MissionId(1)).unwrap();
        let reward = complete(&mut log, &mut wallet, &mut rep, PLAYER, MissionId(1)).unwrap();
        assert_eq!(reward, 5_000);
        assert_eq!(wallet.credits, 5_000);
        assert_eq!(rep.get(PLAYER, UNION), 50);
        assert_eq!(
            log.get(MissionId(1)).unwrap().status,
            MissionStatus::Completed
        );
    }

    #[test]
    fn complete_twice_fails_second_time() {
        let mut board = MissionBoard::new();
        let mut log = MissionLog::new();
        let mut rep = ReputationMatrix::new();
        let mut wallet = Wallet::new(0);
        board.post(demo_mission(1));
        accept(&mut board, &mut log, &rep, PLAYER, MissionId(1)).unwrap();
        complete(&mut log, &mut wallet, &mut rep, PLAYER, MissionId(1)).unwrap();
        let err = complete(&mut log, &mut wallet, &mut rep, PLAYER, MissionId(1)).err();
        assert_eq!(err, Some(MissionError::AlreadyCompleted));
    }

    #[test]
    fn fail_reduces_reputation_and_marks_failed() {
        let mut board = MissionBoard::new();
        let mut log = MissionLog::new();
        let mut rep = ReputationMatrix::new();
        board.post(demo_mission(1));
        accept(&mut board, &mut log, &rep, PLAYER, MissionId(1)).unwrap();
        fail(&mut log, &mut rep, PLAYER, MissionId(1)).unwrap();
        assert_eq!(rep.get(PLAYER, UNION), -25);
        assert_eq!(log.get(MissionId(1)).unwrap().status, MissionStatus::Failed);
    }

    #[test]
    fn board_tick_expires_offers() {
        let mut board = MissionBoard::new();
        let mut m = demo_mission(1);
        m.deadline_seconds = 1.0;
        board.post(m);
        let expired = board.tick(2.0);
        assert_eq!(expired, vec![MissionId(1)]);
        assert!(board.is_empty());
    }

    #[test]
    fn log_tick_fails_expired_accepted_missions() {
        let mut board = MissionBoard::new();
        let mut log = MissionLog::new();
        let rep = ReputationMatrix::new();
        let mut m = demo_mission(1);
        m.deadline_seconds = 0.5;
        board.post(m);
        accept(&mut board, &mut log, &rep, PLAYER, MissionId(1)).unwrap();
        let mut rep_mut = ReputationMatrix::new();
        let expired = tick_log(&mut log, &mut rep_mut, PLAYER, 1.0);
        assert_eq!(expired, vec![MissionId(1)]);
        assert_eq!(log.get(MissionId(1)).unwrap().status, MissionStatus::Failed);
        assert_eq!(rep_mut.get(PLAYER, UNION), -25);
    }

    #[test]
    fn double_accept_is_rejected() {
        let mut board = MissionBoard::new();
        let mut log = MissionLog::new();
        let rep = ReputationMatrix::new();
        board.post(demo_mission(1));
        accept(&mut board, &mut log, &rep, PLAYER, MissionId(1)).unwrap();
        // Re-post and attempt accept again — log already contains it.
        board.post(demo_mission(1));
        let err = accept(&mut board, &mut log, &rep, PLAYER, MissionId(1)).err();
        assert_eq!(err, Some(MissionError::AlreadyAccepted));
    }

    #[test]
    fn log_count_status_segregates() {
        let mut board = MissionBoard::new();
        let mut log = MissionLog::new();
        let mut rep = ReputationMatrix::new();
        let mut wallet = Wallet::new(0);
        for i in 0..3 {
            board.post(demo_mission(i));
            accept(&mut board, &mut log, &rep, PLAYER, MissionId(i)).unwrap();
        }
        complete(&mut log, &mut wallet, &mut rep, PLAYER, MissionId(0)).unwrap();
        fail(&mut log, &mut rep, PLAYER, MissionId(1)).unwrap();
        assert_eq!(log.count_status(MissionStatus::Accepted), 1);
        assert_eq!(log.count_status(MissionStatus::Completed), 1);
        assert_eq!(log.count_status(MissionStatus::Failed), 1);
    }

    #[test]
    fn courier_kind_carries_cargo() {
        let id_iron = ItemId::new("iron_ore");
        let k = MissionKind::Courier {
            destination: "Vega-III".into(),
            item: id_iron,
            count: 10,
        };
        match k {
            MissionKind::Courier { item, count, .. } => {
                assert_eq!(item, id_iron);
                assert_eq!(count, 10);
            }
            _ => panic!("expected Courier"),
        }
    }
}

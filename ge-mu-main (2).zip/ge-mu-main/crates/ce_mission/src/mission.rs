//! Mission records — what contracts exist and what they demand.

use ce_economy::Credits;
use ce_faction::FactionId;
use ce_gameplay::ItemId;

/// Unique identifier for a mission instance. Issued by the mission
/// board; not a string so a single player save can contain thousands
/// of historical missions without string bloat.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct MissionId(pub u64);

/// High-level mission archetype. Each variant carries the
/// gameplay-specific parameters its objectives care about.
#[derive(Debug, Clone, PartialEq)]
pub enum MissionKind {
    /// Deliver `item` × `count` to the destination display label.
    Courier {
        destination: String,
        item: ItemId,
        count: u32,
    },
    /// Destroy `count` ships of `target_faction`.
    Hunt {
        target_faction: FactionId,
        count: u32,
    },
    /// Mine `count` units of `resource` from anywhere.
    Mine { resource: ItemId, count: u32 },
    /// Escort an NPC ship identified by display label to a destination.
    Escort {
        escortee: String,
        destination: String,
    },
    /// Visit each waypoint in order (display labels).
    Patrol { waypoints: Vec<String> },
}

/// One contract. Stored by [`MissionBoard`] while available and moved
/// to the player's [`MissionLog`] on accept.
#[derive(Debug, Clone, PartialEq)]
pub struct Mission {
    pub id: MissionId,
    pub kind: MissionKind,
    /// Faction that posted the contract. Reputation with them swings
    /// on completion / failure.
    pub issuer: FactionId,
    /// Reward in credits paid on successful completion.
    pub reward: Credits,
    /// Minimum reputation with `issuer` required to accept.
    pub required_reputation: i32,
    /// Seconds until the offer (or active mission) expires.
    pub deadline_seconds: f32,
    /// Reputation delta applied to (player, issuer) on completion.
    pub reputation_on_success: i32,
    /// Reputation delta applied to (player, issuer) on failure.
    pub reputation_on_failure: i32,
}

impl Mission {
    /// Convenience constructor with conservative default rep/time.
    pub fn new(id: MissionId, kind: MissionKind, issuer: FactionId, reward: Credits) -> Self {
        Self {
            id,
            kind,
            issuer,
            reward,
            required_reputation: 0,
            deadline_seconds: 600.0,
            reputation_on_success: 50,
            reputation_on_failure: -25,
        }
    }
}

/// Lifecycle state of one contract from the player's side.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MissionStatus {
    /// Listed on a board, not yet accepted.
    Available,
    /// Player has accepted and is working on it.
    Accepted,
    /// Delivered / destroyed / mined — reward claimable.
    Completed,
    /// Deadline missed or objective failed.
    Failed,
    /// Deadline passed while `Available`.
    Expired,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn new_mission_uses_default_policy() {
        let m = Mission::new(
            MissionId(1),
            MissionKind::Hunt {
                target_faction: FactionId::new("pirates"),
                count: 3,
            },
            FactionId::new("union"),
            10_000,
        );
        assert_eq!(m.reward, 10_000);
        assert_eq!(m.required_reputation, 0);
        assert_eq!(m.reputation_on_success, 50);
        assert_eq!(m.reputation_on_failure, -25);
    }
}

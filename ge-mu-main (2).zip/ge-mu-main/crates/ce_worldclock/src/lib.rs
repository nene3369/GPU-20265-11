//! `ce_worldclock` — world epoch and deterministic PRNG.
//!
//! The project's design directive is that the world exists before the
//! player arrives and keeps turning regardless of them. This crate
//! provides the minimum machinery to make that visible from the first
//! frame:
//!
//! - [`WorldClock`] holds a seed and an `epoch_seconds` counter. New
//!   sessions don't start at zero — gameplay code seeds the clock at
//!   an already-elapsed moment (e.g. 30 in-universe minutes) and lets
//!   the rest of the simulation derive "already-in-motion" state from
//!   it. Per-frame `tick` advances the epoch so the clock also
//!   functions as an in-game time-of-day source.
//!
//! - [`DeterministicRng`] is a splitmix64 generator seeded from a
//!   `(seed, epoch_u64, salt)` triple. Callers get a private stream
//!   per salt so e.g. asteroid drift and NPC goal randomisation don't
//!   collide. Pure Rust, zero crate dependencies.
//!
//! Everything is pure + deterministic — the same `(seed, epoch, salt)`
//! always yields the same sequence, so save / load and net replay can
//! reconstruct past states bit-for-bit later.

#![forbid(unsafe_code)]

/// splitmix64 / xoshiro mixing constant — the same family as
/// `ce_planet::noise::hash64` so numerical behaviour stays consistent
/// across the project.
const MIX: u64 = 0x9E37_79B9_7F4A_7C15;

/// Wall-clock-style counter for the simulated world.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct WorldClock {
    pub seed: u64,
    pub epoch_seconds: f64,
}

impl WorldClock {
    /// Fresh clock at epoch zero with the given seed.
    pub const fn new(seed: u64) -> Self {
        Self {
            seed,
            epoch_seconds: 0.0,
        }
    }

    /// Fresh clock already advanced to `epoch_seconds`. Use this at
    /// the start of a new session so the first frame reads as "some
    /// time into the world's existence".
    pub const fn with_epoch(seed: u64, epoch_seconds: f64) -> Self {
        Self {
            seed,
            epoch_seconds,
        }
    }

    /// Advance the epoch by `dt` seconds. Negative or non-finite dt
    /// is silently ignored — time in this world only moves forward.
    pub fn tick(&mut self, dt: f32) {
        if dt.is_finite() && dt > 0.0 {
            self.epoch_seconds += dt as f64;
        }
    }

    /// Returns (hours, minutes, seconds) for HUD display. Hours can
    /// exceed 24 — we don't wrap on a day boundary, because this is
    /// world age, not time-of-day.
    pub fn age_hms(&self) -> (u32, u32, u32) {
        let total = self.epoch_seconds.max(0.0) as u64;
        let h = (total / 3600) as u32;
        let m = ((total % 3600) / 60) as u32;
        let s = (total % 60) as u32;
        (h, m, s)
    }

    /// Build a deterministic PRNG bound to this clock's `(seed,
    /// epoch)` plus a caller-chosen salt. Different salts give
    /// independent streams so multiple subsystems can sample without
    /// interfering.
    pub fn deterministic_rng(&self, salt: u64) -> DeterministicRng {
        DeterministicRng::from_parts(self.seed, self.epoch_seconds.max(0.0) as u64, salt)
    }
}

/// Small splitmix64-style PRNG. Deterministic, Copy, no allocations.
///
/// Not cryptographically secure — the use case is "same inputs, same
/// numbers" for world seeding, not secrecy.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct DeterministicRng {
    state: u64,
}

impl DeterministicRng {
    /// Fold three parameters into an initial state. Uses the same
    /// mixing family as `ce_planet::noise::hash64` so the numerical
    /// behaviour stays consistent with existing generation code.
    pub fn from_parts(seed: u64, epoch_u64: u64, salt: u64) -> Self {
        let mut s = seed
            .wrapping_add(MIX)
            .wrapping_mul(MIX)
            .wrapping_add(epoch_u64.wrapping_mul(MIX));
        s ^= s >> 33;
        s = s.wrapping_mul(0xFF51_AFD7_ED55_8CCD);
        s ^= s >> 33;
        s = s.wrapping_add(salt.wrapping_mul(MIX));
        s ^= s >> 29;
        s = s.wrapping_mul(0xC4CE_B9FE_1A85_EC53);
        s ^= s >> 32;
        Self { state: s }
    }

    /// Splitmix64 — advance state and emit a scrambled u64.
    pub fn next_u64(&mut self) -> u64 {
        self.state = self.state.wrapping_add(MIX);
        let mut z = self.state;
        z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
        z ^ (z >> 31)
    }

    /// Uniform in `[0, 1)`. Uses the top 24 bits so f32 precision
    /// fully covers the range.
    pub fn next_f32_unit(&mut self) -> f32 {
        let bits = (self.next_u64() >> 40) as u32; // 24 bits
        bits as f32 / (1u32 << 24) as f32
    }

    /// Uniform integer in `[lo, hi)`. If `hi <= lo`, returns `lo`.
    pub fn range_u32(&mut self, lo: u32, hi: u32) -> u32 {
        if hi <= lo {
            return lo;
        }
        let span = hi - lo;
        lo + (self.next_u64() % span as u64) as u32
    }

    /// Fair coin flip.
    pub fn bool(&mut self) -> bool {
        (self.next_u64() & 1) == 1
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn new_starts_at_zero_epoch() {
        let c = WorldClock::new(42);
        assert_eq!(c.epoch_seconds, 0.0);
        assert_eq!(c.seed, 42);
    }

    #[test]
    fn with_epoch_stores_value() {
        let c = WorldClock::with_epoch(1, 1800.0);
        assert_eq!(c.epoch_seconds, 1800.0);
    }

    #[test]
    fn tick_advances_epoch_monotonically() {
        let mut c = WorldClock::new(1);
        c.tick(0.5);
        c.tick(1.25);
        assert!((c.epoch_seconds - 1.75).abs() < 1e-9);
    }

    #[test]
    fn tick_ignores_negative_and_nan() {
        let mut c = WorldClock::with_epoch(1, 10.0);
        c.tick(-5.0);
        c.tick(f32::NAN);
        c.tick(f32::INFINITY);
        assert_eq!(c.epoch_seconds, 10.0);
    }

    #[test]
    fn age_hms_wraps_minutes_and_hours() {
        assert_eq!(WorldClock::with_epoch(0, 0.0).age_hms(), (0, 0, 0));
        assert_eq!(WorldClock::with_epoch(0, 59.9).age_hms(), (0, 0, 59));
        assert_eq!(WorldClock::with_epoch(0, 60.0).age_hms(), (0, 1, 0));
        assert_eq!(WorldClock::with_epoch(0, 3_600.0).age_hms(), (1, 0, 0));
        assert_eq!(WorldClock::with_epoch(0, 3_661.5).age_hms(), (1, 1, 1));
        // World age doesn't wrap on 24h — hours keep climbing.
        assert_eq!(
            WorldClock::with_epoch(0, 25.0 * 3600.0).age_hms(),
            (25, 0, 0)
        );
    }

    #[test]
    fn deterministic_rng_same_inputs_same_sequence() {
        let a = WorldClock::with_epoch(123, 1800.0);
        let b = WorldClock::with_epoch(123, 1800.0);
        let mut ra = a.deterministic_rng(7);
        let mut rb = b.deterministic_rng(7);
        for _ in 0..8 {
            assert_eq!(ra.next_u64(), rb.next_u64());
        }
    }

    #[test]
    fn deterministic_rng_different_salts_diverge() {
        let c = WorldClock::with_epoch(1, 100.0);
        let s1: Vec<u64> = (0..4).map(|_| c.deterministic_rng(1).next_u64()).collect();
        let s2: Vec<u64> = (0..4).map(|_| c.deterministic_rng(2).next_u64()).collect();
        assert_ne!(s1, s2);
    }

    #[test]
    fn deterministic_rng_range_respects_bounds_and_is_half_open() {
        let mut r = DeterministicRng::from_parts(0xDEAD_BEEF, 0, 0);
        for _ in 0..2_000 {
            let v = r.range_u32(10, 20);
            assert!((10..20).contains(&v));
        }
        // Degenerate bounds return lo.
        assert_eq!(r.range_u32(5, 5), 5);
        assert_eq!(r.range_u32(9, 3), 9);
    }

    #[test]
    fn deterministic_rng_f32_unit_in_half_open_unit_range() {
        let mut r = DeterministicRng::from_parts(1, 1, 1);
        for _ in 0..2_000 {
            let v = r.next_f32_unit();
            assert!((0.0..1.0).contains(&v), "out of range: {v}");
        }
    }

    #[test]
    fn bool_is_not_constant() {
        let mut r = DeterministicRng::from_parts(7, 7, 7);
        let mut saw_true = false;
        let mut saw_false = false;
        for _ in 0..64 {
            if r.bool() {
                saw_true = true;
            } else {
                saw_false = true;
            }
        }
        assert!(saw_true && saw_false);
    }
}

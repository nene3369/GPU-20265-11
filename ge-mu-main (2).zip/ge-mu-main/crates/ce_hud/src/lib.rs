//! `ce_hud` — tiny screen-space quad batcher for in-game HUDs.
//!
//! Accumulates coloured rectangles in pixel coordinates, then emits a
//! vertex stream suitable either for GPU upload (as `ce_render::Vertex`
//! in NDC) or for CPU rasterisation into a [`Framebuffer`] for golden
//! tests. No font yet — this milestone is bars only.

pub mod batch;
pub mod cpu;
pub mod font;

pub use batch::{HudBatch, HudVertex, Rect};
pub use cpu::rasterize_cpu;
pub use font::{glyph, GLYPH_ADVANCE, GLYPH_H, GLYPH_W};

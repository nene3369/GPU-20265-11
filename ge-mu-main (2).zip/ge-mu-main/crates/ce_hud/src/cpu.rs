//! CPU rasteriser for HUD rects.
//!
//! Not performance-critical; the point is to produce a pixel-exact
//! reference image for golden tests without requiring a GPU.

use crate::batch::{HudBatch, Rect};

/// Output pixel buffer. Row-major RGBA8, top-left origin.
pub struct Target<'a> {
    pub width: u32,
    pub height: u32,
    pub pixels: &'a mut [u8],
}

/// Fills every rect in `batch` onto `target`. Alpha-blends naively:
/// `out = src * a + dst * (1 - a)`.
pub fn rasterize_cpu(batch: &HudBatch, target: &mut Target<'_>) {
    let w = target.width as i32;
    let h = target.height as i32;
    for r in batch.rects() {
        fill_rect(target, *r, w, h);
    }
}

fn fill_rect(target: &mut Target<'_>, r: Rect, w: i32, h: i32) {
    let x0 = r.x.floor().max(0.0) as i32;
    let y0 = r.y.floor().max(0.0) as i32;
    let x1 = ((r.x + r.w).ceil() as i32).min(w);
    let y1 = ((r.y + r.h).ceil() as i32).min(h);
    if x0 >= x1 || y0 >= y1 {
        return;
    }
    let [sr, sg, sb, sa] = r.color;
    let a = sa.clamp(0.0, 1.0);
    let inv = 1.0 - a;
    for y in y0..y1 {
        for x in x0..x1 {
            let i = ((y * w + x) as usize) * 4;
            let dr = target.pixels[i] as f32 / 255.0;
            let dg = target.pixels[i + 1] as f32 / 255.0;
            let db = target.pixels[i + 2] as f32 / 255.0;
            let da = target.pixels[i + 3] as f32 / 255.0;
            target.pixels[i] = ((sr * a + dr * inv).clamp(0.0, 1.0) * 255.0) as u8;
            target.pixels[i + 1] = ((sg * a + dg * inv).clamp(0.0, 1.0) * 255.0) as u8;
            target.pixels[i + 2] = ((sb * a + db * inv).clamp(0.0, 1.0) * 255.0) as u8;
            target.pixels[i + 3] = ((a + da * inv).clamp(0.0, 1.0) * 255.0) as u8;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::batch::{HudBatch, Rect};

    fn fb(w: u32, h: u32, bg: [u8; 4]) -> Vec<u8> {
        let mut v = vec![0u8; (w * h * 4) as usize];
        for px in v.chunks_exact_mut(4) {
            px.copy_from_slice(&bg);
        }
        v
    }

    #[test]
    fn single_rect_fills_expected_region() {
        let (w, h) = (8, 8);
        let mut pixels = fb(w, h, [0, 0, 0, 255]);
        let mut t = Target {
            width: w,
            height: h,
            pixels: &mut pixels,
        };
        let mut batch = HudBatch::new();
        batch.push_rect(Rect {
            x: 2.0,
            y: 2.0,
            w: 4.0,
            h: 4.0,
            color: [1.0, 0.0, 0.0, 1.0],
        });
        rasterize_cpu(&batch, &mut t);
        // Centre pixel should be red, corner should still be background.
        let centre = 4 * (w as usize) * 4 + 4 * 4;
        assert_eq!(&pixels[centre..centre + 3], &[255, 0, 0]);
        assert_eq!(&pixels[0..3], &[0, 0, 0]);
    }

    #[test]
    fn alpha_blends_over_background() {
        let (w, h) = (2, 2);
        let mut pixels = fb(w, h, [200, 200, 200, 255]);
        let mut t = Target {
            width: w,
            height: h,
            pixels: &mut pixels,
        };
        let mut batch = HudBatch::new();
        batch.push_rect(Rect {
            x: 0.0,
            y: 0.0,
            w: 2.0,
            h: 2.0,
            color: [0.0, 0.0, 0.0, 0.5],
        });
        rasterize_cpu(&batch, &mut t);
        // 200 * 0.5 + 0 * 0.5 = 100.
        assert!((pixels[0] as i32 - 100).abs() <= 1);
    }

    #[test]
    fn rect_outside_target_is_clipped() {
        let (w, h) = (4, 4);
        let mut pixels = fb(w, h, [0, 0, 0, 255]);
        let mut t = Target {
            width: w,
            height: h,
            pixels: &mut pixels,
        };
        let mut batch = HudBatch::new();
        batch.push_rect(Rect {
            x: 10.0,
            y: 10.0,
            w: 2.0,
            h: 2.0,
            color: [1.0, 1.0, 1.0, 1.0],
        });
        rasterize_cpu(&batch, &mut t);
        // No pixel should have been written.
        assert!(pixels.iter().step_by(4).all(|&b| b == 0));
    }
}

//! Quad batching in pixel-space, resolved to NDC at finalize time.

/// One axis-aligned rectangle in pixel space.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Rect {
    /// Top-left x in pixels; origin is the top-left of the screen.
    pub x: f32,
    pub y: f32,
    pub w: f32,
    pub h: f32,
    pub color: [f32; 4],
}

/// Final vertex written to a GPU vertex buffer (or consumed by the
/// CPU rasteriser in [`super::cpu`]). Layout matches
/// `ce_render::Vertex` so the same buffer desc can be reused.
#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq, bytemuck::Pod, bytemuck::Zeroable)]
pub struct HudVertex {
    pub position: [f32; 3],
    pub color: [f32; 4],
}

impl HudVertex {
    pub fn desc() -> wgpu_hud_desc::BufferLayoutLike {
        wgpu_hud_desc::BufferLayoutLike {
            stride: std::mem::size_of::<HudVertex>() as u64,
            attributes: [
                wgpu_hud_desc::AttributeLike {
                    offset: 0,
                    location: 0,
                    format: wgpu_hud_desc::FormatLike::Float32x3,
                },
                wgpu_hud_desc::AttributeLike {
                    offset: std::mem::size_of::<[f32; 3]>() as u64,
                    location: 1,
                    format: wgpu_hud_desc::FormatLike::Float32x4,
                },
            ],
        }
    }
}

/// Accumulator. Coordinates are in pixels; [`HudBatch::finish`] maps
/// them to NDC using the target's resolution.
#[derive(Debug, Default, Clone)]
pub struct HudBatch {
    rects: Vec<Rect>,
}

impl HudBatch {
    pub fn new() -> Self {
        Self { rects: Vec::new() }
    }

    pub fn push_rect(&mut self, rect: Rect) {
        self.rects.push(rect);
    }

    /// Horizontal bar at `pos` (pixel top-left) with given `size`,
    /// filled proportionally to `fill` ∈ [0, 1]. Handy for speed and
    /// fuel gauges.
    pub fn push_bar(
        &mut self,
        pos: [f32; 2],
        size: [f32; 2],
        fill: f32,
        fg: [f32; 4],
        bg: [f32; 4],
    ) {
        let [x, y] = pos;
        let [w, h] = size;
        self.push_rect(Rect {
            x,
            y,
            w,
            h,
            color: bg,
        });
        let fill = fill.clamp(0.0, 1.0);
        if fill > 0.0 {
            self.push_rect(Rect {
                x,
                y,
                w: w * fill,
                h,
                color: fg,
            });
        }
    }

    pub fn rects(&self) -> &[Rect] {
        &self.rects
    }

    /// Rasterises `text` using the 3×5 bitmap font in [`super::font`].
    /// `pos` is the top-left corner of the first glyph in pixel space;
    /// `scale` is a per-pixel multiplier (integer upscaling — `scale=2`
    /// means every glyph pixel becomes a 2×2 rect).
    pub fn push_text(&mut self, pos: [f32; 2], scale: f32, color: [f32; 4], text: &str) {
        let [mut x, y] = pos;
        let step_x = f32::from(super::font::GLYPH_ADVANCE) * scale;
        for c in text.chars() {
            self.push_glyph([x, y], scale, color, c);
            x += step_x;
        }
    }

    /// Draws a single glyph at `pos` with the given scale. Exposed so
    /// callers can lay out complex layouts (centred numbers, kerned
    /// labels) without re-walking `push_text`.
    pub fn push_glyph(&mut self, pos: [f32; 2], scale: f32, color: [f32; 4], c: char) {
        let bitmap = super::font::glyph(c);
        let w = super::font::GLYPH_W;
        let h = super::font::GLYPH_H;
        let [px, py] = pos;
        for row in 0..h {
            let bits = bitmap[row as usize];
            for col in 0..w {
                let mask = 1u8 << (w - 1 - col);
                if bits & mask != 0 {
                    self.push_rect(Rect {
                        x: px + f32::from(col) * scale,
                        y: py + f32::from(row) * scale,
                        w: scale,
                        h: scale,
                        color,
                    });
                }
            }
        }
    }

    /// Converts pixel rects into two CCW triangles each in NDC space.
    ///
    /// Screen conventions: x right, y **down**. Output NDC follows the
    /// convention the project's other shaders use (y up).
    pub fn finish(&self, screen_w: f32, screen_h: f32) -> Vec<HudVertex> {
        let mut out = Vec::with_capacity(self.rects.len() * 6);
        for r in &self.rects {
            let x0 = to_ndc_x(r.x, screen_w);
            let x1 = to_ndc_x(r.x + r.w, screen_w);
            let y0 = to_ndc_y(r.y, screen_h);
            let y1 = to_ndc_y(r.y + r.h, screen_h);
            // CCW in the "y-up" NDC convention the other shaders use.
            // (x0, y0) is top-left → NDC y is larger there.
            let tl = HudVertex {
                position: [x0, y0, 0.0],
                color: r.color,
            };
            let tr = HudVertex {
                position: [x1, y0, 0.0],
                color: r.color,
            };
            let bl = HudVertex {
                position: [x0, y1, 0.0],
                color: r.color,
            };
            let br = HudVertex {
                position: [x1, y1, 0.0],
                color: r.color,
            };
            out.extend_from_slice(&[tl, bl, br, tl, br, tr]);
        }
        out
    }
}

fn to_ndc_x(px: f32, screen_w: f32) -> f32 {
    (px / screen_w) * 2.0 - 1.0
}

fn to_ndc_y(py: f32, screen_h: f32) -> f32 {
    1.0 - (py / screen_h) * 2.0
}

// Mini shim so this crate can describe a vertex layout without a hard
// wgpu dep (which would pull a ton of transitive deps into a library
// that might also be used in non-wgpu contexts). Consumers can map
// `BufferLayoutLike` to a `wgpu::VertexBufferLayout` in one line.
pub mod wgpu_hud_desc {
    #[derive(Debug, Clone, Copy, PartialEq)]
    pub enum FormatLike {
        Float32x3,
        Float32x4,
    }
    #[derive(Debug, Clone, Copy, PartialEq)]
    pub struct AttributeLike {
        pub offset: u64,
        pub location: u32,
        pub format: FormatLike,
    }
    #[derive(Debug, Clone)]
    pub struct BufferLayoutLike {
        pub stride: u64,
        pub attributes: [AttributeLike; 2],
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn finish_produces_six_vertices_per_rect() {
        let mut b = HudBatch::new();
        b.push_rect(Rect {
            x: 0.0,
            y: 0.0,
            w: 10.0,
            h: 5.0,
            color: [1.0, 0.0, 0.0, 1.0],
        });
        assert_eq!(b.finish(100.0, 100.0).len(), 6);
    }

    #[test]
    fn push_bar_adds_two_rects_when_fill_positive() {
        let mut b = HudBatch::new();
        b.push_bar([0.0, 0.0], [10.0, 2.0], 0.5, [1.0; 4], [0.2, 0.2, 0.2, 1.0]);
        assert_eq!(b.rects().len(), 2);
    }

    #[test]
    fn push_bar_with_zero_fill_emits_background_only() {
        let mut b = HudBatch::new();
        b.push_bar([0.0, 0.0], [10.0, 2.0], 0.0, [1.0; 4], [0.2, 0.2, 0.2, 1.0]);
        assert_eq!(b.rects().len(), 1);
    }

    #[test]
    fn push_bar_clamps_fill() {
        let mut b = HudBatch::new();
        b.push_bar([0.0, 0.0], [10.0, 2.0], 5.0, [1.0; 4], [0.2, 0.2, 0.2, 1.0]);
        // Second rect width clamped to full bar.
        assert_eq!(b.rects()[1].w, 10.0);
    }

    #[test]
    fn push_glyph_emits_one_rect_per_lit_pixel_of_digit_zero() {
        let mut b = HudBatch::new();
        b.push_glyph([0.0, 0.0], 1.0, [1.0; 4], '0');
        // '0' has 3+2+2+2+3 = 12 lit pixels.
        assert_eq!(b.rects().len(), 12);
    }

    #[test]
    fn push_glyph_respects_scale() {
        let mut b = HudBatch::new();
        b.push_glyph([0.0, 0.0], 3.0, [1.0; 4], '1');
        for r in b.rects() {
            assert_eq!(r.w, 3.0);
            assert_eq!(r.h, 3.0);
        }
    }

    #[test]
    fn push_text_advances_x_per_glyph() {
        let mut b = HudBatch::new();
        b.push_text([0.0, 0.0], 1.0, [1.0; 4], "12");
        // Find the min-x of rects belonging to the '2' glyph: they
        // start at `GLYPH_ADVANCE`.
        let max_x = b.rects().iter().map(|r| r.x as i32).max().unwrap();
        // '2' is 3 wide; its rightmost pixel starts at advance + 2.
        let advance = super::super::font::GLYPH_ADVANCE as i32;
        assert_eq!(max_x, advance + 2);
    }

    #[test]
    fn push_text_skips_space() {
        let mut b = HudBatch::new();
        b.push_text([0.0, 0.0], 1.0, [1.0; 4], "   ");
        assert_eq!(b.rects().len(), 0);
    }

    #[test]
    fn ndc_maps_top_left_to_minus1_plus1() {
        let mut b = HudBatch::new();
        b.push_rect(Rect {
            x: 0.0,
            y: 0.0,
            w: 100.0,
            h: 100.0,
            color: [1.0; 4],
        });
        let vs = b.finish(100.0, 100.0);
        // First emitted vertex is top-left corner.
        assert_eq!(vs[0].position, [-1.0, 1.0, 0.0]);
    }
}

//! 3×5 monospace pixel font.
//!
//! Each glyph is a 3-wide, 5-tall bitmap packed into `[u8; 5]`: one
//! byte per row, with the low 3 bits holding the pixel pattern
//! (bit 2 = leftmost pixel, bit 0 = rightmost).
//!
//! The character set is intentionally tight — digits, uppercase
//! letters, and the handful of punctuation glyphs the HUD needs.
//! Unknown chars map to a filled block so missing glyphs are obvious.

/// Pixels wide per glyph (content).
pub const GLYPH_W: u8 = 3;
/// Pixels tall per glyph.
pub const GLYPH_H: u8 = 5;
/// Horizontal gap between glyphs in the default `push_text` layout.
pub const GLYPH_ADVANCE: u8 = GLYPH_W + 1;

/// Bitmap for one glyph. `rows[y] & (1 << (GLYPH_W - 1 - x))` = pixel on.
pub type Glyph = [u8; GLYPH_H as usize];

/// Looks up the bitmap for `c`. Unsupported chars return a fully-lit
/// block so the missing glyph is obvious in screenshots.
pub fn glyph(c: char) -> Glyph {
    match c {
        ' ' => [0b000, 0b000, 0b000, 0b000, 0b000],
        '.' => [0b000, 0b000, 0b000, 0b000, 0b010],
        ',' => [0b000, 0b000, 0b000, 0b010, 0b100],
        ':' => [0b000, 0b010, 0b000, 0b010, 0b000],
        '-' => [0b000, 0b000, 0b111, 0b000, 0b000],
        '+' => [0b000, 0b010, 0b111, 0b010, 0b000],
        '/' => [0b001, 0b001, 0b010, 0b100, 0b100],
        '=' => [0b000, 0b111, 0b000, 0b111, 0b000],
        '(' => [0b010, 0b100, 0b100, 0b100, 0b010],
        ')' => [0b010, 0b001, 0b001, 0b001, 0b010],
        '0' => [0b111, 0b101, 0b101, 0b101, 0b111],
        '1' => [0b010, 0b110, 0b010, 0b010, 0b111],
        '2' => [0b111, 0b001, 0b111, 0b100, 0b111],
        '3' => [0b111, 0b001, 0b111, 0b001, 0b111],
        '4' => [0b101, 0b101, 0b111, 0b001, 0b001],
        '5' => [0b111, 0b100, 0b111, 0b001, 0b111],
        '6' => [0b111, 0b100, 0b111, 0b101, 0b111],
        '7' => [0b111, 0b001, 0b001, 0b001, 0b001],
        '8' => [0b111, 0b101, 0b111, 0b101, 0b111],
        '9' => [0b111, 0b101, 0b111, 0b001, 0b111],
        'A' => [0b111, 0b101, 0b111, 0b101, 0b101],
        'B' => [0b110, 0b101, 0b110, 0b101, 0b110],
        'C' => [0b111, 0b100, 0b100, 0b100, 0b111],
        'D' => [0b110, 0b101, 0b101, 0b101, 0b110],
        'E' => [0b111, 0b100, 0b111, 0b100, 0b111],
        'F' => [0b111, 0b100, 0b111, 0b100, 0b100],
        'G' => [0b111, 0b100, 0b101, 0b101, 0b111],
        'H' => [0b101, 0b101, 0b111, 0b101, 0b101],
        'I' => [0b111, 0b010, 0b010, 0b010, 0b111],
        'J' => [0b111, 0b001, 0b001, 0b101, 0b111],
        'K' => [0b101, 0b101, 0b110, 0b101, 0b101],
        'L' => [0b100, 0b100, 0b100, 0b100, 0b111],
        'M' => [0b101, 0b111, 0b111, 0b101, 0b101],
        'N' => [0b101, 0b111, 0b111, 0b111, 0b101],
        'O' => [0b111, 0b101, 0b101, 0b101, 0b111],
        'P' => [0b111, 0b101, 0b111, 0b100, 0b100],
        'Q' => [0b111, 0b101, 0b101, 0b111, 0b011],
        'R' => [0b111, 0b101, 0b110, 0b101, 0b101],
        'S' => [0b111, 0b100, 0b111, 0b001, 0b111],
        'T' => [0b111, 0b010, 0b010, 0b010, 0b010],
        'U' => [0b101, 0b101, 0b101, 0b101, 0b111],
        'V' => [0b101, 0b101, 0b101, 0b101, 0b010],
        'W' => [0b101, 0b101, 0b111, 0b111, 0b101],
        'X' => [0b101, 0b101, 0b010, 0b101, 0b101],
        'Y' => [0b101, 0b101, 0b010, 0b010, 0b010],
        'Z' => [0b111, 0b001, 0b010, 0b100, 0b111],
        _ => [0b111, 0b111, 0b111, 0b111, 0b111],
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn glyph_dimensions_are_fixed() {
        assert_eq!(glyph('0').len(), GLYPH_H as usize);
    }

    #[test]
    fn space_is_fully_blank() {
        assert_eq!(glyph(' '), [0; GLYPH_H as usize]);
    }

    #[test]
    fn every_row_fits_in_3_bits() {
        for c in '0'..='9' {
            for row in glyph(c) {
                assert!(row < 8, "{c} row exceeds 3-bit field");
            }
        }
        for c in 'A'..='Z' {
            for row in glyph(c) {
                assert!(row < 8, "{c} row exceeds 3-bit field");
            }
        }
    }

    #[test]
    fn unknown_char_renders_solid_block() {
        assert_eq!(glyph('~'), [0b111; GLYPH_H as usize]);
    }

    #[test]
    fn digit_one_has_expected_stem() {
        // Second row of '1' should have both the stem and the serif:
        // "##." => 0b110.
        assert_eq!(glyph('1')[1], 0b110);
    }

    #[test]
    fn letter_e_has_three_crossbars() {
        // E: top, middle, bottom all on.
        let g = glyph('E');
        assert_eq!(g[0], 0b111);
        assert_eq!(g[2], 0b111);
        assert_eq!(g[4], 0b111);
    }
}

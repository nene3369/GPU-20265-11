//! Golden-image test for the HUD batcher.
//!
//! Builds a representative HUD layout (speed bar + thrust bars),
//! rasterises it on the CPU, then diffs against a committed PPM.

use std::path::PathBuf;

use ce_hud::{rasterize_cpu, HudBatch, Rect};
use ce_softraster::{assert_golden, Framebuffer};

const W: u32 = 128;
const H: u32 = 32;
const TOLERANCE: u8 = 1;

fn goldens_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("tests")
        .join("goldens")
}

#[test]
fn golden_hud_reference_layout() {
    let mut fb = Framebuffer::new(W, H);
    fb.clear([8, 10, 16, 255]);
    // `ce_softraster::Framebuffer` hides its pixel buffer, so build a
    // parallel buffer for the HUD rasteriser and then copy it back
    // via the public `set_pixel` API.
    let mut pixels = vec![0u8; (W * H * 4) as usize];
    // Seed with the same clear colour so alpha blending matches.
    for px in pixels.chunks_exact_mut(4) {
        px.copy_from_slice(&[8, 10, 16, 255]);
    }

    let mut batch = HudBatch::new();
    // Speed bar along the top.
    batch.push_bar(
        [4.0, 4.0],
        [120.0, 4.0],
        0.6,
        [0.2, 0.8, 1.0, 1.0],
        [0.1, 0.15, 0.2, 0.7],
    );
    // Three short thrust bars beneath.
    batch.push_bar(
        [4.0, 14.0],
        [36.0, 3.0],
        0.9,
        [1.0, 0.8, 0.2, 1.0],
        [0.1, 0.1, 0.1, 0.7],
    );
    batch.push_bar(
        [44.0, 14.0],
        [36.0, 3.0],
        0.4,
        [1.0, 0.8, 0.2, 1.0],
        [0.1, 0.1, 0.1, 0.7],
    );
    batch.push_bar(
        [84.0, 14.0],
        [36.0, 3.0],
        0.15,
        [1.0, 0.8, 0.2, 1.0],
        [0.1, 0.1, 0.1, 0.7],
    );
    // A single highlight dot.
    batch.push_rect(Rect {
        x: 62.0,
        y: 24.0,
        w: 4.0,
        h: 4.0,
        color: [1.0, 0.2, 0.2, 1.0],
    });

    let mut target = ce_hud::cpu::Target {
        width: W,
        height: H,
        pixels: &mut pixels,
    };
    rasterize_cpu(&batch, &mut target);

    // Copy the HUD pixels into the Framebuffer (so we can use the
    // existing `assert_golden` helper).
    for y in 0..H {
        for x in 0..W {
            let i = ((y * W + x) as usize) * 4;
            fb.set_pixel(
                x,
                y,
                [pixels[i], pixels[i + 1], pixels[i + 2], pixels[i + 3]],
            );
        }
    }

    assert_golden(&fb, goldens_dir().join("hud_reference.ppm"), TOLERANCE).unwrap();
}

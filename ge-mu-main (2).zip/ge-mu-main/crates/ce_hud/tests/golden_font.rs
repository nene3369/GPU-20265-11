//! Golden-image test for the 3×5 bitmap font.
//!
//! Renders a representative line ("SPD 12.3 POS -4.5:6.7:8.9") at two
//! scales and snapshots the result. Any change to the glyph bitmaps
//! or kerning will fail this test.

use std::path::PathBuf;

use ce_hud::{rasterize_cpu, HudBatch};
use ce_softraster::{assert_golden, Framebuffer};

const W: u32 = 192;
const H: u32 = 24;
const TOLERANCE: u8 = 1;

fn goldens_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("tests")
        .join("goldens")
}

#[test]
fn golden_font_sample_line() {
    let mut pixels = vec![0u8; (W * H * 4) as usize];
    for px in pixels.chunks_exact_mut(4) {
        px.copy_from_slice(&[6, 8, 14, 255]);
    }

    let mut batch = HudBatch::new();
    // Label + numbers at scale 2 (6 wide × 10 tall per glyph).
    batch.push_text([4.0, 2.0], 2.0, [1.0, 1.0, 1.0, 1.0], "SPD 12.3");
    // Second line at scale 1 (3×5) so both scales are exercised.
    batch.push_text([4.0, 16.0], 1.0, [0.6, 0.9, 1.0, 1.0], "POS -4.5:6.7:8.9");

    let mut target = ce_hud::cpu::Target {
        width: W,
        height: H,
        pixels: &mut pixels,
    };
    rasterize_cpu(&batch, &mut target);

    let mut fb = Framebuffer::new(W, H);
    for y in 0..H {
        for x in 0..W {
            let i = ((y * W + x) as usize) * 4;
            fb.set_pixel(
                x,
                y,
                [pixels[i], pixels[i + 1], pixels[i + 2], pixels[i + 3]],
            );
        }
    }

    assert_golden(&fb, goldens_dir().join("font_sample.ppm"), TOLERANCE).unwrap();
}

//! Sparse voxel grid storing ship / base blocks.
//!
//! Design notes:
//! - `ShipBlocks` is a pure data value (HashMap + counters). No
//!   borrowed state, no global mutability — suitable for future serde
//!   serialization and network replication without refactor.
//! - Coordinates are integer cell indices (`IVec3`) in ship-local
//!   space. One cell = 1 m cube.

use std::collections::{HashMap, HashSet};

use ce_math::IVec3;

use crate::block::{Block, BlockKind};

/// The six axis-aligned neighbour offsets used by connectivity walks.
pub const NEIGHBOR_OFFSETS: [IVec3; 6] = [
    IVec3::new(1, 0, 0),
    IVec3::new(-1, 0, 0),
    IVec3::new(0, 1, 0),
    IVec3::new(0, -1, 0),
    IVec3::new(0, 0, 1),
    IVec3::new(0, 0, -1),
];

/// Sparse block storage for one ship or base. A component attached to
/// the ship entity.
#[derive(Debug, Clone, Default)]
pub struct ShipBlocks {
    cells: HashMap<IVec3, Block>,
}

impl ShipBlocks {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn insert(&mut self, pos: IVec3, block: Block) -> Option<Block> {
        self.cells.insert(pos, block)
    }

    pub fn remove(&mut self, pos: IVec3) -> Option<Block> {
        self.cells.remove(&pos)
    }

    pub fn get(&self, pos: IVec3) -> Option<&Block> {
        self.cells.get(&pos)
    }

    pub fn get_mut(&mut self, pos: IVec3) -> Option<&mut Block> {
        self.cells.get_mut(&pos)
    }

    pub fn contains(&self, pos: IVec3) -> bool {
        self.cells.contains_key(&pos)
    }

    pub fn len(&self) -> usize {
        self.cells.len()
    }

    pub fn is_empty(&self) -> bool {
        self.cells.is_empty()
    }

    pub fn iter(&self) -> impl Iterator<Item = (&IVec3, &Block)> {
        self.cells.iter()
    }

    /// Blocks of a given kind.
    pub fn iter_kind(&self, kind: BlockKind) -> impl Iterator<Item = (&IVec3, &Block)> {
        self.cells.iter().filter(move |(_, b)| b.kind == kind)
    }

    /// All cells that make up the connected component containing `seed`.
    /// Empty if `seed` is not occupied.
    pub fn connected_component(&self, seed: IVec3) -> HashSet<IVec3> {
        let mut out = HashSet::new();
        if !self.contains(seed) {
            return out;
        }
        let mut stack = vec![seed];
        while let Some(p) = stack.pop() {
            if !out.insert(p) {
                continue;
            }
            for off in NEIGHBOR_OFFSETS {
                let n = p + off;
                if self.contains(n) && !out.contains(&n) {
                    stack.push(n);
                }
            }
        }
        out
    }

    /// Returns one component per disconnected island of blocks. Used
    /// after damage to detect "the ship broke into two pieces".
    pub fn components(&self) -> Vec<HashSet<IVec3>> {
        let mut seen: HashSet<IVec3> = HashSet::new();
        let mut out: Vec<HashSet<IVec3>> = Vec::new();
        for &cell in self.cells.keys() {
            if seen.contains(&cell) {
                continue;
            }
            let comp = self.connected_component(cell);
            seen.extend(comp.iter().copied());
            out.push(comp);
        }
        out
    }

    /// True if every block is reachable from any other via axis-aligned
    /// neighbours. A one-block ship is trivially connected.
    pub fn is_structurally_connected(&self) -> bool {
        if self.is_empty() {
            return true;
        }
        let any = *self.cells.keys().next().unwrap();
        self.connected_component(any).len() == self.cells.len()
    }

    /// Inclusive axis-aligned bounding box of occupied cells, or `None`
    /// when the grid is empty.
    pub fn bounding_box(&self) -> Option<(IVec3, IVec3)> {
        let mut iter = self.cells.keys().copied();
        let first = iter.next()?;
        let mut min = first;
        let mut max = first;
        for p in iter {
            min = min.min(p);
            max = max.max(p);
        }
        Some((min, max))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::block::{Block, BlockKind, BlockMaterial};

    fn hull(ivec: IVec3) -> (IVec3, Block) {
        (ivec, Block::new(BlockKind::Hull, BlockMaterial::Iron))
    }

    fn grid(positions: &[IVec3]) -> ShipBlocks {
        let mut g = ShipBlocks::new();
        for &p in positions {
            let (pos, b) = hull(p);
            g.insert(pos, b);
        }
        g
    }

    #[test]
    fn empty_grid_is_connected_and_boundsless() {
        let g = ShipBlocks::new();
        assert!(g.is_empty());
        assert!(g.is_structurally_connected());
        assert!(g.bounding_box().is_none());
    }

    #[test]
    fn single_block_is_connected() {
        let g = grid(&[IVec3::ZERO]);
        assert!(g.is_structurally_connected());
        assert_eq!(g.components().len(), 1);
    }

    #[test]
    fn two_adjacent_blocks_are_one_component() {
        let g = grid(&[IVec3::ZERO, IVec3::new(1, 0, 0)]);
        assert!(g.is_structurally_connected());
        let comps = g.components();
        assert_eq!(comps.len(), 1);
        assert_eq!(comps[0].len(), 2);
    }

    #[test]
    fn two_separated_blocks_are_two_components() {
        let g = grid(&[IVec3::ZERO, IVec3::new(5, 0, 0)]);
        assert!(!g.is_structurally_connected());
        let comps = g.components();
        assert_eq!(comps.len(), 2);
        assert_eq!(comps[0].len(), 1);
        assert_eq!(comps[1].len(), 1);
    }

    #[test]
    fn diagonal_neighbours_do_not_connect() {
        // (0,0,0) and (1,1,0) share only an edge, no face — must NOT
        // be treated as one structural component.
        let g = grid(&[IVec3::ZERO, IVec3::new(1, 1, 0)]);
        assert!(!g.is_structurally_connected());
    }

    #[test]
    fn connected_component_floodfills_large_shapes() {
        // 3x3x1 slab = 9 blocks all connected.
        let mut cells = Vec::new();
        for x in 0..3 {
            for z in 0..3 {
                cells.push(IVec3::new(x, 0, z));
            }
        }
        let g = grid(&cells);
        let comp = g.connected_component(IVec3::new(1, 0, 1));
        assert_eq!(comp.len(), 9);
        assert!(g.is_structurally_connected());
    }

    #[test]
    fn bounding_box_covers_all_cells() {
        let g = grid(&[
            IVec3::new(0, 0, 0),
            IVec3::new(2, -1, 3),
            IVec3::new(-1, 4, 1),
        ]);
        let (min, max) = g.bounding_box().unwrap();
        assert_eq!(min, IVec3::new(-1, -1, 0));
        assert_eq!(max, IVec3::new(2, 4, 3));
    }

    #[test]
    fn iter_kind_filters_by_block_kind() {
        let mut g = ShipBlocks::new();
        g.insert(
            IVec3::ZERO,
            Block::new(BlockKind::Hull, BlockMaterial::Iron),
        );
        g.insert(
            IVec3::new(1, 0, 0),
            Block::new(BlockKind::Thruster, BlockMaterial::Iron),
        );
        g.insert(
            IVec3::new(2, 0, 0),
            Block::new(BlockKind::Thruster, BlockMaterial::Iron),
        );
        assert_eq!(g.iter_kind(BlockKind::Thruster).count(), 2);
        assert_eq!(g.iter_kind(BlockKind::Hull).count(), 1);
    }

    #[test]
    fn connected_component_from_empty_cell_is_empty() {
        let g = grid(&[IVec3::ZERO]);
        assert!(g.connected_component(IVec3::new(99, 0, 0)).is_empty());
    }
}

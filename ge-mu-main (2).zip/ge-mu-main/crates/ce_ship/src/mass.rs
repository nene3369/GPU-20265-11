//! Mass properties derived from a [`ShipBlocks`] grid.
//!
//! Pure functions — no ECS contact, trivially testable with hand-built
//! grids.

use ce_math::Vec3;

use crate::grid::ShipBlocks;

/// Aggregate inertial properties for a ship. Produced by
/// [`compute_mass_properties`] from a [`ShipBlocks`] and passed to the
/// physics layer.
#[derive(Debug, Clone, Copy, Default, PartialEq)]
pub struct MassProperties {
    /// Total mass in kilograms.
    pub mass: f32,
    /// Centre of mass in ship-local coordinates (metres).
    pub center_of_mass: Vec3,
    /// Diagonal of the inertia tensor about the centre of mass, in
    /// kg·m². For an Avorion-style axis-aligned ship, off-diagonal
    /// cross terms are typically small; we ignore them in M6 and add
    /// the full 3×3 tensor when rotational damage handling requires it.
    pub inertia_diag: Vec3,
}

/// Computes mass, centre of mass, and diagonal inertia of `grid`.
/// Each block is treated as a 1 m³ cube with uniform density.
/// Block mass is integrated at the *centre* of its cell, which is
/// (pos.x + 0.5, pos.y + 0.5, pos.z + 0.5) in ship-local metres.
pub fn compute_mass_properties(grid: &ShipBlocks) -> MassProperties {
    let mut total_mass = 0.0f32;
    let mut weighted_pos = Vec3::ZERO;

    // First pass: total mass + weighted position sum.
    for (cell, block) in grid.iter() {
        let m = block.mass_kg();
        total_mass += m;
        let c = cell_center(*cell);
        weighted_pos += c * m;
    }

    if total_mass == 0.0 {
        return MassProperties::default();
    }

    let com = weighted_pos / total_mass;

    // Second pass: inertia diagonal about the CoM.
    // For a 1 m³ cube with uniform density, self-inertia about its own
    // centre is (m / 6) on each axis (I = m·a²/6 with a = 1 m). Add the
    // parallel-axis term m·(r² − r_axis²) for each off-axis distance.
    let mut ixx = 0.0f32;
    let mut iyy = 0.0f32;
    let mut izz = 0.0f32;
    for (cell, block) in grid.iter() {
        let m = block.mass_kg();
        let r = cell_center(*cell) - com;
        let self_term = m / 6.0;
        ixx += self_term + m * (r.y * r.y + r.z * r.z);
        iyy += self_term + m * (r.x * r.x + r.z * r.z);
        izz += self_term + m * (r.x * r.x + r.y * r.y);
    }

    MassProperties {
        mass: total_mass,
        center_of_mass: com,
        inertia_diag: Vec3::new(ixx, iyy, izz),
    }
}

#[inline]
fn cell_center(cell: ce_math::IVec3) -> Vec3 {
    Vec3::new(
        cell.x as f32 + 0.5,
        cell.y as f32 + 0.5,
        cell.z as f32 + 0.5,
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use ce_math::IVec3;

    use crate::block::{Block, BlockKind, BlockMaterial};

    fn iron_block() -> Block {
        Block::new(BlockKind::Hull, BlockMaterial::Iron)
    }

    #[test]
    fn empty_grid_has_zero_mass_properties() {
        let p = compute_mass_properties(&ShipBlocks::new());
        assert_eq!(p, MassProperties::default());
    }

    #[test]
    fn single_block_centers_on_its_own_cell() {
        let mut g = ShipBlocks::new();
        g.insert(IVec3::ZERO, iron_block());
        let p = compute_mass_properties(&g);
        assert!((p.mass - BlockMaterial::Iron.density_kg_per_m3()).abs() < 1e-3);
        assert!((p.center_of_mass - Vec3::new(0.5, 0.5, 0.5)).length() < 1e-5);
        // Self-inertia of a 1 m cube: m/6 on each axis.
        let expected = p.mass / 6.0;
        assert!((p.inertia_diag.x - expected).abs() < 1e-2);
        assert!((p.inertia_diag.y - expected).abs() < 1e-2);
        assert!((p.inertia_diag.z - expected).abs() < 1e-2);
    }

    #[test]
    fn com_of_symmetric_two_block_ship_is_midpoint() {
        let mut g = ShipBlocks::new();
        g.insert(IVec3::ZERO, iron_block());
        g.insert(IVec3::new(2, 0, 0), iron_block());
        let p = compute_mass_properties(&g);
        // Cells are centred at (0.5,...) and (2.5,...), midpoint = 1.5.
        assert!((p.center_of_mass.x - 1.5).abs() < 1e-4);
        assert!((p.center_of_mass.y - 0.5).abs() < 1e-4);
    }

    #[test]
    fn mass_scales_linearly_with_block_count() {
        let mut g = ShipBlocks::new();
        for x in 0..5 {
            g.insert(IVec3::new(x, 0, 0), iron_block());
        }
        let p = compute_mass_properties(&g);
        let expected = 5.0 * BlockMaterial::Iron.density_kg_per_m3();
        assert!((p.mass - expected).abs() < 1e-2);
    }

    #[test]
    fn heavier_material_raises_mass() {
        let mut g = ShipBlocks::new();
        g.insert(
            IVec3::ZERO,
            Block::new(BlockKind::Hull, BlockMaterial::Tungsten),
        );
        let p = compute_mass_properties(&g);
        assert!(p.mass > 10_000.0, "tungsten ought to exceed 10 t/m³");
    }

    #[test]
    fn inertia_grows_with_arm_length() {
        // Two configurations of the same mass: long rod vs compact cluster.
        // Long rod must have larger principal inertias about perpendicular axes.
        let mut long_rod = ShipBlocks::new();
        for x in 0..10 {
            long_rod.insert(IVec3::new(x, 0, 0), iron_block());
        }
        let mut cluster = ShipBlocks::new();
        // 10-block 2×5×1 slab has a shorter max extent on X/Y than the rod.
        for x in 0..2 {
            for y in 0..5 {
                cluster.insert(IVec3::new(x, y, 0), iron_block());
            }
        }
        let rod = compute_mass_properties(&long_rod);
        let slab = compute_mass_properties(&cluster);
        assert!((rod.mass - slab.mass).abs() < 1e-1);
        // Rotating the rod about the Y axis sweeps the full 10 m length.
        // The slab's Y inertia about its CoM is bounded by its shorter extent.
        assert!(
            rod.inertia_diag.y > slab.inertia_diag.y,
            "rod must have higher Iyy than compact slab ({} vs {})",
            rod.inertia_diag.y,
            slab.inertia_diag.y
        );
    }
}

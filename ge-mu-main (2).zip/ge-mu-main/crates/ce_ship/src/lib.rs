//! `ce_ship` — Avorion-style block construction.
//!
//! A ship (or base) is a sparse voxel grid of [`Block`] values. From
//! the grid we derive:
//! - Structural connectivity (flood-fill) — damaged ships can split
//!   into multiple independent fragments.
//! - [`MassProperties`] — mass, centre of mass, diagonal inertia used
//!   by the physics layer.
//! - [`ThrustBudget`] — per-axis propulsion capacity used by the
//!   flight controller.
//! - Interior/airtight predicates used by the avatar/life-support
//!   layers (player can walk on `Floor`, `Door`, `Console`, etc.).
//!
//! Design rule: every public type is a plain value (`Clone`, no
//! borrowed state). Systems are pure functions of their inputs. This
//! keeps the door open for serde serialization and network replication
//! without refactoring.

pub mod block;
pub mod grid;
pub mod mass;
pub mod thrust;

pub use block::{Block, BlockKind, BlockMaterial, Facing};
pub use grid::{ShipBlocks, NEIGHBOR_OFFSETS};
pub use mass::{compute_mass_properties, MassProperties};
pub use thrust::{compute_thrust_budget, ThrustBudget, THRUSTER_BASE_FORCE_N};

use ce_app::{App, Plugin};

/// Marker component tagging an entity as a ship. Ships carry a
/// `ShipBlocks` component alongside standard Transform/RigidBody.
#[derive(Debug, Clone, Copy, Default)]
pub struct Ship;

/// Plugin stub: no systems registered yet. Gameplay systems that
/// consume ship state (flight controller, damage processor) will hook
/// in from their own crates in later milestones.
pub struct ShipPlugin;

impl Plugin for ShipPlugin {
    fn build(&self, _app: &mut App) {
        log::info!("ShipPlugin loaded (data types only; systems pending)");
    }
}

#[cfg(test)]
mod plugin_tests {
    use super::*;

    #[test]
    fn plugin_adds_cleanly() {
        let mut app = App::new();
        app.add_plugin(ShipPlugin);
    }
}

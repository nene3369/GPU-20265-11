//! Block taxonomy for Avorion-style ship construction.
//!
//! Every block has a [`BlockKind`] (what it does) and a [`BlockMaterial`]
//! (what it's made of). Materials drive mass, hp, and heat tolerance;
//! kinds drive gameplay behaviour (thrust, fire, open/close, etc.).
//!
//! Blocks are axis-aligned unit cubes addressed by integer grid
//! coordinates. Rotation is restricted to the six face-axes for now
//! (48 orientations aren't worth the complexity at this milestone).

/// What the block does. `Hull` is the default structural shell; other
/// kinds gate gameplay features.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum BlockKind {
    /// Outer structural armor.
    Hull,
    /// Interior walkable floor (avatar-collides).
    Floor,
    /// Interior dividing wall.
    Wall,
    /// Pressure door / airlock segment.
    Door,
    /// Thrust-producing engine (direction = `rotation`).
    Thruster,
    /// Weapon hardpoint (fixed-forward fire).
    Weapon,
    /// Interactable bridge console (flight/navigation).
    Console,
    /// Reactor — produces power; high mass, explodes loudly.
    Reactor,
    /// Crew quarters / life support — contributes to crew cap.
    Quarters,
    /// Refinery module (produces refined materials).
    Refinery,
    /// Cargo hold — contributes to ship storage capacity.
    Cargo,
}

impl BlockKind {
    /// True if avatars can stand inside or adjacent to this block (the
    /// cell is considered "interior-walkable" space).
    pub fn is_interior(&self) -> bool {
        matches!(
            self,
            BlockKind::Floor
                | BlockKind::Door
                | BlockKind::Console
                | BlockKind::Quarters
                | BlockKind::Reactor
                | BlockKind::Refinery
                | BlockKind::Cargo
        )
    }

    /// True if the block is airtight (contributes to hull pressure).
    pub fn is_airtight(&self) -> bool {
        matches!(
            self,
            BlockKind::Hull
                | BlockKind::Wall
                | BlockKind::Door
                | BlockKind::Floor
                | BlockKind::Reactor
        )
    }

    /// True if the block contributes propulsion.
    pub fn is_thruster(&self) -> bool {
        matches!(self, BlockKind::Thruster)
    }

    pub fn is_weapon(&self) -> bool {
        matches!(self, BlockKind::Weapon)
    }
}

/// Physical material.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum BlockMaterial {
    /// Iron — cheap, heavy, middling durability.
    Iron,
    /// Titanium — light and strong.
    Titanium,
    /// Composite — balanced, intermediate cost.
    Composite,
    /// Tungsten — heaviest, highest hp.
    Tungsten,
    /// Aluminium — very light, fragile.
    Aluminium,
}

impl BlockMaterial {
    /// Mass of a 1m³ block in kilograms.
    pub fn density_kg_per_m3(&self) -> f32 {
        match self {
            BlockMaterial::Iron => 7_870.0,
            BlockMaterial::Titanium => 4_506.0,
            BlockMaterial::Composite => 2_200.0,
            BlockMaterial::Tungsten => 19_250.0,
            BlockMaterial::Aluminium => 2_700.0,
        }
    }

    /// Base hit-points for a 1m³ block.
    pub fn base_hp(&self) -> f32 {
        match self {
            BlockMaterial::Iron => 1_000.0,
            BlockMaterial::Titanium => 1_800.0,
            BlockMaterial::Composite => 1_200.0,
            BlockMaterial::Tungsten => 3_000.0,
            BlockMaterial::Aluminium => 500.0,
        }
    }
}

/// Six face-aligned orientations. Affects which face of a block points
/// "forward" (relevant for thrusters, doors, consoles, weapons).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub enum Facing {
    /// +X
    East,
    /// -X
    West,
    /// +Y
    Up,
    /// -Y
    Down,
    /// +Z
    South,
    /// -Z (default for "forward" in the engine's right-handed convention)
    #[default]
    North,
}

impl Facing {
    pub fn unit_vec(self) -> ce_math::Vec3 {
        use ce_math::Vec3;
        match self {
            Facing::East => Vec3::X,
            Facing::West => Vec3::NEG_X,
            Facing::Up => Vec3::Y,
            Facing::Down => Vec3::NEG_Y,
            Facing::South => Vec3::Z,
            Facing::North => Vec3::NEG_Z,
        }
    }
}

/// One block in the sparse grid.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Block {
    pub kind: BlockKind,
    pub material: BlockMaterial,
    pub facing: Facing,
    /// Current health points (decays under damage).
    pub hp: f32,
}

impl Block {
    pub fn new(kind: BlockKind, material: BlockMaterial) -> Self {
        let hp = material.base_hp();
        Self {
            kind,
            material,
            facing: Facing::default(),
            hp,
        }
    }

    pub fn with_facing(mut self, facing: Facing) -> Self {
        self.facing = facing;
        self
    }

    /// Mass of a 1m³ block in kilograms.
    pub fn mass_kg(&self) -> f32 {
        self.material.density_kg_per_m3()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ce_math::Vec3;

    #[test]
    fn hull_is_airtight_but_not_interior() {
        assert!(BlockKind::Hull.is_airtight());
        assert!(!BlockKind::Hull.is_interior());
    }

    #[test]
    fn floor_is_both_interior_and_airtight() {
        assert!(BlockKind::Floor.is_interior());
        assert!(BlockKind::Floor.is_airtight());
    }

    #[test]
    fn thruster_is_thruster_kind() {
        assert!(BlockKind::Thruster.is_thruster());
        assert!(!BlockKind::Hull.is_thruster());
    }

    #[test]
    fn heavier_material_has_more_mass() {
        assert!(
            BlockMaterial::Tungsten.density_kg_per_m3() > BlockMaterial::Iron.density_kg_per_m3()
        );
        assert!(
            BlockMaterial::Iron.density_kg_per_m3() > BlockMaterial::Aluminium.density_kg_per_m3()
        );
    }

    #[test]
    fn new_block_starts_at_full_hp() {
        let b = Block::new(BlockKind::Hull, BlockMaterial::Iron);
        assert_eq!(b.hp, BlockMaterial::Iron.base_hp());
    }

    #[test]
    fn facing_unit_vec_is_axis_aligned() {
        assert_eq!(Facing::East.unit_vec(), Vec3::X);
        assert_eq!(Facing::North.unit_vec(), Vec3::NEG_Z);
        assert_eq!(Facing::default().unit_vec(), Vec3::NEG_Z);
    }

    #[test]
    fn mass_matches_material_density() {
        let b = Block::new(BlockKind::Hull, BlockMaterial::Titanium);
        assert_eq!(b.mass_kg(), 4_506.0);
    }
}

//! Thruster enumeration and aggregate propulsion helpers.
//!
//! A thruster block generates force along its [`Facing`] direction.
//! Aggregate linear-thrust capacity per axis is used by the flight
//! controller to cap commanded accelerations.

use ce_math::Vec3;

use crate::block::BlockKind;
use crate::grid::ShipBlocks;

/// Newtons of thrust produced by one 1 m³ thruster block at full power.
/// Tuned to give an iron-hulled hobby ship ≈ 30 m/s² starter
/// acceleration once a handful of thrusters are mounted.
pub const THRUSTER_BASE_FORCE_N: f32 = 500_000.0;

/// Summed per-face thrust capacity, in newtons.
///
/// Each face's capacity is the total force that can be produced pointing
/// in that direction. For instance `pos_x` is the sum of all thrusters
/// whose nozzles point `+X` (i.e. would accelerate the ship in `+X`).
#[derive(Debug, Clone, Copy, Default, PartialEq)]
pub struct ThrustBudget {
    pub pos_x: f32,
    pub neg_x: f32,
    pub pos_y: f32,
    pub neg_y: f32,
    pub pos_z: f32,
    pub neg_z: f32,
}

impl ThrustBudget {
    /// Maximum net force the ship can produce along `dir`. `dir` need
    /// not be a unit vector; the result is clamped to the per-axis
    /// capacities in the matching half-space.
    pub fn force_along(&self, dir: Vec3) -> f32 {
        // Treat dir as a request and clamp to the per-axis budget in
        // whichever half-space each component sits in.
        let fx = if dir.x >= 0.0 {
            self.pos_x * dir.x
        } else {
            self.neg_x * -dir.x
        };
        let fy = if dir.y >= 0.0 {
            self.pos_y * dir.y
        } else {
            self.neg_y * -dir.y
        };
        let fz = if dir.z >= 0.0 {
            self.pos_z * dir.z
        } else {
            self.neg_z * -dir.z
        };
        fx + fy + fz
    }
}

/// Scans a ship grid and sums thrust capacity per face.
pub fn compute_thrust_budget(grid: &ShipBlocks) -> ThrustBudget {
    let mut b = ThrustBudget::default();
    for (_cell, block) in grid.iter_kind(BlockKind::Thruster) {
        let v = block.facing.unit_vec();
        // `v` is the direction the nozzle points (= direction of thrust force).
        let f = THRUSTER_BASE_FORCE_N;
        if v.x > 0.5 {
            b.pos_x += f;
        } else if v.x < -0.5 {
            b.neg_x += f;
        }
        if v.y > 0.5 {
            b.pos_y += f;
        } else if v.y < -0.5 {
            b.neg_y += f;
        }
        if v.z > 0.5 {
            b.pos_z += f;
        } else if v.z < -0.5 {
            b.neg_z += f;
        }
    }
    b
}

#[cfg(test)]
mod tests {
    use super::*;
    use ce_math::IVec3;

    use crate::block::{Block, BlockKind, BlockMaterial, Facing};

    fn thruster(facing: Facing) -> Block {
        Block::new(BlockKind::Thruster, BlockMaterial::Iron).with_facing(facing)
    }

    #[test]
    fn empty_ship_has_no_thrust() {
        let b = compute_thrust_budget(&ShipBlocks::new());
        assert_eq!(b, ThrustBudget::default());
        assert_eq!(b.force_along(Vec3::X), 0.0);
    }

    #[test]
    fn single_east_thruster_produces_positive_x_only() {
        let mut g = ShipBlocks::new();
        g.insert(IVec3::ZERO, thruster(Facing::East));
        let b = compute_thrust_budget(&g);
        assert_eq!(b.pos_x, THRUSTER_BASE_FORCE_N);
        assert_eq!(b.neg_x, 0.0);
        assert_eq!(b.pos_y, 0.0);
    }

    #[test]
    fn north_and_south_thrusters_populate_opposing_faces() {
        let mut g = ShipBlocks::new();
        g.insert(IVec3::ZERO, thruster(Facing::North));
        g.insert(IVec3::new(1, 0, 0), thruster(Facing::South));
        let b = compute_thrust_budget(&g);
        assert_eq!(b.neg_z, THRUSTER_BASE_FORCE_N);
        assert_eq!(b.pos_z, THRUSTER_BASE_FORCE_N);
    }

    #[test]
    fn force_along_clamps_to_per_axis_budget() {
        let mut g = ShipBlocks::new();
        g.insert(IVec3::ZERO, thruster(Facing::East));
        g.insert(IVec3::new(0, 1, 0), thruster(Facing::East));
        let b = compute_thrust_budget(&g);
        // 2 thrusters × base force along +X, nothing elsewhere.
        let f = b.force_along(Vec3::X);
        assert!((f - 2.0 * THRUSTER_BASE_FORCE_N).abs() < 1.0);
        // No thrust in -X direction.
        assert_eq!(b.force_along(Vec3::NEG_X), 0.0);
    }

    #[test]
    fn non_thruster_blocks_are_ignored() {
        let mut g = ShipBlocks::new();
        g.insert(
            IVec3::ZERO,
            Block::new(BlockKind::Hull, BlockMaterial::Iron).with_facing(Facing::East),
        );
        let b = compute_thrust_budget(&g);
        assert_eq!(b, ThrustBudget::default());
    }
}

//! Procedural galaxy generator.
//!
//! One master seed → a [`Galaxy`] containing a `SectorGraph`, planets
//! per sector, faction ownership, and station markets. Deterministic:
//! same config ⇒ byte-identical galaxy.

use std::collections::HashMap;

use ce_economy::{Market, MarketEntry, PriceModel};
use ce_faction::FactionId;
use ce_gameplay::ItemId;
use ce_planet::{Planet, PlanetId};
use ce_space::{Sector, SectorGraph, SectorId, WorldPos, SECTOR_SIZE_METERS};

/// Inputs for [`generate_galaxy`].
#[derive(Debug, Clone)]
pub struct GalaxyConfig {
    pub seed: u64,
    pub sector_count: u32,
    pub planets_per_sector_min: u32,
    pub planets_per_sector_max: u32,
    /// Factions the generator may assign as sector owners. An empty
    /// slice means unowned space.
    pub factions: Vec<FactionId>,
    /// Commodity ids a station market may list. The generator picks
    /// 1–3 per station from this pool.
    pub commodities: Vec<ItemId>,
}

impl Default for GalaxyConfig {
    fn default() -> Self {
        Self {
            seed: 1,
            sector_count: 8,
            planets_per_sector_min: 1,
            planets_per_sector_max: 3,
            factions: Vec::new(),
            commodities: Vec::new(),
        }
    }
}

/// One procedural trading station.
#[derive(Debug, Clone)]
pub struct Station {
    pub id: u64,
    pub name: String,
    pub sector: SectorId,
    pub owner: Option<FactionId>,
    pub market: Market,
}

/// The output of a generation run.
#[derive(Debug, Clone, Default)]
pub struct Galaxy {
    pub sectors: SectorGraph,
    pub planets: HashMap<SectorId, Vec<Planet>>,
    pub owners: HashMap<SectorId, FactionId>,
    pub stations: HashMap<SectorId, Vec<Station>>,
}

impl Galaxy {
    pub fn sector_count(&self) -> usize {
        self.sectors.len()
    }

    pub fn planet_count(&self) -> usize {
        self.planets.values().map(Vec::len).sum()
    }

    pub fn station_count(&self) -> usize {
        self.stations.values().map(Vec::len).sum()
    }

    /// All stations in the galaxy in a flat iterator.
    pub fn stations_iter(&self) -> impl Iterator<Item = &Station> {
        self.stations.values().flat_map(|v| v.iter())
    }
}

/// Entry point: seed → galaxy.
pub fn generate_galaxy(config: &GalaxyConfig) -> Galaxy {
    let mut galaxy = Galaxy::default();
    let seed = config.seed;

    // Sector placement: pack `sector_count` sectors into a cube of side
    // `ceil(cbrt(count))`, placed at integer grid coords offset from
    // origin. Keeps the spatial layout compact and deterministic.
    let grid_side = ((config.sector_count as f64).cbrt().ceil() as i64).max(1);

    let mut sector_ids = Vec::with_capacity(config.sector_count as usize);
    let mut placed = 0u32;
    'outer: for z in 0..grid_side {
        for y in 0..grid_side {
            for x in 0..grid_side {
                if placed >= config.sector_count {
                    break 'outer;
                }
                let id = SectorId(x, y, z);
                let name = sector_name(seed, id);
                let sector_seed = mix(seed, 0xA1, placed as u64);
                let sector = Sector::new(id).with_seed(sector_seed).with_name(name);
                galaxy.sectors.insert(sector);
                sector_ids.push(id);
                placed += 1;
            }
        }
    }

    // Warp connectivity: link every sector to its closest Manhattan
    // neighbour already placed. Guarantees a connected graph
    // (minimum spanning forest in practice).
    for (i, &id) in sector_ids.iter().enumerate().skip(1) {
        let mut best: Option<(SectorId, i64)> = None;
        for &prev in &sector_ids[..i] {
            let d = manhattan(id, prev);
            if best.map(|(_, bd)| d < bd).unwrap_or(true) {
                best = Some((prev, d));
            }
        }
        if let Some((nearest, _)) = best {
            galaxy.sectors.link(id, nearest);
        }
    }

    // Per-sector content.
    let owner_table = if config.factions.is_empty() {
        Vec::new()
    } else {
        config.factions.clone()
    };
    let mut station_id_counter: u64 = 1;
    for &id in &sector_ids {
        // Ownership.
        if !owner_table.is_empty() {
            let owner_ix = (mix(seed, 0xC7, sector_key(id)) as usize) % owner_table.len();
            galaxy.owners.insert(id, owner_table[owner_ix]);
        }

        // Planets.
        let planet_count = pick_in_range(
            mix(seed, 0xB2, sector_key(id)),
            config.planets_per_sector_min,
            config.planets_per_sector_max,
        );
        let mut sector_planets = Vec::with_capacity(planet_count as usize);
        for p in 0..planet_count {
            let planet_seed = mix(seed, 0xB3, sector_key(id).wrapping_add(p as u64));
            let offset_mag = ((p as f64) + 1.0) * (SECTOR_SIZE_METERS * 0.05);
            let angle = (p as f64) * 1.317; // golden-ish spread
            let centre = id.center();
            let offset = glam::DVec3::new(angle.cos() * offset_mag, 0.0, angle.sin() * offset_mag);
            let planet_centre = WorldPos(centre.as_dvec3() + offset);
            let pid = PlanetId(mix(seed, 0xB4, sector_key(id).wrapping_add(p as u64 * 31)));
            sector_planets.push(Planet::earth_like(pid, planet_centre, planet_seed));
        }
        galaxy.planets.insert(id, sector_planets);

        // Stations: 0, 1, or 2 per sector.
        let station_count = pick_in_range(mix(seed, 0xD1, sector_key(id)), 0, 2);
        let mut sector_stations = Vec::with_capacity(station_count as usize);
        for s in 0..station_count {
            let station_seed = mix(seed, 0xD2, sector_key(id).wrapping_add(s as u64));
            let market = generate_market(station_seed, &config.commodities);
            sector_stations.push(Station {
                id: station_id_counter,
                name: station_name(station_seed, id, s),
                sector: id,
                owner: galaxy.owners.get(&id).copied(),
                market,
            });
            station_id_counter += 1;
        }
        galaxy.stations.insert(id, sector_stations);
    }

    galaxy
}

fn generate_market(seed: u64, commodities: &[ItemId]) -> Market {
    let mut market = Market::new();
    if commodities.is_empty() {
        return market;
    }
    let pool_size = commodities.len();
    // Pick 1..=3 unique commodities.
    let pick_count = 1 + (mix(seed, 0x01, 0) % 3) as usize;
    let pick_count = pick_count.min(pool_size);
    let mut used = vec![false; pool_size];
    for i in 0..pick_count {
        let mut idx = (mix(seed, 0x02, i as u64) as usize) % pool_size;
        // Linear probe to avoid duplicates.
        while used[idx] {
            idx = (idx + 1) % pool_size;
        }
        used[idx] = true;
        let id = commodities[idx];
        let base = 20 + ((mix(seed, 0x03, i as u64) % 180) as i64);
        let stock = 50 + (mix(seed, 0x04, i as u64) % 150) as u32;
        let equilibrium = 100;
        let elasticity = 0.5 + ((mix(seed, 0x05, i as u64) % 150) as f32) / 100.0;
        market.insert(
            id,
            MarketEntry::new(stock, equilibrium, PriceModel::new(base, elasticity)),
        );
    }
    market
}

fn sector_name(seed: u64, id: SectorId) -> String {
    let syllables = [
        "Ku", "Za", "Ri", "No", "Lu", "Ven", "Cor", "Sol", "Nex", "Arc", "Tre", "Mor", "Sha", "Ly",
        "Ori", "Den",
    ];
    let h = mix(seed, 0xA1, sector_key(id));
    let a = syllables[(h as usize) % syllables.len()];
    let b = syllables[((h >> 8) as usize) % syllables.len()];
    let num = 1 + (h >> 16) % 900;
    format!("{a}{}-{num}", b.to_lowercase())
}

fn station_name(seed: u64, id: SectorId, index: u32) -> String {
    let prefixes = ["Gate", "Hub", "Docks", "Relay", "Refinery", "Bastion"];
    let h = mix(seed, 0xD3, sector_key(id).wrapping_add(index as u64));
    let prefix = prefixes[(h as usize) % prefixes.len()];
    let num = 1 + (h >> 8) % 99;
    format!("{prefix}-{num}")
}

fn sector_key(id: SectorId) -> u64 {
    let x = (id.0 as i128 + (1_i128 << 62)) as u64;
    let y = (id.1 as i128 + (1_i128 << 62)) as u64;
    let z = (id.2 as i128 + (1_i128 << 62)) as u64;
    x.wrapping_mul(0x9E37_79B9_7F4A_7C15)
        ^ y.wrapping_mul(0xBF58_476D_1CE4_E5B9)
        ^ z.wrapping_mul(0x94D0_49BB_1331_11EB)
}

fn manhattan(a: SectorId, b: SectorId) -> i64 {
    (a.0 - b.0).abs() + (a.1 - b.1).abs() + (a.2 - b.2).abs()
}

fn mix(seed: u64, salt: u64, x: u64) -> u64 {
    let mut h = seed.wrapping_mul(0x9E37_79B9_7F4A_7C15);
    h = h.wrapping_add(salt).wrapping_mul(0xBF58_476D_1CE4_E5B9);
    h = h.wrapping_add(x).wrapping_mul(0x94D0_49BB_1331_11EB);
    h ^= h >> 33;
    h
}

fn pick_in_range(seed: u64, min: u32, max: u32) -> u32 {
    if min >= max {
        return min;
    }
    let span = (max - min) as u64 + 1;
    min + (seed % span) as u32
}

#[cfg(test)]
#[allow(clippy::len_zero)]
mod tests {
    use super::*;

    const UNION: FactionId = FactionId::new("union");
    const PIRATES: FactionId = FactionId::new("pirates");
    const IRON: ItemId = ItemId::new("iron_ore");
    const WATER: ItemId = ItemId::new("water");
    const COAL: ItemId = ItemId::new("coal");

    fn demo_config(seed: u64) -> GalaxyConfig {
        GalaxyConfig {
            seed,
            sector_count: 12,
            planets_per_sector_min: 1,
            planets_per_sector_max: 3,
            factions: vec![UNION, PIRATES],
            commodities: vec![IRON, WATER, COAL],
        }
    }

    #[test]
    fn generate_respects_sector_count() {
        let g = generate_galaxy(&demo_config(1));
        assert_eq!(g.sector_count(), 12);
    }

    #[test]
    fn generate_is_deterministic_for_same_seed() {
        let a = generate_galaxy(&demo_config(42));
        let b = generate_galaxy(&demo_config(42));
        assert_eq!(a.sector_count(), b.sector_count());
        assert_eq!(a.planet_count(), b.planet_count());
        assert_eq!(a.station_count(), b.station_count());
        // Sector names should match.
        let mut names_a: Vec<String> = a.sectors.sectors().filter_map(|s| s.name.clone()).collect();
        let mut names_b: Vec<String> = b.sectors.sectors().filter_map(|s| s.name.clone()).collect();
        names_a.sort();
        names_b.sort();
        assert_eq!(names_a, names_b);
    }

    #[test]
    fn different_seeds_produce_different_galaxies() {
        let a = generate_galaxy(&demo_config(1));
        let b = generate_galaxy(&demo_config(2));
        // Content must diverge somewhere: name list or planet count.
        let a_names: Vec<_> = a.sectors.sectors().filter_map(|s| s.name.clone()).collect();
        let b_names: Vec<_> = b.sectors.sectors().filter_map(|s| s.name.clone()).collect();
        assert_ne!(a_names, b_names, "two seeds should produce different names");
    }

    #[test]
    fn planets_per_sector_in_range() {
        let g = generate_galaxy(&demo_config(3));
        for planets in g.planets.values() {
            assert!(planets.len() >= 1);
            assert!(planets.len() <= 3);
        }
    }

    #[test]
    fn every_sector_except_first_has_at_least_one_warp_link() {
        let g = generate_galaxy(&demo_config(11));
        let ids: Vec<SectorId> = g.sectors.sectors().map(|s| s.id).collect();
        // First sector may be unlinked only when alone; with >=2 it must
        // be reachable from at least one neighbour.
        let mut unlinked = 0;
        for &id in &ids {
            if g.sectors.neighbors(id).is_empty() {
                unlinked += 1;
            }
        }
        assert_eq!(unlinked, 0, "galaxy must be connected");
    }

    #[test]
    fn owners_assigned_when_factions_provided() {
        let g = generate_galaxy(&demo_config(7));
        assert_eq!(g.owners.len(), g.sector_count());
        // Every owner is one of the two listed factions.
        for owner in g.owners.values() {
            assert!(*owner == UNION || *owner == PIRATES);
        }
    }

    #[test]
    fn stations_have_markets_and_owners_reflect_sector_owner() {
        let g = generate_galaxy(&demo_config(5));
        for station in g.stations_iter() {
            assert_eq!(station.owner, g.owners.get(&station.sector).copied());
            // If any commodities were provided, at least one market
            // entry should be listed.
            assert!(!station.market.is_empty());
        }
    }

    #[test]
    fn empty_factions_produces_unowned_sectors() {
        let mut cfg = demo_config(9);
        cfg.factions.clear();
        let g = generate_galaxy(&cfg);
        assert!(g.owners.is_empty());
    }

    #[test]
    fn empty_commodities_produces_empty_markets() {
        let mut cfg = demo_config(9);
        cfg.commodities.clear();
        let g = generate_galaxy(&cfg);
        for station in g.stations_iter() {
            assert!(station.market.is_empty());
        }
    }

    #[test]
    fn sector_names_are_unique_for_placed_sectors() {
        // Names aren't strictly guaranteed unique by the scheme, but
        // for the default 12 sectors with the default seed the salt
        // mix should give us reasonable variety. Assert "at least
        // half are unique" as a rough quality floor.
        let g = generate_galaxy(&demo_config(21));
        let names: Vec<_> = g.sectors.sectors().filter_map(|s| s.name.clone()).collect();
        let unique: std::collections::HashSet<_> = names.iter().collect();
        assert!(
            unique.len() * 2 >= names.len(),
            "name variety is too low: {names:?}"
        );
    }
}

//! Golden-image regression test for the procedural galaxy generator.
//!
//! Renders a top-down sector map for a fixed seed as a small PPM and
//! diffs it against a committed baseline. This is a *deterministic*
//! CPU render (no GPU, no driver-dependent math), so tolerance=0 can
//! catch any drift in:
//!
//!   - sector placement (`generate_galaxy` grid layout)
//!   - warp-link connectivity (nearest-neighbour algorithm)
//!   - faction ownership assignment (RNG `mix()` contract)
//!   - station count distribution (`pick_in_range` contract)
//!
//! If a generator change is intentional, refresh the baseline with:
//!
//!     UPDATE_GOLDENS=1 cargo test -p ce_worldgen --test golden_galaxy_map
//!
//! and commit the new PPM.

use std::path::PathBuf;

use ce_faction::FactionId;
use ce_gameplay::ItemId;
use ce_softraster::{assert_golden, Framebuffer};
use ce_worldgen::galaxy::{generate_galaxy, GalaxyConfig};

const W: u32 = 128;
const H: u32 = 128;
// tolerance=0: this is pure-integer CPU rendering from deterministic input.
// Any non-zero drift is a real regression, not floating-point noise.
const TOLERANCE: u8 = 0;

// Shared with `galaxy.rs` tests.
const UNION: FactionId = FactionId::new("union");
const PIRATES: FactionId = FactionId::new("pirates");
const IRON: ItemId = ItemId::new("iron_ore");
const WATER: ItemId = ItemId::new("water");

fn goldens_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("tests")
        .join("goldens")
}

/// Bresenham line — integer-only, so output is bit-stable across platforms.
fn draw_line(fb: &mut Framebuffer, x0: i32, y0: i32, x1: i32, y1: i32, rgba: [u8; 4]) {
    let dx = (x1 - x0).abs();
    let dy = -(y1 - y0).abs();
    let sx: i32 = if x0 < x1 { 1 } else { -1 };
    let sy: i32 = if y0 < y1 { 1 } else { -1 };
    let mut err = dx + dy;
    let (mut x, mut y) = (x0, y0);
    loop {
        put_pixel(fb, x, y, rgba);
        if x == x1 && y == y1 {
            break;
        }
        let e2 = 2 * err;
        if e2 >= dy {
            err += dy;
            x += sx;
        }
        if e2 <= dx {
            err += dx;
            y += sy;
        }
    }
}

fn put_pixel(fb: &mut Framebuffer, x: i32, y: i32, rgba: [u8; 4]) {
    if x < 0 || y < 0 {
        return;
    }
    let (xu, yu) = (x as u32, y as u32);
    if xu < fb.width && yu < fb.height {
        fb.set_pixel(xu, yu, rgba);
    }
}

fn fill_square(fb: &mut Framebuffer, cx: i32, cy: i32, half: i32, rgba: [u8; 4]) {
    for dy in -half..=half {
        for dx in -half..=half {
            put_pixel(fb, cx + dx, cy + dy, rgba);
        }
    }
}

fn demo_config(seed: u64) -> GalaxyConfig {
    GalaxyConfig {
        seed,
        sector_count: 12,
        planets_per_sector_min: 1,
        planets_per_sector_max: 3,
        factions: vec![UNION, PIRATES],
        commodities: vec![IRON, WATER],
    }
}

/// Render a top-down (x,y) projection of the galaxy into `fb`.
///
/// Iteration order is forced to sorted `SectorId` to avoid `HashMap`
/// ordering leaking into the pixel output — that's what keeps the
/// golden stable across runs.
fn render_galaxy_map(galaxy: &ce_worldgen::galaxy::Galaxy, fb: &mut Framebuffer) {
    // Deep-space background.
    fb.clear([8, 10, 18, 255]);

    // Collect and sort sector ids so draw order is deterministic.
    let mut ids: Vec<ce_space::SectorId> = galaxy.sectors.sectors().map(|s| s.id).collect();
    ids.sort_by_key(|id| (id.0, id.1, id.2));
    if ids.is_empty() {
        return;
    }

    // Projection bounds from (x, y); drop z for 2D map.
    let (mut min_x, mut max_x) = (ids[0].0, ids[0].0);
    let (mut min_y, mut max_y) = (ids[0].1, ids[0].1);
    for id in &ids {
        min_x = min_x.min(id.0);
        max_x = max_x.max(id.0);
        min_y = min_y.min(id.1);
        max_y = max_y.max(id.1);
    }
    let span_x = ((max_x - min_x) as f32).max(1.0);
    let span_y = ((max_y - min_y) as f32).max(1.0);
    let pad = 16.0f32;
    // Capture dimensions as plain values so the closure doesn't hold an
    // immutable borrow of `fb` (we need to pass `fb` mutably to drawers).
    let fb_w = fb.width as f32;
    let fb_h = fb.height as f32;
    let project = |x: i64, y: i64| -> (i32, i32) {
        let fx = (x - min_x) as f32 / span_x;
        let fy = (y - min_y) as f32 / span_y;
        let px = pad + fx * (fb_w - 2.0 * pad);
        let py = pad + fy * (fb_h - 2.0 * pad);
        (px.round() as i32, py.round() as i32)
    };

    // 1) Warp lanes first, so sector dots overlay them.
    for &id in &ids {
        let (x0, y0) = project(id.0, id.1);
        let mut neighbors: Vec<ce_space::SectorId> = galaxy.sectors.neighbors(id).to_vec();
        neighbors.sort_by_key(|n| (n.0, n.1, n.2));
        for n in neighbors {
            // Draw each undirected edge once (the larger endpoint draws).
            if (n.0, n.1, n.2) > (id.0, id.1, id.2) {
                let (x1, y1) = project(n.0, n.1);
                draw_line(fb, x0, y0, x1, y1, [40, 100, 150, 255]);
            }
        }
    }

    // 2) Sector dots, coloured by owning faction.
    for &id in &ids {
        let (x, y) = project(id.0, id.1);
        let color = match galaxy.owners.get(&id) {
            Some(f) if *f == UNION => [80, 220, 120, 255],
            Some(f) if *f == PIRATES => [220, 80, 80, 255],
            _ => [150, 150, 150, 255],
        };
        fill_square(fb, x, y, 1, color); // 3×3 pixel dot
    }

    // 3) Stations as small yellow ticks offset from the sector centre.
    for &id in &ids {
        let stations = galaxy
            .stations
            .get(&id)
            .map(Vec::as_slice)
            .unwrap_or_default();
        let (x, y) = project(id.0, id.1);
        for (i, _) in stations.iter().enumerate() {
            let ox = 3 + i as i32 * 2;
            put_pixel(fb, x + ox, y - 3, [255, 220, 80, 255]);
        }
    }
}

#[test]
fn golden_galaxy_map_seed42() {
    let galaxy = generate_galaxy(&demo_config(42));
    let mut fb = Framebuffer::new(W, H);
    render_galaxy_map(&galaxy, &mut fb);
    assert_golden(&fb, goldens_dir().join("galaxy_map_seed42.ppm"), TOLERANCE).unwrap();
}

#[test]
fn golden_galaxy_map_seed7() {
    // A second seed acts as a differential test: if some change
    // mutates the RNG contract in a way that accidentally cancels
    // out on seed 42, it should still show up here.
    let galaxy = generate_galaxy(&demo_config(7));
    let mut fb = Framebuffer::new(W, H);
    render_galaxy_map(&galaxy, &mut fb);
    assert_golden(&fb, goldens_dir().join("galaxy_map_seed7.ppm"), TOLERANCE).unwrap();
}

#[test]
fn two_goldens_are_visually_different() {
    // Sanity check: the two committed goldens should not be byte-equal,
    // otherwise the test is vacuous (proves only that rendering is
    // deterministic, not that seed actually propagates).
    let mut a = Framebuffer::new(W, H);
    render_galaxy_map(&generate_galaxy(&demo_config(42)), &mut a);
    let mut b = Framebuffer::new(W, H);
    render_galaxy_map(&generate_galaxy(&demo_config(7)), &mut b);
    let stats = ce_softraster::diff(&a, &b);
    assert!(
        stats.differing_pixels > 0,
        "seed 42 and seed 7 produced visually identical maps — RNG not propagating?"
    );
}

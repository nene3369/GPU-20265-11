//! Deterministic name generation from a dignity vector.
//!
//! Given a target [`DignityVector`] and a seed, `generate_name` picks
//! a world and a core body whose structure reflects the dominant
//! dignity, then stamps the corresponding suffix. The same
//! `(vector, seed)` pair always returns the same token, so save / load
//! and multiplayer replication reconstruct the same vocabulary.

use ce_worldclock::DeterministicRng;

use crate::alphabet::{World, CORE_ALPHABET};
use crate::dignity::DignityVector;
use crate::token::{Token, TokenError, MIN_CORE_LEN};

/// Preferred core-body length distribution — short names feel more
/// "natural" as faction / item identifiers. Sum > 1 only because the
/// picker uses it as a weighted draw.
const LENGTH_WEIGHTS: [f32; 3] = [0.2, 0.55, 0.25]; // len 1 / 2 / 3

/// Generates a token that reads as "this dignity vector".
///
/// - `world_hint` picks the prefix. `None` derives the world from the
///   largest magnitude index of the vector deterministically — useful
///   for "this faction is intellectual" auto-selection.
/// - `seed` feeds `ce_worldclock::DeterministicRng` so two players
///   with the same world can enumerate identical vocabularies.
pub fn generate_name(
    vector: &DignityVector,
    world_hint: Option<World>,
    seed: u64,
) -> Result<Token, TokenError> {
    let normalised = vector.normalise();
    let mut rng = DeterministicRng::from_parts(seed, 0xD16_1117_C0DE, 0);

    let world = world_hint.unwrap_or_else(|| pick_world(&normalised, &mut rng));
    let dignity = normalised.dominant();

    let len = pick_length(&mut rng);
    let mut core = Vec::with_capacity(len);
    for _ in 0..len {
        let idx = rng.range_u32(0, CORE_ALPHABET.len() as u32) as usize;
        core.push(CORE_ALPHABET[idx]);
    }
    Token::new(world, core, dignity)
}

fn pick_world(vector: &DignityVector, rng: &mut DeterministicRng) -> World {
    // Use the dignity vector as a soft cue for the world: high Aly /
    // Oly leans intellectual, Ody leans celestial (pattern / cycle),
    // Edy leans material (embodied beauty). The rng breaks ties so
    // different seeds pick different worlds given the same vector.
    let intellectual = vector.weights[0] + vector.weights[3];
    let celestial = vector.weights[1];
    let material = vector.weights[2];
    let total = intellectual + celestial + material;
    if total <= 0.0 {
        return match rng.range_u32(0, 3) {
            0 => World::Material,
            1 => World::Celestial,
            _ => World::Intellectual,
        };
    }
    let pick = rng.next_f32_unit() * total;
    if pick < intellectual {
        World::Intellectual
    } else if pick < intellectual + celestial {
        World::Celestial
    } else {
        World::Material
    }
}

fn pick_length(rng: &mut DeterministicRng) -> usize {
    let total: f32 = LENGTH_WEIGHTS.iter().sum();
    let pick = rng.next_f32_unit() * total;
    let mut acc = 0.0;
    for (i, w) in LENGTH_WEIGHTS.iter().enumerate() {
        acc += *w;
        if pick < acc {
            return i + MIN_CORE_LEN;
        }
    }
    MIN_CORE_LEN + LENGTH_WEIGHTS.len() - 1
}

/// Bulk helper: produce `n` distinct names biased toward `vector`.
/// Internally varies the seed so the caller gets a vocabulary, not
/// `n` copies of the same token. Duplicates are filtered so the
/// returned vector length may be less than `n` if the dignity
/// vector is very peaked.
pub fn generate_vocabulary(
    vector: &DignityVector,
    world_hint: Option<World>,
    seed: u64,
    n: usize,
) -> Vec<Token> {
    use std::collections::HashSet;
    let mut out = Vec::with_capacity(n);
    let mut seen = HashSet::new();
    for i in 0..(n * 4) {
        if out.len() == n {
            break;
        }
        let t = match generate_name(vector, world_hint, seed.wrapping_add(i as u64)) {
            Ok(t) => t,
            Err(_) => continue,
        };
        if seen.insert(t.canonical.clone()) {
            out.push(t);
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::dignity::Dignity;

    #[test]
    fn same_seed_same_name() {
        let v = DignityVector::new(0.6, 0.1, 0.2, 0.1);
        let a = generate_name(&v, None, 42).unwrap();
        let b = generate_name(&v, None, 42).unwrap();
        assert_eq!(a, b);
    }

    #[test]
    fn different_seed_diverges() {
        let v = DignityVector::default();
        let a = generate_name(&v, None, 1).unwrap();
        let b = generate_name(&v, None, 2).unwrap();
        assert_ne!(a.canonical, b.canonical);
    }

    #[test]
    fn dominant_dignity_picks_suffix() {
        let v = DignityVector::new(0.0, 0.0, 0.0, 1.0);
        let t = generate_name(&v, None, 0).unwrap();
        assert_eq!(t.dignity, Dignity::Oly);
        assert!(t.canonical.ends_with("oly"));
    }

    #[test]
    fn world_hint_is_respected() {
        let v = DignityVector::default();
        let t = generate_name(&v, Some(World::Intellectual), 0).unwrap();
        assert_eq!(t.world, World::Intellectual);
        assert!(t.canonical.starts_with("yo"));
    }

    #[test]
    fn vocabulary_is_unique() {
        let v = DignityVector::default();
        let vocab = generate_vocabulary(&v, None, 100, 20);
        let mut uniq = std::collections::HashSet::new();
        for t in &vocab {
            assert!(uniq.insert(t.canonical.clone()));
        }
        assert!(vocab.len() >= 15, "only got {} tokens", vocab.len());
    }

    #[test]
    fn length_stays_in_range() {
        let v = DignityVector::default();
        for seed in 0..50 {
            let t = generate_name(&v, None, seed).unwrap();
            let core_len = t.core.len();
            assert!((1..=3).contains(&core_len), "bad len {core_len}");
        }
    }
}

//! `ce_llull` — combinatorial vocabulary after Ramon Llull.
//!
//! The game's procgen name, faction, item, and mission archetype
//! strings all draw from this crate. Design rationale lives in the
//! module docs:
//!
//! - [`alphabet`] holds the canonical 8-character core alphabet, the
//!   3 Neoplatonic world prefixes, and the 4 dignity suffixes derived
//!   from the Voynich zodiac analysis (folios f70v–f73v) cross-checked
//!   with Llull's *Ars Magna*.
//! - [`token`] composes `prefix + core + suffix` into a bounded
//!   7,008-token vocabulary, with parsing, validation, and index-based
//!   enumeration for tests and UI.
//! - [`dignity`] models the four-axis dignity vector and its cosine
//!   geometry. The four axes align 1-to-1 with the four immeasurables
//!   in `ce_ai` — no historical contact, structural convergence.
//! - [`relation`] scores complementarity (≈ 0.571) and opposition
//!   (≈ 0.444) between tokens, calibrated to the corpus statistics.
//! - [`name`] derives deterministic names from a dignity vector +
//!   seed using `ce_worldclock::DeterministicRng`, so vocabularies
//!   reconstruct bit-for-bit across save / load and network replay.
//!
//! Everything here is pure, deterministic, `no_std`-friendly in
//! spirit (we only touch `std::collections` in tests). No I/O, no
//! rendering, no RNG state outside what the caller supplies.

#![forbid(unsafe_code)]

pub mod alphabet;
pub mod dignity;
pub mod name;
pub mod relation;
pub mod token;

pub use alphabet::{is_core_char, World, CORE_ALPHABET, PREFIXES, SUFFIXES};
pub use dignity::{Dignity, DignityVector};
pub use name::{generate_name, generate_vocabulary};
pub use relation::{
    classify, complementarity, cosine_score, dignity_of, opposition, Relation,
    EXPECTED_COMPLEMENTARITY, EXPECTED_OPPOSITION,
};
pub use token::{parse, token_at, Token, TokenError, MAX_CORE_LEN, MIN_CORE_LEN, VOCABULARY_SIZE};

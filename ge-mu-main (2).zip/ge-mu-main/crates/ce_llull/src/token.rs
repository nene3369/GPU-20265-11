//! The `Token` — one atom of the Llullian vocabulary.
//!
//! A token is `prefix + core + suffix`: one of three prefixes, a
//! 1-to-3 character body drawn from the core alphabet, and one of
//! four suffixes. That's a bounded combinatorial space of
//! `3 × (8 + 8² + 8³) × 4 = 7,008` unique strings — enough for every
//! faction, item, mission archetype, and place name one save will
//! ever need, while still small enough that the full catalog fits in
//! a HashMap for debug browsing.

use crate::alphabet::{is_core_char, World, CORE_ALPHABET};
use crate::dignity::Dignity;

/// Upper and lower bounds on the core-body length. Chosen to match
/// the Voynich label length distribution (modal 2, long tail to 3).
pub const MIN_CORE_LEN: usize = 1;
pub const MAX_CORE_LEN: usize = 3;

/// Total number of tokens the vocabulary can produce. Derived once so
/// tests can pin the number.
pub const VOCABULARY_SIZE: usize = 3 * (8 + 8 * 8 + 8 * 8 * 8) * 4;

/// A parsed, validated token. The `canonical` string is the
/// concatenation callers store in `FactionId` / `ItemId` etc. — it's
/// kept alongside the structured parts so round-tripping is cheap.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Token {
    pub world: World,
    pub core: Vec<char>,
    pub dignity: Dignity,
    pub canonical: String,
}

impl Token {
    /// Assembles a token from components. Returns `Err` when the core
    /// is empty, too long, or contains non-alphabet characters. All
    /// other combinations are legal.
    pub fn new(
        world: World,
        core: impl IntoIterator<Item = char>,
        dignity: Dignity,
    ) -> Result<Self, TokenError> {
        let core: Vec<char> = core.into_iter().collect();
        if core.len() < MIN_CORE_LEN {
            return Err(TokenError::CoreTooShort);
        }
        if core.len() > MAX_CORE_LEN {
            return Err(TokenError::CoreTooLong);
        }
        for &c in &core {
            if !is_core_char(c) {
                return Err(TokenError::CoreCharUnknown(c));
            }
        }
        let mut canonical = String::with_capacity(2 + core.len() + 3);
        canonical.push_str(world.prefix());
        for &c in &core {
            canonical.push(c);
        }
        canonical.push_str(dignity.suffix());
        Ok(Self {
            world,
            core,
            dignity,
            canonical,
        })
    }

    pub fn as_str(&self) -> &str {
        &self.canonical
    }
}

/// Why a string failed to parse into a [`Token`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TokenError {
    /// String shorter than `prefix + 1 core char + suffix` = 6 bytes.
    TooShort,
    /// Prefix (first two chars) isn't in [`PREFIXES`].
    PrefixUnknown,
    /// Suffix (last three chars) isn't in [`SUFFIXES`].
    SuffixUnknown,
    /// Core body is empty after stripping affixes.
    CoreTooShort,
    /// Core body has more than [`MAX_CORE_LEN`] characters.
    CoreTooLong,
    /// Core contains a character outside [`CORE_ALPHABET`].
    CoreCharUnknown(char),
}

/// Parses a canonical string back into a [`Token`]. Accepts only the
/// exact form [`Token::as_str`] produces.
pub fn parse(s: &str) -> Result<Token, TokenError> {
    if s.len() < 2 + MIN_CORE_LEN + 3 {
        return Err(TokenError::TooShort);
    }
    let (prefix_str, rest) = s.split_at(2);
    let world = World::from_prefix(prefix_str).ok_or(TokenError::PrefixUnknown)?;
    if rest.len() < 3 + MIN_CORE_LEN {
        return Err(TokenError::CoreTooShort);
    }
    let (core_str, suffix_str) = rest.split_at(rest.len() - 3);
    let dignity = Dignity::from_suffix(suffix_str).ok_or(TokenError::SuffixUnknown)?;
    let core: Vec<char> = core_str.chars().collect();
    Token::new(world, core, dignity)
}

/// Generates a token deterministically from an index in
/// `[0, VOCABULARY_SIZE)`. Useful for exhaustive testing and for
/// enumerating the full vocabulary in UI.
pub fn token_at(index: usize) -> Option<Token> {
    if index >= VOCABULARY_SIZE {
        return None;
    }
    // Layout: slowest-varying is world (3), then core body (584), then dignity (4).
    // 584 = 8 + 64 + 512 addresses length-1/2/3 bodies.
    const BODY_COUNT: usize = 8 + 8 * 8 + 8 * 8 * 8;
    let dignity_idx = index % 4;
    let after_dig = index / 4;
    let body_idx = after_dig % BODY_COUNT;
    let world_idx = after_dig / BODY_COUNT;
    let world = match world_idx {
        0 => World::Material,
        1 => World::Celestial,
        _ => World::Intellectual,
    };
    let dignity = Dignity::ALL[dignity_idx];
    let core = body_at(body_idx);
    Token::new(world, core, dignity).ok()
}

fn body_at(mut idx: usize) -> Vec<char> {
    // Block 0: length 1 (8 bodies, indices 0..=7).
    if idx < 8 {
        return vec![CORE_ALPHABET[idx]];
    }
    idx -= 8;
    // Block 1: length 2 (64 bodies, 0..=63).
    if idx < 64 {
        let a = idx / 8;
        let b = idx % 8;
        return vec![CORE_ALPHABET[a], CORE_ALPHABET[b]];
    }
    idx -= 64;
    // Block 2: length 3 (512 bodies).
    let a = idx / 64;
    let rest = idx % 64;
    let b = rest / 8;
    let c = rest % 8;
    vec![CORE_ALPHABET[a], CORE_ALPHABET[b], CORE_ALPHABET[c]]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn vocabulary_size_is_7008() {
        assert_eq!(VOCABULARY_SIZE, 7008);
    }

    #[test]
    fn new_assembles_canonical_form() {
        let t = Token::new(World::Material, ['a', 'd'], Dignity::Aly).unwrap();
        assert_eq!(t.as_str(), "okadaly");
    }

    #[test]
    fn new_rejects_empty_core() {
        let err = Token::new(World::Material, std::iter::empty(), Dignity::Aly).err();
        assert_eq!(err, Some(TokenError::CoreTooShort));
    }

    #[test]
    fn new_rejects_over_long_core() {
        let err = Token::new(World::Material, ['a', 'd', 'e', 'k'], Dignity::Aly).err();
        assert_eq!(err, Some(TokenError::CoreTooLong));
    }

    #[test]
    fn new_rejects_non_alphabet_char() {
        let err = Token::new(World::Material, ['z'], Dignity::Aly).err();
        assert_eq!(err, Some(TokenError::CoreCharUnknown('z')));
    }

    #[test]
    fn parse_round_trips_for_canonical_string() {
        let t = Token::new(World::Celestial, ['t', 'y'], Dignity::Edy).unwrap();
        let round = parse(t.as_str()).unwrap();
        assert_eq!(round, t);
    }

    #[test]
    fn parse_rejects_unknown_prefix() {
        assert_eq!(parse("zzady"), Err(TokenError::TooShort));
        assert_eq!(parse("zzadaly"), Err(TokenError::PrefixUnknown));
    }

    #[test]
    fn parse_rejects_unknown_suffix() {
        assert_eq!(parse("okadxyz"), Err(TokenError::SuffixUnknown));
    }

    #[test]
    fn token_at_zero_is_smallest_material_aly() {
        let t = token_at(0).unwrap();
        assert_eq!(t.as_str(), "okaaly");
    }

    #[test]
    fn token_at_covers_full_vocabulary_without_duplication() {
        use std::collections::HashSet;
        let mut seen = HashSet::new();
        for i in 0..VOCABULARY_SIZE {
            let s = token_at(i).unwrap().canonical;
            assert!(seen.insert(s), "duplicate at index {i}");
        }
        assert_eq!(seen.len(), VOCABULARY_SIZE);
    }

    #[test]
    fn token_at_out_of_range_returns_none() {
        assert!(token_at(VOCABULARY_SIZE).is_none());
    }
}

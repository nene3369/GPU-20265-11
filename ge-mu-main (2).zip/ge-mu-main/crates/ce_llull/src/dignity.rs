//! Llullian dignities — the four suffix axes.
//!
//! Each [`Dignity`] is a principle on which every token can take a
//! position: `-aly` for truth / compassion, `-ody` for joy / justice,
//! `-edy` for love / beauty, `-oly` for equanimity / unity.
//! A [`DignityVector`] holds the weights per axis and drives both
//! name generation (the dominant axis picks the suffix) and relation
//! scoring (cosine similarity in `ℝ⁴`).
//!
//! The four axes correspond 1-to-1 with the four immeasurables
//! (慈 / 悲 / 喜 / 捨) of the `ce_ai` consciousness model. The
//! mapping is intentional: Llull's medieval catalog and the Buddhist
//! brahma-vihāra converge on the same four-fold structure.

use crate::alphabet::SUFFIXES;

/// One of the four Llullian dignities. The discriminant indexes
/// [`SUFFIXES`] and [`DignityVector::weights`].
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[repr(u8)]
pub enum Dignity {
    /// `-aly` — truth / compassion. The axis of direct seeing.
    Aly = 0,
    /// `-ody` — joy / justice. The axis of proportion.
    Ody = 1,
    /// `-edy` — love / beauty. The axis of relation.
    Edy = 2,
    /// `-oly` — equanimity / unity. The axis of wholeness.
    Oly = 3,
}

impl Dignity {
    pub const ALL: [Dignity; 4] = [Dignity::Aly, Dignity::Ody, Dignity::Edy, Dignity::Oly];

    /// String form — matches the suffix the token carries.
    pub fn suffix(&self) -> &'static str {
        SUFFIXES[*self as usize]
    }

    /// Parses one of `"aly"` / `"ody"` / `"edy"` / `"oly"`.
    pub fn from_suffix(s: &str) -> Option<Dignity> {
        match s {
            "aly" => Some(Dignity::Aly),
            "ody" => Some(Dignity::Ody),
            "edy" => Some(Dignity::Edy),
            "oly" => Some(Dignity::Oly),
            _ => None,
        }
    }

    pub fn index(&self) -> usize {
        *self as usize
    }
}

/// Four-dimensional dignity position. All components are finite and
/// [`DignityVector::normalise`] drives the sum to 1 when weights are
/// non-zero; a fully-zero vector stays zero (neutral).
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct DignityVector {
    pub weights: [f32; 4],
}

impl Default for DignityVector {
    /// Uniform 0.25 across all axes — the balanced default used when
    /// callers haven't expressed a preference.
    fn default() -> Self {
        Self { weights: [0.25; 4] }
    }
}

impl DignityVector {
    pub const ZERO: DignityVector = DignityVector { weights: [0.0; 4] };

    pub fn new(aly: f32, ody: f32, edy: f32, oly: f32) -> Self {
        Self {
            weights: [aly, ody, edy, oly],
        }
    }

    pub fn weight(&self, d: Dignity) -> f32 {
        self.weights[d.index()]
    }

    /// Axis with the largest weight. Ties break toward earliest in
    /// [`Dignity::ALL`] order (Aly > Ody > Edy > Oly).
    pub fn dominant(&self) -> Dignity {
        let mut best_idx = 0usize;
        let mut best_val = self.weights[0];
        for i in 1..4 {
            if self.weights[i] > best_val {
                best_val = self.weights[i];
                best_idx = i;
            }
        }
        Dignity::ALL[best_idx]
    }

    /// Sum of weights. Used by `normalise` and relation scoring.
    pub fn sum(&self) -> f32 {
        self.weights.iter().sum()
    }

    /// Returns a copy whose weights sum to 1 when the original sum was
    /// positive and finite; otherwise a [`DignityVector::ZERO`].
    /// Negative inputs are clamped to 0 first so "inverse" vectors
    /// don't cancel to NaN.
    pub fn normalise(&self) -> Self {
        let clamped: [f32; 4] = [
            self.weights[0].max(0.0),
            self.weights[1].max(0.0),
            self.weights[2].max(0.0),
            self.weights[3].max(0.0),
        ];
        let s: f32 = clamped.iter().sum();
        if !s.is_finite() || s <= 0.0 {
            return DignityVector::ZERO;
        }
        Self {
            weights: [
                clamped[0] / s,
                clamped[1] / s,
                clamped[2] / s,
                clamped[3] / s,
            ],
        }
    }

    /// Cosine similarity in ℝ⁴. `NaN` inputs collapse to 0 so relation
    /// scoring can't blow up on degenerate tokens.
    pub fn cosine(&self, other: &Self) -> f32 {
        let dot: f32 = self
            .weights
            .iter()
            .zip(other.weights.iter())
            .map(|(a, b)| a * b)
            .sum();
        let na: f32 = self.weights.iter().map(|w| w * w).sum::<f32>().sqrt();
        let nb: f32 = other.weights.iter().map(|w| w * w).sum::<f32>().sqrt();
        if na <= 0.0 || nb <= 0.0 || !dot.is_finite() {
            return 0.0;
        }
        (dot / (na * nb)).clamp(-1.0, 1.0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn suffix_round_trips() {
        for d in Dignity::ALL {
            assert_eq!(Dignity::from_suffix(d.suffix()), Some(d));
        }
    }

    #[test]
    fn default_is_uniform() {
        let v = DignityVector::default();
        assert!((v.sum() - 1.0).abs() < 1e-6);
        for w in v.weights {
            assert!((w - 0.25).abs() < 1e-6);
        }
    }

    #[test]
    fn dominant_picks_largest() {
        let v = DignityVector::new(0.1, 0.8, 0.0, 0.1);
        assert_eq!(v.dominant(), Dignity::Ody);
        let tied = DignityVector::new(0.5, 0.5, 0.0, 0.0);
        assert_eq!(tied.dominant(), Dignity::Aly);
    }

    #[test]
    fn normalise_sums_to_one() {
        let v = DignityVector::new(2.0, 1.0, 1.0, 0.0).normalise();
        assert!((v.sum() - 1.0).abs() < 1e-6);
        assert!((v.weight(Dignity::Aly) - 0.5).abs() < 1e-6);
    }

    #[test]
    fn normalise_zero_stays_zero() {
        assert_eq!(DignityVector::ZERO.normalise(), DignityVector::ZERO);
    }

    #[test]
    fn normalise_negative_is_clamped() {
        let v = DignityVector::new(-1.0, 1.0, 0.0, 0.0).normalise();
        assert_eq!(v, DignityVector::new(0.0, 1.0, 0.0, 0.0));
    }

    #[test]
    fn cosine_is_symmetric_and_bounded() {
        let a = DignityVector::new(0.6, 0.3, 0.1, 0.0);
        let b = DignityVector::new(0.2, 0.2, 0.4, 0.2);
        let ab = a.cosine(&b);
        let ba = b.cosine(&a);
        assert!((ab - ba).abs() < 1e-5);
        assert!((-1.0..=1.0).contains(&ab));
    }

    #[test]
    fn cosine_degenerate_returns_zero() {
        let zero = DignityVector::ZERO;
        let v = DignityVector::new(1.0, 0.0, 0.0, 0.0);
        assert_eq!(zero.cosine(&v), 0.0);
    }
}

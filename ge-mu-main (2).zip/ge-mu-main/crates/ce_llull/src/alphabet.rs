//! The canonical symbol set derived from the Voynich zodiac labels.
//!
//! Constants here are the ground truth the rest of the crate composes
//! on top of. Numbers come from the statistical analysis of the 284
//! zodiac labels (folios f70v–f73v): 78 unique label types over an
//! 8-character core alphabet, structured as prefix + core + suffix.
//! Ramon Llull's *Ars Magna* supplies the four-dignity scaffold the
//! suffixes map onto.

/// The 8 characters that form every non-affix body of a token.
///
/// Ordering matches the Voynich transcription convention (EVA
/// sub-alphabet). Index-based lookup (`CORE_ALPHABET[i]`) is what the
/// procgen name generator uses, so re-ordering is a breaking change.
pub const CORE_ALPHABET: [char; 8] = ['a', 'd', 'e', 'k', 'l', 'o', 't', 'y'];

/// The three prefixes. Each one stands for one of the Neoplatonic
/// worlds (intellectual / celestial / material). Mapped here as an
/// enum so callers get compile-time safety.
pub const PREFIXES: [&str; 3] = ["ok", "ot", "yo"];

/// The four suffixes — one per Llullian dignity. Ordering maps
/// one-to-one with [`Dignity`](crate::dignity::Dignity).
pub const SUFFIXES: [&str; 4] = ["aly", "ody", "edy", "oly"];

/// Neoplatonic three-world tag backing each prefix. Kept as a plain
/// enum so gameplay code can pattern-match without pulling the string.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum World {
    /// `yo-` — the intellectual realm (ideas, intent).
    Intellectual,
    /// `ot-` — the celestial realm (pattern, time, cycle).
    Celestial,
    /// `ok-` — the material realm (matter, mass, place).
    Material,
}

impl World {
    pub const ALL: [World; 3] = [World::Intellectual, World::Celestial, World::Material];

    /// Maps `"ok"` / `"ot"` / `"yo"` to the corresponding world.
    pub fn from_prefix(prefix: &str) -> Option<World> {
        match prefix {
            "yo" => Some(World::Intellectual),
            "ot" => Some(World::Celestial),
            "ok" => Some(World::Material),
            _ => None,
        }
    }

    pub fn prefix(&self) -> &'static str {
        match self {
            World::Intellectual => "yo",
            World::Celestial => "ot",
            World::Material => "ok",
        }
    }

    /// Integer index into [`PREFIXES`], useful for deterministic
    /// RNG-driven selection.
    pub fn index(&self) -> usize {
        match self {
            World::Intellectual => 2,
            World::Celestial => 1,
            World::Material => 0,
        }
    }
}

/// Returns `true` when `c` belongs to the canonical core alphabet.
pub fn is_core_char(c: char) -> bool {
    CORE_ALPHABET.contains(&c)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn core_alphabet_has_eight_unique_chars() {
        let mut sorted = CORE_ALPHABET;
        sorted.sort_unstable();
        for pair in sorted.windows(2) {
            assert_ne!(pair[0], pair[1], "duplicate in core alphabet");
        }
    }

    #[test]
    fn three_prefixes_match_three_worlds() {
        for p in PREFIXES {
            assert!(World::from_prefix(p).is_some(), "unmapped prefix: {p}");
        }
        for w in World::ALL {
            assert!(PREFIXES.contains(&w.prefix()));
        }
    }

    #[test]
    fn four_suffixes_are_unique() {
        for (i, a) in SUFFIXES.iter().enumerate() {
            for b in SUFFIXES.iter().skip(i + 1) {
                assert_ne!(a, b);
            }
        }
    }

    #[test]
    fn is_core_char_matches_alphabet() {
        for c in CORE_ALPHABET {
            assert!(is_core_char(c));
        }
        for c in ['b', 'f', 'g', 'q', 'z'] {
            assert!(!is_core_char(c));
        }
    }

    #[test]
    fn world_prefix_round_trips() {
        for w in World::ALL {
            assert_eq!(World::from_prefix(w.prefix()), Some(w));
        }
    }
}

//! Canonical audio clip identifiers.
//!
//! These are *what gameplay asks for*; the actual sample data (or
//! synthesis recipe) lives in a later rendering / DSP layer that
//! subscribes to the audio event queue.

/// One discrete sound the engine knows how to play.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum AudioClip {
    // UI
    UiClick,
    UiConfirm,
    UiDeny,

    // Ship
    ThrusterLoop,
    WarpCharge,
    WarpEnter,
    WarpArrive,
    DockingClamp,

    // Combat
    LaserFire,
    RailgunFire,
    MissileLaunch,
    ShieldHit,
    HullHit,
    Explosion,

    // Environment / ambient
    Ambient,
    StationInterior,
    PlanetWind,

    // Economy
    TradeBeep,
    CraftDone,
    CreditsEarned,

    // Avatar
    Footstep,
    Jetpack,
    LowOxygenAlarm,
}

impl AudioClip {
    /// Rough category used for mixer bus routing.
    pub fn bus(&self) -> AudioBus {
        match self {
            AudioClip::UiClick
            | AudioClip::UiConfirm
            | AudioClip::UiDeny
            | AudioClip::TradeBeep
            | AudioClip::CraftDone
            | AudioClip::CreditsEarned
            | AudioClip::LowOxygenAlarm => AudioBus::Ui,
            AudioClip::Ambient | AudioClip::StationInterior | AudioClip::PlanetWind => {
                AudioBus::Ambient
            }
            _ => AudioBus::Sfx,
        }
    }

    /// True if the clip is intended to loop until stopped.
    pub fn is_looping(&self) -> bool {
        matches!(
            self,
            AudioClip::ThrusterLoop
                | AudioClip::WarpCharge
                | AudioClip::Ambient
                | AudioClip::StationInterior
                | AudioClip::PlanetWind
                | AudioClip::Jetpack
                | AudioClip::LowOxygenAlarm
        )
    }
}

/// Mixer bus. Each bus has its own volume multiplier.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum AudioBus {
    Sfx,
    Ui,
    Music,
    Ambient,
    Voice,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ui_clips_route_to_ui_bus() {
        assert_eq!(AudioClip::UiClick.bus(), AudioBus::Ui);
        assert_eq!(AudioClip::CreditsEarned.bus(), AudioBus::Ui);
    }

    #[test]
    fn ambient_clips_route_to_ambient_bus() {
        assert_eq!(AudioClip::Ambient.bus(), AudioBus::Ambient);
        assert_eq!(AudioClip::PlanetWind.bus(), AudioBus::Ambient);
    }

    #[test]
    fn default_clips_route_to_sfx() {
        assert_eq!(AudioClip::LaserFire.bus(), AudioBus::Sfx);
        assert_eq!(AudioClip::ThrusterLoop.bus(), AudioBus::Sfx);
    }

    #[test]
    fn looping_clips_marked_correctly() {
        assert!(AudioClip::ThrusterLoop.is_looping());
        assert!(AudioClip::Ambient.is_looping());
        assert!(!AudioClip::UiClick.is_looping());
        assert!(!AudioClip::LaserFire.is_looping());
    }
}

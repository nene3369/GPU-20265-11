//! `ce_audio` — data-layer audio events + mixer state.
//!
//! M17-lite scope: the *what* of audio (which clips exist, which bus
//! they route to, what the current volumes are, and a queue gameplay
//! pushes requests into). The *how* (actual sample playback, DSP
//! synthesis, spatialisation) is a later milestone tied to the
//! windowed example and a backend crate like `rodio` or `kira`.

pub mod clip;
pub mod mixer;

pub use clip::{AudioBus, AudioClip};
pub use mixer::{AudioEvent, AudioQueue, MixerState};

use ce_app::{App, Plugin};

pub struct AudioPlugin;

impl Plugin for AudioPlugin {
    fn build(&self, app: &mut App) {
        if app.world.get_resource::<MixerState>().is_none() {
            app.insert_resource(MixerState::new());
        }
        if app.world.get_resource::<AudioQueue>().is_none() {
            app.insert_resource(AudioQueue::new());
        }
        log::info!("AudioPlugin loaded (data layer only)");
    }
}

#[cfg(test)]
mod plugin_tests {
    use super::*;

    #[test]
    fn plugin_installs_resources() {
        let mut app = App::new();
        app.add_plugin(AudioPlugin);
        assert!(app.world.get_resource::<MixerState>().is_some());
        assert!(app.world.get_resource::<AudioQueue>().is_some());
    }
}

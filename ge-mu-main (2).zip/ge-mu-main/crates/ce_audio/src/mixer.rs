//! Mixer state + event queue.

use std::collections::HashMap;

use crate::clip::{AudioBus, AudioClip};

/// Per-bus volume in `[0, 1]`.
#[derive(Debug, Clone)]
pub struct MixerState {
    master: f32,
    bus_volumes: HashMap<AudioBus, f32>,
}

impl MixerState {
    pub fn new() -> Self {
        let mut bus_volumes = HashMap::new();
        bus_volumes.insert(AudioBus::Sfx, 1.0);
        bus_volumes.insert(AudioBus::Ui, 1.0);
        bus_volumes.insert(AudioBus::Music, 0.8);
        bus_volumes.insert(AudioBus::Ambient, 0.7);
        bus_volumes.insert(AudioBus::Voice, 1.0);
        Self {
            master: 1.0,
            bus_volumes,
        }
    }

    pub fn master(&self) -> f32 {
        self.master
    }

    pub fn set_master(&mut self, v: f32) {
        self.master = v.clamp(0.0, 1.0);
    }

    pub fn bus_volume(&self, bus: AudioBus) -> f32 {
        self.bus_volumes.get(&bus).copied().unwrap_or(1.0)
    }

    pub fn set_bus_volume(&mut self, bus: AudioBus, v: f32) {
        self.bus_volumes.insert(bus, v.clamp(0.0, 1.0));
    }

    /// Effective gain for a clip: master × bus × per-event volume.
    pub fn effective_gain(&self, clip: AudioClip, event_volume: f32) -> f32 {
        self.master * self.bus_volume(clip.bus()) * event_volume.clamp(0.0, 1.0)
    }
}

impl Default for MixerState {
    fn default() -> Self {
        Self::new()
    }
}

/// One queued play request.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct AudioEvent {
    pub clip: AudioClip,
    /// Per-event volume multiplier, `[0, 1]`.
    pub volume: f32,
    /// Pitch multiplier, `0.5..2.0` reasonable range.
    pub pitch: f32,
}

impl AudioEvent {
    pub fn play(clip: AudioClip) -> Self {
        Self {
            clip,
            volume: 1.0,
            pitch: 1.0,
        }
    }

    pub fn with_volume(mut self, v: f32) -> Self {
        self.volume = v.clamp(0.0, 1.0);
        self
    }

    pub fn with_pitch(mut self, p: f32) -> Self {
        self.pitch = p.clamp(0.25, 4.0);
        self
    }
}

/// Simple FIFO queue. Gameplay pushes events; the audio backend
/// drains them each frame. Keeping it out of ce_audio keeps the
/// crate dep-free beyond `std`.
#[derive(Debug, Clone, Default)]
pub struct AudioQueue {
    events: Vec<AudioEvent>,
}

impl AudioQueue {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn push(&mut self, event: AudioEvent) {
        self.events.push(event);
    }

    pub fn len(&self) -> usize {
        self.events.len()
    }

    pub fn is_empty(&self) -> bool {
        self.events.is_empty()
    }

    pub fn drain(&mut self) -> Vec<AudioEvent> {
        std::mem::take(&mut self.events)
    }

    pub fn iter(&self) -> impl Iterator<Item = &AudioEvent> {
        self.events.iter()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn master_and_bus_volumes_are_clamped() {
        let mut m = MixerState::new();
        m.set_master(2.0);
        assert_eq!(m.master(), 1.0);
        m.set_master(-0.5);
        assert_eq!(m.master(), 0.0);
        m.set_bus_volume(AudioBus::Music, 5.0);
        assert_eq!(m.bus_volume(AudioBus::Music), 1.0);
    }

    #[test]
    fn effective_gain_multiplies_master_bus_event() {
        let mut m = MixerState::new();
        m.set_master(0.5);
        m.set_bus_volume(AudioBus::Ui, 0.5);
        let g = m.effective_gain(AudioClip::UiClick, 0.5);
        assert!((g - 0.125).abs() < 1e-5);
    }

    #[test]
    fn event_volume_and_pitch_clamped() {
        let e = AudioEvent::play(AudioClip::LaserFire)
            .with_volume(5.0)
            .with_pitch(0.01);
        assert_eq!(e.volume, 1.0);
        assert_eq!(e.pitch, 0.25);
    }

    #[test]
    fn queue_push_drain_and_order() {
        let mut q = AudioQueue::new();
        q.push(AudioEvent::play(AudioClip::UiClick));
        q.push(AudioEvent::play(AudioClip::LaserFire));
        assert_eq!(q.len(), 2);
        let drained = q.drain();
        assert_eq!(drained.len(), 2);
        assert!(q.is_empty());
        assert_eq!(drained[0].clip, AudioClip::UiClick);
        assert_eq!(drained[1].clip, AudioClip::LaserFire);
    }

    #[test]
    fn default_bus_volumes_are_sensible() {
        let m = MixerState::new();
        assert_eq!(m.bus_volume(AudioBus::Sfx), 1.0);
        assert!(m.bus_volume(AudioBus::Music) < m.bus_volume(AudioBus::Sfx));
        assert!(m.bus_volume(AudioBus::Ambient) < m.bus_volume(AudioBus::Sfx));
    }
}

//! NPC ship identity and mutable simulation state.

use ce_combat::{Shield, WeaponCooldown, WeaponStats};
use ce_faction::FactionId;
use ce_math::{Quat, Vec3};

use crate::goal::NpcGoal;

/// Stable per-ship identifier. Assigned by the spawn director; once
/// allocated it is never reused — permadeath is tracked by id so that
/// save files and logs can refer to the same individual across time.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct NpcId(pub u32);

impl NpcId {
    pub const fn new(n: u32) -> Self {
        Self(n)
    }
}

impl std::fmt::Display for NpcId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "N{:04}", self.0)
    }
}

/// A single NPC ship. Everything the behaviour system needs to reason
/// about one citizen of the world.
#[derive(Debug, Clone)]
pub struct NpcShip {
    pub id: NpcId,
    pub faction: FactionId,
    /// Human-readable name — "Guard 01", "Hermes Hauler". Shown in
    /// HUD target boxes and logs. Owns its storage so directors can
    /// synthesise names at spawn.
    pub display_name: String,

    pub pos: Vec3,
    pub vel: Vec3,
    pub orient: Quat,

    pub max_speed: f32,

    pub hull: f32,
    pub hull_max: f32,
    pub shield: Shield,

    pub weapon_stats: WeaponStats,
    pub weapon_cooldown: WeaponCooldown,
    /// Maximum distance at which this ship will open fire on a hostile.
    pub engage_range: f32,

    pub goal: NpcGoal,
}

impl NpcShip {
    /// Convenience constructor used by directors and tests. Seeds full
    /// hull + shield, idle goal, fresh cooldown. Tune fields after.
    pub fn new(
        id: NpcId,
        faction: FactionId,
        display_name: impl Into<String>,
        pos: Vec3,
        hull_max: f32,
        shield: Shield,
        weapon_stats: WeaponStats,
    ) -> Self {
        Self {
            id,
            faction,
            display_name: display_name.into(),
            pos,
            vel: Vec3::ZERO,
            orient: Quat::IDENTITY,
            max_speed: 12.0,
            hull: hull_max,
            hull_max,
            shield,
            weapon_stats,
            weapon_cooldown: WeaponCooldown::new(),
            engage_range: 28.0,
            goal: NpcGoal::Idle,
        }
    }

    pub fn is_alive(&self) -> bool {
        self.hull > 0.0
    }

    pub fn with_goal(mut self, goal: NpcGoal) -> Self {
        self.goal = goal;
        self
    }

    pub fn with_max_speed(mut self, v: f32) -> Self {
        self.max_speed = v;
        self
    }

    pub fn with_engage_range(mut self, r: f32) -> Self {
        self.engage_range = r;
        self
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ce_combat::{DamageType, Shield, WeaponStats};

    fn sample() -> NpcShip {
        NpcShip::new(
            NpcId::new(1),
            FactionId::new("union"),
            "Guard 01",
            Vec3::ZERO,
            150.0,
            Shield::new(60.0, 12.0, 3.0),
            WeaponStats {
                damage_type: DamageType::Energy,
                damage: 15.0,
                cooldown_seconds: 0.8,
                range_meters: 40.0,
                energy_cost: 3.0,
            },
        )
    }

    #[test]
    fn new_ship_is_alive_with_full_hull() {
        let s = sample();
        assert!(s.is_alive());
        assert_eq!(s.hull, s.hull_max);
    }

    #[test]
    fn goal_and_speed_builders_stack() {
        let s = sample()
            .with_goal(NpcGoal::Idle)
            .with_max_speed(20.0)
            .with_engage_range(50.0);
        assert_eq!(s.max_speed, 20.0);
        assert_eq!(s.engage_range, 50.0);
    }

    #[test]
    fn npc_id_display() {
        assert_eq!(format!("{}", NpcId::new(42)), "N0042");
    }
}

//! Faction strongholds — destructible bases that gate the director.
//!
//! A [`FactionBase`] is a stationary structure owned by a faction.
//! Bolts can damage it via the same `apply_damage` path ships use;
//! when its hull reaches zero the base is destroyed and its owner
//! faction stops getting replenishments from [`crate::director`]
//! until [`advance_base`] counts the rebuild timer down to zero.
//!
//! Bases are not NPCs: they don't move, don't hunt, and don't fire.
//! Their purpose is to make director gating physical — the player
//! can reshape the world's politics by knocking out a faction's
//! source of reinforcements.
//!
//! Pure data + pure-function ticks, same pattern as [`crate::ship`].

use ce_combat::Shield;
use ce_faction::FactionId;
use ce_math::Vec3;

/// Stable id for a base. Assigned once by the gameplay layer; never
/// reused (even after destruction) so saves / logs can refer to the
/// same structure across its lifecycle.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct BaseId(pub u32);

impl std::fmt::Display for BaseId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "B{:04}", self.0)
    }
}

/// A stationary faction asset: station, depot, hideout.
#[derive(Debug, Clone)]
pub struct FactionBase {
    pub id: BaseId,
    pub faction: FactionId,
    pub display_name: String,
    pub pos: Vec3,

    pub hull: f32,
    pub hull_max: f32,
    pub shield: Shield,
    /// Collision radius for projectile hits. Stations should be
    /// bigger than ships.
    pub hit_radius: f32,

    /// `true` once hull has reached zero. While destroyed, the
    /// faction's director halts new spawns until `rebuild_timer`
    /// counts down to zero.
    pub destroyed: bool,
    /// Seconds until the base rebuilds (only meaningful when
    /// `destroyed == true`).
    pub rebuild_timer: f32,
    /// Seconds a freshly-destroyed base must wait before rebuild
    /// starts. Reset every time the base is destroyed.
    pub rebuild_seconds: f32,
    /// Fraction of `hull_max` a rebuild returns with. `1.0` = full
    /// heal, `0.5` = half, etc.
    pub rebuild_hull_fraction: f32,
}

impl FactionBase {
    pub fn new(
        id: BaseId,
        faction: FactionId,
        display_name: impl Into<String>,
        pos: Vec3,
        hull_max: f32,
        shield: Shield,
    ) -> Self {
        Self {
            id,
            faction,
            display_name: display_name.into(),
            pos,
            hull: hull_max,
            hull_max,
            shield,
            hit_radius: 4.0,
            destroyed: false,
            rebuild_timer: 0.0,
            rebuild_seconds: 60.0,
            rebuild_hull_fraction: 0.6,
        }
    }

    pub fn with_hit_radius(mut self, r: f32) -> Self {
        self.hit_radius = r;
        self
    }

    pub fn with_rebuild(mut self, seconds: f32, hull_fraction: f32) -> Self {
        self.rebuild_seconds = seconds;
        self.rebuild_hull_fraction = hull_fraction.clamp(0.05, 1.0);
        self
    }

    pub fn is_alive(&self) -> bool {
        !self.destroyed
    }

    /// Mark the base as destroyed and start its rebuild cooldown.
    /// Safe to call more than once — destroyed state is idempotent.
    pub fn mark_destroyed(&mut self) {
        if !self.destroyed {
            self.destroyed = true;
            self.rebuild_timer = self.rebuild_seconds;
            self.hull = 0.0;
        }
    }
}

/// One frame of base upkeep: regenerate shield, count the rebuild
/// timer down when destroyed, restore hull when it reaches zero.
///
/// Returns `true` if this tick transitioned the base from destroyed
/// back to alive (so the gameplay layer can log / notify).
pub fn advance_base(base: &mut FactionBase, dt: f32) -> bool {
    base.shield.tick(dt);
    if !base.destroyed {
        return false;
    }
    base.rebuild_timer = (base.rebuild_timer - dt).max(0.0);
    if base.rebuild_timer == 0.0 {
        base.destroyed = false;
        base.hull = (base.hull_max * base.rebuild_hull_fraction).max(1.0);
        base.shield.current = base.shield.max;
        return true;
    }
    false
}

/// Is a faction currently barred from spawning replenishments because
/// none of its bases are alive? Returns `true` if `bases` contains at
/// least one entry for `faction` and every such entry is destroyed.
/// Factions with no base entries are never gated by this rule.
pub fn faction_spawning_gated(bases: &[FactionBase], faction: FactionId) -> bool {
    let mut has_any = false;
    for b in bases {
        if b.faction == faction {
            has_any = true;
            if !b.destroyed {
                return false;
            }
        }
    }
    has_any
}

#[cfg(test)]
mod tests {
    use super::*;
    use ce_combat::Shield;

    const PIRATE: FactionId = FactionId::new("pirate");
    const GUARD: FactionId = FactionId::new("guard");

    fn sample_base() -> FactionBase {
        FactionBase::new(
            BaseId(1),
            PIRATE,
            "Reaver's Nest",
            Vec3::ZERO,
            600.0,
            Shield::new(200.0, 30.0, 3.0),
        )
    }

    #[test]
    fn new_base_is_alive_at_full_hull() {
        let b = sample_base();
        assert!(b.is_alive());
        assert_eq!(b.hull, b.hull_max);
    }

    #[test]
    fn mark_destroyed_sets_flags_and_timer() {
        let mut b = sample_base();
        b.mark_destroyed();
        assert!(!b.is_alive());
        assert_eq!(b.hull, 0.0);
        assert!(b.rebuild_timer > 0.0);
    }

    #[test]
    fn mark_destroyed_is_idempotent() {
        let mut b = sample_base();
        b.rebuild_seconds = 10.0;
        b.mark_destroyed();
        let t_after_first = b.rebuild_timer;
        // Second call shouldn't reset the timer back to 10s.
        // (Caller is expected not to double-destroy, but the guard
        // protects against accidental double hits in the same frame.)
        b.mark_destroyed();
        assert_eq!(b.rebuild_timer, t_after_first);
    }

    #[test]
    fn advance_base_counts_timer_down_and_rebuilds() {
        let mut b = sample_base().with_rebuild(5.0, 0.5);
        b.mark_destroyed();
        let rebuilt = advance_base(&mut b, 2.0);
        assert!(!rebuilt);
        assert!(b.rebuild_timer > 0.0);
        let rebuilt = advance_base(&mut b, 10.0); // overshoot
        assert!(rebuilt);
        assert!(b.is_alive());
        assert!((b.hull - b.hull_max * 0.5).abs() < 0.01);
    }

    #[test]
    fn advance_alive_base_only_regens_shield() {
        let mut b = sample_base();
        b.shield.current = 10.0;
        // Push past the regen delay so the tick actually adds shield.
        b.shield.time_since_hit = b.shield.regen_delay_seconds + 1.0;
        let before = b.shield.current;
        let _ = advance_base(&mut b, 1.0);
        assert!(b.shield.current > before);
        assert!(b.is_alive());
    }

    #[test]
    fn faction_spawning_not_gated_without_entry() {
        let bases: [FactionBase; 0] = [];
        assert!(!faction_spawning_gated(&bases, PIRATE));
    }

    #[test]
    fn faction_spawning_gated_only_when_all_destroyed() {
        let mut b1 = FactionBase::new(
            BaseId(1),
            PIRATE,
            "Nest A",
            Vec3::ZERO,
            100.0,
            Shield::new(50.0, 0.0, 0.0),
        );
        let mut b2 = FactionBase::new(
            BaseId(2),
            PIRATE,
            "Nest B",
            Vec3::new(10.0, 0.0, 0.0),
            100.0,
            Shield::new(50.0, 0.0, 0.0),
        );
        // Both alive — not gated.
        assert!(!faction_spawning_gated(&[b1.clone(), b2.clone()], PIRATE));
        // Only one destroyed — still has a base.
        b1.mark_destroyed();
        assert!(!faction_spawning_gated(&[b1.clone(), b2.clone()], PIRATE));
        // Both destroyed — gated.
        b2.mark_destroyed();
        assert!(faction_spawning_gated(&[b1, b2], PIRATE));
    }

    #[test]
    fn faction_spawning_gating_is_per_faction() {
        let mut p = FactionBase::new(
            BaseId(1),
            PIRATE,
            "Pirate Nest",
            Vec3::ZERO,
            100.0,
            Shield::new(50.0, 0.0, 0.0),
        );
        let g = FactionBase::new(
            BaseId(2),
            GUARD,
            "Guard Post",
            Vec3::new(5.0, 0.0, 0.0),
            100.0,
            Shield::new(50.0, 0.0, 0.0),
        );
        p.mark_destroyed();
        let bases = vec![p, g];
        assert!(faction_spawning_gated(&bases, PIRATE));
        assert!(!faction_spawning_gated(&bases, GUARD));
    }
}

//! What an NPC is currently trying to do.
//!
//! The canonical goal list maps onto the player-agreed autonomy
//! surface: patrolling a route, mining an asteroid, running cargo
//! between stations, and hunting a specific target (pirate, threat,
//! escalation). `Idle` is the resting state between assignments;
//! directors never leave a ship idle for long.

use ce_math::Vec3;

/// One waypoint the NPC is visiting. Positions are in world-space
/// metres — the same frame as [`crate::ship::NpcShip::pos`].
pub type Waypoint = Vec3;

#[derive(Debug, Clone, PartialEq)]
pub enum NpcGoal {
    /// Placeholder between missions. A ship in `Idle` drifts at zero
    /// velocity — never the end state of a living NPC.
    Idle,

    /// Cycle through `waypoints`. `cursor` indexes the next point to
    /// visit. On arrival within `arrive_radius`, `cursor` advances.
    Patrol {
        waypoints: Vec<Waypoint>,
        cursor: usize,
        arrive_radius: f32,
    },

    /// Mine a resource node. The ship approaches `target` and, when
    /// within `mine_radius`, extracts one unit per `tick_seconds`.
    /// `units_left` gates how long the job lasts; when zero the ship
    /// hands back to its director.
    Mine {
        target: Vec3,
        mine_radius: f32,
        tick_seconds: f32,
        tick_accum: f32,
        units_left: u32,
    },

    /// Carry cargo between two stations. `heading_back` flips each
    /// time the ship arrives at `from` or `to`, so the same goal
    /// describes an ongoing round-trip.
    Trade {
        from: Waypoint,
        to: Waypoint,
        heading_back: bool,
        arrive_radius: f32,
    },

    /// Actively engage a hostile. `last_seen` is refreshed while the
    /// target stays inside engage range; once `lost_timer` expires
    /// without a refresh, the NPC drops back to its previous goal —
    /// but here, we simply fall back to Idle and let the director
    /// reassign rather than stacking goals.
    Hunt { last_seen: Vec3, lost_timer: f32 },
}

impl NpcGoal {
    /// Convenience: returns the steering target the ship should aim
    /// for right now, if the goal has one. `None` means "no target —
    /// hold position".
    pub fn steering_target(&self) -> Option<Vec3> {
        match self {
            NpcGoal::Idle => None,
            NpcGoal::Patrol {
                waypoints, cursor, ..
            } => waypoints.get(*cursor).copied(),
            NpcGoal::Mine { target, .. } => Some(*target),
            NpcGoal::Trade {
                from,
                to,
                heading_back,
                ..
            } => Some(if *heading_back { *from } else { *to }),
            NpcGoal::Hunt { last_seen, .. } => Some(*last_seen),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn idle_has_no_target() {
        assert!(NpcGoal::Idle.steering_target().is_none());
    }

    #[test]
    fn patrol_targets_the_cursor_waypoint() {
        let g = NpcGoal::Patrol {
            waypoints: vec![Vec3::new(1.0, 0.0, 0.0), Vec3::new(5.0, 0.0, 0.0)],
            cursor: 1,
            arrive_radius: 1.0,
        };
        assert_eq!(g.steering_target(), Some(Vec3::new(5.0, 0.0, 0.0)));
    }

    #[test]
    fn trade_flips_direction_via_heading_back() {
        let from = Vec3::new(0.0, 0.0, 0.0);
        let to = Vec3::new(10.0, 0.0, 0.0);
        let outbound = NpcGoal::Trade {
            from,
            to,
            heading_back: false,
            arrive_radius: 1.0,
        };
        let inbound = NpcGoal::Trade {
            from,
            to,
            heading_back: true,
            arrive_radius: 1.0,
        };
        assert_eq!(outbound.steering_target(), Some(to));
        assert_eq!(inbound.steering_target(), Some(from));
    }

    #[test]
    fn hunt_targets_last_seen() {
        let g = NpcGoal::Hunt {
            last_seen: Vec3::new(3.0, 0.0, -4.0),
            lost_timer: 2.0,
        };
        assert_eq!(g.steering_target(), Some(Vec3::new(3.0, 0.0, -4.0)));
    }

    #[test]
    fn patrol_cursor_out_of_bounds_returns_none() {
        let g = NpcGoal::Patrol {
            waypoints: vec![Vec3::ZERO],
            cursor: 5,
            arrive_radius: 1.0,
        };
        assert_eq!(g.steering_target(), None);
    }
}

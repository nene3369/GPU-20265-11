//! Sector-breath spawn budget.
//!
//! The director is a description, not an engine. It says "this sector
//! wants N patrollers, M miners, K pirates"; the gameplay layer tracks
//! which slots are filled and which ships are in flight. When a ship
//! dies the gameplay layer marks its slot vacant and the director
//! re-fills it on a cooldown.
//!
//! Keeping the policy split from the pool lets saves serialise the
//! live-ship list alone, while the budget is regenerated from world
//! state each load.

/// One kind of role the director reserves slots for.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum SlotKind {
    Patrol,
    Miner,
    Trader,
    Pirate,
}

/// How many of each role a sector should contain when calm. The
/// numbers are targets, not quotas — directors spawn toward them but
/// do not forbid more (e.g. pirates reinforcing a raid).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct SectorBudget {
    pub patrol: u16,
    pub miner: u16,
    pub trader: u16,
    pub pirate: u16,
}

impl SectorBudget {
    /// Sum across roles.
    pub fn total(self) -> u16 {
        self.patrol + self.miner + self.trader + self.pirate
    }

    pub fn of(self, kind: SlotKind) -> u16 {
        match kind {
            SlotKind::Patrol => self.patrol,
            SlotKind::Miner => self.miner,
            SlotKind::Trader => self.trader,
            SlotKind::Pirate => self.pirate,
        }
    }
}

/// Convenience: the starter sector around the home station —
/// one patrol, one miner, one pirate. A tiny, readable cross-section
/// of the living world.
pub fn starter_sector() -> SectorBudget {
    SectorBudget {
        patrol: 1,
        miner: 1,
        trader: 0,
        pirate: 1,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn total_sums_roles() {
        let b = SectorBudget {
            patrol: 2,
            miner: 1,
            trader: 3,
            pirate: 4,
        };
        assert_eq!(b.total(), 10);
    }

    #[test]
    fn of_returns_per_role() {
        let b = SectorBudget {
            patrol: 2,
            miner: 5,
            trader: 0,
            pirate: 1,
        };
        assert_eq!(b.of(SlotKind::Patrol), 2);
        assert_eq!(b.of(SlotKind::Miner), 5);
        assert_eq!(b.of(SlotKind::Trader), 0);
        assert_eq!(b.of(SlotKind::Pirate), 1);
    }

    #[test]
    fn starter_sector_has_one_of_each_combatant() {
        let b = starter_sector();
        assert_eq!(b.patrol, 1);
        assert_eq!(b.miner, 1);
        assert_eq!(b.pirate, 1);
    }
}

//! `ce_npc` — living NPC ships.
//!
//! The project's design directive is that NPCs are not respawning
//! targets arranged for the player; they are citizens of another
//! world. This crate gives them a minimum infrastructure to act on
//! their own:
//!
//! - An [`NpcShip`] carries identity (`id`, `faction`, `display_name`),
//!   a simple state (position, velocity, hull, shield, weapon), and a
//!   [`NpcGoal`] describing what they are trying to do.
//! - [`advance_npc`] integrates one simulation tick: steer toward the
//!   current goal, scan for hostile threats, switch to `Hunt` if one
//!   appears, and emit a [`BehaviorTick`] describing what actually
//!   happened (desired velocity, optional fire intent, goal-specific
//!   side effects such as mining units extracted).
//! - Hostility is derived from `ce_faction::ReputationMatrix` via
//!   [`is_hostile_to`], so the same rule governs pirate-vs-trader,
//!   guard-vs-pirate, and pirate-vs-player interactions.
//! - A [`SectorBudget`] captures the AI-director view: a sector wants
//!   N patrollers, M miners, K pirates. It does not spawn ships itself;
//!   the gameplay layer owns the spawn pool so render/audio/network
//!   concerns stay out of this crate.
//!
//! Pure data + pure functions — no ECS registration, no global state,
//! no random sources (callers pass seeded RNG in). This keeps NPC
//! behaviour testable in isolation and deterministic for save/load
//! and net replay.

pub mod base;
pub mod behavior;
pub mod director;
pub mod goal;
pub mod ship;

pub use base::{advance_base, faction_spawning_gated, BaseId, FactionBase};
pub use behavior::{
    advance_npc, engage_range_with_security, is_hostile_to, BehaviorTick, FireIntent, Threat,
};
pub use director::{SectorBudget, SlotKind};
pub use goal::NpcGoal;
pub use ship::{NpcId, NpcShip};

use ce_app::{App, Plugin};

/// Stub plugin. No systems registered — NPC logic is pure-functional
/// and owned by whichever gameplay crate wires the simulation loop.
pub struct NpcPlugin;

impl Plugin for NpcPlugin {
    fn build(&self, _app: &mut App) {
        log::info!("NpcPlugin loaded (pure functions only)");
    }
}

#[cfg(test)]
mod plugin_tests {
    use super::*;

    #[test]
    fn plugin_adds_cleanly() {
        let mut app = App::new();
        app.add_plugin(NpcPlugin);
    }
}

//! One-tick NPC behaviour: steering, goal advancement, threat scan,
//! and weapon intent. Pure function so it's trivial to test and
//! replay.

use ce_faction::{FactionId, ReputationMatrix};
use ce_math::Vec3;

use crate::goal::NpcGoal;
use crate::ship::NpcShip;

/// A potential threat visible to this NPC. The gameplay layer
/// assembles the list each frame from every ship and station it
/// considers. The behaviour routine decides, per ship, which (if
/// any) of them are genuine hostiles.
#[derive(Debug, Clone, Copy)]
pub struct Threat {
    pub faction: FactionId,
    pub pos: Vec3,
    /// Optional bounding radius — helps callers keep projectiles
    /// centred. Defaults to 1.0 if unknown.
    pub radius: f32,
}

/// Fire-weapon intent emitted by the behaviour routine. Gameplay is
/// responsible for actually spawning a projectile (because it owns
/// the projectile pool and renderer).
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct FireIntent {
    pub from_pos: Vec3,
    pub toward_pos: Vec3,
    pub damage: f32,
    pub damage_type: ce_combat::DamageType,
    pub speed_hint: f32,
}

/// One-tick behaviour output. All vectors are world-space.
#[derive(Debug, Clone, Copy, Default, PartialEq)]
pub struct BehaviorTick {
    /// Desired world-space velocity for the ship this frame. Callers
    /// integrate `pos += desired_vel * dt`.
    pub desired_vel: Vec3,
    /// Optional fire intent. `None` means "did not shoot".
    pub fire: Option<FireIntent>,
    /// How many units the ship mined this tick (Mine goal). Zero
    /// when not mining or not yet at the node.
    pub mined_units: u32,
    /// True if the ship reached the current goal's arrival point this
    /// tick (e.g. patrol waypoint, trade destination). Gameplay can
    /// use this to advance the goal externally — or ignore it, since
    /// [`advance_npc`] already advances Patrol cursors and Trade
    /// directions itself.
    pub arrived: bool,
}

/// Scale a ship's `engage_range` by the sector's `security` mood.
/// Low-security worlds push NPCs to scan and open fire sooner; very
/// safe sectors let them stay cautious and close only when a threat
/// steps on their toes.
///
/// `security` is expected in `[0.0, 1.0]` — at `1.0` the function is
/// the identity. The multiplier is clamped to `[0.75, 1.5]` so one
/// saturated mood swing can't turn the whole sector into a free-fire
/// zone.
pub fn engage_range_with_security(base_range: f32, security: f32) -> f32 {
    if !security.is_finite() {
        return base_range;
    }
    let s = security.clamp(0.0, 1.0);
    let mult = (1.0 + (1.0 - s) * 0.5).clamp(1.0, 1.5);
    base_range * mult
}

/// Returns `true` if `a` considers `b` hostile.
pub fn is_hostile_to(rep: &ReputationMatrix, a: FactionId, b: FactionId) -> bool {
    if a == b {
        return false;
    }
    rep.relation(a, b).is_hostile()
}

/// Pick the closest hostile within `engage_range`.
fn pick_hostile<'a>(
    ship: &NpcShip,
    rep: &ReputationMatrix,
    threats: &'a [Threat],
) -> Option<&'a Threat> {
    threats
        .iter()
        .filter(|t| is_hostile_to(rep, ship.faction, t.faction))
        .filter(|t| (t.pos - ship.pos).length() <= ship.engage_range)
        .min_by(|a, b| {
            (a.pos - ship.pos)
                .length_squared()
                .partial_cmp(&(b.pos - ship.pos).length_squared())
                .unwrap_or(std::cmp::Ordering::Equal)
        })
}

/// Advances `ship` by one tick of `dt` seconds against the current
/// visible `threats` and `rep` matrix. Returns what happened so the
/// caller can integrate position, play effects, and spawn projectiles.
///
/// Mutates:
/// - `ship.weapon_cooldown` (tick)
/// - `ship.shield.time_since_hit` via `shield.tick` so regen can run
/// - `ship.goal`: Patrol cursor advance, Trade direction flip, Hunt
///   takeover when a hostile enters range, Hunt expiry → Idle.
pub fn advance_npc(
    ship: &mut NpcShip,
    rep: &ReputationMatrix,
    threats: &[Threat],
    dt: f32,
) -> BehaviorTick {
    ship.weapon_cooldown.tick(dt);
    ship.shield.tick(dt);

    // -------------------- Threat takeover --------------------
    let hostile = pick_hostile(ship, rep, threats);
    if let Some(h) = hostile {
        // Replace any current goal with Hunt — the world is not safe
        // enough to insist on mining while being shot at. We keep the
        // takeover simple: no goal stack.
        ship.goal = NpcGoal::Hunt {
            last_seen: h.pos,
            lost_timer: 3.0,
        };
    } else if let NpcGoal::Hunt { lost_timer, .. } = &mut ship.goal {
        *lost_timer -= dt;
        if *lost_timer <= 0.0 {
            ship.goal = NpcGoal::Idle;
        }
    }

    // -------------------- Steering + goal housekeeping --------------------
    let mut tick = BehaviorTick::default();
    if let Some(target) = ship.goal.steering_target() {
        let to_target = target - ship.pos;
        let distance = to_target.length();
        if distance > 1e-4 {
            let dir = to_target / distance;
            // Closer than one max-speed step → slow down linearly so we
            // don't overshoot the waypoint.
            let desired_speed = if distance < ship.max_speed * dt * 2.0 {
                distance / dt
            } else {
                ship.max_speed
            };
            tick.desired_vel = dir * desired_speed.min(ship.max_speed);
            // Aim the ship toward its heading (rendering can read
            // orient to draw it). Keep up = +Y. Build a quaternion
            // that rotates -Z onto `dir`.
            ship.orient = look_along(dir);
        }

        // Goal-specific arrival / ticking.
        match &mut ship.goal {
            NpcGoal::Patrol {
                waypoints,
                cursor,
                arrive_radius,
            } => {
                if distance <= *arrive_radius && !waypoints.is_empty() {
                    *cursor = (*cursor + 1) % waypoints.len();
                    tick.arrived = true;
                }
            }
            NpcGoal::Trade {
                heading_back,
                arrive_radius,
                ..
            } => {
                if distance <= *arrive_radius {
                    *heading_back = !*heading_back;
                    tick.arrived = true;
                }
            }
            NpcGoal::Mine {
                mine_radius,
                tick_seconds,
                tick_accum,
                units_left,
                ..
            } => {
                if distance <= *mine_radius && *units_left > 0 {
                    *tick_accum += dt;
                    while *tick_accum >= *tick_seconds && *units_left > 0 {
                        *tick_accum -= *tick_seconds;
                        *units_left -= 1;
                        tick.mined_units += 1;
                    }
                }
            }
            NpcGoal::Hunt { .. } | NpcGoal::Idle => {}
        }
    } else {
        tick.desired_vel = Vec3::ZERO;
    }

    // -------------------- Weapon --------------------
    if let Some(h) = hostile {
        let to = h.pos - ship.pos;
        if to.length() <= ship.weapon_stats.range_meters
            && ship.weapon_cooldown.try_fire(&ship.weapon_stats.clone())
        {
            tick.fire = Some(FireIntent {
                from_pos: ship.pos,
                toward_pos: h.pos,
                damage: ship.weapon_stats.damage,
                damage_type: ship.weapon_stats.damage_type,
                speed_hint: 70.0,
            });
        }
    }

    tick
}

/// Builds a rotation that maps ship-local forward (`-Z`) onto `dir`,
/// with world-up (`+Y`) preserved. Used to set ship orient for
/// rendering and for muzzle direction.
fn look_along(dir: Vec3) -> ce_math::Quat {
    use ce_math::Quat;
    let forward = -Vec3::Z;
    let dot = forward.dot(dir).clamp(-1.0, 1.0);
    if dot > 0.9999 {
        return Quat::IDENTITY;
    }
    if dot < -0.9999 {
        // 180° flip around Y — any perpendicular axis works.
        return Quat::from_axis_angle(Vec3::Y, std::f32::consts::PI);
    }
    let axis = forward.cross(dir).normalize();
    let angle = dot.acos();
    Quat::from_axis_angle(axis, angle)
}

#[cfg(test)]
mod tests {
    use super::*;
    use ce_combat::{DamageType, Shield, WeaponStats};
    use ce_faction::FactionId;

    use crate::ship::NpcId;

    const GUARD: FactionId = FactionId::new("guard");
    const PIRATE: FactionId = FactionId::new("pirate");

    fn fighter(pos: Vec3, faction: FactionId) -> NpcShip {
        NpcShip::new(
            NpcId::new(1),
            faction,
            "test",
            pos,
            100.0,
            Shield::new(50.0, 0.0, 0.0),
            WeaponStats {
                damage_type: DamageType::Energy,
                damage: 20.0,
                cooldown_seconds: 0.5,
                range_meters: 30.0,
                energy_cost: 2.0,
            },
        )
        .with_max_speed(10.0)
        .with_engage_range(25.0)
    }

    fn war_matrix() -> ReputationMatrix {
        let mut m = ReputationMatrix::new();
        m.set(GUARD, PIRATE, -800);
        m
    }

    #[test]
    fn hostility_comes_from_reputation() {
        let rep = war_matrix();
        assert!(is_hostile_to(&rep, GUARD, PIRATE));
        assert!(is_hostile_to(&rep, PIRATE, GUARD));
        assert!(!is_hostile_to(&rep, GUARD, GUARD));
    }

    #[test]
    fn patrol_advances_cursor_on_arrival() {
        let mut ship = fighter(Vec3::ZERO, GUARD).with_goal(NpcGoal::Patrol {
            waypoints: vec![Vec3::new(0.0, 0.0, 0.0), Vec3::new(10.0, 0.0, 0.0)],
            cursor: 0,
            arrive_radius: 1.0,
        });
        // First tick is already within arrive_radius of cursor 0,
        // so cursor should advance and arrived == true.
        let tick = advance_npc(&mut ship, &ReputationMatrix::new(), &[], 0.1);
        assert!(tick.arrived);
        if let NpcGoal::Patrol { cursor, .. } = &ship.goal {
            assert_eq!(*cursor, 1);
        } else {
            panic!("expected Patrol");
        }
    }

    #[test]
    fn miner_extracts_units_only_when_inside_radius() {
        let mut ship = fighter(Vec3::new(0.0, 0.0, 0.0), GUARD).with_goal(NpcGoal::Mine {
            target: Vec3::new(0.5, 0.0, 0.0),
            mine_radius: 1.0,
            tick_seconds: 0.1,
            tick_accum: 0.0,
            units_left: 5,
        });
        let tick = advance_npc(&mut ship, &ReputationMatrix::new(), &[], 0.2);
        assert!(tick.mined_units >= 1);
    }

    #[test]
    fn hostile_in_range_overrides_goal_and_fires() {
        let rep = war_matrix();
        let mut guard = fighter(Vec3::ZERO, GUARD).with_goal(NpcGoal::Patrol {
            waypoints: vec![Vec3::new(50.0, 0.0, 0.0)],
            cursor: 0,
            arrive_radius: 1.0,
        });
        let threats = [Threat {
            faction: PIRATE,
            pos: Vec3::new(10.0, 0.0, 0.0),
            radius: 1.0,
        }];
        let tick = advance_npc(&mut guard, &rep, &threats, 0.1);
        assert!(tick.fire.is_some(), "should open fire");
        assert!(matches!(guard.goal, NpcGoal::Hunt { .. }));
    }

    #[test]
    fn neutral_contact_is_not_engaged() {
        let rep = ReputationMatrix::new();
        let mut guard = fighter(Vec3::ZERO, GUARD);
        let threats = [Threat {
            faction: PIRATE,
            pos: Vec3::new(10.0, 0.0, 0.0),
            radius: 1.0,
        }];
        let tick = advance_npc(&mut guard, &rep, &threats, 0.1);
        assert!(tick.fire.is_none());
    }

    #[test]
    fn hunt_falls_back_to_idle_once_lost_timer_expires() {
        let rep = war_matrix();
        let mut guard = fighter(Vec3::ZERO, GUARD);
        guard.goal = NpcGoal::Hunt {
            last_seen: Vec3::new(20.0, 0.0, 0.0),
            lost_timer: 0.5,
        };
        // No threats visible — after 1s the timer runs out.
        let _ = advance_npc(&mut guard, &rep, &[], 1.0);
        assert_eq!(guard.goal, NpcGoal::Idle);
    }

    #[test]
    fn weapon_respects_cooldown() {
        let rep = war_matrix();
        let mut guard = fighter(Vec3::ZERO, GUARD);
        let threats = [Threat {
            faction: PIRATE,
            pos: Vec3::new(5.0, 0.0, 0.0),
            radius: 1.0,
        }];
        let t1 = advance_npc(&mut guard, &rep, &threats, 0.05);
        let t2 = advance_npc(&mut guard, &rep, &threats, 0.05);
        assert!(t1.fire.is_some());
        // Second tick is well inside the 0.5s cooldown.
        assert!(t2.fire.is_none());
    }

    #[test]
    fn out_of_range_hostile_is_ignored() {
        let rep = war_matrix();
        let mut guard = fighter(Vec3::ZERO, GUARD);
        let threats = [Threat {
            faction: PIRATE,
            pos: Vec3::new(100.0, 0.0, 0.0),
            radius: 1.0,
        }];
        let tick = advance_npc(&mut guard, &rep, &threats, 0.1);
        assert!(tick.fire.is_none());
        // Goal should not change to Hunt either.
        assert!(matches!(guard.goal, NpcGoal::Idle));
    }

    #[test]
    fn engage_range_is_identity_when_world_is_perfectly_safe() {
        assert!((engage_range_with_security(28.0, 1.0) - 28.0).abs() < 1e-5);
    }

    #[test]
    fn engage_range_expands_when_security_collapses() {
        let safe = engage_range_with_security(28.0, 1.0);
        let anarchy = engage_range_with_security(28.0, 0.0);
        assert!(anarchy > safe);
        // Multiplier ceiling is 1.5; anarchy stays bounded.
        assert!(anarchy <= 28.0 * 1.5 + 1e-3);
    }

    #[test]
    fn engage_range_scaling_clamps_to_safe_bounds() {
        // Non-finite falls back to the base range.
        assert!((engage_range_with_security(28.0, f32::NAN) - 28.0).abs() < 1e-5);
        // Out-of-range security clamps before scaling.
        assert!((engage_range_with_security(28.0, 5.0) - 28.0).abs() < 1e-5);
        assert!(engage_range_with_security(28.0, -1.0) <= 28.0 * 1.5 + 1e-3);
    }
}

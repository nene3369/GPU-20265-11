//! `ce_worldpulse` — the meta-logic layer that lets the world evolve
//! its own mood.
//!
//! The project's design directive is that the world exists without
//! the player and keeps reshaping its own rules. Fixed constants in
//! the subsystems (flee thresholds, reputation weights, market
//! spreads) would make the world "closed"; this crate exposes a
//! compact state vector whose values drift based on what just
//! happened, and which the subsystems read as multipliers.
//!
//! # Invariants
//!
//! - All scalars are clamped to `[0.0, 1.0]` every tick. No field
//!   can saturate the feedback loop silently.
//! - [`advance_pulse`] is a pure function: same inputs, same output.
//!   Determinism is delegated entirely to [`pre_drift_pulse`], which
//!   uses the same splitmix64 mixing family as [`ce_worldclock`].
//! - When there are no events and no elapsed time the state is a
//!   fixed point: `tension → 0`, `market_mood → 0.5`, etc. Absent any
//!   stimulus the world relaxes — exactly like grudges in
//!   [`ce_faction::politics::decay_reputation`].
//!
//! # Feedback loop (the whole point)
//!
//! ```text
//!   kill ──► tension ▲
//!           │
//!           ▼
//!        security ▼ ──► NPC engage_range ▲ ──► more kills
//!           │                           │
//!           └────────── tension ▲ ◄─────┘
//! ```
//!
//! The loop is only closed once the gameplay layer binds
//! [`WorldPulse`] values to the subsystem formulas it previously held
//! as constants; see `ce_faction::politics::apply_kill_delta_weighted`,
//! `ce_economy::price::PriceModel::spread_with_mood`, and
//! `ce_npc::behavior::engage_range_with_security`.

#![forbid(unsafe_code)]

/// splitmix64 / xoshiro mixing constant — shared with `ce_worldclock`
/// so pre-drift sequences stay consistent with other seeded state.
const MIX: u64 = 0x9E37_79B9_7F4A_7C15;

/// Clamp helper local to this crate so we don't take a dep just for
/// `f32::clamp`.
#[inline]
fn unit_clamp(x: f32) -> f32 {
    if !x.is_finite() {
        return 0.0;
    }
    x.clamp(0.0, 1.0)
}

/// Compact mood vector for one sector. Each field is in `[0.0, 1.0]`.
/// The gameplay layer reads these instead of hard-coded constants so
/// subsystem behaviour drifts with the world's history.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct WorldPulse {
    /// Heat of active conflict. Rises on every kill, decays slowly
    /// back toward zero. `0.0` = peaceful, `1.0` = open war.
    pub tension: f32,
    /// Perceived safety of the sector. Falls with `tension` and with
    /// each base destroyed, rises as tension relaxes. Subsystems use
    /// this to widen NPC engage ranges when the world feels unsafe.
    pub security: f32,
    /// Market sentiment. `0.5` is neutral; rises on trade volume,
    /// falls on violence that disrupts trade routes. Low mood widens
    /// bid-ask spreads (stations charge risk premiums).
    pub market_mood: f32,
    /// Ambient ringing of the local volume — debris, weapon flash,
    /// shield arcs. Rises on explosions, decays quickly. Subsystems
    /// can key visual density on this.
    pub space_density: f32,
}

impl Default for WorldPulse {
    fn default() -> Self {
        Self::calm()
    }
}

impl WorldPulse {
    /// The resting fixed point. `advance_pulse` with zero events and
    /// any `dt` converges to this over time.
    pub const fn calm() -> Self {
        Self {
            tension: 0.0,
            security: 1.0,
            market_mood: 0.5,
            space_density: 0.0,
        }
    }
}

/// Events accumulated by the gameplay layer over one tick. The layer
/// clears this struct after feeding it to [`advance_pulse`].
#[derive(Debug, Clone, Copy, Default, PartialEq)]
pub struct PulseEvents {
    /// NPC or player ships destroyed this tick (from any faction).
    pub kills: u32,
    /// Total credit value of trades closed this tick.
    pub trades_value: f32,
    /// Faction strongholds reduced to zero hull this tick.
    pub bases_destroyed: u32,
    /// Visible explosions (projectile hits, ship detonations) this
    /// tick. Drives [`WorldPulse::space_density`].
    pub explosions: u32,
    /// Mission contracts completed successfully this tick. Lifts
    /// `market_mood` — a delivered contract means trade lanes held
    /// and someone got paid.
    pub missions_completed: u32,
    /// Mission contracts that timed out or were botched this tick.
    /// Depresses `market_mood` — a broken promise ripples through
    /// the station's reputation with its own clients.
    pub missions_failed: u32,
}

impl PulseEvents {
    /// Convenience reset so the gameplay layer can keep one struct
    /// across frames and clear it after feeding `advance_pulse`.
    pub fn clear(&mut self) {
        *self = Self::default();
    }
}

/// Per-second decay rates pulling each field toward its rest value.
///
/// These are deliberate: tension fades slowly (grudges linger),
/// space_density fades fast (debris sinks into the void), market_mood
/// drifts back to neutral gradually.
const TENSION_DECAY_PER_SEC: f32 = 0.02;
const SECURITY_RESTORE_PER_SEC: f32 = 0.04;
const MOOD_RESTORE_PER_SEC: f32 = 0.03;
const DENSITY_DECAY_PER_SEC: f32 = 0.25;

/// Per-event impulses. Shaped so one kill is a nudge, a handful moves
/// the needle, and a dozen saturate.
const KILL_TENSION_IMPULSE: f32 = 0.06;
const BASE_TENSION_IMPULSE: f32 = 0.15;
const BASE_SECURITY_HIT: f32 = 0.20;
const EXPLOSION_DENSITY_IMPULSE: f32 = 0.05;
/// Trade value needed to lift market_mood by `1.0` (saturated).
const MOOD_TRADE_SATURATION: f32 = 2_000.0;
/// Kills needed to push market_mood fully to pessimistic.
const MOOD_KILL_SATURATION: f32 = 20.0;
/// Per-completion mood lift. A handful of successful contracts noticeably
/// warms the sector.
const MISSION_COMPLETE_MOOD: f32 = 0.05;
/// Per-failure mood drop. Failures punch a little harder than
/// completions lift so the sector can cool fast if trust breaks.
const MISSION_FAIL_MOOD: f32 = 0.08;

/// Advance `pulse` by `dt` seconds against the accumulated `events`.
///
/// The transformation is:
///
/// 1. Apply event impulses to raw `tension`, `market_mood`,
///    `space_density`, and a `security_drag`.
/// 2. Decay toward the rest point by `*_PER_SEC * dt`.
/// 3. Couple: `security` is pulled down by current `tension` as well
///    as by the frame's `security_drag`.
/// 4. Clamp every field back into `[0, 1]`.
///
/// Pure: the same `(pulse, events, dt)` always yields the same
/// result.
pub fn advance_pulse(pulse: WorldPulse, events: &PulseEvents, dt: f32) -> WorldPulse {
    if !dt.is_finite() || dt <= 0.0 {
        return pulse;
    }

    let WorldPulse {
        mut tension,
        mut security,
        mut market_mood,
        mut space_density,
    } = pulse;

    // -------------------- Event impulses --------------------
    let kills = events.kills as f32;
    let bases = events.bases_destroyed as f32;
    let explosions = events.explosions as f32;
    let trades = events.trades_value.max(0.0);

    tension += kills * KILL_TENSION_IMPULSE + bases * BASE_TENSION_IMPULSE;
    space_density += explosions * EXPLOSION_DENSITY_IMPULSE;
    // Direct strike on security for any destroyed stronghold.
    let security_event_drag = bases * BASE_SECURITY_HIT;

    // Market mood: trades lift it, kills drop it. Both saturate.
    // Mission outcomes move mood directly: completions add a steady
    // push, failures subtract the same.
    let mood_up = (trades / MOOD_TRADE_SATURATION).min(1.0);
    let mood_down = (kills / MOOD_KILL_SATURATION).min(1.0);
    market_mood += (mood_up - mood_down) * 0.5;
    market_mood += MISSION_COMPLETE_MOOD * events.missions_completed as f32;
    market_mood -= MISSION_FAIL_MOOD * events.missions_failed as f32;

    // -------------------- Time decay --------------------
    tension = (tension - TENSION_DECAY_PER_SEC * dt).max(0.0);
    // market_mood relaxes toward 0.5
    let mood_gap = 0.5 - market_mood;
    market_mood += mood_gap.signum() * MOOD_RESTORE_PER_SEC * dt * mood_gap.abs().min(1.0);
    space_density = (space_density - DENSITY_DECAY_PER_SEC * dt).max(0.0);

    // -------------------- Coupling --------------------
    // security tracks "1 - tension * weight" and is drained further
    // by the event drag; it also restores over time toward 1.
    let target_security = (1.0 - tension * 0.7).max(0.0) - security_event_drag;
    let gap = target_security - security;
    security += gap.signum() * SECURITY_RESTORE_PER_SEC * dt * gap.abs().min(1.0);

    WorldPulse {
        tension: unit_clamp(tension),
        security: unit_clamp(security),
        market_mood: unit_clamp(market_mood),
        space_density: unit_clamp(space_density),
    }
}

/// Reconstruct a "world was already pulsing when the player arrived"
/// snapshot from `(seed, epoch_seconds)`. Deterministic: same inputs,
/// same output.
///
/// The generator walks a splitmix64 stream to synthesise a short
/// sequence of pseudo-events and feeds them through `advance_pulse`
/// at one-second steps. This is the same trick `ce_worldclock` uses
/// to pre-drift asteroid stock, and it guarantees save / load can
/// replay the same starting mood.
pub fn pre_drift_pulse(seed: u64, epoch_seconds: f64) -> WorldPulse {
    let mut state: u64 = seed
        .wrapping_add(MIX)
        .wrapping_mul(MIX)
        .wrapping_add((epoch_seconds.max(0.0) as u64).wrapping_mul(MIX));

    // One-second sim steps so the decay constants play fair. Cap at
    // 1800 steps (30 minutes) so pathological epochs don't stall the
    // startup loop.
    let steps = (epoch_seconds.max(0.0) as u64).min(1_800);
    let mut pulse = WorldPulse::calm();
    for _ in 0..steps {
        // splitmix64 next
        state = state.wrapping_add(MIX);
        let mut z = state;
        z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
        let r = z ^ (z >> 31);

        // ~20% of seconds see a kill, ~5% an explosion, and a
        // baseline flow of trade. Keeps the drift recognisable as
        // "world was alive" without ramping to war.
        let events = PulseEvents {
            kills: if (r & 0b1111) < 3 { 1 } else { 0 },
            trades_value: ((r >> 4) & 0x3FF) as f32, // 0..1023
            bases_destroyed: 0,
            explosions: if (r >> 14) & 0b11111 == 0 { 1 } else { 0 },
            missions_completed: 0,
            missions_failed: 0,
        };
        pulse = advance_pulse(pulse, &events, 1.0);
    }
    pulse
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn calm_is_the_fixed_point() {
        let p = WorldPulse::calm();
        assert_eq!(p.tension, 0.0);
        assert_eq!(p.security, 1.0);
        assert_eq!(p.market_mood, 0.5);
        assert_eq!(p.space_density, 0.0);
    }

    #[test]
    fn advance_with_no_events_and_no_time_is_identity() {
        let p = WorldPulse {
            tension: 0.4,
            security: 0.6,
            market_mood: 0.7,
            space_density: 0.2,
        };
        let q = advance_pulse(p, &PulseEvents::default(), 0.0);
        assert_eq!(p, q);
    }

    #[test]
    fn advance_ignores_non_finite_dt() {
        let p = WorldPulse::calm();
        assert_eq!(advance_pulse(p, &PulseEvents::default(), f32::NAN), p);
        assert_eq!(advance_pulse(p, &PulseEvents::default(), f32::INFINITY), p);
        assert_eq!(advance_pulse(p, &PulseEvents::default(), -1.0), p);
    }

    #[test]
    fn kills_raise_tension() {
        let p = WorldPulse::calm();
        let q = advance_pulse(
            p,
            &PulseEvents {
                kills: 4,
                ..Default::default()
            },
            0.016,
        );
        assert!(q.tension > p.tension);
        assert!(q.tension <= 1.0);
    }

    #[test]
    fn destroyed_base_cuts_security_immediately() {
        let p = WorldPulse::calm();
        let q = advance_pulse(
            p,
            &PulseEvents {
                bases_destroyed: 1,
                ..Default::default()
            },
            0.5,
        );
        assert!(q.security < p.security);
        assert!(q.tension > 0.0);
    }

    #[test]
    fn tension_decays_over_time_without_events() {
        let p = WorldPulse {
            tension: 0.8,
            ..WorldPulse::calm()
        };
        let mut q = p;
        for _ in 0..400 {
            q = advance_pulse(q, &PulseEvents::default(), 0.1);
        }
        assert!(q.tension < 0.01, "tension did not decay: {}", q.tension);
    }

    #[test]
    fn security_restores_toward_one_after_storm() {
        let p = WorldPulse {
            tension: 0.9,
            security: 0.1,
            ..WorldPulse::calm()
        };
        let mut q = p;
        for _ in 0..1200 {
            q = advance_pulse(q, &PulseEvents::default(), 0.1);
        }
        assert!(q.security > 0.95, "security stuck low: {}", q.security);
        assert!(q.tension < 0.05);
    }

    #[test]
    fn market_mood_relaxes_to_neutral() {
        let mut q = WorldPulse {
            market_mood: 1.0,
            ..WorldPulse::calm()
        };
        for _ in 0..2000 {
            q = advance_pulse(q, &PulseEvents::default(), 0.1);
        }
        assert!((q.market_mood - 0.5).abs() < 0.02);

        let mut q = WorldPulse {
            market_mood: 0.0,
            ..WorldPulse::calm()
        };
        for _ in 0..2000 {
            q = advance_pulse(q, &PulseEvents::default(), 0.1);
        }
        assert!((q.market_mood - 0.5).abs() < 0.02);
    }

    #[test]
    fn trade_lifts_mood_and_kills_depress_it() {
        let p = WorldPulse::calm();
        let up = advance_pulse(
            p,
            &PulseEvents {
                trades_value: MOOD_TRADE_SATURATION,
                ..Default::default()
            },
            0.016,
        );
        assert!(up.market_mood > p.market_mood);

        let down = advance_pulse(
            p,
            &PulseEvents {
                kills: MOOD_KILL_SATURATION as u32,
                ..Default::default()
            },
            0.016,
        );
        assert!(down.market_mood < p.market_mood);
    }

    #[test]
    fn explosions_raise_density_and_then_fade() {
        let p = WorldPulse::calm();
        let q = advance_pulse(
            p,
            &PulseEvents {
                explosions: 5,
                ..Default::default()
            },
            0.016,
        );
        assert!(q.space_density > 0.0);

        let mut r = q;
        for _ in 0..100 {
            r = advance_pulse(r, &PulseEvents::default(), 0.1);
        }
        assert!(r.space_density < 0.01);
    }

    #[test]
    fn all_fields_stay_clamped_under_storm() {
        let mut q = WorldPulse::calm();
        for _ in 0..1000 {
            q = advance_pulse(
                q,
                &PulseEvents {
                    kills: 50,
                    bases_destroyed: 5,
                    explosions: 40,
                    trades_value: 1e9,
                    missions_completed: 10,
                    missions_failed: 10,
                },
                0.016,
            );
            assert!(
                (0.0..=1.0).contains(&q.tension)
                    && (0.0..=1.0).contains(&q.security)
                    && (0.0..=1.0).contains(&q.market_mood)
                    && (0.0..=1.0).contains(&q.space_density),
                "clamp violated: {:?}",
                q
            );
        }
    }

    #[test]
    fn pre_drift_is_deterministic() {
        let a = pre_drift_pulse(42, 1800.0);
        let b = pre_drift_pulse(42, 1800.0);
        assert_eq!(a, b);
    }

    #[test]
    fn pre_drift_depends_on_seed() {
        let a = pre_drift_pulse(1, 1800.0);
        let b = pre_drift_pulse(2, 1800.0);
        assert_ne!(a, b);
    }

    #[test]
    fn pre_drift_with_zero_epoch_is_calm() {
        let p = pre_drift_pulse(42, 0.0);
        assert_eq!(p, WorldPulse::calm());
    }

    #[test]
    fn pulse_events_clear_resets() {
        let mut e = PulseEvents {
            kills: 3,
            trades_value: 100.0,
            bases_destroyed: 1,
            explosions: 5,
            missions_completed: 2,
            missions_failed: 1,
        };
        e.clear();
        assert_eq!(e, PulseEvents::default());
    }

    #[test]
    fn mission_completion_lifts_mood() {
        let p = WorldPulse::calm();
        let q = advance_pulse(
            p,
            &PulseEvents {
                missions_completed: 3,
                ..Default::default()
            },
            0.016,
        );
        assert!(q.market_mood > p.market_mood);
    }

    #[test]
    fn mission_failure_depresses_mood() {
        let p = WorldPulse {
            market_mood: 0.7,
            ..WorldPulse::calm()
        };
        let q = advance_pulse(
            p,
            &PulseEvents {
                missions_failed: 3,
                ..Default::default()
            },
            0.016,
        );
        assert!(q.market_mood < p.market_mood);
    }

    #[test]
    fn mission_outcomes_stay_clamped() {
        let mut q = WorldPulse::calm();
        for _ in 0..500 {
            q = advance_pulse(
                q,
                &PulseEvents {
                    missions_completed: 50,
                    missions_failed: 50,
                    ..Default::default()
                },
                0.016,
            );
            assert!(
                (0.0..=1.0).contains(&q.market_mood),
                "mood out of range: {}",
                q.market_mood
            );
        }
    }
}

//! In-process loopback transport.
//!
//! Used by unit / integration tests and by local-only hosting where
//! the server and its host-client are in the same process. Fulfils
//! the [`Transport`] contract through `Arc<Mutex<Shared>>` — not the
//! fastest implementation imaginable, but the tests exercise semantics,
//! not throughput.

use std::collections::{HashMap, VecDeque};
use std::sync::{Arc, Mutex};

use crate::role::{ClientId, HOST_CLIENT_ID};
use crate::transport::{Channel, NetEvent, Transport};

/// Shared mailbox state for a loopback mesh.
///
/// Stores each peer's inbound queue plus a pending connection list so
/// newly-attached clients surface as `Connected` events on the server's
/// next `tick`.
#[derive(Default)]
struct Shared {
    /// Inbox per destination peer.
    inboxes: HashMap<ClientId, VecDeque<NetEvent>>,
    /// Clients that have been attached but whose `Connected` event has
    /// not yet been emitted to the server.
    pending_server_connects: VecDeque<ClientId>,
    /// Clients that have been detached but whose `Disconnected` event
    /// has not yet been emitted.
    pending_server_disconnects: VecDeque<ClientId>,
    /// Whether the server has observed a `Connected` event for itself
    /// (from the client side).
    pending_client_connects: VecDeque<ClientId>,
}

/// Handle to a shared loopback mesh. Cheap `Clone`; internally refcounted.
#[derive(Clone, Default)]
pub struct LoopbackMesh {
    inner: Arc<Mutex<Shared>>,
}

impl LoopbackMesh {
    pub fn new() -> Self {
        Self::default()
    }

    fn push(&self, to: ClientId, ev: NetEvent) {
        let mut s = self.inner.lock().unwrap();
        s.inboxes.entry(to).or_default().push_back(ev);
    }

    fn pop(&self, from: ClientId) -> Option<NetEvent> {
        let mut s = self.inner.lock().unwrap();
        s.inboxes.get_mut(&from).and_then(|q| q.pop_front())
    }
}

/// Server-side loopback transport. All traffic from any client lands
/// in this endpoint's inbox and can be dispatched back out per-peer
/// or via `broadcast`.
pub struct LoopbackServer {
    mesh: LoopbackMesh,
    peers: Vec<ClientId>,
}

impl LoopbackServer {
    pub fn new() -> Self {
        Self {
            mesh: LoopbackMesh::new(),
            peers: Vec::new(),
        }
    }

    /// Spawns a paired client bound to `client_id` and registers it
    /// with the mesh. The server will see a `Connected` event on its
    /// next `poll`.
    pub fn attach_client(&mut self, client_id: ClientId) -> LoopbackClient {
        {
            let mut s = self.mesh.inner.lock().unwrap();
            s.inboxes.entry(client_id).or_default();
            s.pending_server_connects.push_back(client_id);
            s.pending_client_connects.push_back(client_id);
        }
        self.peers.push(client_id);
        LoopbackClient {
            mesh: self.mesh.clone(),
            client_id,
            observed_connect: false,
        }
    }

    /// Simulates a client dropping.
    pub fn drop_client(&mut self, client_id: ClientId) {
        self.peers.retain(|&c| c != client_id);
        let mut s = self.mesh.inner.lock().unwrap();
        s.pending_server_disconnects.push_back(client_id);
    }
}

impl Default for LoopbackServer {
    fn default() -> Self {
        Self::new()
    }
}

impl Transport for LoopbackServer {
    fn send(&mut self, to: ClientId, channel: Channel, bytes: &[u8]) {
        if self.peers.contains(&to) {
            self.mesh.push(
                to,
                NetEvent::Message {
                    from: HOST_CLIENT_ID,
                    channel,
                    bytes: bytes.to_vec(),
                },
            );
        }
    }

    fn broadcast(&mut self, channel: Channel, bytes: &[u8]) {
        // Snapshot peer list to avoid aliasing issues with future code.
        let peers = self.peers.clone();
        for c in peers {
            self.mesh.push(
                c,
                NetEvent::Message {
                    from: HOST_CLIENT_ID,
                    channel,
                    bytes: bytes.to_vec(),
                },
            );
        }
    }

    fn poll(&mut self) -> Option<NetEvent> {
        // Connect / disconnect events first, then data.
        {
            let mut s = self.mesh.inner.lock().unwrap();
            if let Some(c) = s.pending_server_connects.pop_front() {
                return Some(NetEvent::Connected(c));
            }
            if let Some(c) = s.pending_server_disconnects.pop_front() {
                return Some(NetEvent::Disconnected(c));
            }
        }
        self.mesh.pop(HOST_CLIENT_ID)
    }

    fn tick(&mut self) {
        // No deferred flush: LoopbackMesh delivers synchronously.
    }

    fn peers(&self) -> Vec<ClientId> {
        self.peers.clone()
    }
}

/// Client-side endpoint returned by [`LoopbackServer::attach_client`].
pub struct LoopbackClient {
    mesh: LoopbackMesh,
    client_id: ClientId,
    observed_connect: bool,
}

impl LoopbackClient {
    pub fn client_id(&self) -> ClientId {
        self.client_id
    }
}

impl Transport for LoopbackClient {
    fn send(&mut self, _to: ClientId, channel: Channel, bytes: &[u8]) {
        // Clients always address the server (HOST_CLIENT_ID).
        self.mesh.push(
            HOST_CLIENT_ID,
            NetEvent::Message {
                from: self.client_id,
                channel,
                bytes: bytes.to_vec(),
            },
        );
    }

    fn broadcast(&mut self, channel: Channel, bytes: &[u8]) {
        // Broadcast-from-client means "send to server".
        self.send(HOST_CLIENT_ID, channel, bytes);
    }

    fn poll(&mut self) -> Option<NetEvent> {
        // Emit a one-time Connected(HOST_CLIENT_ID) on first poll so the
        // client-side code can drive its connection state machine.
        if !self.observed_connect {
            let mut s = self.mesh.inner.lock().unwrap();
            if s.pending_client_connects
                .iter()
                .any(|&c| c == self.client_id)
            {
                s.pending_client_connects.retain(|&c| c != self.client_id);
                drop(s);
                self.observed_connect = true;
                return Some(NetEvent::Connected(HOST_CLIENT_ID));
            }
        }
        self.mesh.pop(self.client_id)
    }

    fn tick(&mut self) {}

    fn peers(&self) -> Vec<ClientId> {
        vec![HOST_CLIENT_ID]
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn attach_client_emits_connected_on_server_poll() {
        let mut server = LoopbackServer::new();
        let _client = server.attach_client(ClientId(1));
        match server.poll() {
            Some(NetEvent::Connected(c)) => assert_eq!(c, ClientId(1)),
            other => panic!("expected Connected(1), got {other:?}"),
        }
        assert!(server.poll().is_none(), "inbox should be drained");
    }

    #[test]
    fn client_observes_connect_once() {
        let mut server = LoopbackServer::new();
        let mut client = server.attach_client(ClientId(1));
        match client.poll() {
            Some(NetEvent::Connected(_)) => {}
            other => panic!("expected Connected, got {other:?}"),
        }
        assert!(client.poll().is_none());
    }

    #[test]
    fn client_to_server_reliable_roundtrip() {
        let mut server = LoopbackServer::new();
        let mut client = server.attach_client(ClientId(1));
        // Drain connect events.
        let _ = server.poll();
        let _ = client.poll();

        client.send(HOST_CLIENT_ID, Channel::Reliable, b"hello");
        match server.poll() {
            Some(NetEvent::Message {
                from,
                channel,
                bytes,
            }) => {
                assert_eq!(from, ClientId(1));
                assert_eq!(channel, Channel::Reliable);
                assert_eq!(&bytes, b"hello");
            }
            other => panic!("expected Message, got {other:?}"),
        }
    }

    #[test]
    fn server_broadcast_reaches_every_client() {
        let mut server = LoopbackServer::new();
        let mut c1 = server.attach_client(ClientId(1));
        let mut c2 = server.attach_client(ClientId(2));
        // Drain connect events.
        let _ = server.poll();
        let _ = server.poll();
        let _ = c1.poll();
        let _ = c2.poll();

        server.broadcast(Channel::Unreliable, b"snap");

        for (label, c) in [("c1", &mut c1), ("c2", &mut c2)] {
            match c.poll() {
                Some(NetEvent::Message { from, bytes, .. }) => {
                    assert_eq!(from, HOST_CLIENT_ID, "{label} sender");
                    assert_eq!(&bytes, b"snap");
                }
                other => panic!("{label}: expected Message, got {other:?}"),
            }
        }
    }

    #[test]
    fn server_send_targets_single_client() {
        let mut server = LoopbackServer::new();
        let mut c1 = server.attach_client(ClientId(1));
        let mut c2 = server.attach_client(ClientId(2));
        let _ = server.poll();
        let _ = server.poll();
        let _ = c1.poll();
        let _ = c2.poll();

        server.send(ClientId(2), Channel::Reliable, b"for-two");

        assert!(c1.poll().is_none(), "c1 should not receive targeted send");
        match c2.poll() {
            Some(NetEvent::Message { bytes, .. }) => assert_eq!(&bytes, b"for-two"),
            other => panic!("c2 expected Message, got {other:?}"),
        }
    }

    #[test]
    fn drop_client_emits_disconnected() {
        let mut server = LoopbackServer::new();
        let _client = server.attach_client(ClientId(5));
        let _ = server.poll();
        server.drop_client(ClientId(5));
        match server.poll() {
            Some(NetEvent::Disconnected(c)) => assert_eq!(c, ClientId(5)),
            other => panic!("expected Disconnected(5), got {other:?}"),
        }
        assert!(!server.peers().contains(&ClientId(5)));
    }

    #[test]
    fn ten_clients_can_all_round_trip() {
        let mut server = LoopbackServer::new();
        let mut clients: Vec<LoopbackClient> = (1u32..=10)
            .map(|i| server.attach_client(ClientId(i)))
            .collect();

        // Drain 10 Connected events on the server.
        for _ in 0..10 {
            assert!(matches!(server.poll(), Some(NetEvent::Connected(_))));
        }
        for c in clients.iter_mut() {
            assert!(matches!(c.poll(), Some(NetEvent::Connected(_))));
        }

        // Every client sends one byte; server broadcasts a distinct
        // payload; every client receives it.
        for (i, c) in clients.iter_mut().enumerate() {
            c.send(HOST_CLIENT_ID, Channel::Reliable, &[i as u8]);
        }
        let mut received_from = Vec::new();
        while let Some(ev) = server.poll() {
            if let NetEvent::Message { from, .. } = ev {
                received_from.push(from);
            }
        }
        received_from.sort();
        let expected: Vec<ClientId> = (1u32..=10).map(ClientId).collect();
        assert_eq!(received_from, expected);

        server.broadcast(Channel::Unreliable, b"go");
        for (i, c) in clients.iter_mut().enumerate() {
            match c.poll() {
                Some(NetEvent::Message { bytes, .. }) => assert_eq!(&bytes, b"go", "client {i}"),
                other => panic!("client {i}: {other:?}"),
            }
        }
    }

    #[test]
    fn server_peers_list_tracks_attach_and_drop() {
        let mut server = LoopbackServer::new();
        assert!(server.peers().is_empty());
        let _a = server.attach_client(ClientId(1));
        let _b = server.attach_client(ClientId(2));
        assert_eq!(server.peers().len(), 2);
        server.drop_client(ClientId(1));
        assert_eq!(server.peers(), vec![ClientId(2)]);
    }

    #[test]
    fn client_peers_contains_only_host() {
        let mut server = LoopbackServer::new();
        let client = server.attach_client(ClientId(7));
        assert_eq!(client.peers(), vec![HOST_CLIENT_ID]);
    }

    #[test]
    fn server_send_to_unknown_client_is_dropped() {
        let mut server = LoopbackServer::new();
        // No clients attached.
        server.send(ClientId(99), Channel::Reliable, b"nowhere");
        // No panic, nothing pending.
        assert!(server.poll().is_none());
    }
}

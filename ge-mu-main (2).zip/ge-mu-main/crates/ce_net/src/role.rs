//! Network role — who am I in the session?
//!
//! Inserted as a resource. Gameplay systems branch on this to decide
//! whether to simulate authoritatively (server), apply received state
//! (client), or both (solo).

/// Identifier for a connected player. `SERVER_CLIENT_ID` is conventionally
/// the host: the server itself also occupies a client slot for its player.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct ClientId(pub u32);

/// ID used by the host process's own player, when the host is also
/// playing (common for listen-server / host-client mode).
pub const HOST_CLIENT_ID: ClientId = ClientId(0);

impl ClientId {
    pub fn is_host(self) -> bool {
        self == HOST_CLIENT_ID
    }
}

/// Which side of the session is this instance running as.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum NetRole {
    /// No multiplayer. All gameplay is local and authoritative.
    #[default]
    Solo,
    /// Hosting an authoritative server. The host player is a client of
    /// itself with `HOST_CLIENT_ID`.
    Server { max_clients: u32 },
    /// Connected to a remote server.
    Client,
}

impl NetRole {
    pub fn is_authoritative(self) -> bool {
        matches!(self, NetRole::Solo | NetRole::Server { .. })
    }

    pub fn is_networked(self) -> bool {
        matches!(self, NetRole::Server { .. } | NetRole::Client)
    }

    pub fn capacity(self) -> u32 {
        match self {
            NetRole::Solo => 1,
            NetRole::Server { max_clients } => max_clients,
            NetRole::Client => 1,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn host_client_id_is_zero() {
        assert_eq!(HOST_CLIENT_ID, ClientId(0));
        assert!(HOST_CLIENT_ID.is_host());
        assert!(!ClientId(1).is_host());
    }

    #[test]
    fn solo_and_server_are_authoritative_client_is_not() {
        assert!(NetRole::Solo.is_authoritative());
        assert!(NetRole::Server { max_clients: 10 }.is_authoritative());
        assert!(!NetRole::Client.is_authoritative());
    }

    #[test]
    fn networked_roles_exclude_solo() {
        assert!(!NetRole::Solo.is_networked());
        assert!(NetRole::Server { max_clients: 10 }.is_networked());
        assert!(NetRole::Client.is_networked());
    }

    #[test]
    fn capacity_returns_max_clients() {
        assert_eq!(NetRole::Solo.capacity(), 1);
        assert_eq!(NetRole::Server { max_clients: 10 }.capacity(), 10);
        assert_eq!(NetRole::Client.capacity(), 1);
    }
}

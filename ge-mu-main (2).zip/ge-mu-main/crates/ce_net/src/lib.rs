//! `ce_net` — network interface for ChemEngine multiplayer (PvE, 10p).
//!
//! M7 scope: the abstractions every networked system needs (roles,
//! client IDs, channels, events, `Transport` trait) plus an in-process
//! loopback implementation used by tests and by local-only hosting.
//!
//! A real transport bound to Steam Datagram Relay / QUIC / raw UDP
//! lands in a later milestone; the interface is frozen here so the
//! gameplay crates that follow can code against it immediately.

pub mod loopback;
pub mod role;
pub mod transport;

pub use loopback::{LoopbackClient, LoopbackMesh, LoopbackServer};
pub use role::{ClientId, NetRole, HOST_CLIENT_ID};
pub use transport::{Channel, NetEvent, Transport};

use ce_app::{App, Plugin};

/// Installs a [`NetRole`] resource. Default is `NetRole::Solo` — single
/// player with no networking. Swap to `Server { max_clients: 10 }` or
/// `Client` before other plugins build if you want multiplayer.
pub struct NetPlugin {
    pub role: NetRole,
}

impl NetPlugin {
    pub fn solo() -> Self {
        Self {
            role: NetRole::Solo,
        }
    }

    pub fn host(max_clients: u32) -> Self {
        Self {
            role: NetRole::Server { max_clients },
        }
    }

    pub fn client() -> Self {
        Self {
            role: NetRole::Client,
        }
    }
}

impl Default for NetPlugin {
    fn default() -> Self {
        Self::solo()
    }
}

impl Plugin for NetPlugin {
    fn build(&self, app: &mut App) {
        if app.world.get_resource::<NetRole>().is_none() {
            app.insert_resource(self.role);
        }
        log::info!("NetPlugin loaded: role = {:?}", self.role);
    }
}

#[cfg(test)]
mod plugin_tests {
    use super::*;

    #[test]
    fn solo_plugin_inserts_solo_role() {
        let mut app = App::new();
        app.add_plugin(NetPlugin::solo());
        assert_eq!(app.world.get_resource::<NetRole>(), Some(&NetRole::Solo));
    }

    #[test]
    fn host_plugin_inserts_server_role_with_cap() {
        let mut app = App::new();
        app.add_plugin(NetPlugin::host(10));
        assert_eq!(
            app.world.get_resource::<NetRole>(),
            Some(&NetRole::Server { max_clients: 10 })
        );
    }

    #[test]
    fn plugin_preserves_preinserted_role() {
        let mut app = App::new();
        app.insert_resource(NetRole::Client);
        app.add_plugin(NetPlugin::solo());
        assert_eq!(app.world.get_resource::<NetRole>(), Some(&NetRole::Client));
    }
}

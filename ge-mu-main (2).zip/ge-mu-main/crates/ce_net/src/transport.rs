//! Transport abstraction.
//!
//! Gameplay-facing API. Concrete implementations live below (loopback)
//! and in future milestones (Steam Datagram Relay, QUIC, raw UDP).

use crate::role::ClientId;

/// Delivery guarantee for a message.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Channel {
    /// Must arrive, must arrive in-order. Use for chat, commands,
    /// inventory edits, crafting, ship block placement.
    Reliable,
    /// May drop, may reorder. Use for snapshots, position streams,
    /// weapon fire VFX — anything where a newer packet obsoletes the
    /// old.
    Unreliable,
}

/// One event drained from a transport in a single `tick`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum NetEvent {
    /// A client finished its handshake and is ready to exchange
    /// messages.
    Connected(ClientId),
    /// A previously-connected client left or timed out.
    Disconnected(ClientId),
    /// Data frame.
    Message {
        from: ClientId,
        channel: Channel,
        bytes: Vec<u8>,
    },
}

/// A transport moves raw byte frames between the local endpoint and
/// other participants. It is symmetric: both server and client
/// implementations expose the same interface; the only difference is
/// what `send`'s `to` field means on each side:
/// - Server: "send to this client".
/// - Client: `to` is ignored; traffic always flows to the server.
pub trait Transport: Send + Sync {
    /// Enqueues a frame for delivery. Non-blocking. Implementations
    /// are free to buffer and flush on the next `tick`.
    fn send(&mut self, to: ClientId, channel: Channel, bytes: &[u8]);

    /// Enqueues a frame for delivery to every connected peer.
    fn broadcast(&mut self, channel: Channel, bytes: &[u8]);

    /// Drains the next incoming event, if any. Returns `None` when the
    /// inbox is empty for this frame.
    fn poll(&mut self) -> Option<NetEvent>;

    /// Called once per frame. Implementations flush pending sends and
    /// refill their inboxes from the underlying socket / channel.
    fn tick(&mut self);

    /// Currently-connected peers. On a client this will be at most one
    /// (the server).
    fn peers(&self) -> Vec<ClientId>;
}

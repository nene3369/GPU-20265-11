//! UI layer — menu state machine + HUD data model.
//!
//! M4 scope: the state & data the UI needs. The actual rendering
//! pipeline (egui + egui-wgpu bound to `ce_render`) ships in a later
//! milestone once a real window example is added.

pub mod hud;
pub mod menu;

pub use hud::{HudMessage, HudMessageKind, HudState};
pub use menu::{MenuOrigin, MenuState, TransitionError};

use ce_app::{App, Plugin};

/// Installs UI state resources.
///
/// - [`MenuState::Title`] is the starting screen.
/// - A fresh [`HudState`] is inserted so gameplay systems can push
///   messages from frame one.
///
/// The plugin does **not** install a rendering system yet; adding one
/// requires the wgpu device/queue from `ce_render` and is left to the
/// egui integration milestone.
pub struct UiPlugin;

impl Plugin for UiPlugin {
    fn build(&self, app: &mut App) {
        if app.world.get_resource::<MenuState>().is_none() {
            app.insert_resource(MenuState::Title);
        }
        if app.world.get_resource::<HudState>().is_none() {
            app.insert_resource(HudState::new());
        }
        log::info!("UiPlugin loaded (state only; renderer pending)");
    }
}

#[cfg(test)]
mod plugin_tests {
    use super::*;

    #[test]
    fn ui_plugin_inserts_default_resources() {
        let mut app = App::new();
        app.add_plugin(UiPlugin);

        assert_eq!(
            app.world.get_resource::<MenuState>(),
            Some(&MenuState::Title)
        );
        assert!(app.world.get_resource::<HudState>().is_some());
    }

    #[test]
    fn ui_plugin_preserves_pre_inserted_state() {
        let mut app = App::new();
        app.insert_resource(MenuState::Playing);
        app.add_plugin(UiPlugin);

        assert_eq!(
            app.world.get_resource::<MenuState>(),
            Some(&MenuState::Playing)
        );
    }
}

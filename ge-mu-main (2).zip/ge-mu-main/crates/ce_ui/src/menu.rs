//! Top-level menu / gameplay state machine.
//!
//! Drives transitions between the title screen, the live game world,
//! the pause menu, and the settings screen. The actual rendering of
//! each screen is up to a later rendering milestone (egui integration);
//! this module owns only the state and its legal transitions.

/// Every screen the player can be in.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum MenuState {
    /// First screen on launch. Shows "New Game / Load / Settings / Quit".
    Title,
    /// The game world is live; input drives the avatar.
    Playing,
    /// Pause overlay on top of a frozen world.
    Paused,
    /// Graphics / audio / key-binding screen. Accessible from Title and
    /// Paused.
    Settings(MenuOrigin),
    /// Terminal state. Main loop should exit shortly after observing this.
    Quitting,
}

/// Remembers which screen the player opened [`MenuState::Settings`] from,
/// so closing it returns to the right place.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum MenuOrigin {
    Title,
    Paused,
}

impl MenuState {
    /// Is the underlying world expected to advance this frame?
    pub fn world_active(&self) -> bool {
        matches!(self, MenuState::Playing)
    }

    /// Should gameplay input (move, interact, etc.) be routed to the
    /// avatar, as opposed to UI navigation?
    pub fn gameplay_input_active(&self) -> bool {
        matches!(self, MenuState::Playing)
    }
}

/// Reasons the state machine may reject a transition. Returned so the
/// caller can log / bubble up diagnostics rather than silently ignoring
/// invalid attempts.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TransitionError {
    /// The requested transition isn't allowed from the current state.
    Illegal,
}

impl MenuState {
    /// Attempts the transition and returns the new state on success. The
    /// original state is returned unchanged on error.
    pub fn try_transition(self, to: MenuState) -> Result<MenuState, TransitionError> {
        let ok = matches!(
            (self, to),
            // Title → start new game / settings / quit
            (MenuState::Title, MenuState::Playing)
            | (MenuState::Title, MenuState::Settings(MenuOrigin::Title))
            | (MenuState::Title, MenuState::Quitting)
            // Playing → pause / return to title / quit
            | (MenuState::Playing, MenuState::Paused)
            | (MenuState::Playing, MenuState::Title)
            | (MenuState::Playing, MenuState::Quitting)
            // Paused → resume / open settings / return to title / quit
            | (MenuState::Paused, MenuState::Playing)
            | (MenuState::Paused, MenuState::Settings(MenuOrigin::Paused))
            | (MenuState::Paused, MenuState::Title)
            | (MenuState::Paused, MenuState::Quitting)
            // Settings closes back to whatever opened it
            | (MenuState::Settings(MenuOrigin::Title), MenuState::Title)
            | (MenuState::Settings(MenuOrigin::Paused), MenuState::Paused)
        );
        if ok {
            Ok(to)
        } else {
            Err(TransitionError::Illegal)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn launch_to_gameplay() {
        let s = MenuState::Title;
        let s = s.try_transition(MenuState::Playing).unwrap();
        assert!(s.world_active());
        assert!(s.gameplay_input_active());
    }

    #[test]
    fn pause_and_resume() {
        let s = MenuState::Playing;
        let paused = s.try_transition(MenuState::Paused).unwrap();
        assert!(!paused.world_active());
        assert!(!paused.gameplay_input_active());
        let resumed = paused.try_transition(MenuState::Playing).unwrap();
        assert!(resumed.world_active());
    }

    #[test]
    fn settings_remembers_origin() {
        // From title.
        let s = MenuState::Title;
        let settings = s
            .try_transition(MenuState::Settings(MenuOrigin::Title))
            .unwrap();
        let back = settings.try_transition(MenuState::Title).unwrap();
        assert_eq!(back, MenuState::Title);

        // From paused.
        let s = MenuState::Paused;
        let settings = s
            .try_transition(MenuState::Settings(MenuOrigin::Paused))
            .unwrap();
        let back = settings.try_transition(MenuState::Paused).unwrap();
        assert_eq!(back, MenuState::Paused);
    }

    #[test]
    fn cannot_pause_from_title() {
        let s = MenuState::Title;
        assert_eq!(
            s.try_transition(MenuState::Paused),
            Err(TransitionError::Illegal)
        );
    }

    #[test]
    fn cannot_close_title_settings_into_paused() {
        let settings = MenuState::Settings(MenuOrigin::Title);
        assert_eq!(
            settings.try_transition(MenuState::Paused),
            Err(TransitionError::Illegal)
        );
    }

    #[test]
    fn quit_is_reachable_from_any_live_state() {
        for start in [MenuState::Title, MenuState::Playing, MenuState::Paused] {
            assert!(start.try_transition(MenuState::Quitting).is_ok());
        }
    }
}

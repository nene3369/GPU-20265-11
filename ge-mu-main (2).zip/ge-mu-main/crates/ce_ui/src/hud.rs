//! HUD state — the data the in-world overlay reads every frame.
//!
//! Does not paint anything yet; an egui / egui-wgpu integration (next
//! milestone) will consume this resource and draw the actual widgets.

use std::collections::VecDeque;

/// Category of a transient on-screen message. The HUD renderer uses
/// this to colour / icon the message.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HudMessageKind {
    Info,
    Warning,
    Error,
    /// NPC dialogue line. Also fans out to the dialogue panel.
    Dialogue,
}

/// One queued line for the HUD message log.
#[derive(Debug, Clone)]
pub struct HudMessage {
    pub kind: HudMessageKind,
    pub text: String,
    /// Seconds remaining before the message is auto-dismissed. `None`
    /// means the message is pinned until the code explicitly removes it.
    pub ttl: Option<f32>,
}

/// Everything the HUD draws every frame.
///
/// Inserted as a resource by `UiPlugin`. Gameplay systems push
/// messages; the renderer reads them; a decay system calls
/// [`HudState::tick`] once per frame to expire them.
#[derive(Debug, Clone)]
pub struct HudState {
    /// Frames-per-second moving estimate, updated by the app loop.
    pub fps: f32,
    /// Whether the game-world crosshair should be drawn.
    pub crosshair_visible: bool,
    /// Ring buffer of recent messages. Oldest entries at the front.
    messages: VecDeque<HudMessage>,
    /// Maximum messages kept in the buffer. Oldest are dropped past this.
    capacity: usize,
}

impl HudState {
    pub const DEFAULT_CAPACITY: usize = 16;

    pub fn new() -> Self {
        Self {
            fps: 0.0,
            crosshair_visible: true,
            messages: VecDeque::new(),
            capacity: Self::DEFAULT_CAPACITY,
        }
    }

    pub fn with_capacity(capacity: usize) -> Self {
        Self {
            capacity: capacity.max(1),
            ..Self::new()
        }
    }

    /// Pushes a message, dropping the oldest if the buffer is at capacity.
    pub fn push(&mut self, msg: HudMessage) {
        if self.messages.len() == self.capacity {
            self.messages.pop_front();
        }
        self.messages.push_back(msg);
    }

    /// Convenience for info-level flash messages with a TTL.
    pub fn push_info(&mut self, text: impl Into<String>, ttl_seconds: f32) {
        self.push(HudMessage {
            kind: HudMessageKind::Info,
            text: text.into(),
            ttl: Some(ttl_seconds),
        });
    }

    /// Convenience for NPC dialogue lines.
    pub fn push_dialogue(&mut self, text: impl Into<String>, ttl_seconds: f32) {
        self.push(HudMessage {
            kind: HudMessageKind::Dialogue,
            text: text.into(),
            ttl: Some(ttl_seconds),
        });
    }

    /// Returns all currently-live messages in chronological order.
    pub fn messages(&self) -> impl Iterator<Item = &HudMessage> {
        self.messages.iter()
    }

    pub fn message_count(&self) -> usize {
        self.messages.len()
    }

    /// Advances each message's TTL by `dt_seconds` and discards expired
    /// ones. Messages with `ttl = None` are left alone.
    pub fn tick(&mut self, dt_seconds: f32) {
        self.messages.retain_mut(|m| match m.ttl.as_mut() {
            Some(ttl) => {
                *ttl -= dt_seconds;
                *ttl > 0.0
            }
            None => true,
        });
    }

    pub fn clear(&mut self) {
        self.messages.clear();
    }
}

impl Default for HudState {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn new_hud_is_empty_with_visible_crosshair() {
        let hud = HudState::new();
        assert_eq!(hud.fps, 0.0);
        assert!(hud.crosshair_visible);
        assert_eq!(hud.message_count(), 0);
    }

    #[test]
    fn push_respects_capacity() {
        let mut hud = HudState::with_capacity(3);
        for i in 0..5 {
            hud.push_info(format!("m{i}"), 1.0);
        }
        assert_eq!(hud.message_count(), 3);
        let texts: Vec<_> = hud.messages().map(|m| m.text.as_str()).collect();
        assert_eq!(texts, vec!["m2", "m3", "m4"]);
    }

    #[test]
    fn tick_expires_messages_with_ttl() {
        let mut hud = HudState::new();
        hud.push_info("short", 0.5);
        hud.push_info("long", 5.0);
        hud.push(HudMessage {
            kind: HudMessageKind::Info,
            text: "pinned".into(),
            ttl: None,
        });

        hud.tick(1.0);

        let texts: Vec<_> = hud.messages().map(|m| m.text.as_str()).collect();
        assert_eq!(texts, vec!["long", "pinned"]);
    }

    #[test]
    fn dialogue_helper_tags_kind() {
        let mut hud = HudState::new();
        hud.push_dialogue("hello", 2.0);
        let m = hud.messages().next().unwrap();
        assert_eq!(m.kind, HudMessageKind::Dialogue);
        assert_eq!(m.ttl, Some(2.0));
    }

    #[test]
    fn with_capacity_clamps_zero() {
        let hud = HudState::with_capacity(0);
        // Minimum capacity of 1 is enforced so `push` can never divide
        // by zero or fail the VecDeque contract.
        assert_eq!(hud.capacity, 1);
    }
}

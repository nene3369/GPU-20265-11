/// Holds all wgpu GPU state.
pub struct GpuContext {
    pub instance: wgpu::Instance,
    pub adapter: wgpu::Adapter,
    pub device: wgpu::Device,
    pub queue: wgpu::Queue,
}

impl GpuContext {
    /// Create GpuContext without a surface (headless).
    pub fn new_headless() -> Result<Self, String> {
        pollster::block_on(Self::new_headless_async())
    }

    async fn new_headless_async() -> Result<Self, String> {
        let instance = wgpu::Instance::new(&wgpu::InstanceDescriptor {
            backends: wgpu::Backends::all(),
            ..Default::default()
        });
        let adapter = instance
            .request_adapter(&wgpu::RequestAdapterOptions {
                power_preference: wgpu::PowerPreference::HighPerformance,
                compatible_surface: None,
                force_fallback_adapter: false,
            })
            .await
            .ok_or("No GPU adapter found")?;

        let (device, queue) = adapter
            .request_device(
                &wgpu::DeviceDescriptor {
                    label: Some("ChemEngine Device"),
                    required_features: wgpu::Features::empty(),
                    required_limits: wgpu::Limits::default(),
                    memory_hints: wgpu::MemoryHints::default(),
                },
                None,
            )
            .await
            .map_err(|e| format!("Device request failed: {e}"))?;

        Ok(Self {
            instance,
            adapter,
            device,
            queue,
        })
    }

    /// Read mip-0 of `texture` back to CPU memory as a tightly-packed
    /// pixel buffer.
    ///
    /// # Why this exists
    /// Goldens for GPU-rendered output need a way to get pixels from
    /// a render target into a [`Vec<u8>`] without going through a
    /// surface. This is the bridge: render → `capture_texture` →
    /// `ce_softraster::Framebuffer` → `assert_golden`.
    ///
    /// # Requirements on `texture`
    /// - Must have been created with [`wgpu::TextureUsages::COPY_SRC`].
    /// - Must be `D2`, single-sampled, single-mip, single-layer.
    /// - Format must be one of:
    ///   `Rgba8Unorm`, `Rgba8UnormSrgb`,
    ///   `Bgra8Unorm`, `Bgra8UnormSrgb`,
    ///   `R8Unorm`.
    ///
    /// Other formats (HDR `Rgba16Float`, depth, compressed) need
    /// per-format quantisation and are not yet wired up — they would
    /// quietly produce garbage if reinterpreted as RGBA8, so the
    /// function rejects them explicitly instead.
    ///
    /// # Returns
    /// On success, a [`CapturedTexture`] whose `pixels` field is
    /// `width * height * bytes_per_pixel(format)` bytes long, with
    /// **no row padding** — wgpu's 256-byte row alignment is stripped
    /// internally.
    ///
    /// # Determinism
    /// The capture itself is deterministic (it's a memcpy + map). The
    /// rasterisation that produced the texture may NOT be — driver
    /// floating-point order, MSAA resolve, etc. can drift between
    /// vendors. For tolerance=0 goldens, render with integer maths
    /// and `sample_count: 1`. For tolerance>0 goldens, allow a small
    /// channel delta in `assert_golden`.
    pub fn capture_texture(&self, texture: &wgpu::Texture) -> Result<CapturedTexture, String> {
        let size = texture.size();
        let format = texture.format();

        // Reject anything we can't safely linearise to a flat byte buffer.
        if texture.dimension() != wgpu::TextureDimension::D2 {
            return Err(format!(
                "capture_texture: unsupported dimension {:?} (D2 only)",
                texture.dimension()
            ));
        }
        if texture.sample_count() != 1 {
            return Err(format!(
                "capture_texture: MSAA texture (sample_count={}) — resolve to single-sampled first",
                texture.sample_count()
            ));
        }
        if texture.mip_level_count() != 1 {
            return Err(format!(
                "capture_texture: multi-mip texture ({} mips) — only mip 0 capture is supported",
                texture.mip_level_count()
            ));
        }
        if size.depth_or_array_layers != 1 {
            return Err(format!(
                "capture_texture: array/3D texture ({} layers) — only single-layer supported",
                size.depth_or_array_layers
            ));
        }

        let bytes_per_pixel = bytes_per_pixel_for(format).ok_or_else(|| {
            format!(
                "capture_texture: format {format:?} not supported — extend `bytes_per_pixel_for`"
            )
        })?;

        // wgpu requires `bytes_per_row` in `copy_texture_to_buffer` to be a
        // multiple of 256. Pad the staging buffer accordingly; we strip
        // the padding back out below.
        let unpadded_bytes_per_row = size.width as usize * bytes_per_pixel;
        let align = wgpu::COPY_BYTES_PER_ROW_ALIGNMENT as usize;
        let padded_bytes_per_row = unpadded_bytes_per_row.div_ceil(align) * align;
        let buffer_size = (padded_bytes_per_row * size.height as usize) as u64;

        let staging = self.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("capture_texture staging"),
            size: buffer_size,
            usage: wgpu::BufferUsages::MAP_READ | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        let mut encoder = self
            .device
            .create_command_encoder(&wgpu::CommandEncoderDescriptor {
                label: Some("capture_texture encoder"),
            });
        encoder.copy_texture_to_buffer(
            wgpu::TexelCopyTextureInfo {
                texture,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            wgpu::TexelCopyBufferInfo {
                buffer: &staging,
                layout: wgpu::TexelCopyBufferLayout {
                    offset: 0,
                    bytes_per_row: Some(padded_bytes_per_row as u32),
                    rows_per_image: Some(size.height),
                },
            },
            size,
        );
        self.queue.submit(std::iter::once(encoder.finish()));

        // Same map-and-poll pattern as `ce_compute::wgpu_compute::read_buffer`.
        // `poll(Wait)` blocks until `submit`-ed work has finished, which is
        // what makes the synchronous `recv()` below safe.
        let slice = staging.slice(..);
        let (sender, receiver) = std::sync::mpsc::channel();
        slice.map_async(wgpu::MapMode::Read, move |result| {
            sender.send(result).unwrap();
        });
        self.device.poll(wgpu::Maintain::Wait);
        receiver
            .recv()
            .map_err(|e| format!("capture_texture: map_async channel: {e}"))?
            .map_err(|e| format!("capture_texture: map_async: {e:?}"))?;

        let raw = slice.get_mapped_range();

        // Strip per-row padding so callers see a tightly-packed buffer.
        let mut pixels = Vec::with_capacity(unpadded_bytes_per_row * size.height as usize);
        for row in 0..size.height as usize {
            let start = row * padded_bytes_per_row;
            let end = start + unpadded_bytes_per_row;
            pixels.extend_from_slice(&raw[start..end]);
        }
        drop(raw);
        staging.unmap();

        Ok(CapturedTexture {
            width: size.width,
            height: size.height,
            format,
            pixels,
        })
    }
}

/// Result of a successful [`GpuContext::capture_texture`] call.
///
/// `pixels` is tightly packed — `width * height * bytes_per_pixel(format)`
/// bytes long, no row padding.
#[derive(Debug, Clone)]
pub struct CapturedTexture {
    pub width: u32,
    pub height: u32,
    pub format: wgpu::TextureFormat,
    pub pixels: Vec<u8>,
}

impl CapturedTexture {
    /// `(width, height, bytes_per_pixel)` — handy for callers feeding
    /// the buffer into image libraries.
    pub fn dims(&self) -> (u32, u32, usize) {
        // Unwrap is safe: format passed `bytes_per_pixel_for` during capture.
        (
            self.width,
            self.height,
            bytes_per_pixel_for(self.format).expect("captured format must be known"),
        )
    }
}

/// Bytes per pixel for the formats `capture_texture` supports.
///
/// This is the **gatekeeper** for which formats are safe to capture —
/// adding a new entry is the only thing needed to extend support
/// for any other linear, single-aspect, uncompressed format. Returns
/// `None` for formats that need per-format decoding (HDR float, depth,
/// stencil, BCn, ASTC, ETC, etc.).
fn bytes_per_pixel_for(format: wgpu::TextureFormat) -> Option<usize> {
    use wgpu::TextureFormat as F;
    match format {
        F::R8Unorm | F::R8Snorm | F::R8Uint | F::R8Sint => Some(1),
        F::Rgba8Unorm
        | F::Rgba8UnormSrgb
        | F::Rgba8Snorm
        | F::Rgba8Uint
        | F::Rgba8Sint
        | F::Bgra8Unorm
        | F::Bgra8UnormSrgb => Some(4),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Build a 4×4 RGBA8 texture, write a known pattern, copy back, and
    /// check round-trip integrity.
    ///
    /// The pattern uses `(x*16 + y) as the red channel so we can spot
    /// the difference between row-padding stripped correctly vs. dropped
    /// rows or shifted columns: any off-by-row error would scramble the
    /// red ramp in a visually obvious way (and an exact-byte way here).
    #[test]
    fn capture_texture_round_trips_rgba8() {
        let Ok(ctx) = GpuContext::new_headless() else {
            // CI without a GPU adapter: skip rather than fail.
            // The self-hosted RTX 4060 Ti runner does have one, so this
            // still exercises the path on the runner.
            eprintln!("skipping capture_texture_round_trips_rgba8: no GPU adapter");
            return;
        };

        const W: u32 = 4;
        const H: u32 = 4;
        let mut expected = Vec::with_capacity((W * H * 4) as usize);
        for y in 0..H {
            for x in 0..W {
                expected.push((x * 16 + y) as u8); // R
                expected.push(255 - x as u8); // G
                expected.push(y as u8 * 32); // B
                expected.push(255); // A
            }
        }

        let texture = ctx.device.create_texture(&wgpu::TextureDescriptor {
            label: Some("capture_round_trip src"),
            size: wgpu::Extent3d {
                width: W,
                height: H,
                depth_or_array_layers: 1,
            },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Rgba8Unorm,
            usage: wgpu::TextureUsages::COPY_DST | wgpu::TextureUsages::COPY_SRC,
            view_formats: &[],
        });

        ctx.queue.write_texture(
            wgpu::TexelCopyTextureInfo {
                texture: &texture,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            &expected,
            wgpu::TexelCopyBufferLayout {
                offset: 0,
                bytes_per_row: Some(W * 4),
                rows_per_image: Some(H),
            },
            wgpu::Extent3d {
                width: W,
                height: H,
                depth_or_array_layers: 1,
            },
        );

        let captured = ctx
            .capture_texture(&texture)
            .expect("capture_texture should succeed for a vanilla Rgba8Unorm src");

        assert_eq!(captured.width, W);
        assert_eq!(captured.height, H);
        assert_eq!(captured.pixels.len(), (W * H * 4) as usize);
        assert_eq!(
            captured.pixels, expected,
            "round-trip pixels diverge — row-padding strip is probably wrong"
        );
    }

    /// MSAA / 3D / array textures must be rejected explicitly rather
    /// than silently producing garbage.
    #[test]
    fn capture_texture_rejects_unsupported_shapes() {
        let Ok(ctx) = GpuContext::new_headless() else {
            eprintln!("skipping capture_texture_rejects_unsupported_shapes: no GPU adapter");
            return;
        };

        // Multi-sample (MSAA) — must reject.
        let msaa = ctx.device.create_texture(&wgpu::TextureDescriptor {
            label: Some("reject_msaa"),
            size: wgpu::Extent3d {
                width: 4,
                height: 4,
                depth_or_array_layers: 1,
            },
            mip_level_count: 1,
            sample_count: 4,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Rgba8Unorm,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::COPY_SRC,
            view_formats: &[],
        });
        assert!(
            ctx.capture_texture(&msaa)
                .is_err_and(|e| e.contains("MSAA")),
            "MSAA capture should fail with a clear error"
        );

        // Array layer — must reject.
        let arr = ctx.device.create_texture(&wgpu::TextureDescriptor {
            label: Some("reject_array"),
            size: wgpu::Extent3d {
                width: 4,
                height: 4,
                depth_or_array_layers: 2,
            },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Rgba8Unorm,
            usage: wgpu::TextureUsages::COPY_SRC,
            view_formats: &[],
        });
        assert!(
            ctx.capture_texture(&arr)
                .is_err_and(|e| e.contains("array") || e.contains("layer")),
            "array texture capture should fail with a clear error"
        );
    }
}

//! `ce_chronicle` — append-only event log for the self-evolving world.
//!
//! Every gameplay-significant moment (a kill, a station falling, a
//! mission closing, a pulse shift) gets a [`WorldEvent`] pushed into a
//! [`Chronicle`]. The chronicle is what lets the player walk back in
//! after a week offline and read "the war happened here, and here",
//! and it's the substrate the worldbuilder / time-scrub layers will
//! sit on later.
//!
//! Design:
//! - **Append-only** — events are never rewritten, only appended.
//!   Offline catch-up dumps its synthetic events the same way a live
//!   tick would.
//! - **Ring buffer** — the in-memory `Chronicle` caps at `capacity`
//!   events; the full history lives on disk via `serialize_text` /
//!   `deserialize_text`. Callers that want unbounded history persist
//!   every push.
//! - **Serialisation is a plain text format** — one event per line,
//!   tab-separated. Human-readable so save debugging is trivial, and
//!   forward-compatible: unknown kind tags decode to `Unknown` rather
//!   than erroring.
//! - **Faction IDs are stored as strings** — the underlying
//!   `FactionId` is an interned `&'static str`, so text round-trips
//!   without a symbol table.

#![forbid(unsafe_code)]

use std::collections::VecDeque;

use ce_app::{App, Plugin};
use ce_faction::FactionId;

/// Something that happened in the world. `timestamp_seconds` is a
/// `WorldClock.epoch_seconds` reading — monotonic, never wraps on a
/// day boundary.
#[derive(Debug, Clone, PartialEq)]
pub struct WorldEvent {
    pub timestamp_seconds: f64,
    pub kind: EventKind,
}

/// The category of a recorded event. Variants carry only the data the
/// scrubber / HUD needs — full entity references are reconstructed at
/// read time from their string labels if needed.
#[derive(Debug, Clone, PartialEq)]
pub enum EventKind {
    /// First-ever emission in a save — marks the seed the world grew
    /// from. Useful for "tell me the story of seed X" playback.
    WorldBorn { seed: u64 },
    /// Offline catch-up fast-forwarded the clock from `from` to `to`.
    /// `capped` is true when the real-time delta exceeded the cap and
    /// we truncated.
    EpochSkipped { from: f64, to: f64, capped: bool },
    /// An NPC / player was destroyed. Player kills use
    /// `killer = FactionId::new("player")`.
    Kill {
        killer: FactionId,
        victim: FactionId,
    },
    /// A faction stronghold reached zero hull.
    BaseDestroyed { name: String, faction: FactionId },
    /// A faction stronghold's rebuild timer elapsed and it's back in
    /// play.
    BaseRebuilt { name: String, faction: FactionId },
    /// A station posted a new contract on its board.
    MissionPosted {
        id: u64,
        kind_label: String,
        issuer: FactionId,
    },
    /// A player mission reached Completed — reward already paid by
    /// gameplay code.
    MissionCompleted {
        id: u64,
        by_player: bool,
        reward_credits: i64,
    },
    /// A player mission rolled over its deadline.
    MissionFailed { id: u64 },
    /// A trade closed (player or NPC-to-NPC). `value_credits` is the
    /// net credits moved; sign depends on caller convention.
    Trade { value_credits: i64 },
    /// WorldPulse moved by more than `PULSE_SHIFT_EPSILON` in at least
    /// one axis this tick. Recorded so the history has a coarse
    /// "mood changed" marker without drowning in per-tick noise.
    PulseShift {
        tension: f32,
        market_mood: f32,
        security: f32,
    },
    /// Unknown text tag encountered during `deserialize_text`. Kept so
    /// forward-compat loads don't lose history — the display layer
    /// renders it as `?{tag}`.
    Unknown { raw: String },
}

/// Minimum WorldPulse delta (per-axis, absolute) to emit a
/// `PulseShift` event. Smaller moves are noise; larger ones are
/// "something tipped".
pub const PULSE_SHIFT_EPSILON: f32 = 0.15;

/// Ring-buffer chronicle. Acts as the in-memory HUD slice and the
/// source of serialisation. The disk image is the full history; the
/// ring only caps how much survives in-process memory at once.
#[derive(Debug, Clone)]
pub struct Chronicle {
    events: VecDeque<WorldEvent>,
    capacity: usize,
}

impl Default for Chronicle {
    /// 256 in-memory events — enough for an hour of heavy play
    /// without dropping anything noticeable.
    fn default() -> Self {
        Self::new(256)
    }
}

impl Chronicle {
    pub fn new(capacity: usize) -> Self {
        Self {
            events: VecDeque::with_capacity(capacity.max(1)),
            capacity: capacity.max(1),
        }
    }

    /// Append one event, dropping the oldest to stay within capacity.
    pub fn push(&mut self, event: WorldEvent) {
        if self.events.len() == self.capacity {
            self.events.pop_front();
        }
        self.events.push_back(event);
    }

    /// Slice of the most recent `n` events, newest-last.
    pub fn recent(&self, n: usize) -> Vec<&WorldEvent> {
        let skip = self.events.len().saturating_sub(n);
        self.events.iter().skip(skip).collect()
    }

    pub fn iter(&self) -> impl Iterator<Item = &WorldEvent> {
        self.events.iter()
    }

    pub fn len(&self) -> usize {
        self.events.len()
    }

    pub fn is_empty(&self) -> bool {
        self.events.is_empty()
    }

    pub fn capacity(&self) -> usize {
        self.capacity
    }

    pub fn clear(&mut self) {
        self.events.clear();
    }
}

/// Serialise a chronicle to text — one event per line. Lines use
/// tab-separated fields; the first field is always `timestamp kind_tag`,
/// the rest are kind-specific.
pub fn serialize_text(chronicle: &Chronicle) -> String {
    let mut out = String::new();
    for ev in chronicle.iter() {
        write_event(&mut out, ev);
        out.push('\n');
    }
    out
}

/// Parse a chronicle from the text produced by `serialize_text`.
/// Malformed lines are swallowed (logged at debug) so a partially
/// corrupted file still restores what it can.
pub fn deserialize_text(text: &str, capacity: usize) -> Chronicle {
    let mut c = Chronicle::new(capacity);
    for line in text.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        match parse_event(line) {
            Some(ev) => c.push(ev),
            None => log::debug!("chronicle: skipped malformed line: {line}"),
        }
    }
    c
}

fn write_event(out: &mut String, ev: &WorldEvent) {
    use std::fmt::Write as _;
    let ts = ev.timestamp_seconds;
    match &ev.kind {
        EventKind::WorldBorn { seed } => {
            let _ = write!(out, "{ts}\tworld_born\t{seed}");
        }
        EventKind::EpochSkipped { from, to, capped } => {
            let _ = write!(
                out,
                "{ts}\tepoch_skipped\t{from}\t{to}\t{}",
                if *capped { 1 } else { 0 }
            );
        }
        EventKind::Kill { killer, victim } => {
            let _ = write!(out, "{ts}\tkill\t{}\t{}", killer.as_str(), victim.as_str());
        }
        EventKind::BaseDestroyed { name, faction } => {
            let _ = write!(
                out,
                "{ts}\tbase_destroyed\t{}\t{}",
                escape(name),
                faction.as_str()
            );
        }
        EventKind::BaseRebuilt { name, faction } => {
            let _ = write!(
                out,
                "{ts}\tbase_rebuilt\t{}\t{}",
                escape(name),
                faction.as_str()
            );
        }
        EventKind::MissionPosted {
            id,
            kind_label,
            issuer,
        } => {
            let _ = write!(
                out,
                "{ts}\tmission_posted\t{id}\t{}\t{}",
                escape(kind_label),
                issuer.as_str()
            );
        }
        EventKind::MissionCompleted {
            id,
            by_player,
            reward_credits,
        } => {
            let _ = write!(
                out,
                "{ts}\tmission_completed\t{id}\t{}\t{reward_credits}",
                if *by_player { 1 } else { 0 }
            );
        }
        EventKind::MissionFailed { id } => {
            let _ = write!(out, "{ts}\tmission_failed\t{id}");
        }
        EventKind::Trade { value_credits } => {
            let _ = write!(out, "{ts}\ttrade\t{value_credits}");
        }
        EventKind::PulseShift {
            tension,
            market_mood,
            security,
        } => {
            let _ = write!(
                out,
                "{ts}\tpulse_shift\t{tension}\t{market_mood}\t{security}"
            );
        }
        EventKind::Unknown { raw } => {
            // Round-trip the raw payload so we don't corrupt history
            // on reserialize.
            let _ = write!(out, "{ts}\tunknown\t{}", escape(raw));
        }
    }
}

fn parse_event(line: &str) -> Option<WorldEvent> {
    let mut parts = line.split('\t');
    let ts: f64 = parts.next()?.parse().ok()?;
    let tag = parts.next()?;
    let kind = match tag {
        "world_born" => {
            let seed = parts.next()?.parse().ok()?;
            EventKind::WorldBorn { seed }
        }
        "epoch_skipped" => {
            let from = parts.next()?.parse().ok()?;
            let to = parts.next()?.parse().ok()?;
            let capped = parts.next()?.parse::<u32>().ok()? != 0;
            EventKind::EpochSkipped { from, to, capped }
        }
        "kill" => {
            let killer = FactionId::new(intern_static(parts.next()?));
            let victim = FactionId::new(intern_static(parts.next()?));
            EventKind::Kill { killer, victim }
        }
        "base_destroyed" => {
            let name = unescape(parts.next()?);
            let faction = FactionId::new(intern_static(parts.next()?));
            EventKind::BaseDestroyed { name, faction }
        }
        "base_rebuilt" => {
            let name = unescape(parts.next()?);
            let faction = FactionId::new(intern_static(parts.next()?));
            EventKind::BaseRebuilt { name, faction }
        }
        "mission_posted" => {
            let id = parts.next()?.parse().ok()?;
            let kind_label = unescape(parts.next()?);
            let issuer = FactionId::new(intern_static(parts.next()?));
            EventKind::MissionPosted {
                id,
                kind_label,
                issuer,
            }
        }
        "mission_completed" => {
            let id = parts.next()?.parse().ok()?;
            let by_player = parts.next()?.parse::<u32>().ok()? != 0;
            let reward_credits = parts.next()?.parse().ok()?;
            EventKind::MissionCompleted {
                id,
                by_player,
                reward_credits,
            }
        }
        "mission_failed" => {
            let id = parts.next()?.parse().ok()?;
            EventKind::MissionFailed { id }
        }
        "trade" => {
            let value_credits = parts.next()?.parse().ok()?;
            EventKind::Trade { value_credits }
        }
        "pulse_shift" => {
            let tension = parts.next()?.parse().ok()?;
            let market_mood = parts.next()?.parse().ok()?;
            let security = parts.next()?.parse().ok()?;
            EventKind::PulseShift {
                tension,
                market_mood,
                security,
            }
        }
        other => EventKind::Unknown {
            raw: format!("{other}:{}", parts.collect::<Vec<_>>().join("\t")),
        },
    };
    Some(WorldEvent {
        timestamp_seconds: ts,
        kind,
    })
}

/// Tabs, newlines, and backslashes get escaped so they never confuse
/// the line/field parser. Everything else is passed through.
fn escape(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for c in s.chars() {
        match c {
            '\\' => out.push_str("\\\\"),
            '\t' => out.push_str("\\t"),
            '\n' => out.push_str("\\n"),
            other => out.push(other),
        }
    }
    out
}

fn unescape(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut chars = s.chars();
    while let Some(c) = chars.next() {
        if c != '\\' {
            out.push(c);
            continue;
        }
        match chars.next() {
            Some('\\') => out.push('\\'),
            Some('t') => out.push('\t'),
            Some('n') => out.push('\n'),
            Some(other) => {
                out.push('\\');
                out.push(other);
            }
            None => out.push('\\'),
        }
    }
    out
}

/// Intern a runtime string to a `'static` one so it can become a
/// `FactionId`. `FactionId::new` is `const` and takes `&'static str`;
/// chronicle lines can carry arbitrary faction labels (including ones
/// from procgen factions in future worlds), so we leak into a static
/// lifetime on first sight. The leak is bounded by the faction
/// vocabulary a save contains — tens to a few hundred at worst —
/// and is simpler than threading a faction intern table through
/// every call site.
fn intern_static(s: &str) -> &'static str {
    Box::leak(s.to_owned().into_boxed_str())
}

/// Installs an empty [`Chronicle`] resource on the app.
pub struct ChroniclePlugin;

impl Plugin for ChroniclePlugin {
    fn build(&self, app: &mut App) {
        if app.world.get_resource::<Chronicle>().is_none() {
            app.insert_resource(Chronicle::default());
        }
        log::info!("ChroniclePlugin loaded");
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const ALPHA: FactionId = FactionId::new("alpha");
    const BETA: FactionId = FactionId::new("beta");

    fn sample() -> Chronicle {
        let mut c = Chronicle::new(128);
        c.push(WorldEvent {
            timestamp_seconds: 0.0,
            kind: EventKind::WorldBorn { seed: 42 },
        });
        c.push(WorldEvent {
            timestamp_seconds: 10.0,
            kind: EventKind::Kill {
                killer: ALPHA,
                victim: BETA,
            },
        });
        c.push(WorldEvent {
            timestamp_seconds: 11.5,
            kind: EventKind::BaseDestroyed {
                name: "Reaver's Nest".to_string(),
                faction: BETA,
            },
        });
        c.push(WorldEvent {
            timestamp_seconds: 42.0,
            kind: EventKind::MissionCompleted {
                id: 9,
                by_player: true,
                reward_credits: 12_000,
            },
        });
        c
    }

    #[test]
    fn ring_buffer_drops_oldest() {
        let mut c = Chronicle::new(2);
        for i in 0..5 {
            c.push(WorldEvent {
                timestamp_seconds: i as f64,
                kind: EventKind::MissionFailed { id: i },
            });
        }
        assert_eq!(c.len(), 2);
        let tops: Vec<f64> = c.iter().map(|e| e.timestamp_seconds).collect();
        assert_eq!(tops, vec![3.0, 4.0]);
    }

    #[test]
    fn recent_returns_newest_last() {
        let c = sample();
        let r = c.recent(2);
        assert_eq!(r.len(), 2);
        assert_eq!(r[0].timestamp_seconds, 11.5);
        assert_eq!(r[1].timestamp_seconds, 42.0);
    }

    #[test]
    fn serialize_round_trips() {
        let c = sample();
        let text = serialize_text(&c);
        let restored = deserialize_text(&text, 128);
        assert_eq!(restored.len(), c.len());
        let orig: Vec<_> = c.iter().collect();
        let back: Vec<_> = restored.iter().collect();
        for (a, b) in orig.iter().zip(back.iter()) {
            assert_eq!(a.timestamp_seconds, b.timestamp_seconds);
            assert_eq!(a.kind, b.kind);
        }
    }

    #[test]
    fn unknown_tag_preserved() {
        let line = "5.5\tfuture_event\tcolor=blue\tweight=3";
        let c = deserialize_text(line, 16);
        assert_eq!(c.len(), 1);
        let events: Vec<_> = c.iter().collect();
        match &events[0].kind {
            EventKind::Unknown { raw } => {
                assert!(raw.contains("color=blue"));
            }
            other => panic!("expected Unknown, got {other:?}"),
        }
    }

    #[test]
    fn malformed_lines_are_skipped() {
        let text = "not-a-number\tkill\tx\ty\n\
                    10.0\tkill\tx\ty\n";
        let c = deserialize_text(text, 16);
        // First line drops, second survives.
        assert_eq!(c.len(), 1);
    }

    #[test]
    fn escapes_tab_in_name() {
        let mut c = Chronicle::new(4);
        c.push(WorldEvent {
            timestamp_seconds: 1.0,
            kind: EventKind::BaseDestroyed {
                name: "weird\tname\nhere".to_string(),
                faction: ALPHA,
            },
        });
        let text = serialize_text(&c);
        let back = deserialize_text(&text, 4);
        assert_eq!(back.len(), 1);
        let events: Vec<_> = back.iter().collect();
        match &events[0].kind {
            EventKind::BaseDestroyed { name, .. } => assert_eq!(name, "weird\tname\nhere"),
            _ => panic!(),
        }
    }

    #[test]
    fn clear_empties_buffer() {
        let mut c = sample();
        assert!(!c.is_empty());
        c.clear();
        assert!(c.is_empty());
    }

    #[test]
    fn epoch_skipped_round_trips_with_capped_flag() {
        let mut c = Chronicle::new(4);
        c.push(WorldEvent {
            timestamp_seconds: 100.0,
            kind: EventKind::EpochSkipped {
                from: 0.0,
                to: 86_400.0,
                capped: true,
            },
        });
        let text = serialize_text(&c);
        let back = deserialize_text(&text, 4);
        let events: Vec<_> = back.iter().collect();
        match &events[0].kind {
            EventKind::EpochSkipped { capped, to, .. } => {
                assert!(*capped);
                assert!((to - 86_400.0).abs() < 1e-6);
            }
            _ => panic!(),
        }
    }

    #[test]
    fn plugin_installs_chronicle() {
        let mut app = App::new();
        app.add_plugin(ChroniclePlugin);
        assert!(app.world.get_resource::<Chronicle>().is_some());
    }
}

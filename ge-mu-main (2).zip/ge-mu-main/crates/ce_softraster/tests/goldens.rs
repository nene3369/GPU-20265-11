//! Golden-image regression tests for procedurally generated meshes.
//!
//! These exist so an agent without a display can detect visual
//! regressions automatically. Each test:
//!   1. Builds a deterministic mesh from `ce_mesh_gen`.
//!   2. Rasterises it via the CPU renderer at a fixed camera.
//!   3. Compares against a committed PPM under `tests/goldens/`.
//!
//! If the generator output intentionally changes, re-run with
//! `UPDATE_GOLDENS=1` to refresh the baselines.

use std::path::PathBuf;

use ce_math::{Mat4, Vec3};
use ce_mesh_gen::{build_asteroid, build_planet_mesh};
use ce_softraster::{assert_golden, render_mesh, Framebuffer};

const SIZE: u32 = 64;
const TOLERANCE: u8 = 1;

fn goldens_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("tests")
        .join("goldens")
}

fn orthographic() -> Mat4 {
    // Fits roughly a unit-radius object centred on origin into NDC.
    // Mirrors what we'd get with scale 0.5 + look-at from +Z.
    Mat4::from_scale(Vec3::splat(0.55))
}

#[test]
fn golden_planet_sphere() {
    let mesh = build_planet_mesh(None, 16);
    let mut fb = Framebuffer::new(SIZE, SIZE);
    let drawn = render_mesh(&mesh, orthographic(), &mut fb);
    assert!(drawn > 0, "expected at least one planet triangle to draw");
    assert_golden(&fb, goldens_dir().join("planet_sphere.ppm"), TOLERANCE).unwrap();
}

#[test]
fn golden_asteroid() {
    let mesh = build_asteroid(0xA57E_0001, 1.0, 0.3, 8);
    let mut fb = Framebuffer::new(SIZE, SIZE);
    let drawn = render_mesh(&mesh, orthographic(), &mut fb);
    assert!(drawn > 0, "expected at least one asteroid triangle to draw");
    assert_golden(&fb, goldens_dir().join("asteroid.ppm"), TOLERANCE).unwrap();
}

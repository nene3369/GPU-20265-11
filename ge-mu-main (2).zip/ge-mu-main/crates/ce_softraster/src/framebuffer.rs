//! RGBA colour + depth framebuffer.

/// Packed RGBA pixel buffer + float depth buffer.
#[derive(Debug, Clone)]
pub struct Framebuffer {
    pub width: u32,
    pub height: u32,
    /// Row-major RGBA8. Length = width * height * 4.
    pixels: Vec<u8>,
    /// Row-major depth. `1.0` = clear (far), `0.0` = near.
    depth: Vec<f32>,
}

impl Framebuffer {
    pub fn new(width: u32, height: u32) -> Self {
        let px = (width as usize) * (height as usize);
        Self {
            width,
            height,
            pixels: vec![0; px * 4],
            depth: vec![1.0; px],
        }
    }

    /// Fills the colour buffer with `rgba` and resets depth to 1.0.
    pub fn clear(&mut self, rgba: [u8; 4]) {
        for chunk in self.pixels.chunks_exact_mut(4) {
            chunk.copy_from_slice(&rgba);
        }
        for d in self.depth.iter_mut() {
            *d = 1.0;
        }
    }

    #[inline]
    fn index(&self, x: u32, y: u32) -> usize {
        (y as usize) * (self.width as usize) + (x as usize)
    }

    /// Writes one pixel. Silently no-ops on out-of-range coords.
    pub fn set_pixel(&mut self, x: u32, y: u32, rgba: [u8; 4]) {
        if x >= self.width || y >= self.height {
            return;
        }
        let i = self.index(x, y) * 4;
        self.pixels[i..i + 4].copy_from_slice(&rgba);
    }

    /// Writes a pixel only if its depth is closer than what's already
    /// in the Z-buffer. Returns `true` when the write landed.
    pub fn set_pixel_z(&mut self, x: u32, y: u32, z: f32, rgba: [u8; 4]) -> bool {
        if x >= self.width || y >= self.height {
            return false;
        }
        let i = self.index(x, y);
        if z < self.depth[i] {
            self.depth[i] = z;
            let p = i * 4;
            self.pixels[p..p + 4].copy_from_slice(&rgba);
            true
        } else {
            false
        }
    }

    pub fn pixels(&self) -> &[u8] {
        &self.pixels
    }

    pub fn depth(&self) -> &[f32] {
        &self.depth
    }

    /// Counts pixels whose RGB matches `rgb` exactly. Handy for tests.
    pub fn count_pixels_rgb(&self, rgb: [u8; 3]) -> u32 {
        let mut count = 0;
        for px in self.pixels.chunks_exact(4) {
            if px[0] == rgb[0] && px[1] == rgb[1] && px[2] == rgb[2] {
                count += 1;
            }
        }
        count
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn new_framebuffer_is_black_and_far() {
        let fb = Framebuffer::new(8, 4);
        assert!(fb.pixels().iter().all(|&b| b == 0));
        assert!(fb.depth().iter().all(|&d| (d - 1.0).abs() < f32::EPSILON));
    }

    #[test]
    fn clear_sets_all_pixels() {
        let mut fb = Framebuffer::new(4, 4);
        fb.clear([255, 128, 64, 255]);
        assert_eq!(fb.count_pixels_rgb([255, 128, 64]), 16);
    }

    #[test]
    fn set_pixel_respects_bounds() {
        let mut fb = Framebuffer::new(2, 2);
        fb.set_pixel(10, 10, [255; 4]); // out of range — no panic
        assert_eq!(fb.count_pixels_rgb([255, 255, 255]), 0);
        fb.set_pixel(0, 0, [255; 4]);
        assert_eq!(fb.count_pixels_rgb([255, 255, 255]), 1);
    }

    #[test]
    fn z_buffer_rejects_farther_writes() {
        let mut fb = Framebuffer::new(2, 2);
        assert!(fb.set_pixel_z(0, 0, 0.5, [255, 0, 0, 255]));
        // Farther write is rejected.
        assert!(!fb.set_pixel_z(0, 0, 0.8, [0, 255, 0, 255]));
        assert_eq!(fb.count_pixels_rgb([255, 0, 0]), 1);
        // Closer write wins.
        assert!(fb.set_pixel_z(0, 0, 0.1, [0, 0, 255, 255]));
        assert_eq!(fb.count_pixels_rgb([0, 0, 255]), 1);
    }
}

//! Golden-image regression tests.
//!
//! Soft-raster output + PPM round-trip makes it cheap to commit a
//! known-good reference frame, then assert future runs reproduce it
//! byte-for-byte (or within a small tolerance). This is the primary
//! way an agent without a display can detect visual regressions.
//!
//! Workflow:
//!   1. Write a test that renders a scene into a [`Framebuffer`].
//!   2. Call [`assert_golden(&fb, "tests/goldens/foo.ppm")`].
//!   3. First run (file missing) fails with a clear message. Re-run
//!      with `UPDATE_GOLDENS=1` to write the baseline, then commit it.
//!   4. Subsequent runs diff the rendered frame against the baseline
//!      and fail on drift; on failure an `*.actual.ppm` is written
//!      next to the golden for inspection.

use std::io;
use std::path::{Path, PathBuf};

use crate::framebuffer::Framebuffer;
use crate::ppm::save_ppm;

/// Per-pixel differences between two equally-sized framebuffers.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct DiffStats {
    /// Pixels where at least one channel (R/G/B) differs at all.
    pub differing_pixels: u32,
    /// Maximum absolute per-channel difference seen.
    pub max_channel_delta: u8,
    /// Total number of pixels compared.
    pub total_pixels: u32,
}

impl DiffStats {
    pub fn is_identical(self) -> bool {
        self.differing_pixels == 0
    }
}

/// Loads a P6 PPM file into a [`Framebuffer`]. Alpha channel is set
/// to 255 (PPM is RGB-only).
pub fn load_ppm(path: impl AsRef<Path>) -> io::Result<Framebuffer> {
    let bytes = std::fs::read(path)?;
    parse_ppm(&bytes)
}

fn parse_ppm(bytes: &[u8]) -> io::Result<Framebuffer> {
    // Header: "P6\n<w> <h>\n<maxval>\n<payload>". PPM allows comments
    // (lines starting with '#') and extra whitespace; we handle the
    // minimal form our own `save_ppm` writes, which is enough.
    let mut cursor = 0usize;
    let tag = read_token(bytes, &mut cursor)?;
    if tag != b"P6" {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!("not a P6 PPM (tag={:?})", String::from_utf8_lossy(&tag)),
        ));
    }
    let w: u32 = parse_number(&read_token(bytes, &mut cursor)?)?;
    let h: u32 = parse_number(&read_token(bytes, &mut cursor)?)?;
    let maxval: u32 = parse_number(&read_token(bytes, &mut cursor)?)?;
    if maxval != 255 {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!("only 8-bit PPM supported, got maxval={maxval}"),
        ));
    }
    // Skip exactly one whitespace byte after maxval token (per spec).
    if cursor < bytes.len() && is_ws(bytes[cursor]) {
        cursor += 1;
    }
    let expected = (w as usize) * (h as usize) * 3;
    if bytes.len() - cursor < expected {
        return Err(io::Error::new(
            io::ErrorKind::UnexpectedEof,
            format!(
                "PPM payload truncated: need {expected}, have {}",
                bytes.len() - cursor
            ),
        ));
    }
    let mut fb = Framebuffer::new(w, h);
    let payload = &bytes[cursor..cursor + expected];
    // Copy RGB → RGBA.
    for (i, rgb) in payload.chunks_exact(3).enumerate() {
        let x = (i as u32) % w;
        let y = (i as u32) / w;
        fb.set_pixel(x, y, [rgb[0], rgb[1], rgb[2], 255]);
    }
    Ok(fb)
}

fn is_ws(b: u8) -> bool {
    matches!(b, b' ' | b'\t' | b'\n' | b'\r')
}

fn read_token(bytes: &[u8], cursor: &mut usize) -> io::Result<Vec<u8>> {
    // Skip whitespace + comments.
    loop {
        while *cursor < bytes.len() && is_ws(bytes[*cursor]) {
            *cursor += 1;
        }
        if *cursor < bytes.len() && bytes[*cursor] == b'#' {
            while *cursor < bytes.len() && bytes[*cursor] != b'\n' {
                *cursor += 1;
            }
        } else {
            break;
        }
    }
    let start = *cursor;
    while *cursor < bytes.len() && !is_ws(bytes[*cursor]) {
        *cursor += 1;
    }
    if start == *cursor {
        return Err(io::Error::new(
            io::ErrorKind::UnexpectedEof,
            "PPM header token missing",
        ));
    }
    Ok(bytes[start..*cursor].to_vec())
}

fn parse_number(token: &[u8]) -> io::Result<u32> {
    std::str::from_utf8(token)
        .ok()
        .and_then(|s| s.parse().ok())
        .ok_or_else(|| {
            io::Error::new(
                io::ErrorKind::InvalidData,
                format!(
                    "PPM header expected integer, got {:?}",
                    String::from_utf8_lossy(token)
                ),
            )
        })
}

/// Compares `a` and `b` pixel-by-pixel. RGB only; alpha is ignored
/// since PPM does not store it.
pub fn diff(a: &Framebuffer, b: &Framebuffer) -> DiffStats {
    assert_eq!(a.width, b.width, "framebuffer widths differ");
    assert_eq!(a.height, b.height, "framebuffer heights differ");
    let mut differing = 0u32;
    let mut max_delta = 0u8;
    for (pa, pb) in a.pixels().chunks_exact(4).zip(b.pixels().chunks_exact(4)) {
        let dr = pa[0].abs_diff(pb[0]);
        let dg = pa[1].abs_diff(pb[1]);
        let db = pa[2].abs_diff(pb[2]);
        let m = dr.max(dg).max(db);
        if m > 0 {
            differing += 1;
        }
        if m > max_delta {
            max_delta = m;
        }
    }
    DiffStats {
        differing_pixels: differing,
        max_channel_delta: max_delta,
        total_pixels: a.width * a.height,
    }
}

/// Asserts that `actual` matches the PPM committed at `golden_path`.
///
/// Behaviour:
/// - If `UPDATE_GOLDENS=1` is set in the environment, the golden is
///   (re)written and the assertion succeeds.
/// - If the golden file is missing, the test fails with a message
///   pointing at `UPDATE_GOLDENS=1`.
/// - On mismatch (any channel differs by more than `tolerance`), the
///   actual frame is written alongside as `<stem>.actual.ppm` for
///   visual inspection, and the test fails with diff stats.
pub fn assert_golden(
    actual: &Framebuffer,
    golden_path: impl AsRef<Path>,
    tolerance: u8,
) -> io::Result<()> {
    let golden_path = golden_path.as_ref();

    if std::env::var_os("UPDATE_GOLDENS").is_some() {
        if let Some(parent) = golden_path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        save_ppm(actual, golden_path)?;
        return Ok(());
    }

    if !golden_path.exists() {
        return Err(io::Error::new(
            io::ErrorKind::NotFound,
            format!(
                "golden missing: {}. Run with UPDATE_GOLDENS=1 to create it.",
                golden_path.display()
            ),
        ));
    }

    let golden = load_ppm(golden_path)?;
    if golden.width != actual.width || golden.height != actual.height {
        write_actual_next_to(actual, golden_path)?;
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!(
                "size mismatch: golden {}x{}, actual {}x{}",
                golden.width, golden.height, actual.width, actual.height
            ),
        ));
    }
    let stats = diff(&golden, actual);
    if stats.max_channel_delta > tolerance {
        let actual_path = write_actual_next_to(actual, golden_path)?;
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!(
                "golden mismatch: {} of {} pixels differ, max channel Δ={} (tolerance={}). \
                 Wrote actual frame to {}.",
                stats.differing_pixels,
                stats.total_pixels,
                stats.max_channel_delta,
                tolerance,
                actual_path.display()
            ),
        ));
    }
    Ok(())
}

fn write_actual_next_to(actual: &Framebuffer, golden_path: &Path) -> io::Result<PathBuf> {
    let stem = golden_path
        .file_stem()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_else(|| "golden".into());
    let mut actual_path = golden_path.to_path_buf();
    actual_path.set_file_name(format!("{stem}.actual.ppm"));
    save_ppm(actual, &actual_path)?;
    Ok(actual_path)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_fb(rgba: [u8; 4]) -> Framebuffer {
        let mut fb = Framebuffer::new(3, 2);
        fb.clear(rgba);
        fb
    }

    #[test]
    fn round_trip_save_and_load_preserves_rgb() {
        let fb = make_fb([10, 200, 50, 255]);
        let dir = std::env::temp_dir();
        let path = dir.join(format!("golden_roundtrip_{}.ppm", std::process::id()));
        save_ppm(&fb, &path).unwrap();
        let loaded = load_ppm(&path).unwrap();
        assert_eq!(loaded.width, fb.width);
        assert_eq!(loaded.height, fb.height);
        assert!(diff(&fb, &loaded).is_identical());
        let _ = std::fs::remove_file(&path);
    }

    #[test]
    fn diff_detects_channel_delta() {
        let a = make_fb([100, 100, 100, 255]);
        let mut b = a.clone();
        b.set_pixel(1, 1, [100, 100, 110, 255]);
        let s = diff(&a, &b);
        assert_eq!(s.differing_pixels, 1);
        assert_eq!(s.max_channel_delta, 10);
    }

    // Env-var mutation is process-global, so the three behaviours that
    // depend on UPDATE_GOLDENS are exercised by one sequential test to
    // avoid races with cargo's parallel test runner.
    #[test]
    fn assert_golden_env_modes() {
        let nonce = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let base = std::env::temp_dir().join(format!("golden_env_{}_{nonce}", std::process::id()));

        // --- Mode 1: missing file without UPDATE_GOLDENS fails with NotFound. ---
        let path_missing = base.with_extension("missing.ppm");
        // SAFETY: this test is the only one in the crate that touches
        // UPDATE_GOLDENS, and it runs sequentially within itself.
        unsafe {
            std::env::remove_var("UPDATE_GOLDENS");
        }
        let fb_a = make_fb([1, 2, 3, 255]);
        let err = assert_golden(&fb_a, &path_missing, 0).unwrap_err();
        assert_eq!(err.kind(), io::ErrorKind::NotFound);

        // --- Mode 2: UPDATE_GOLDENS=1 writes the file and succeeds. ---
        let path_update = base.with_extension("update.ppm");
        unsafe {
            std::env::set_var("UPDATE_GOLDENS", "1");
        }
        assert_golden(&fb_a, &path_update, 0).unwrap();
        unsafe {
            std::env::remove_var("UPDATE_GOLDENS");
        }
        assert_golden(&fb_a, &path_update, 0).unwrap();

        // --- Mode 3: mismatch writes a sibling .actual.ppm. ---
        let path_mismatch = base.with_extension("mismatch.ppm");
        let fb_b = make_fb([100, 100, 200, 255]);
        save_ppm(&fb_a, &path_mismatch).unwrap();
        let err = assert_golden(&fb_b, &path_mismatch, 0).unwrap_err();
        assert_eq!(err.kind(), io::ErrorKind::InvalidData);
        let stem = path_mismatch
            .file_stem()
            .unwrap()
            .to_string_lossy()
            .into_owned();
        let actual = path_mismatch.with_file_name(format!("{stem}.actual.ppm"));
        assert!(actual.exists(), "actual PPM should have been written");

        // Cleanup.
        let _ = std::fs::remove_file(&path_update);
        let _ = std::fs::remove_file(&path_mismatch);
        let _ = std::fs::remove_file(&actual);
    }
}

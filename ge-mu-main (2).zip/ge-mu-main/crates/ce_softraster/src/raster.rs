//! Triangle rasterizer with barycentric colour interpolation + Z-test.

use ce_math::{Mat4, Vec3, Vec4};
use ce_render::mesh::{Mesh, Vertex};

use crate::framebuffer::Framebuffer;

/// Rasterizes every triangle in `mesh` into `fb` using the provided
/// view-projection matrix. Triangles are back-face culled (CCW front).
pub fn render_mesh(mesh: &Mesh, view_proj: Mat4, fb: &mut Framebuffer) -> u32 {
    let indices_vec;
    let indices: &[u32] = match &mesh.indices {
        Some(ix) => ix,
        None => {
            indices_vec = (0..mesh.vertices.len() as u32).collect::<Vec<_>>();
            &indices_vec[..]
        }
    };
    let mut triangles_drawn = 0u32;
    for tri in indices.chunks_exact(3) {
        let a = project_vertex(mesh.vertices[tri[0] as usize], view_proj, fb);
        let b = project_vertex(mesh.vertices[tri[1] as usize], view_proj, fb);
        let c = project_vertex(mesh.vertices[tri[2] as usize], view_proj, fb);
        let (Some(a), Some(b), Some(c)) = (a, b, c) else {
            continue; // clipped behind camera
        };
        if back_face(a.screen, b.screen, c.screen) {
            continue;
        }
        raster_triangle(a, b, c, fb);
        triangles_drawn += 1;
    }
    triangles_drawn
}

#[derive(Clone, Copy)]
struct Projected {
    screen: Vec3,
    color: [f32; 4],
    _padding: f32,
}

fn project_vertex(v: Vertex, vp: Mat4, fb: &Framebuffer) -> Option<Projected> {
    let clip = vp * Vec4::new(v.position[0], v.position[1], v.position[2], 1.0);
    if clip.w <= 0.0 {
        return None; // behind camera
    }
    let ndc = Vec3::new(clip.x, clip.y, clip.z) / clip.w;
    // Simple clip against -1..1 on xy with some margin so off-screen
    // edges still feed into raster (rasterizer clamps at pixel write).
    let screen = Vec3::new(
        (ndc.x * 0.5 + 0.5) * fb.width as f32,
        (1.0 - (ndc.y * 0.5 + 0.5)) * fb.height as f32,
        ndc.z * 0.5 + 0.5,
    );
    Some(Projected {
        screen,
        color: v.color,
        _padding: 0.0,
    })
}

fn back_face(a: Vec3, b: Vec3, c: Vec3) -> bool {
    let ab = b - a;
    let ac = c - a;
    // Screen-space has Y flipped from NDC, so a CCW-in-NDC front-face
    // becomes CW-in-screen (cross.z > 0). We therefore cull triangles
    // with cross.z < 0 (screen CCW == NDC CW == back-face).
    ab.x * ac.y - ab.y * ac.x >= 0.0
}

fn raster_triangle(a: Projected, b: Projected, c: Projected, fb: &mut Framebuffer) {
    let min_x = a.screen.x.min(b.screen.x).min(c.screen.x).floor().max(0.0) as u32;
    let max_x = a
        .screen
        .x
        .max(b.screen.x)
        .max(c.screen.x)
        .ceil()
        .min((fb.width - 1) as f32) as u32;
    let min_y = a.screen.y.min(b.screen.y).min(c.screen.y).floor().max(0.0) as u32;
    let max_y = a
        .screen
        .y
        .max(b.screen.y)
        .max(c.screen.y)
        .ceil()
        .min((fb.height - 1) as f32) as u32;

    let area = edge(a.screen, b.screen, c.screen);
    if area.abs() < 1e-4 {
        return; // degenerate
    }

    for y in min_y..=max_y {
        for x in min_x..=max_x {
            let p = Vec3::new(x as f32 + 0.5, y as f32 + 0.5, 0.0);
            let w0 = edge(b.screen, c.screen, p);
            let w1 = edge(c.screen, a.screen, p);
            let w2 = edge(a.screen, b.screen, p);
            if (w0 >= 0.0 && w1 >= 0.0 && w2 >= 0.0) || (w0 <= 0.0 && w1 <= 0.0 && w2 <= 0.0) {
                let inv = 1.0 / area;
                let bw0 = w0 * inv;
                let bw1 = w1 * inv;
                let bw2 = w2 * inv;
                let z = bw0 * a.screen.z + bw1 * b.screen.z + bw2 * c.screen.z;
                if !(0.0..=1.0).contains(&z) {
                    continue;
                }
                let r = bw0 * a.color[0] + bw1 * b.color[0] + bw2 * c.color[0];
                let g = bw0 * a.color[1] + bw1 * b.color[1] + bw2 * c.color[1];
                let bl = bw0 * a.color[2] + bw1 * b.color[2] + bw2 * c.color[2];
                let al = bw0 * a.color[3] + bw1 * b.color[3] + bw2 * c.color[3];
                let rgba = [
                    (r.clamp(0.0, 1.0) * 255.0) as u8,
                    (g.clamp(0.0, 1.0) * 255.0) as u8,
                    (bl.clamp(0.0, 1.0) * 255.0) as u8,
                    (al.clamp(0.0, 1.0) * 255.0) as u8,
                ];
                fb.set_pixel_z(x, y, z, rgba);
            }
        }
    }
}

fn edge(a: Vec3, b: Vec3, c: Vec3) -> f32 {
    (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn solid_red_triangle() -> Mesh {
        let red = [1.0, 0.0, 0.0, 1.0];
        Mesh {
            vertices: vec![
                Vertex {
                    position: [-0.6, -0.6, 0.0],
                    color: red,
                },
                Vertex {
                    position: [0.6, -0.6, 0.0],
                    color: red,
                },
                Vertex {
                    position: [0.0, 0.6, 0.0],
                    color: red,
                },
            ],
            indices: None,
        }
    }

    fn orthographic_vp() -> Mat4 {
        // Simple ortho: identity is fine; NDC = local coords.
        Mat4::IDENTITY
    }

    #[test]
    fn triangle_fills_centre_pixels() {
        let mut fb = Framebuffer::new(16, 16);
        let drawn = render_mesh(&solid_red_triangle(), orthographic_vp(), &mut fb);
        assert_eq!(drawn, 1);
        // Centre pixel should be lit.
        let centre = fb.count_pixels_rgb([255, 0, 0]);
        assert!(centre > 30, "expected >30 red pixels, got {centre}");
    }

    #[test]
    fn back_face_is_culled() {
        // Flip CCW to CW.
        let mut mesh = solid_red_triangle();
        mesh.vertices.swap(1, 2);
        let mut fb = Framebuffer::new(16, 16);
        let drawn = render_mesh(&mesh, orthographic_vp(), &mut fb);
        assert_eq!(drawn, 0);
        assert_eq!(fb.count_pixels_rgb([255, 0, 0]), 0);
    }

    #[test]
    fn colour_interpolates_across_triangle() {
        let mut fb = Framebuffer::new(32, 32);
        let mesh = Mesh {
            vertices: vec![
                Vertex {
                    position: [-0.8, -0.8, 0.0],
                    color: [1.0, 0.0, 0.0, 1.0],
                },
                Vertex {
                    position: [0.8, -0.8, 0.0],
                    color: [0.0, 1.0, 0.0, 1.0],
                },
                Vertex {
                    position: [0.0, 0.8, 0.0],
                    color: [0.0, 0.0, 1.0, 1.0],
                },
            ],
            indices: None,
        };
        render_mesh(&mesh, orthographic_vp(), &mut fb);
        // Expect at least three distinct rgb values near each corner.
        let mut palette = std::collections::HashSet::new();
        for chunk in fb.pixels().chunks_exact(4) {
            if chunk[3] > 0 {
                palette.insert([chunk[0], chunk[1], chunk[2]]);
            }
        }
        assert!(
            palette.len() > 10,
            "interpolation produced {}",
            palette.len()
        );
    }

    #[test]
    fn indexed_mesh_produces_same_output_as_unindexed() {
        let base = solid_red_triangle();
        let indexed = Mesh {
            vertices: base.vertices.clone(),
            indices: Some(vec![0, 1, 2]),
        };
        let mut fb_a = Framebuffer::new(16, 16);
        let mut fb_b = Framebuffer::new(16, 16);
        render_mesh(&base, orthographic_vp(), &mut fb_a);
        render_mesh(&indexed, orthographic_vp(), &mut fb_b);
        assert_eq!(fb_a.pixels(), fb_b.pixels());
    }

    #[test]
    fn z_buffer_prefers_closer_triangle() {
        let mut fb = Framebuffer::new(16, 16);
        // Far red triangle at z=0.8.
        let red = Mesh {
            vertices: vec![
                Vertex {
                    position: [-0.9, -0.9, 0.8],
                    color: [1.0, 0.0, 0.0, 1.0],
                },
                Vertex {
                    position: [0.9, -0.9, 0.8],
                    color: [1.0, 0.0, 0.0, 1.0],
                },
                Vertex {
                    position: [0.0, 0.9, 0.8],
                    color: [1.0, 0.0, 0.0, 1.0],
                },
            ],
            indices: None,
        };
        // Near green triangle at z=0.1 overlapping the centre.
        let green = Mesh {
            vertices: vec![
                Vertex {
                    position: [-0.3, -0.3, 0.1],
                    color: [0.0, 1.0, 0.0, 1.0],
                },
                Vertex {
                    position: [0.3, -0.3, 0.1],
                    color: [0.0, 1.0, 0.0, 1.0],
                },
                Vertex {
                    position: [0.0, 0.3, 0.1],
                    color: [0.0, 1.0, 0.0, 1.0],
                },
            ],
            indices: None,
        };
        render_mesh(&red, orthographic_vp(), &mut fb);
        render_mesh(&green, orthographic_vp(), &mut fb);
        // Centre pixel must be green.
        let w = fb.width / 2;
        let h = fb.height / 2;
        let idx = ((h as usize) * (fb.width as usize) + (w as usize)) * 4;
        let px = [fb.pixels()[idx], fb.pixels()[idx + 1], fb.pixels()[idx + 2]];
        assert_eq!(px, [0, 255, 0]);
    }
}

//! PPM (P6 binary) file writer.
//!
//! Dep-free: every viewer supports it, and it round-trips without loss.

use std::fs::File;
use std::io::{self, BufWriter, Write};
use std::path::Path;

use crate::framebuffer::Framebuffer;

/// Writes `fb`'s RGB channels (alpha dropped) to `path` as a P6 PPM.
pub fn save_ppm(fb: &Framebuffer, path: impl AsRef<Path>) -> io::Result<()> {
    let file = File::create(path)?;
    let mut w = BufWriter::new(file);
    writeln!(w, "P6")?;
    writeln!(w, "{} {}", fb.width, fb.height)?;
    writeln!(w, "255")?;
    // Strip alpha.
    for px in fb.pixels().chunks_exact(4) {
        w.write_all(&px[0..3])?;
    }
    w.flush()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn writes_valid_ppm_header() {
        let mut fb = Framebuffer::new(4, 3);
        fb.clear([100, 150, 200, 255]);
        let dir = std::env::temp_dir();
        let path = dir.join(format!(
            "ce_softraster_test_{}_{}.ppm",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        save_ppm(&fb, &path).unwrap();
        let bytes = std::fs::read(&path).unwrap();
        // Strip to just the header lines.
        let header: String = bytes
            .iter()
            .take(32)
            .take_while(|&&b| b != 0)
            .map(|&b| b as char)
            .collect();
        assert!(header.starts_with("P6\n4 3\n255\n"));
        // 4*3 pixels × 3 bytes = 36 bytes of data past header.
        assert_eq!(
            bytes.len(),
            header.lines().take(3).map(|l| l.len() + 1).sum::<usize>() + 36
        );
        let _ = std::fs::remove_file(&path);
    }

    #[test]
    fn payload_drops_alpha() {
        let mut fb = Framebuffer::new(1, 1);
        fb.set_pixel(0, 0, [10, 20, 30, 255]);
        let dir = std::env::temp_dir();
        let path = dir.join(format!("ce_softraster_alpha_{}.ppm", std::process::id()));
        save_ppm(&fb, &path).unwrap();
        let bytes = std::fs::read(&path).unwrap();
        // Last three bytes should be 10 20 30.
        let tail = &bytes[bytes.len() - 3..];
        assert_eq!(tail, &[10, 20, 30]);
        let _ = std::fs::remove_file(&path);
    }
}

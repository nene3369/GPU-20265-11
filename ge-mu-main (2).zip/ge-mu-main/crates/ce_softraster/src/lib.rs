//! `ce_softraster` — tiny CPU triangle rasterizer.
//!
//! Takes a `ce_render::Mesh` + a view-projection matrix and fills a
//! [`Framebuffer`] with colour + depth. Handy for CI smoke tests that
//! want a real visual artefact (write PPM), for offscreen validation
//! of procedurally generated meshes, and as a fallback renderer when
//! wgpu can't find an adapter.

pub mod framebuffer;
pub mod golden;
pub mod ppm;
pub mod raster;

pub use framebuffer::Framebuffer;
pub use golden::{assert_golden, diff, load_ppm, DiffStats};
pub use ppm::save_ppm;
pub use raster::render_mesh;

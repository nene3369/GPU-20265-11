//! Recipe book + inventory-based craft resolution.
//!
//! A recipe consumes input stacks and produces output stacks over some
//! work duration. Work progress is tracked externally (a crafting
//! station or avatar component ticks a timer); this module only
//! handles the "do we have the ingredients?" and "apply the result"
//! logic as pure functions.

use std::collections::HashMap;

use crate::inventory::Inventory;
use crate::item::{ItemId, ItemStack};

/// One recipe entry.
#[derive(Debug, Clone)]
pub struct Recipe {
    pub id: RecipeId,
    pub inputs: Vec<ItemStack>,
    pub outputs: Vec<ItemStack>,
    /// Seconds of work required.
    pub work_seconds: f32,
}

/// Unique handle for recipes.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct RecipeId(pub &'static str);

impl RecipeId {
    pub const fn new(id: &'static str) -> Self {
        Self(id)
    }
}

/// Collection of known recipes.
#[derive(Debug, Clone, Default)]
pub struct RecipeBook {
    recipes: HashMap<RecipeId, Recipe>,
}

impl RecipeBook {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn insert(&mut self, recipe: Recipe) {
        self.recipes.insert(recipe.id, recipe);
    }

    pub fn get(&self, id: RecipeId) -> Option<&Recipe> {
        self.recipes.get(&id)
    }

    pub fn len(&self) -> usize {
        self.recipes.len()
    }

    pub fn is_empty(&self) -> bool {
        self.recipes.is_empty()
    }

    pub fn iter(&self) -> impl Iterator<Item = &Recipe> {
        self.recipes.values()
    }
}

/// Reasons a craft attempt can't proceed.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CraftError {
    MissingRecipe,
    MissingIngredient(ItemId),
    InventoryOverflow,
}

/// Can the inventory supply all ingredients for `recipe`?
pub fn can_craft(inv: &Inventory, recipe: &Recipe) -> Result<(), CraftError> {
    for stack in &recipe.inputs {
        if inv.count(stack.id) < stack.count {
            return Err(CraftError::MissingIngredient(stack.id));
        }
    }
    Ok(())
}

/// Performs a single craft: subtracts inputs, adds outputs. On failure
/// the inventory is not modified.
pub fn craft_once(
    inv: &mut Inventory,
    book: &RecipeBook,
    recipe_id: RecipeId,
) -> Result<(), CraftError> {
    let recipe = book.get(recipe_id).ok_or(CraftError::MissingRecipe)?;
    can_craft(inv, recipe)?;

    // Reserve a snapshot so partial failure (capacity) can rewind.
    let snapshot = inv.clone();

    for stack in &recipe.inputs {
        // We already validated counts; `NotEnough` cannot fire here.
        inv.remove(stack.id, stack.count).unwrap();
    }
    for stack in &recipe.outputs {
        if inv.add(stack.id, stack.count).is_err() {
            *inv = snapshot;
            return Err(CraftError::InventoryOverflow);
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::inventory::InventoryError;

    const IRON: ItemId = ItemId::new("iron_ore");
    const INGOT: ItemId = ItemId::new("iron_ingot");
    const COAL: ItemId = ItemId::new("coal");

    fn smelt_recipe() -> Recipe {
        Recipe {
            id: RecipeId::new("smelt_iron"),
            inputs: vec![ItemStack::new(IRON, 2), ItemStack::new(COAL, 1)],
            outputs: vec![ItemStack::new(INGOT, 1)],
            work_seconds: 5.0,
        }
    }

    fn book_with_smelt() -> RecipeBook {
        let mut b = RecipeBook::new();
        b.insert(smelt_recipe());
        b
    }

    #[test]
    fn missing_recipe_reports_missing_recipe() {
        let mut inv = Inventory::new(100);
        let book = RecipeBook::new();
        assert_eq!(
            craft_once(&mut inv, &book, RecipeId::new("nope")),
            Err(CraftError::MissingRecipe)
        );
    }

    #[test]
    fn craft_fails_when_ingredients_are_missing() {
        let mut inv = Inventory::new(100);
        inv.add(IRON, 1).unwrap(); // need 2
        inv.add(COAL, 1).unwrap();
        let book = book_with_smelt();
        assert_eq!(
            craft_once(&mut inv, &book, RecipeId::new("smelt_iron")),
            Err(CraftError::MissingIngredient(IRON))
        );
        // Inventory is unchanged.
        assert_eq!(inv.count(IRON), 1);
        assert_eq!(inv.count(COAL), 1);
    }

    #[test]
    fn successful_craft_consumes_inputs_and_produces_outputs() {
        let mut inv = Inventory::new(100);
        inv.add(IRON, 5).unwrap();
        inv.add(COAL, 3).unwrap();
        let book = book_with_smelt();
        assert!(craft_once(&mut inv, &book, RecipeId::new("smelt_iron")).is_ok());
        assert_eq!(inv.count(IRON), 3);
        assert_eq!(inv.count(COAL), 2);
        assert_eq!(inv.count(INGOT), 1);
    }

    #[test]
    fn capacity_overflow_rolls_back() {
        // 3/4 slots full; trying to smelt would need to remove 2 IRON +
        // 1 COAL (freeing 3) and add 1 INGOT. Net change is -2, so it
        // fits. Force overflow instead by setting capacity to exactly
        // current total, then attempting a craft that *adds* a net item.
        let mut inv = Inventory::new(3);
        inv.add(IRON, 2).unwrap();
        inv.add(COAL, 1).unwrap();
        // Recipe here emits 5 ingots for 2 iron + 1 coal: +2 net.
        let mut book = RecipeBook::new();
        book.insert(Recipe {
            id: RecipeId::new("wasteful"),
            inputs: vec![ItemStack::new(IRON, 2), ItemStack::new(COAL, 1)],
            outputs: vec![ItemStack::new(INGOT, 5)],
            work_seconds: 1.0,
        });
        let err = craft_once(&mut inv, &book, RecipeId::new("wasteful"));
        assert_eq!(err, Err(CraftError::InventoryOverflow));
        // Snapshot restored.
        assert_eq!(inv.count(IRON), 2);
        assert_eq!(inv.count(COAL), 1);
        assert_eq!(inv.count(INGOT), 0);
    }

    #[test]
    fn book_lookup_returns_recipe_by_id() {
        let book = book_with_smelt();
        assert!(book.get(RecipeId::new("smelt_iron")).is_some());
        assert!(book.get(RecipeId::new("nope")).is_none());
    }

    #[test]
    fn can_craft_passes_when_ingredients_present() {
        let mut inv = Inventory::new(100);
        inv.add(IRON, 2).unwrap();
        inv.add(COAL, 1).unwrap();
        assert!(can_craft(&inv, &smelt_recipe()).is_ok());
    }

    #[test]
    fn inventory_error_surfaces_from_craft_overflow_case_only() {
        // `NotEnough` never leaks out because `can_craft` runs first.
        // Here we simulate the internal invariant by ensuring
        // `InventoryError::NotEnough` maps to `CraftError::MissingIngredient`.
        let mut inv = Inventory::new(100);
        inv.add(IRON, 1).unwrap(); // missing COAL, missing 1 IRON
        inv.add(COAL, 1).unwrap();
        let book = book_with_smelt();
        match craft_once(&mut inv, &book, RecipeId::new("smelt_iron")) {
            Err(CraftError::MissingIngredient(_)) => {}
            Err(CraftError::InventoryOverflow) => panic!("should be MissingIngredient"),
            Err(CraftError::MissingRecipe) => panic!("recipe is present"),
            Ok(()) => panic!("not enough iron"),
        }
        let _ = InventoryError::NotEnough; // prove variant is referenced
    }
}

//! `ce_gameplay` — universal gameplay data.
//!
//! M9 scope: the data types that every later system leans on —
//! [`Inventory`], [`ItemStack`], [`AvatarStats`], [`RecipeBook`].
//! All pure values so snapshots for multiplayer / save will be
//! straightforward.
//!
//! Concrete gameplay systems (avatar controller, refinery tick,
//! station shop logic) are intentionally deferred. This crate just
//! provides the building blocks and pure transform functions.

pub mod avatar;
pub mod crafting;
pub mod inventory;
pub mod item;

pub use avatar::{tick_avatar, AvatarEnvironment, AvatarStats, DecayRates};
pub use crafting::{can_craft, craft_once, CraftError, Recipe, RecipeBook, RecipeId};
pub use inventory::{Inventory, InventoryError};
pub use item::{ItemId, ItemStack};

use ce_app::{App, Plugin};

/// Installs an empty [`RecipeBook`] and a default [`DecayRates`] so
/// other plugins can read them. No avatar entity is spawned — that's
/// gameplay-specific and handled by the game layer.
pub struct GameplayPlugin;

impl Plugin for GameplayPlugin {
    fn build(&self, app: &mut App) {
        if app.world.get_resource::<RecipeBook>().is_none() {
            app.insert_resource(RecipeBook::new());
        }
        if app.world.get_resource::<DecayRates>().is_none() {
            app.insert_resource(DecayRates::default());
        }
        log::info!("GameplayPlugin loaded");
    }
}

#[cfg(test)]
mod plugin_tests {
    use super::*;

    #[test]
    fn plugin_installs_defaults() {
        let mut app = App::new();
        app.add_plugin(GameplayPlugin);
        assert!(app.world.get_resource::<RecipeBook>().is_some());
        assert!(app.world.get_resource::<DecayRates>().is_some());
    }

    #[test]
    fn plugin_preserves_preinserted_resources() {
        let mut app = App::new();
        let mut book = RecipeBook::new();
        book.insert(Recipe {
            id: RecipeId::new("pre_inserted"),
            inputs: vec![],
            outputs: vec![],
            work_seconds: 0.0,
        });
        app.insert_resource(book);
        app.add_plugin(GameplayPlugin);
        let b = app.world.get_resource::<RecipeBook>().unwrap();
        assert!(b.get(RecipeId::new("pre_inserted")).is_some());
    }
}

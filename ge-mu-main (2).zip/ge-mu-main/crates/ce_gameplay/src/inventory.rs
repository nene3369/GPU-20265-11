//! Per-entity inventory.
//!
//! Stacks-by-id: simple and works for both avatar belts and ship cargo
//! holds. Capacity is total stack count; per-item stacking limits are
//! gameplay-level concerns and not modelled here.

use std::collections::HashMap;

use crate::item::{ItemId, ItemStack};

/// Sparse inventory keyed by `ItemId`.
#[derive(Debug, Clone)]
pub struct Inventory {
    stacks: HashMap<ItemId, u32>,
    /// Upper bound on total items across every stack. `u32::MAX` ≈ no limit.
    pub capacity: u32,
}

/// Why an inventory operation was rejected.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum InventoryError {
    /// Adding the requested count would exceed capacity.
    OverCapacity,
    /// Not enough of the requested item to remove.
    NotEnough,
}

impl Inventory {
    pub fn new(capacity: u32) -> Self {
        Self {
            stacks: HashMap::new(),
            capacity,
        }
    }

    /// Total item count across every stack.
    pub fn total(&self) -> u32 {
        self.stacks.values().sum()
    }

    pub fn remaining(&self) -> u32 {
        self.capacity.saturating_sub(self.total())
    }

    pub fn count(&self, id: ItemId) -> u32 {
        self.stacks.get(&id).copied().unwrap_or(0)
    }

    /// Adds `count` of `id`. Fails with `OverCapacity` if it wouldn't fit.
    pub fn add(&mut self, id: ItemId, count: u32) -> Result<(), InventoryError> {
        if count > self.remaining() {
            return Err(InventoryError::OverCapacity);
        }
        *self.stacks.entry(id).or_insert(0) += count;
        Ok(())
    }

    /// Convenience: add an [`ItemStack`].
    pub fn add_stack(&mut self, s: ItemStack) -> Result<(), InventoryError> {
        self.add(s.id, s.count)
    }

    /// Removes `count` of `id`. Fails with `NotEnough` if the inventory
    /// holds fewer than `count`. On success, empties the stack entry
    /// when it drops to zero.
    pub fn remove(&mut self, id: ItemId, count: u32) -> Result<(), InventoryError> {
        let have = self.count(id);
        if have < count {
            return Err(InventoryError::NotEnough);
        }
        if have == count {
            self.stacks.remove(&id);
        } else {
            *self.stacks.get_mut(&id).unwrap() -= count;
        }
        Ok(())
    }

    pub fn iter(&self) -> impl Iterator<Item = (&ItemId, &u32)> {
        self.stacks.iter()
    }

    pub fn clear(&mut self) {
        self.stacks.clear();
    }
}

impl Default for Inventory {
    fn default() -> Self {
        Self::new(u32::MAX)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const IRON: ItemId = ItemId::new("iron_ore");
    const WATER: ItemId = ItemId::new("water");

    #[test]
    fn new_inventory_is_empty() {
        let inv = Inventory::new(100);
        assert_eq!(inv.total(), 0);
        assert_eq!(inv.count(IRON), 0);
        assert_eq!(inv.remaining(), 100);
    }

    #[test]
    fn add_accumulates_same_item() {
        let mut inv = Inventory::new(100);
        inv.add(IRON, 5).unwrap();
        inv.add(IRON, 3).unwrap();
        assert_eq!(inv.count(IRON), 8);
    }

    #[test]
    fn add_rejects_over_capacity() {
        let mut inv = Inventory::new(10);
        inv.add(IRON, 7).unwrap();
        assert_eq!(inv.add(IRON, 5), Err(InventoryError::OverCapacity));
        assert_eq!(inv.count(IRON), 7); // unchanged
    }

    #[test]
    fn remove_empties_stack_at_zero() {
        let mut inv = Inventory::new(100);
        inv.add(IRON, 5).unwrap();
        inv.remove(IRON, 5).unwrap();
        assert_eq!(inv.count(IRON), 0);
        assert_eq!(inv.iter().count(), 0);
    }

    #[test]
    fn remove_more_than_owned_fails() {
        let mut inv = Inventory::new(100);
        inv.add(IRON, 2).unwrap();
        assert_eq!(inv.remove(IRON, 5), Err(InventoryError::NotEnough));
        assert_eq!(inv.count(IRON), 2);
    }

    #[test]
    fn total_sums_across_stacks() {
        let mut inv = Inventory::new(100);
        inv.add(IRON, 5).unwrap();
        inv.add(WATER, 7).unwrap();
        assert_eq!(inv.total(), 12);
    }

    #[test]
    fn add_stack_convenience() {
        let mut inv = Inventory::new(100);
        inv.add_stack(ItemStack::new(IRON, 4)).unwrap();
        assert_eq!(inv.count(IRON), 4);
    }
}

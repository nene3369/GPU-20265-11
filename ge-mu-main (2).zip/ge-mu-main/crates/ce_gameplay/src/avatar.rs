//! Avatar vitals — the stats that decide whether the player survives
//! being outside the ship.

/// Per-avatar survival state. All values are normalised to `[0, 1]`
/// except `suit_integrity` which carries the same unit so damage
/// modelling stays consistent.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct AvatarStats {
    /// Biological health. Zero means dead.
    pub hp: f32,
    /// Breathable oxygen remaining in the suit/tank.
    pub oxygen: f32,
    /// Hull of the spacesuit. At zero, `hp` starts bleeding off when
    /// the avatar is in vacuum or toxic atmosphere.
    pub suit_integrity: f32,
    /// Food level. Drops slowly; affects stamina regen and at zero
    /// starts draining hp.
    pub hunger: f32,
    /// Hydration level. Same shape as hunger but drains faster.
    pub thirst: f32,
    /// Body temperature, normalised `0 = freezing`, `0.5 = ideal`,
    /// `1 = overheating`.
    pub temperature: f32,
    /// Reserve for sprinting / jetpack. Regenerates when breathable
    /// atmosphere is available.
    pub stamina: f32,
}

impl AvatarStats {
    /// Fresh avatar: full vitals, ideal temperature.
    pub fn full() -> Self {
        Self {
            hp: 1.0,
            oxygen: 1.0,
            suit_integrity: 1.0,
            hunger: 1.0,
            thirst: 1.0,
            temperature: 0.5,
            stamina: 1.0,
        }
    }

    pub fn is_dead(&self) -> bool {
        self.hp <= 0.0
    }

    /// True when the avatar is in life-threatening condition (low O₂,
    /// dehydrated, suit breached in vacuum).
    pub fn is_critical(&self) -> bool {
        self.oxygen < 0.1 || self.thirst < 0.1 || self.suit_integrity < 0.1
    }
}

impl Default for AvatarStats {
    fn default() -> Self {
        Self::full()
    }
}

/// Environmental context that drives vital decay each tick. Populated
/// by higher-level systems (sector/ship/planet contexts) and consumed
/// by [`tick_avatar`].
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct AvatarEnvironment {
    /// Breathable atmosphere available outside the suit? (Inside a
    /// pressurised ship / planet with O₂, this is `true`.)
    pub breathable_air: bool,
    /// Is the avatar currently moving hard enough to burn stamina?
    pub sprinting: bool,
    /// Ambient temperature deviation from neutral (-1…+1).
    /// Negative = cold, positive = hot.
    pub temperature_delta: f32,
}

impl Default for AvatarEnvironment {
    fn default() -> Self {
        Self {
            breathable_air: true,
            sprinting: false,
            temperature_delta: 0.0,
        }
    }
}

/// Per-second decay rates. Gameplay tuning knobs — the plugin carries
/// one of these as a resource.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct DecayRates {
    pub oxygen_use_per_second: f32,
    pub oxygen_regen_per_second: f32,
    pub hunger_per_second: f32,
    pub thirst_per_second: f32,
    pub stamina_drain_per_second: f32,
    pub stamina_regen_per_second: f32,
    /// How fast body temperature drifts toward the environment.
    pub temperature_drift_per_second: f32,
    /// Hp lost per second while suffocating / dehydrated / frozen.
    pub critical_hp_drain_per_second: f32,
}

impl Default for DecayRates {
    fn default() -> Self {
        Self {
            oxygen_use_per_second: 1.0 / 180.0, // 3 minutes of suit O₂
            oxygen_regen_per_second: 1.0 / 5.0,
            hunger_per_second: 1.0 / 1800.0, // 30 minutes
            thirst_per_second: 1.0 / 900.0,  // 15 minutes
            stamina_drain_per_second: 1.0 / 12.0,
            stamina_regen_per_second: 1.0 / 8.0,
            temperature_drift_per_second: 0.05,
            critical_hp_drain_per_second: 0.1,
        }
    }
}

/// Advances `stats` by `dt` seconds under `env` using `rates`.
///
/// Pure function — no ECS access — so gameplay balancing can be tested
/// on a range of environments without plumbing a live world.
pub fn tick_avatar(stats: &mut AvatarStats, env: AvatarEnvironment, rates: &DecayRates, dt: f32) {
    if stats.is_dead() {
        return;
    }

    // Snapshot pre-tick temperature so a starting extreme still counts
    // as "critical" for HP drain even if drift has since pushed it back
    // into the safe band by the end of the step.
    let starting_temperature = stats.temperature;

    // Oxygen: regenerates in breathable air, drains otherwise.
    if env.breathable_air {
        stats.oxygen = (stats.oxygen + rates.oxygen_regen_per_second * dt).min(1.0);
    } else {
        stats.oxygen = (stats.oxygen - rates.oxygen_use_per_second * dt).max(0.0);
    }

    // Food / water always drain; sprinting burns extra stamina, else regen.
    stats.hunger = (stats.hunger - rates.hunger_per_second * dt).max(0.0);
    stats.thirst = (stats.thirst - rates.thirst_per_second * dt).max(0.0);
    if env.sprinting {
        stats.stamina = (stats.stamina - rates.stamina_drain_per_second * dt).max(0.0);
    } else if env.breathable_air {
        stats.stamina = (stats.stamina + rates.stamina_regen_per_second * dt).min(1.0);
    }

    // Temperature drifts toward 0.5 + env_delta*0.5, clamped 0..1.
    let target = (0.5 + env.temperature_delta * 0.5).clamp(0.0, 1.0);
    let drift = (target - stats.temperature) * rates.temperature_drift_per_second * dt;
    stats.temperature = (stats.temperature + drift).clamp(0.0, 1.0);

    // HP drain under critical conditions — use the worse of pre- and
    // post-drift temperature so brief-but-lethal exposures still bite.
    let extreme_temp = |t: f32| t <= 0.05 || t >= 0.95;
    if stats.is_critical() || extreme_temp(starting_temperature) || extreme_temp(stats.temperature)
    {
        stats.hp = (stats.hp - rates.critical_hp_drain_per_second * dt).max(0.0);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn breathable_env() -> AvatarEnvironment {
        AvatarEnvironment::default()
    }

    fn vacuum_env() -> AvatarEnvironment {
        AvatarEnvironment {
            breathable_air: false,
            ..Default::default()
        }
    }

    #[test]
    fn full_avatar_is_not_dead_or_critical() {
        let a = AvatarStats::full();
        assert!(!a.is_dead());
        assert!(!a.is_critical());
    }

    #[test]
    fn low_oxygen_is_critical() {
        let mut a = AvatarStats::full();
        a.oxygen = 0.05;
        assert!(a.is_critical());
    }

    #[test]
    fn breathable_air_does_not_drain_oxygen() {
        let mut a = AvatarStats::full();
        a.oxygen = 0.5;
        tick_avatar(&mut a, breathable_env(), &DecayRates::default(), 5.0);
        assert!(a.oxygen >= 0.5);
    }

    #[test]
    fn vacuum_drains_oxygen_over_time() {
        let mut a = AvatarStats::full();
        tick_avatar(&mut a, vacuum_env(), &DecayRates::default(), 60.0);
        assert!(a.oxygen < 1.0);
    }

    #[test]
    fn tick_on_dead_avatar_is_noop() {
        let mut a = AvatarStats::full();
        a.hp = 0.0;
        a.oxygen = 0.5;
        tick_avatar(&mut a, vacuum_env(), &DecayRates::default(), 60.0);
        assert_eq!(a.oxygen, 0.5);
    }

    #[test]
    fn sprinting_drains_stamina() {
        let mut a = AvatarStats::full();
        let env = AvatarEnvironment {
            sprinting: true,
            ..Default::default()
        };
        tick_avatar(&mut a, env, &DecayRates::default(), 5.0);
        assert!(a.stamina < 1.0);
    }

    #[test]
    fn resting_in_breathable_air_regenerates_stamina() {
        let mut a = AvatarStats::full();
        a.stamina = 0.2;
        tick_avatar(&mut a, breathable_env(), &DecayRates::default(), 5.0);
        assert!(a.stamina > 0.2);
    }

    #[test]
    fn critical_condition_drains_hp() {
        let mut a = AvatarStats::full();
        a.oxygen = 0.0; // suffocating
        tick_avatar(&mut a, vacuum_env(), &DecayRates::default(), 5.0);
        assert!(a.hp < 1.0);
    }

    #[test]
    fn extreme_temperature_drains_hp_via_critical_path() {
        let mut a = AvatarStats::full();
        a.temperature = 0.0; // freezing
        tick_avatar(&mut a, breathable_env(), &DecayRates::default(), 5.0);
        assert!(a.hp < 1.0);
    }

    #[test]
    fn temperature_drifts_toward_environment() {
        let mut a = AvatarStats::full();
        let hot = AvatarEnvironment {
            temperature_delta: 1.0, // max hot
            ..Default::default()
        };
        tick_avatar(&mut a, hot, &DecayRates::default(), 10.0);
        assert!(a.temperature > 0.5);
    }
}

//! Item identity + stack type.
//!
//! `ItemId` is a small interned-style handle (`&'static str`) so item
//! catalogue lookups stay cheap and comparable, while recipe/economy
//! data files can still ship human-readable IDs.

/// Unique identifier for an item kind (e.g. `"iron_ore"`).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct ItemId(pub &'static str);

impl ItemId {
    pub const fn new(id: &'static str) -> Self {
        Self(id)
    }

    pub fn as_str(&self) -> &'static str {
        self.0
    }
}

impl std::fmt::Display for ItemId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.0)
    }
}

/// One stack of items — the unit of most gameplay transactions.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ItemStack {
    pub id: ItemId,
    pub count: u32,
}

impl ItemStack {
    pub const fn new(id: ItemId, count: u32) -> Self {
        Self { id, count }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn item_id_round_trips_through_display() {
        let id = ItemId::new("iron_ore");
        assert_eq!(format!("{id}"), "iron_ore");
        assert_eq!(id.as_str(), "iron_ore");
    }

    #[test]
    fn item_ids_of_same_str_are_equal() {
        assert_eq!(ItemId::new("foo"), ItemId::new("foo"));
        assert_ne!(ItemId::new("foo"), ItemId::new("bar"));
    }
}

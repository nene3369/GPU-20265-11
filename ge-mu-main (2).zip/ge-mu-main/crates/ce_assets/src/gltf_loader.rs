//! glTF 2.0 loader.
//!
//! Converts every mesh primitive found in a glTF file (`.gltf` or `.glb`)
//! into one [`ce_render::Mesh`]. Each primitive becomes one output mesh;
//! submesh indexing is not preserved yet (M2 scope).
//!
//! Currently supported attributes:
//! - `POSITION` (required)
//! - `COLOR_0` (optional, defaults to opaque white)
//! - indices of any integer width (folded to `u32`)
//!
//! Normals, tangents and UVs are ignored in M2; the `Vertex` type in
//! `ce_render` doesn't expose slots for them yet. Extending `Vertex` and
//! the render pipeline is deferred to a later milestone.

use std::path::Path;

use ce_render::mesh::{Mesh, Vertex};

use crate::error::AssetError;

/// Loads a glTF or GLB file and returns one [`Mesh`] per primitive.
pub fn load_gltf(path: impl AsRef<Path>) -> Result<Vec<Mesh>, AssetError> {
    let (document, buffers, _images) = gltf::import(path.as_ref())?;
    meshes_from_document(&document, &buffers)
}

/// Loads a GLB (binary glTF) from an in-memory byte slice.
///
/// Useful for embedded fixtures and tests where reading from disk is
/// inconvenient.
pub fn load_glb_slice(bytes: &[u8]) -> Result<Vec<Mesh>, AssetError> {
    let glb = gltf::Glb::from_slice(bytes)?;
    let document = gltf::Gltf::from_slice(&glb.json)?;
    // Collect the single embedded BIN chunk (if any) into a buffer vec.
    let bin = glb.bin.unwrap_or_default().into_owned();
    let buffers = if bin.is_empty() {
        Vec::new()
    } else {
        vec![gltf::buffer::Data(bin)]
    };
    meshes_from_document(&document, &buffers)
}

fn meshes_from_document(
    document: &gltf::Document,
    buffers: &[gltf::buffer::Data],
) -> Result<Vec<Mesh>, AssetError> {
    let mut out = Vec::new();
    for mesh in document.meshes() {
        for primitive in mesh.primitives() {
            out.push(primitive_to_mesh(&primitive, buffers)?);
        }
    }
    log::debug!(
        "loaded {} primitive(s) from {} mesh(es)",
        out.len(),
        document.meshes().len()
    );
    Ok(out)
}

fn primitive_to_mesh(
    primitive: &gltf::Primitive,
    buffers: &[gltf::buffer::Data],
) -> Result<Mesh, AssetError> {
    let reader = primitive.reader(|b| buffers.get(b.index()).map(|d| &d.0[..]));

    let positions: Vec<[f32; 3]> = reader
        .read_positions()
        .ok_or(AssetError::MissingPositions)?
        .collect();

    let colors: Option<Vec<[f32; 4]>> = reader.read_colors(0).map(|c| c.into_rgba_f32().collect());

    let vertices: Vec<Vertex> = positions
        .into_iter()
        .enumerate()
        .map(|(i, pos)| Vertex {
            position: pos,
            color: colors
                .as_ref()
                .and_then(|c| c.get(i).copied())
                .unwrap_or([1.0, 1.0, 1.0, 1.0]),
        })
        .collect();

    let indices = reader.read_indices().map(|i| i.into_u32().collect());

    Ok(Mesh { vertices, indices })
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Hand-crafts a minimal GLB (binary glTF) containing one triangle
    /// primitive with a POSITION accessor. No external fixtures are
    /// required, which keeps the test hermetic and CI-friendly.
    fn minimal_triangle_glb() -> Vec<u8> {
        // Binary chunk: 3 positions × (3 × f32) = 36 bytes.
        let positions: [[f32; 3]; 3] = [[0.0, 0.5, 0.0], [-0.5, -0.5, 0.0], [0.5, -0.5, 0.0]];
        let mut bin = Vec::with_capacity(36);
        for v in &positions {
            for c in v {
                bin.extend_from_slice(&c.to_le_bytes());
            }
        }

        // glTF JSON chunk referencing the binary buffer.
        let json = r#"{
  "asset": { "version": "2.0" },
  "buffers": [ { "byteLength": 36 } ],
  "bufferViews": [ { "buffer": 0, "byteLength": 36, "target": 34962 } ],
  "accessors": [ {
    "bufferView": 0, "componentType": 5126, "count": 3, "type": "VEC3",
    "min": [-0.5, -0.5, 0.0], "max": [0.5, 0.5, 0.0]
  } ],
  "meshes": [ { "primitives": [ { "attributes": { "POSITION": 0 } } ] } ]
}"#;

        // Align JSON chunk to 4 bytes with spaces, BIN chunk to 4 bytes with zeros.
        let mut json_bytes = json.as_bytes().to_vec();
        while !json_bytes.len().is_multiple_of(4) {
            json_bytes.push(b' ');
        }
        while !bin.len().is_multiple_of(4) {
            bin.push(0);
        }

        let total_len = 12 + 8 + json_bytes.len() + 8 + bin.len();
        let mut glb = Vec::with_capacity(total_len);
        // Header.
        glb.extend_from_slice(b"glTF");
        glb.extend_from_slice(&2u32.to_le_bytes());
        glb.extend_from_slice(&(total_len as u32).to_le_bytes());
        // JSON chunk.
        glb.extend_from_slice(&(json_bytes.len() as u32).to_le_bytes());
        glb.extend_from_slice(b"JSON");
        glb.extend_from_slice(&json_bytes);
        // BIN chunk.
        glb.extend_from_slice(&(bin.len() as u32).to_le_bytes());
        glb.extend_from_slice(b"BIN\0");
        glb.extend_from_slice(&bin);
        glb
    }

    #[test]
    fn loads_minimal_triangle_glb() {
        let bytes = minimal_triangle_glb();
        let meshes = load_glb_slice(&bytes).expect("load");
        assert_eq!(meshes.len(), 1);
        let m = &meshes[0];
        assert_eq!(m.vertices.len(), 3);
        assert!(m.indices.is_none()); // we didn't emit indices

        // Positions match what we packed.
        assert_eq!(m.vertices[0].position, [0.0, 0.5, 0.0]);
        assert_eq!(m.vertices[1].position, [-0.5, -0.5, 0.0]);
        assert_eq!(m.vertices[2].position, [0.5, -0.5, 0.0]);

        // With no COLOR_0 accessor, vertex colour defaults to white.
        for v in &m.vertices {
            assert_eq!(v.color, [1.0, 1.0, 1.0, 1.0]);
        }
    }

    #[test]
    fn invalid_glb_header_reports_gltf_error() {
        // A header that doesn't start with "glTF" must round-trip out as
        // a gltf::Error rather than panic or succeed.
        let bytes = b"not a glb file";
        match load_glb_slice(bytes) {
            Err(AssetError::Gltf(_)) => {}
            Err(e) => panic!("expected Gltf error, got {e}"),
            Ok(_) => panic!("expected Gltf error, got Ok"),
        }
    }
}

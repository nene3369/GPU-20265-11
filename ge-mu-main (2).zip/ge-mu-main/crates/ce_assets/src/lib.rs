//! Asset pipeline.
//!
//! M2 scope: load glTF 2.0 meshes (`.gltf` or `.glb`) into
//! [`ce_render::Mesh`]. Future work will add textures, materials,
//! animation and hot reloading — see the project plan.

pub mod error;
pub mod gltf_loader;

pub use error::AssetError;
pub use gltf_loader::{load_glb_slice, load_gltf};

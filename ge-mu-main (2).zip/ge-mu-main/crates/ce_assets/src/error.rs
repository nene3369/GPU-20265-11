use std::fmt;

/// Errors that can occur while loading an asset.
#[derive(Debug)]
pub enum AssetError {
    /// Underlying I/O failure reading the file.
    Io(std::io::Error),
    /// glTF parser/validator error.
    Gltf(gltf::Error),
    /// A mesh primitive lacked required POSITION data.
    MissingPositions,
}

impl fmt::Display for AssetError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            AssetError::Io(e) => write!(f, "io error: {e}"),
            AssetError::Gltf(e) => write!(f, "gltf error: {e}"),
            AssetError::MissingPositions => {
                write!(f, "glTF primitive has no POSITION attribute")
            }
        }
    }
}

impl std::error::Error for AssetError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            AssetError::Io(e) => Some(e),
            AssetError::Gltf(e) => Some(e),
            AssetError::MissingPositions => None,
        }
    }
}

impl From<std::io::Error> for AssetError {
    fn from(e: std::io::Error) -> Self {
        AssetError::Io(e)
    }
}

impl From<gltf::Error> for AssetError {
    fn from(e: gltf::Error) -> Self {
        AssetError::Gltf(e)
    }
}

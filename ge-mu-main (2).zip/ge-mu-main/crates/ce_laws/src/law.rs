use ce_math::Vec3;

/// Local context supplied to a law when it is sampled.
///
/// M1 exposes the minimum fields needed by the gravity law. Future
/// milestones may extend this (temperature, neighbour entities, etc.).
#[derive(Debug, Clone, Copy, Default)]
pub struct LawCtx {
    /// World-space position being sampled.
    pub pos: Vec3,
    /// Elapsed simulation time, in seconds.
    pub t: f32,
    /// Local matter density around the sample point. Zero if unknown.
    pub local_density: f32,
}

/// A generator for gravitational acceleration at a point.
///
/// Implementations are shared across threads via `Arc`, so they must be
/// `Send + Sync + 'static`.
pub trait GravityLaw: Send + Sync + 'static {
    fn sample(&self, ctx: &LawCtx) -> Vec3;
}

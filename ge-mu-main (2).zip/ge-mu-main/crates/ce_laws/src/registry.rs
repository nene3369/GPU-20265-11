use std::sync::Arc;

use ce_math::Vec3;

use crate::builtin::ConstGravity;
use crate::law::GravityLaw;

/// Registry of generative laws that govern the L0 (Fundamental Laws) layer
/// of the HGC model.
///
/// Inserted into the ECS as a resource. Phenomena systems (physics,
/// chemistry, worldgen) read this instead of hardcoded constants.
///
/// M1 only exposes gravity. Later milestones extend the struct with
/// `noise`, `day_night`, `weather`, `reaction_rate`, etc.
#[derive(Clone)]
pub struct Laws {
    pub gravity: Arc<dyn GravityLaw>,
}

impl Laws {
    /// Constructs a `Laws` with a spatially constant gravity vector.
    pub fn constant(g: Vec3) -> Self {
        Self {
            gravity: Arc::new(ConstGravity(g)),
        }
    }

    /// Constructs a `Laws` with the supplied gravity law.
    pub fn with_gravity<G: GravityLaw>(g: G) -> Self {
        Self {
            gravity: Arc::new(g),
        }
    }
}

impl Default for Laws {
    fn default() -> Self {
        Self::constant(Vec3::new(0.0, -9.81, 0.0))
    }
}

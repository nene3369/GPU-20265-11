use ce_math::Vec3;

use crate::law::{GravityLaw, LawCtx};

/// Spatially and temporally constant gravity. Equivalent to the previous
/// hardcoded behaviour before `ce_laws` existed.
pub struct ConstGravity(pub Vec3);

impl GravityLaw for ConstGravity {
    fn sample(&self, _ctx: &LawCtx) -> Vec3 {
        self.0
    }
}

/// Gravity whose magnitude scales linearly with local matter density.
///
/// Generation rule: `g = base * (1 + coefficient * local_density)`.
///
/// This is the minimal implementation of the HGC example "gravity is not
/// a function of distance but of local density". The density field itself
/// must be computed upstream (by a physics or worldgen system) and
/// supplied via [`LawCtx::local_density`].
pub struct DensityCoupledGravity {
    pub base: Vec3,
    pub coefficient: f32,
}

impl GravityLaw for DensityCoupledGravity {
    fn sample(&self, ctx: &LawCtx) -> Vec3 {
        self.base * (1.0 + self.coefficient * ctx.local_density)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn const_gravity_is_constant() {
        let g = ConstGravity(Vec3::new(0.0, -9.81, 0.0));
        let low = g.sample(&LawCtx {
            local_density: 0.0,
            ..Default::default()
        });
        let high = g.sample(&LawCtx {
            local_density: 5.0,
            ..Default::default()
        });
        assert_eq!(low, high);
        assert_eq!(low, Vec3::new(0.0, -9.81, 0.0));
    }

    #[test]
    fn density_coupled_gravity_changes_with_neighbors() {
        let g = DensityCoupledGravity {
            base: Vec3::new(0.0, -9.81, 0.0),
            coefficient: 2.0,
        };
        let low = g.sample(&LawCtx {
            local_density: 0.0,
            ..Default::default()
        });
        let high = g.sample(&LawCtx {
            local_density: 1.0,
            ..Default::default()
        });
        assert_ne!(low, high);
        assert!(
            high.length() > low.length(),
            "higher density must produce stronger gravity"
        );
    }

    #[test]
    fn density_coupled_gravity_zero_density_equals_base() {
        let base = Vec3::new(0.0, -9.81, 0.0);
        let g = DensityCoupledGravity {
            base,
            coefficient: 42.0,
        };
        let sampled = g.sample(&LawCtx::default());
        assert_eq!(sampled, base);
    }
}

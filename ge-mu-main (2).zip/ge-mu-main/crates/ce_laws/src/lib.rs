//! L0 Fundamental Laws layer.
//!
//! Provides a registry of *generative* laws (currently: gravity) that
//! phenomena systems query instead of reading hardcoded constants. See
//! the `HGC` 5-layer model described in the project plan.

pub mod builtin;
pub mod law;
pub mod registry;

pub use builtin::{ConstGravity, DensityCoupledGravity};
pub use law::{GravityLaw, LawCtx};
pub use registry::Laws;

use ce_app::{App, Plugin};

/// Plugin that installs the default [`Laws`] resource if none is present.
///
/// Add this *before* `PhysicsPlugin` so phenomena systems can observe the
/// law registry. Overriding the defaults is done with a plain
/// `app.insert_resource(Laws::with_gravity(...))` either before or after
/// `LawsPlugin` (later inserts win).
pub struct LawsPlugin;

impl Plugin for LawsPlugin {
    fn build(&self, app: &mut App) {
        if app.world.get_resource::<Laws>().is_none() {
            app.insert_resource(Laws::default());
        }
        log::info!("LawsPlugin loaded");
    }
}

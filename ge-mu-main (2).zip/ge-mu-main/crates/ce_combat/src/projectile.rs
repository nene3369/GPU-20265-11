//! Projectile ballistics and hit detection.
//!
//! Pure data and pure functions, same as the rest of `ce_combat`. The
//! gameplay layer owns the projectile pool, spawns them when a weapon
//! fires, advances them per frame with [`advance_projectile`], and
//! tests them against target spheres via [`projectile_hits_sphere`].
//!
//! Projectiles live entirely in `f32` local space: at the muzzle
//! velocities we use (~120 m/s) and typical time-to-live (~2 s), f32
//! is plenty precise. Callers bridge to `WorldPos` at their boundary.
//!
//! Hit detection uses a swept sphere-vs-segment test rather than a
//! point check, so fast rounds cannot tunnel through small targets in
//! a single frame.
//!
//! Both `DamageType` and the projectile's raw `damage` travel with the
//! projectile, ready to be handed to `apply_damage` when a hit lands.
//!
//! ```
//! use ce_math::Vec3;
//! use ce_combat::projectile::{advance_projectile, projectile_hits_sphere, Projectile};
//! use ce_combat::DamageType;
//!
//! let mut p = Projectile::new(Vec3::ZERO, Vec3::new(0.0, 0.0, -100.0), 40.0, DamageType::Energy);
//! // Within a 0.1s tick, a 100 m/s round crosses a sphere at -5m.
//! let prev = p.pos;
//! let alive = advance_projectile(&mut p, 0.1);
//! assert!(alive);
//! assert!(projectile_hits_sphere(prev, p.pos, Vec3::new(0.0, 0.0, -5.0), 1.5));
//! ```

use ce_math::Vec3;

use crate::damage::DamageType;

/// A single live projectile. Muzzle-launched at a fixed velocity; no
/// drag, no gravity — space combat stays snappy.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Projectile {
    pub pos: Vec3,
    pub vel: Vec3,
    /// Remaining lifetime in seconds. When this reaches zero the
    /// projectile despawns (see [`advance_projectile`]).
    pub ttl: f32,
    /// Raw damage to apply on hit, before shield/hull multipliers.
    pub damage: f32,
    pub damage_type: DamageType,
}

impl Projectile {
    /// Spawns a projectile with a default 2.0s time-to-live.
    pub fn new(pos: Vec3, vel: Vec3, damage: f32, damage_type: DamageType) -> Self {
        Self {
            pos,
            vel,
            ttl: 2.0,
            damage,
            damage_type,
        }
    }

    /// Spawns with an explicit time-to-live. Useful when weapon range
    /// determines lifetime (`ttl = range / speed`).
    pub fn with_ttl(mut self, ttl_seconds: f32) -> Self {
        self.ttl = ttl_seconds;
        self
    }

    pub fn is_alive(&self) -> bool {
        self.ttl > 0.0
    }
}

/// Advances `p` by `dt` seconds. Returns `true` while the projectile is
/// still alive. Callers typically despawn rounds for which this returns
/// `false`.
pub fn advance_projectile(p: &mut Projectile, dt: f32) -> bool {
    if !p.is_alive() {
        return false;
    }
    p.pos += p.vel * dt;
    p.ttl -= dt;
    p.is_alive()
}

/// Returns `true` if the segment from `prev` to `curr` pierces the
/// sphere `(center, radius)`. This is the standard "closest point on
/// segment" test — equivalent to a swept point against a sphere.
pub fn projectile_hits_sphere(prev: Vec3, curr: Vec3, center: Vec3, radius: f32) -> bool {
    let seg = curr - prev;
    let len2 = seg.length_squared();
    if len2 < f32::EPSILON {
        return (prev - center).length_squared() <= radius * radius;
    }
    let t = ((center - prev).dot(seg) / len2).clamp(0.0, 1.0);
    let closest = prev + seg * t;
    (closest - center).length_squared() <= radius * radius
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn new_projectile_is_alive_with_default_ttl() {
        let p = Projectile::new(Vec3::ZERO, Vec3::X, 10.0, DamageType::Energy);
        assert!(p.is_alive());
        assert_eq!(p.ttl, 2.0);
    }

    #[test]
    fn advance_moves_by_velocity_and_drains_ttl() {
        let mut p = Projectile::new(
            Vec3::ZERO,
            Vec3::new(10.0, 0.0, 0.0),
            5.0,
            DamageType::Energy,
        );
        let alive = advance_projectile(&mut p, 0.1);
        assert!(alive);
        assert!((p.pos.x - 1.0).abs() < 1e-6);
        assert!((p.ttl - 1.9).abs() < 1e-6);
    }

    #[test]
    fn advance_despawns_once_ttl_expires() {
        let mut p = Projectile::new(Vec3::ZERO, Vec3::X, 5.0, DamageType::Energy).with_ttl(0.05);
        let alive = advance_projectile(&mut p, 0.1);
        assert!(!alive);
        assert!(p.ttl <= 0.0);
        // Advancing again is a no-op on a dead round.
        let still = advance_projectile(&mut p, 0.1);
        assert!(!still);
    }

    #[test]
    fn segment_through_sphere_hits() {
        // Crossing a sphere at origin along +Z.
        assert!(projectile_hits_sphere(
            Vec3::new(0.0, 0.0, -5.0),
            Vec3::new(0.0, 0.0, 5.0),
            Vec3::ZERO,
            1.0,
        ));
    }

    #[test]
    fn segment_missing_sphere_does_not_hit() {
        assert!(!projectile_hits_sphere(
            Vec3::new(0.0, 10.0, -5.0),
            Vec3::new(0.0, 10.0, 5.0),
            Vec3::ZERO,
            1.0,
        ));
    }

    #[test]
    fn segment_endpoint_inside_sphere_counts_as_hit() {
        // Projectile spawns inside the target — close enough counts.
        assert!(projectile_hits_sphere(
            Vec3::new(5.0, 0.0, 0.0),
            Vec3::new(4.5, 0.0, 0.0),
            Vec3::new(4.5, 0.0, 0.0),
            0.5,
        ));
    }

    #[test]
    fn zero_length_segment_tests_endpoint_only() {
        // Stationary projectile on top of a target.
        assert!(projectile_hits_sphere(
            Vec3::new(1.0, 0.0, 0.0),
            Vec3::new(1.0, 0.0, 0.0),
            Vec3::new(1.0, 0.0, 0.0),
            0.1,
        ));
        // And misses when stationary off-target.
        assert!(!projectile_hits_sphere(
            Vec3::new(5.0, 0.0, 0.0),
            Vec3::new(5.0, 0.0, 0.0),
            Vec3::ZERO,
            1.0,
        ));
    }

    #[test]
    fn hit_test_tolerates_fast_rounds() {
        // 500 m/s round over a 16ms step crosses 8m — and should still
        // register hits on 1m-radius targets at the midpoint.
        let prev = Vec3::new(0.0, 0.0, 0.0);
        let curr = Vec3::new(0.0, 0.0, -8.0);
        assert!(projectile_hits_sphere(
            prev,
            curr,
            Vec3::new(0.0, 0.0, -4.0),
            1.0
        ));
    }
}

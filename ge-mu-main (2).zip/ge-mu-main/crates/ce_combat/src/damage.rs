//! Damage types, shield/hull layer model, and the canonical
//! damage-resolution function.
//!
//! Shields absorb incoming damage first; overflow rolls onto the hull.
//! Different damage types are scaled via a simple two-multiplier model
//! (`shield_mult`, `hull_mult`) to give weapons personality — e.g.
//! plasma melts shields but tickles hull; kinetic does the opposite.

/// Weapon damage category.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum DamageType {
    /// Lasers — balanced.
    Energy,
    /// Railguns, mass drivers — strong vs hull, weak vs shields.
    Kinetic,
    /// Plasma, EMP — strong vs shields, weak vs hull.
    Plasma,
    /// Missiles — balanced, may ignore a portion of shields (handled
    /// upstream via piercing).
    Explosive,
}

impl DamageType {
    /// Fraction of the raw damage that actually lands against shields.
    pub fn shield_mult(&self) -> f32 {
        match self {
            DamageType::Energy => 1.0,
            DamageType::Kinetic => 0.5,
            DamageType::Plasma => 1.5,
            DamageType::Explosive => 1.0,
        }
    }

    /// Fraction of the raw damage that actually lands against hull.
    pub fn hull_mult(&self) -> f32 {
        match self {
            DamageType::Energy => 1.0,
            DamageType::Kinetic => 1.5,
            DamageType::Plasma => 0.5,
            DamageType::Explosive => 1.0,
        }
    }
}

/// Per-ship shield state. Regenerates when the gameplay layer calls
/// [`Shield::tick`] (intentionally external so this crate stays
/// side-effect-free).
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Shield {
    pub current: f32,
    pub max: f32,
    /// Regeneration rate, in hp per second.
    pub regen_per_second: f32,
    /// How long shields must idle before regen resumes, in seconds.
    pub regen_delay_seconds: f32,
    /// Internal: seconds since the last damaging hit.
    pub time_since_hit: f32,
}

impl Shield {
    pub fn new(max: f32, regen_per_second: f32, regen_delay_seconds: f32) -> Self {
        Self {
            current: max,
            max,
            regen_per_second,
            regen_delay_seconds,
            time_since_hit: regen_delay_seconds,
        }
    }

    pub fn is_down(&self) -> bool {
        self.current <= 0.0
    }

    /// Advances time. Call once per frame before or after damage
    /// resolution — order doesn't matter for correctness but the
    /// `regen_delay` means regen will only accrue when enough idle
    /// time has accumulated since the last call to [`apply_damage`].
    pub fn tick(&mut self, dt: f32) {
        self.time_since_hit += dt;
        if self.time_since_hit >= self.regen_delay_seconds {
            self.current = (self.current + self.regen_per_second * dt).min(self.max);
        }
    }
}

impl Default for Shield {
    fn default() -> Self {
        Self::new(500.0, 50.0, 3.0)
    }
}

/// Applies `raw_damage` of `dtype` to `shield` and `hull_hp`.
///
/// Returns the breakdown `(shield_damage, hull_damage)` so callers can
/// display it. The shield's `time_since_hit` is reset to zero whenever
/// any damage lands.
pub fn apply_damage(
    shield: &mut Shield,
    hull_hp: &mut f32,
    dtype: DamageType,
    raw_damage: f32,
) -> (f32, f32) {
    if raw_damage <= 0.0 {
        return (0.0, 0.0);
    }

    let shield_dmg_budget = raw_damage * dtype.shield_mult();
    let hull_dmg_budget = raw_damage * dtype.hull_mult();

    let shield_dmg = shield.current.min(shield_dmg_budget);
    shield.current = (shield.current - shield_dmg).max(0.0);

    // Fraction of the shield budget that was absorbed; the leftover
    // shield_dmg_budget spills onto the hull converted back to raw,
    // then scaled by hull multiplier.
    let shield_overflow_raw = if shield_dmg_budget > 0.0 {
        raw_damage * (1.0 - (shield_dmg / shield_dmg_budget))
    } else {
        raw_damage
    };

    // Hull damage: from the overflow, scaled by hull multiplier. When
    // the shield absorbed everything, this is zero.
    let hull_dmg = if shield.is_down() {
        (shield_overflow_raw * dtype.hull_mult()).min(*hull_hp)
    } else {
        0.0
    };
    *hull_hp = (*hull_hp - hull_dmg).max(0.0);

    if shield_dmg > 0.0 || hull_dmg > 0.0 {
        shield.time_since_hit = 0.0;
    }
    let _ = hull_dmg_budget; // reserved for a future armor layer
    (shield_dmg, hull_dmg)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn shield_starts_full_and_is_not_down() {
        let s = Shield::default();
        assert_eq!(s.current, s.max);
        assert!(!s.is_down());
    }

    #[test]
    fn damage_type_multipliers_are_complementary() {
        assert!(DamageType::Kinetic.shield_mult() < 1.0);
        assert!(DamageType::Kinetic.hull_mult() > 1.0);
        assert!(DamageType::Plasma.shield_mult() > 1.0);
        assert!(DamageType::Plasma.hull_mult() < 1.0);
    }

    #[test]
    fn energy_hits_shield_first() {
        let mut s = Shield::new(100.0, 0.0, 0.0);
        let mut hull = 500.0;
        let (sd, hd) = apply_damage(&mut s, &mut hull, DamageType::Energy, 40.0);
        assert_eq!(sd, 40.0);
        assert_eq!(hd, 0.0);
        assert_eq!(s.current, 60.0);
        assert_eq!(hull, 500.0);
    }

    #[test]
    fn overflow_damages_hull_once_shields_drop() {
        let mut s = Shield::new(20.0, 0.0, 0.0);
        let mut hull = 500.0;
        // 50 raw Energy hits a 20hp shield — 20 absorbed, 30 onto hull.
        let (sd, hd) = apply_damage(&mut s, &mut hull, DamageType::Energy, 50.0);
        assert_eq!(sd, 20.0);
        assert!(hd > 0.0);
        assert!(s.is_down());
        assert!(hull < 500.0);
    }

    #[test]
    fn zero_damage_has_no_effect() {
        let mut s = Shield::default();
        let mut hull = 500.0;
        let (sd, hd) = apply_damage(&mut s, &mut hull, DamageType::Energy, 0.0);
        assert_eq!((sd, hd), (0.0, 0.0));
        assert_eq!(s.current, s.max);
        assert_eq!(hull, 500.0);
    }

    #[test]
    fn hull_cannot_go_below_zero() {
        let mut s = Shield::new(0.0, 0.0, 0.0);
        let mut hull = 10.0;
        let (_, hd) = apply_damage(&mut s, &mut hull, DamageType::Kinetic, 999.0);
        assert!(hull == 0.0);
        assert!(hd > 0.0);
    }

    #[test]
    fn tick_regenerates_after_delay() {
        let mut s = Shield::new(100.0, 20.0, 0.5);
        s.current = 40.0;
        s.time_since_hit = 0.0;
        // First small tick: still inside the regen delay, no change.
        s.tick(0.1);
        assert_eq!(s.current, 40.0);
        // After the delay elapses, regen applies on subsequent ticks.
        s.tick(0.5); // total 0.6 since hit
        assert!(s.current > 40.0);
        assert!(s.current <= 100.0);
    }

    #[test]
    fn tick_cannot_overshoot_max() {
        let mut s = Shield::new(100.0, 10_000.0, 0.0);
        s.current = 90.0;
        s.tick(10.0);
        assert_eq!(s.current, s.max);
    }

    #[test]
    fn kinetic_weak_on_shields_leaves_more_shield_budget_vs_energy() {
        // Same raw damage, fully absorbed by shield: kinetic leaves
        // more shield standing than energy does.
        let raw = 40.0;
        let mut s_en = Shield::new(100.0, 0.0, 0.0);
        let mut s_ki = Shield::new(100.0, 0.0, 0.0);
        let mut h_en = 500.0;
        let mut h_ki = 500.0;
        apply_damage(&mut s_en, &mut h_en, DamageType::Energy, raw);
        apply_damage(&mut s_ki, &mut h_ki, DamageType::Kinetic, raw);
        assert!(s_ki.current > s_en.current);
    }

    #[test]
    fn plasma_breaks_shields_faster_than_energy() {
        let mut s_en = Shield::new(100.0, 0.0, 0.0);
        let mut s_pl = Shield::new(100.0, 0.0, 0.0);
        let mut h_en = 500.0;
        let mut h_pl = 500.0;
        apply_damage(&mut s_en, &mut h_en, DamageType::Energy, 50.0);
        apply_damage(&mut s_pl, &mut h_pl, DamageType::Plasma, 50.0);
        assert!(s_pl.current < s_en.current);
    }
}

//! `ce_combat` — weapons, shields, and damage resolution.
//!
//! Scope: pure data and pure-functional resolution. Projectile physics,
//! targeting AI, and explosion VFX live in later milestones.
//!
//! Typical flow in a later gameplay system (gated by `NetRole::
//! is_authoritative` so clients mirror server decisions):
//!
//! ```ignore
//! if cooldown.try_fire(&stats) && in_range(&stats, distance) {
//!     let (sd, hd) = apply_damage(&mut target_shield, &mut target_hull,
//!                                 stats.damage_type, stats.damage);
//! }
//! ```

pub mod damage;
pub mod projectile;
pub mod weapon;

pub use damage::{apply_damage, DamageType, Shield};
pub use projectile::{advance_projectile, projectile_hits_sphere, Projectile};
pub use weapon::{in_range, WeaponCooldown, WeaponStats};

use ce_app::{App, Plugin};

/// Stub plugin. No systems yet — weapons and shields are exposed as
/// pure functions so later gameplay crates can drive them under the
/// stage they prefer.
pub struct CombatPlugin;

impl Plugin for CombatPlugin {
    fn build(&self, _app: &mut App) {
        log::info!("CombatPlugin loaded (pure functions only; systems pending)");
    }
}

#[cfg(test)]
mod plugin_tests {
    use super::*;

    #[test]
    fn plugin_adds_cleanly() {
        let mut app = App::new();
        app.add_plugin(CombatPlugin);
    }

    #[test]
    fn end_to_end_fire_and_damage() {
        // One round out of a railgun against a lightly-shielded target.
        let stats = WeaponStats::railgun();
        let mut cooldown = WeaponCooldown::new();
        let fired = cooldown.try_fire(&stats);
        assert!(fired);
        let mut shield = Shield::new(100.0, 0.0, 0.0);
        let mut hull = 500.0;
        let (sd, hd) = apply_damage(&mut shield, &mut hull, stats.damage_type, stats.damage);
        // 250 raw * 0.5 shield mult = 125 shield budget, absorbs all 100 shield.
        // Shield drops; overflow spills onto hull.
        assert_eq!(sd, 100.0);
        assert!(shield.is_down());
        assert!(hd > 0.0);
        assert!(hull < 500.0);
    }
}

//! Weapon stats and firing cadence.
//!
//! Cooldown advances via [`WeaponCooldown::tick`]; firing is gated by
//! [`WeaponCooldown::try_fire`] which returns true and starts the
//! next cooldown when a round is ready.

use crate::damage::DamageType;

/// Per-weapon tuning values.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct WeaponStats {
    pub damage_type: DamageType,
    /// Raw damage per shot before shield / hull multipliers.
    pub damage: f32,
    /// Seconds between shots.
    pub cooldown_seconds: f32,
    /// Maximum engagement distance in meters. Beyond this, hits miss.
    pub range_meters: f32,
    /// Energy consumed per shot. Gameplay enforces the reactor budget.
    pub energy_cost: f32,
}

impl WeaponStats {
    /// Sensible starter laser turret.
    pub fn laser_turret() -> Self {
        Self {
            damage_type: DamageType::Energy,
            damage: 40.0,
            cooldown_seconds: 0.5,
            range_meters: 2_500.0,
            energy_cost: 5.0,
        }
    }

    /// Heavier, slower kinetic mount.
    pub fn railgun() -> Self {
        Self {
            damage_type: DamageType::Kinetic,
            damage: 250.0,
            cooldown_seconds: 3.0,
            range_meters: 6_000.0,
            energy_cost: 30.0,
        }
    }
}

/// Per-weapon cooldown state. A fresh instance is "ready to fire"
/// immediately; after a shot, it takes `cooldown_seconds` before the
/// next trigger succeeds.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct WeaponCooldown {
    pub remaining: f32,
}

impl WeaponCooldown {
    pub fn new() -> Self {
        Self { remaining: 0.0 }
    }

    /// True if the weapon can shoot this instant.
    pub fn is_ready(&self) -> bool {
        self.remaining <= 0.0
    }

    /// Advances cooldown by `dt` seconds.
    pub fn tick(&mut self, dt: f32) {
        self.remaining = (self.remaining - dt).max(0.0);
    }

    /// Attempts to fire. When successful, starts the next cooldown and
    /// returns `true`. When not ready, returns `false` without
    /// changing state.
    pub fn try_fire(&mut self, stats: &WeaponStats) -> bool {
        if !self.is_ready() {
            return false;
        }
        self.remaining = stats.cooldown_seconds;
        true
    }
}

impl Default for WeaponCooldown {
    fn default() -> Self {
        Self::new()
    }
}

/// Returns `true` if `range_meters` between a firer and its target is
/// within the weapon's effective range.
pub fn in_range(stats: &WeaponStats, distance_meters: f32) -> bool {
    distance_meters <= stats.range_meters
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn laser_is_energy_damage() {
        let w = WeaponStats::laser_turret();
        assert_eq!(w.damage_type, DamageType::Energy);
    }

    #[test]
    fn railgun_is_kinetic_and_stronger() {
        let w = WeaponStats::railgun();
        assert_eq!(w.damage_type, DamageType::Kinetic);
        assert!(w.damage > WeaponStats::laser_turret().damage);
    }

    #[test]
    fn fresh_cooldown_is_ready() {
        let mut c = WeaponCooldown::new();
        assert!(c.is_ready());
        assert!(c.try_fire(&WeaponStats::laser_turret()));
    }

    #[test]
    fn try_fire_engages_cooldown() {
        let mut c = WeaponCooldown::new();
        let stats = WeaponStats::laser_turret();
        assert!(c.try_fire(&stats));
        assert!(!c.is_ready());
        assert!(!c.try_fire(&stats));
    }

    #[test]
    fn tick_recharges_after_cooldown_duration() {
        let mut c = WeaponCooldown::new();
        let stats = WeaponStats::laser_turret();
        c.try_fire(&stats);
        c.tick(stats.cooldown_seconds + 0.01);
        assert!(c.is_ready());
        assert!(c.try_fire(&stats));
    }

    #[test]
    fn in_range_uses_weapon_stats() {
        let stats = WeaponStats::laser_turret();
        assert!(in_range(&stats, 0.0));
        assert!(in_range(&stats, stats.range_meters));
        assert!(!in_range(&stats, stats.range_meters + 1.0));
    }
}

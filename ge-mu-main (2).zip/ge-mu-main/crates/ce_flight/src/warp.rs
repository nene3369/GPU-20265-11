//! FTL warp state machine.
//!
//! A ship goes `Idle` → `Charging` → `InFlight` → `Idle`. Arrival
//! teleports the ship's [`WorldPos`] to the target; the
//! [`WarpEvent::Arrived`] emission lets gameplay trigger audio,
//! sector-enter logic, mission progress.

use ce_space::WorldPos;

/// Default number of seconds required to charge a jump drive. Gameplay
/// plugins may set a longer charge time based on distance / cargo mass.
pub const DEFAULT_CHARGE_SECONDS: f32 = 5.0;
/// Duration spent "in warp" visually. Short by default; the ship is
/// considered mid-jump and cannot fire or receive damage.
pub const DEFAULT_FLIGHT_SECONDS: f32 = 2.0;

/// Per-ship warp state. Attach as a component.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub enum WarpState {
    /// Warp drive is spun down. Ship accepts flight commands normally.
    #[default]
    Idle,
    /// Capacitor is charging. Ship may abort by commanding `Idle`.
    Charging { remaining: f32, target: WorldPos },
    /// Ship is translating through FTL. Cannot abort.
    InFlight { remaining: f32, target: WorldPos },
}

/// One event produced by [`step_warp`].
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum WarpEvent {
    /// Charge finished; ship just entered FTL. Useful for VFX / audio.
    Entered,
    /// Ship dropped out of warp at `target`. Gameplay should update the
    /// ship's `WorldPos` to this.
    Arrived(WorldPos),
}

/// Advances `state` by `dt` seconds. Returns an event when a phase
/// transition happens; otherwise `None`. The state itself is updated
/// in place.
pub fn step_warp(state: &mut WarpState, dt: f32) -> Option<WarpEvent> {
    match *state {
        WarpState::Idle => None,
        WarpState::Charging { remaining, target } => {
            let r = remaining - dt;
            if r <= 0.0 {
                *state = WarpState::InFlight {
                    remaining: DEFAULT_FLIGHT_SECONDS,
                    target,
                };
                Some(WarpEvent::Entered)
            } else {
                *state = WarpState::Charging {
                    remaining: r,
                    target,
                };
                None
            }
        }
        WarpState::InFlight { remaining, target } => {
            let r = remaining - dt;
            if r <= 0.0 {
                *state = WarpState::Idle;
                Some(WarpEvent::Arrived(target))
            } else {
                *state = WarpState::InFlight {
                    remaining: r,
                    target,
                };
                None
            }
        }
    }
}

/// Convenience: begins a jump to `target` with default charge time.
pub fn begin_warp(state: &mut WarpState, target: WorldPos) {
    *state = WarpState::Charging {
        remaining: DEFAULT_CHARGE_SECONDS,
        target,
    };
}

/// Aborts a charging warp. Has no effect once `InFlight`.
pub fn abort_warp(state: &mut WarpState) -> bool {
    if matches!(state, WarpState::Charging { .. }) {
        *state = WarpState::Idle;
        true
    } else {
        false
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn idle_state_step_is_noop() {
        let mut s = WarpState::Idle;
        assert_eq!(step_warp(&mut s, 10.0), None);
        assert_eq!(s, WarpState::Idle);
    }

    #[test]
    fn charge_advances_and_enters_flight() {
        let mut s = WarpState::Idle;
        let target = WorldPos::new(1e10, 0.0, 0.0);
        begin_warp(&mut s, target);
        // Partial tick: still charging.
        assert_eq!(step_warp(&mut s, 1.0), None);
        assert!(matches!(
            s,
            WarpState::Charging {
                remaining,
                ..
            } if (remaining - 4.0).abs() < 1e-3
        ));
        // Finish charge.
        let ev = step_warp(&mut s, 10.0);
        assert_eq!(ev, Some(WarpEvent::Entered));
        assert!(matches!(s, WarpState::InFlight { .. }));
    }

    #[test]
    fn flight_arrives_with_event() {
        let mut s = WarpState::InFlight {
            remaining: 0.5,
            target: WorldPos::new(42.0, 0.0, 0.0),
        };
        let ev = step_warp(&mut s, 10.0);
        assert_eq!(ev, Some(WarpEvent::Arrived(WorldPos::new(42.0, 0.0, 0.0))));
        assert_eq!(s, WarpState::Idle);
    }

    #[test]
    fn abort_works_only_during_charge() {
        let mut s = WarpState::Charging {
            remaining: 3.0,
            target: WorldPos::ZERO,
        };
        assert!(abort_warp(&mut s));
        assert_eq!(s, WarpState::Idle);

        let mut in_flight = WarpState::InFlight {
            remaining: 1.0,
            target: WorldPos::ZERO,
        };
        assert!(!abort_warp(&mut in_flight));
        assert!(matches!(in_flight, WarpState::InFlight { .. }));
    }

    #[test]
    fn full_sequence_progresses_through_three_states() {
        let mut s = WarpState::Idle;
        let target = WorldPos::new(1.0e10, 0.0, 0.0);
        begin_warp(&mut s, target);
        // Charge ends.
        let ev1 = step_warp(&mut s, DEFAULT_CHARGE_SECONDS + 0.01);
        assert_eq!(ev1, Some(WarpEvent::Entered));
        // Flight ends.
        let ev2 = step_warp(&mut s, DEFAULT_FLIGHT_SECONDS + 0.01);
        assert_eq!(ev2, Some(WarpEvent::Arrived(target)));
        // Back to idle.
        assert_eq!(s, WarpState::Idle);
    }

    #[test]
    fn small_ticks_do_not_skip_phases() {
        let mut s = WarpState::Idle;
        begin_warp(&mut s, WorldPos::ZERO);
        for _ in 0..10 {
            // 0.1s ticks for 1s total — still charging.
            assert_eq!(step_warp(&mut s, 0.1), None);
        }
        assert!(matches!(s, WarpState::Charging { .. }));
    }
}

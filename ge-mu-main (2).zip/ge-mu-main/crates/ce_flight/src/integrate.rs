//! Pure integrator: command + ship mass + thrust budget → new velocity.
//!
//! Kept as a free function so it can be unit-tested without an ECS
//! world. ECS systems call it from the `FixedUpdate` stage.

use ce_math::Vec3;
use ce_ship::{MassProperties, ThrustBudget};

use crate::command::FlightCommand;

/// Flight-assist damping factor per-second (per-axis). With 60 Hz
/// fixed steps this corresponds to ≈2% velocity decay per frame —
/// tight enough to feel crisp but without over-damping.
pub const ASSIST_DAMPING_PER_SECOND: f32 = 0.7;

/// Returns the new linear velocity after applying `command` for `dt`
/// seconds. Axis-aligned per-face thrust capacities are used: commanding
/// `-0.5` on X uses the `neg_x` budget; `+0.5` uses `pos_x`.
pub fn integrate_linear(
    command: &FlightCommand,
    budget: &ThrustBudget,
    mass: &MassProperties,
    current_velocity: Vec3,
) -> Vec3 {
    // This helper returns instantaneous acceleration for a fixed dt.
    // Callers that want new velocity should use `advance_linear`.
    let _ = current_velocity;
    let t = command.clamped().linear;
    let fx = axis_force(t.x, budget.pos_x, budget.neg_x);
    let fy = axis_force(t.y, budget.pos_y, budget.neg_y);
    let fz = axis_force(t.z, budget.pos_z, budget.neg_z);
    if mass.mass <= 0.0 {
        return Vec3::ZERO;
    }
    Vec3::new(fx, fy, fz) / mass.mass
}

/// Advances `current_velocity` by one `dt` step of `command`.
/// Includes flight-assist damping when the command's `assist` flag is on.
pub fn advance_linear(
    command: &FlightCommand,
    budget: &ThrustBudget,
    mass: &MassProperties,
    current_velocity: Vec3,
    dt: f32,
) -> Vec3 {
    let a = integrate_linear(command, budget, mass, current_velocity);
    let mut v = current_velocity + a * dt;

    if command.assist {
        // Exponential damping: fraction kept per second.
        let keep = ASSIST_DAMPING_PER_SECOND.powf(dt);
        v *= keep;
    }
    v
}

/// Advances ship-local angular velocity. The pilot's `command.angular`
/// is treated as the *desired* angular velocity (rad/s) on each axis;
/// when present it snaps the velocity directly so input feels crisp.
/// When the command is zero and `assist` is on, angular velocity decays
/// exponentially toward rest (same constant as the linear integrator).
pub fn advance_angular(command: &FlightCommand, current_angular_vel: Vec3, dt: f32) -> Vec3 {
    let target = command.angular;
    let mut v = if target.length_squared() > 1e-6 {
        target
    } else {
        current_angular_vel
    };
    if command.assist && target.length_squared() < 1e-6 {
        let keep = ASSIST_DAMPING_PER_SECOND.powf(dt);
        v *= keep;
    }
    v
}

#[inline]
fn axis_force(throttle: f32, pos_budget: f32, neg_budget: f32) -> f32 {
    if throttle >= 0.0 {
        pos_budget * throttle
    } else {
        neg_budget * throttle // sign follows throttle
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ce_math::IVec3;
    use ce_ship::{
        compute_mass_properties, compute_thrust_budget, Block, BlockKind, BlockMaterial, Facing,
        ShipBlocks,
    };

    fn ship_with_east_thrust() -> (MassProperties, ThrustBudget) {
        let mut g = ShipBlocks::new();
        g.insert(
            IVec3::ZERO,
            Block::new(BlockKind::Hull, BlockMaterial::Iron),
        );
        g.insert(
            IVec3::new(-1, 0, 0),
            Block::new(BlockKind::Thruster, BlockMaterial::Iron).with_facing(Facing::East),
        );
        (compute_mass_properties(&g), compute_thrust_budget(&g))
    }

    #[test]
    fn zero_command_produces_zero_acceleration() {
        let (m, b) = ship_with_east_thrust();
        let a = integrate_linear(&FlightCommand::new(), &b, &m, Vec3::ZERO);
        assert_eq!(a, Vec3::ZERO);
    }

    #[test]
    fn positive_x_throttle_accelerates_positive_x() {
        let (m, b) = ship_with_east_thrust();
        let cmd = FlightCommand::new().with_linear(Vec3::new(1.0, 0.0, 0.0));
        let a = integrate_linear(&cmd, &b, &m, Vec3::ZERO);
        assert!(a.x > 0.0);
        assert_eq!(a.y, 0.0);
        assert_eq!(a.z, 0.0);
    }

    #[test]
    fn negative_throttle_with_no_neg_budget_is_zero() {
        // Ship has only East-facing thrusters; commanding -X should
        // produce no force.
        let (m, b) = ship_with_east_thrust();
        let cmd = FlightCommand::new().with_linear(Vec3::new(-1.0, 0.0, 0.0));
        let a = integrate_linear(&cmd, &b, &m, Vec3::ZERO);
        assert_eq!(a, Vec3::ZERO);
    }

    #[test]
    fn acceleration_scales_with_throttle_magnitude() {
        let (m, b) = ship_with_east_thrust();
        let half = FlightCommand::new().with_linear(Vec3::new(0.5, 0.0, 0.0));
        let full = FlightCommand::new().with_linear(Vec3::new(1.0, 0.0, 0.0));
        let a_half = integrate_linear(&half, &b, &m, Vec3::ZERO);
        let a_full = integrate_linear(&full, &b, &m, Vec3::ZERO);
        assert!((a_full.x - 2.0 * a_half.x).abs() < 1e-3);
    }

    #[test]
    fn clamped_throttle_does_not_exceed_budget() {
        let (m, b) = ship_with_east_thrust();
        let over = FlightCommand::new().with_linear(Vec3::new(5.0, 0.0, 0.0));
        let full = FlightCommand::new().with_linear(Vec3::new(1.0, 0.0, 0.0));
        let a_over = integrate_linear(&over, &b, &m, Vec3::ZERO);
        let a_full = integrate_linear(&full, &b, &m, Vec3::ZERO);
        assert!((a_over.x - a_full.x).abs() < 1e-3);
    }

    #[test]
    fn advance_linear_integrates_velocity_over_time() {
        let (m, b) = ship_with_east_thrust();
        let cmd = FlightCommand::new().with_linear(Vec3::new(1.0, 0.0, 0.0));
        let v0 = Vec3::ZERO;
        let v1 = advance_linear(&cmd, &b, &m, v0, 1.0);
        let v2 = advance_linear(&cmd, &b, &m, v1, 1.0);
        // Linear acceleration with no damping: v1 == a*dt, v2 == 2*a*dt.
        assert!((v2.x - 2.0 * v1.x).abs() < 1e-3);
    }

    #[test]
    fn assist_damps_drifting_velocity() {
        let (m, b) = ship_with_east_thrust();
        let cmd = FlightCommand::new().with_assist(true);
        let v0 = Vec3::new(10.0, 0.0, 0.0);
        let v1 = advance_linear(&cmd, &b, &m, v0, 1.0);
        // With assist damping ≈0.7/s, velocity should drop to ≈7 m/s
        // after one second with zero throttle.
        assert!((v1.x - 7.0).abs() < 0.2);
    }

    #[test]
    fn angular_command_snaps_velocity_to_target() {
        let cmd = FlightCommand::new().with_angular(Vec3::new(0.0, 1.5, 0.0));
        let v = advance_angular(&cmd, Vec3::ZERO, 0.016);
        assert_eq!(v, Vec3::new(0.0, 1.5, 0.0));
    }

    #[test]
    fn angular_zero_command_with_assist_decays_velocity() {
        let cmd = FlightCommand::new().with_assist(true);
        let v = advance_angular(&cmd, Vec3::new(0.0, 1.0, 0.0), 1.0);
        // Decays toward zero, but not exactly zero in one step.
        assert!(v.y < 1.0 && v.y > 0.0);
    }

    #[test]
    fn angular_zero_command_without_assist_holds_velocity() {
        let cmd = FlightCommand::new();
        let v = advance_angular(&cmd, Vec3::new(0.0, 1.0, 0.0), 1.0);
        assert_eq!(v, Vec3::new(0.0, 1.0, 0.0));
    }

    #[test]
    fn zero_mass_ship_stays_put() {
        let empty = ShipBlocks::new();
        let mass = compute_mass_properties(&empty);
        let budget = compute_thrust_budget(&empty);
        let cmd = FlightCommand::new().with_linear(Vec3::X);
        let a = integrate_linear(&cmd, &budget, &mass, Vec3::ZERO);
        assert_eq!(a, Vec3::ZERO);
    }
}

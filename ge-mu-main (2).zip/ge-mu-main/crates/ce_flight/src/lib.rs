//! `ce_flight` — pilot input → ship motion + FTL warp state.
//!
//! Connects the building blocks from earlier milestones:
//! - [`ce_ship::ShipBlocks`] → [`ce_ship::MassProperties`] and
//!   [`ce_ship::ThrustBudget`] feed the integrator.
//! - [`ce_space::WorldPos`] is the target of warp jumps.
//!
//! Intentionally small: the integrator is a pure function, warp is a
//! tiny state machine, and the plugin just holds the wiring. Weapons,
//! docking, and multi-ship autopilot live in later milestones.

pub mod command;
pub mod integrate;
pub mod warp;

pub use command::FlightCommand;
pub use integrate::{advance_angular, advance_linear, integrate_linear, ASSIST_DAMPING_PER_SECOND};
pub use warp::{
    abort_warp, begin_warp, step_warp, WarpEvent, WarpState, DEFAULT_CHARGE_SECONDS,
    DEFAULT_FLIGHT_SECONDS,
};

use ce_app::{App, Plugin};

/// Stub plugin. The integrator is exposed as a free function so
/// gameplay code can choose when and for whom to apply it (e.g. only
/// on the authoritative server in multiplayer). A system that walks
/// the world and calls `advance_linear` for every flown ship lands in
/// a later milestone, once there is a concrete ship entity schema.
pub struct FlightPlugin;

impl Plugin for FlightPlugin {
    fn build(&self, _app: &mut App) {
        log::info!("FlightPlugin loaded (integrator available; systems pending)");
    }
}

#[cfg(test)]
mod plugin_tests {
    use super::*;

    #[test]
    fn plugin_adds_cleanly() {
        let mut app = App::new();
        app.add_plugin(FlightPlugin);
    }
}

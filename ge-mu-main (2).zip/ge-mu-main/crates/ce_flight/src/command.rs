//! Pilot input → ship motion.
//!
//! [`FlightCommand`] is a per-ship component populated by whoever's
//! flying (player input, remote authoritative state, or AI). The
//! integrator in `integrate.rs` converts it into a velocity delta.

use ce_math::Vec3;

/// Per-frame pilot command. Throttle values are clamped to `[-1, 1]`.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct FlightCommand {
    /// Desired per-axis linear thrust, ship-local. `+x` strafe right,
    /// `+y` up, `+z` backward (since `Facing::North = -Z` is forward).
    pub linear: Vec3,
    /// Desired angular velocity in rad/s per axis: pitch (around X),
    /// yaw (around Y), roll (around Z).
    pub angular: Vec3,
    /// When true the integrator applies flight-assist damping so an
    /// unpiloted stick returns the ship to rest. Off = Newtonian.
    pub assist: bool,
}

impl FlightCommand {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn with_linear(mut self, l: Vec3) -> Self {
        self.linear = l;
        self
    }

    pub fn with_angular(mut self, a: Vec3) -> Self {
        self.angular = a;
        self
    }

    pub fn with_assist(mut self, assist: bool) -> Self {
        self.assist = assist;
        self
    }

    /// Returns a copy of this command with throttle clamped to unit
    /// magnitude per axis.
    pub fn clamped(&self) -> Self {
        Self {
            linear: self.linear.clamp(Vec3::splat(-1.0), Vec3::splat(1.0)),
            angular: self.angular,
            assist: self.assist,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_is_all_zero() {
        let c = FlightCommand::new();
        assert_eq!(c.linear, Vec3::ZERO);
        assert_eq!(c.angular, Vec3::ZERO);
        assert!(!c.assist);
    }

    #[test]
    fn clamped_saturates_at_unit_magnitude() {
        let c = FlightCommand::new()
            .with_linear(Vec3::new(3.0, -2.0, 0.5))
            .clamped();
        assert_eq!(c.linear, Vec3::new(1.0, -1.0, 0.5));
    }
}

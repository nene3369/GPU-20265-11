//! Procedural terrain height + temperature / humidity fields.
//!
//! All sampling derives from the planet's `seed`. Same seed → same
//! planet, across save/load and between server and client.

use crate::noise::fbm_3d;
use crate::planet::Planet;

/// Returns surface elevation (meters relative to `planet.radius_m`)
/// at the given `(lat, lon)`.
///
/// Positive values are above the reference radius; negative are below
/// (ocean floor terrain). The result is clamped to `±max_elevation_m`.
pub fn surface_elevation(planet: &Planet, lat: f64, lon: f64) -> f64 {
    // Sample along the unit sphere so adjacent lat/lon pairs hit
    // adjacent noise space.
    let x = lat.cos() * lon.sin();
    let y = lat.sin();
    let z = lat.cos() * lon.cos();
    let scale = 3.0; // controls base noise wavelength
    let raw = fbm_3d(planet.seed, x * scale, y * scale, z * scale, 5);
    // Remap [0, 1] → [-1, 1] so half of the planet sits below sea level.
    let signed = raw * 2.0 - 1.0;
    signed * planet.max_elevation_m
}

/// Surface temperature in degrees Celsius at `(lat, lon, altitude_m)`.
///
/// Drops linearly with absolute latitude and with altitude (≈ 6.5 °C
/// per km for the troposphere).
pub fn surface_temperature_c(planet: &Planet, lat: f64, _lon: f64, altitude_m: f64) -> f32 {
    let latitude_factor = 1.0 - (lat.abs() / std::f64::consts::FRAC_PI_2).min(1.0);
    let base = planet.temperature_pole_c as f64
        + (planet.temperature_equator_c - planet.temperature_pole_c) as f64 * latitude_factor;
    let lapse = (altitude_m.max(0.0) / 1_000.0) * 6.5;
    (base - lapse) as f32
}

/// Surface humidity in `[0, 1]`. A second noise field, independent of
/// elevation, so deserts and swamps can sit at the same altitude.
pub fn surface_humidity(planet: &Planet, lat: f64, lon: f64) -> f32 {
    let x = lat.cos() * lon.sin();
    let y = lat.sin();
    let z = lat.cos() * lon.cos();
    // A different seed salt for the humidity field.
    let seed = planet.seed.wrapping_add(0xA5A5_A5A5_A5A5_A5A5);
    let raw = fbm_3d(seed, x * 2.0, y * 2.0, z * 2.0, 4);
    raw as f32
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::planet::PlanetId;
    use ce_space::WorldPos;

    fn earth() -> Planet {
        Planet::earth_like(PlanetId(1), WorldPos::ZERO, 42)
    }

    #[test]
    fn surface_elevation_is_within_max() {
        let p = earth();
        for i in 0..50 {
            let lat = (i as f64 / 50.0 - 0.5) * std::f64::consts::PI;
            let lon = (i as f64 / 25.0) * std::f64::consts::PI;
            let e = surface_elevation(&p, lat, lon);
            assert!(e.abs() <= p.max_elevation_m + 1.0, "e = {e} at {lat},{lon}");
        }
    }

    #[test]
    fn surface_elevation_is_deterministic() {
        let p = earth();
        let a = surface_elevation(&p, 0.3, 0.2);
        let b = surface_elevation(&p, 0.3, 0.2);
        assert_eq!(a, b);
    }

    #[test]
    fn equator_is_warmer_than_poles() {
        let p = earth();
        let t_eq = surface_temperature_c(&p, 0.0, 0.0, 0.0);
        let t_pole = surface_temperature_c(&p, std::f64::consts::FRAC_PI_2, 0.0, 0.0);
        assert!(t_eq > t_pole);
    }

    #[test]
    fn altitude_cools_temperature() {
        let p = earth();
        let t_low = surface_temperature_c(&p, 0.0, 0.0, 0.0);
        let t_high = surface_temperature_c(&p, 0.0, 0.0, 5_000.0);
        assert!(t_high < t_low);
        // ~6.5 °C per km: at 5 km drop should be ≈ 32.5 °C.
        assert!((t_low - t_high - 32.5).abs() < 1.0);
    }

    #[test]
    fn humidity_is_in_unit_range() {
        let p = earth();
        for i in 0..20 {
            let lat = i as f64 / 10.0 - 1.0;
            let lon = i as f64 / 3.0;
            let h = surface_humidity(&p, lat, lon);
            assert!((0.0..=1.0).contains(&h));
        }
    }

    #[test]
    fn different_seeds_produce_different_terrain() {
        let p1 = Planet::earth_like(PlanetId(1), WorldPos::ZERO, 1);
        let p2 = Planet::earth_like(PlanetId(1), WorldPos::ZERO, 2);
        let e1 = surface_elevation(&p1, 0.0, 0.0);
        let e2 = surface_elevation(&p2, 0.0, 0.0);
        assert_ne!(e1, e2);
    }
}

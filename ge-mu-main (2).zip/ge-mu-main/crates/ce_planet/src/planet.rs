//! Planet body definition.

use ce_space::WorldPos;
use glam::DVec3;

/// Identifier for a planet (procedural, per-galaxy-seed).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct PlanetId(pub u64);

/// One procedurally-generated celestial body.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Planet {
    pub id: PlanetId,
    /// Centre in the galactic frame.
    pub center: WorldPos,
    /// Radius of the reference sphere, meters.
    pub radius_m: f64,
    /// Rotation axis (unit length, pointing at north pole).
    pub axis: DVec3,
    /// Seconds per full rotation (solar day).
    pub day_seconds: f64,
    /// Altitude (below reference radius) considered sea level for the
    /// biome classifier. Negative = below reference, positive = above.
    pub sea_level_offset_m: f64,
    /// Maximum terrain elevation relative to `radius_m`. Noise amplitude.
    pub max_elevation_m: f64,
    /// Surface freeze/boil range, used by the biome temperature curve.
    /// `temperature_equator_c` at the equator decays to
    /// `temperature_pole_c` at the poles.
    pub temperature_equator_c: f32,
    pub temperature_pole_c: f32,
    /// Procedural noise seed.
    pub seed: u64,
}

impl Planet {
    /// Constructs an Earth-ish default planet at `center` with `seed`.
    pub fn earth_like(id: PlanetId, center: WorldPos, seed: u64) -> Self {
        Self {
            id,
            center,
            radius_m: 6_371_000.0,
            axis: DVec3::Y,
            day_seconds: 86_400.0,
            sea_level_offset_m: 0.0,
            max_elevation_m: 8_848.0,
            temperature_equator_c: 30.0,
            temperature_pole_c: -40.0,
            seed,
        }
    }

    /// Altitude at which transitioning between surface / atmosphere /
    /// space regimes happens. Default: 100 km (Karman line-ish).
    pub fn atmosphere_top_m(&self) -> f64 {
        100_000.0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn earth_like_has_reasonable_defaults() {
        let p = Planet::earth_like(PlanetId(1), WorldPos::ZERO, 42);
        assert!((p.radius_m - 6_371_000.0).abs() < 1.0);
        assert_eq!(p.axis, DVec3::Y);
        assert!(p.max_elevation_m > 0.0);
        assert!(p.temperature_equator_c > p.temperature_pole_c);
    }

    #[test]
    fn atmosphere_top_is_above_surface() {
        let p = Planet::earth_like(PlanetId(1), WorldPos::ZERO, 0);
        assert!(p.atmosphere_top_m() > 0.0);
    }
}

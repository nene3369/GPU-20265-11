//! Biome classification — the readable label for a surface tile.

use crate::planet::Planet;
use crate::terrain::{surface_elevation, surface_humidity, surface_temperature_c};

/// Canonical biome labels.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Biome {
    /// Liquid water ocean (below sea level, moderate temperature).
    Ocean,
    /// Frozen ocean or polar ice cap.
    Ice,
    /// Hot and dry; sand or rock.
    Desert,
    /// Dense vegetation, warm and wet.
    RainForest,
    /// Mixed forest, temperate.
    Forest,
    /// Grass + scattered trees, temperate.
    Grassland,
    /// Cold and dry; sparse vegetation.
    Tundra,
    /// High altitude rock and ice, any latitude.
    Mountain,
    /// Molten surface — uninhabitable.
    Lava,
    /// Airless dust/rock, no atmosphere or very thin.
    Barren,
}

/// Classifies a surface cell given environmental variables.
///
/// Temperature is in °C; humidity `[0, 1]`; altitude in meters above
/// sea level; atmospheric pressure `[0, 1]` where 0 = vacuum and 1 =
/// Earth sea-level.
pub fn classify(
    temperature_c: f32,
    humidity: f32,
    altitude_m: f64,
    atmosphere_pressure: f32,
) -> Biome {
    if atmosphere_pressure < 0.05 {
        return if temperature_c > 200.0 {
            Biome::Lava
        } else {
            Biome::Barren
        };
    }
    if altitude_m < 0.0 {
        return if temperature_c < -2.0 {
            Biome::Ice
        } else {
            Biome::Ocean
        };
    }
    if altitude_m > 3_500.0 {
        return Biome::Mountain;
    }
    if temperature_c > 100.0 {
        return Biome::Lava;
    }
    match (temperature_c, humidity) {
        (t, _) if t < -10.0 => Biome::Tundra,
        (t, h) if t > 30.0 && h < 0.3 => Biome::Desert,
        (t, h) if t > 22.0 && h > 0.6 => Biome::RainForest,
        (t, h) if t > 5.0 && h > 0.35 => Biome::Forest,
        (_, _) => Biome::Grassland,
    }
}

/// Convenience: classify by planet + lat/lon, computing the
/// environmental inputs from the terrain + temperature fields. Assumes
/// a breathable atmosphere.
pub fn classify_at(planet: &Planet, lat: f64, lon: f64) -> Biome {
    let altitude = surface_elevation(planet, lat, lon);
    let temperature = surface_temperature_c(planet, lat, lon, altitude.max(0.0));
    let humidity = surface_humidity(planet, lat, lon);
    classify(temperature, humidity, altitude, 1.0)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::planet::PlanetId;
    use ce_space::WorldPos;

    #[test]
    fn vacuum_with_cool_surface_is_barren() {
        assert_eq!(classify(0.0, 0.5, 0.0, 0.0), Biome::Barren);
    }

    #[test]
    fn vacuum_with_molten_surface_is_lava() {
        assert_eq!(classify(500.0, 0.0, 0.0, 0.0), Biome::Lava);
    }

    #[test]
    fn underwater_above_zero_is_ocean_below_zero_is_ice() {
        assert_eq!(classify(10.0, 0.5, -100.0, 1.0), Biome::Ocean);
        assert_eq!(classify(-5.0, 0.5, -100.0, 1.0), Biome::Ice);
    }

    #[test]
    fn high_altitude_is_mountain() {
        assert_eq!(classify(5.0, 0.5, 4_000.0, 1.0), Biome::Mountain);
    }

    #[test]
    fn hot_dry_is_desert() {
        assert_eq!(classify(40.0, 0.1, 0.0, 1.0), Biome::Desert);
    }

    #[test]
    fn hot_wet_is_rain_forest() {
        assert_eq!(classify(27.0, 0.8, 0.0, 1.0), Biome::RainForest);
    }

    #[test]
    fn cold_is_tundra() {
        assert_eq!(classify(-20.0, 0.5, 0.0, 1.0), Biome::Tundra);
    }

    #[test]
    fn temperate_humid_is_forest() {
        assert_eq!(classify(15.0, 0.6, 0.0, 1.0), Biome::Forest);
    }

    #[test]
    fn temperate_dry_is_grassland() {
        assert_eq!(classify(15.0, 0.2, 0.0, 1.0), Biome::Grassland);
    }

    #[test]
    fn classify_at_is_deterministic() {
        let p = Planet::earth_like(PlanetId(1), WorldPos::ZERO, 123);
        let a = classify_at(&p, 0.2, 1.0);
        let b = classify_at(&p, 0.2, 1.0);
        assert_eq!(a, b);
    }

    #[test]
    fn classify_at_produces_variety_on_earth() {
        let p = Planet::earth_like(PlanetId(1), WorldPos::ZERO, 17);
        let mut biomes = std::collections::HashSet::new();
        for i in 0..30 {
            for j in 0..30 {
                let lat = (i as f64 / 30.0 - 0.5) * std::f64::consts::PI;
                let lon = (j as f64 / 30.0 - 0.5) * 2.0 * std::f64::consts::PI;
                biomes.insert(classify_at(&p, lat, lon));
            }
        }
        assert!(
            biomes.len() >= 3,
            "Earth-like planet should cover several biomes, got {biomes:?}"
        );
    }
}

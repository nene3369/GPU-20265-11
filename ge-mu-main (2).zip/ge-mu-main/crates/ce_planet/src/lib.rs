//! `ce_planet` — spherical planet data layer.
//!
//! M16 scope:
//! - `Planet` body definition keyed by `PlanetId`.
//! - Lat/lon ↔ world-space conversion aligned to each planet's axis.
//! - Deterministic hash-based value / fBm noise (no dependencies).
//! - Procedural surface elevation, temperature, humidity from seed.
//! - `Biome` classifier.
//! - `ScaleRegime` transition (`OnSurface` / `InAtmosphere` / `InSpace`).
//!
//! Actual terrain meshing (cubesphere + LOD) and rendering live in a
//! later milestone that touches `ce_render`; this crate stays
//! headless-testable and codec-agnostic for snapshots / saves.

pub mod biome;
pub mod coords;
pub mod noise;
pub mod planet;
pub mod regime;
pub mod terrain;

pub use biome::{classify, classify_at, Biome};
pub use coords::{to_lat_lon_altitude, world_position};
pub use noise::{fbm_3d, value_noise_3d};
pub use planet::{Planet, PlanetId};
pub use regime::{regime_at, regime_at_altitude, ScaleRegime, SURFACE_PROXIMITY_M};
pub use terrain::{surface_elevation, surface_humidity, surface_temperature_c};

use ce_app::{App, Plugin};

/// Stub plugin. Planets are data-only right now; the gameplay layer
/// spawns planet entities and attaches `Planet` as a component. The
/// plugin doesn't install any systems yet — rendering, LOD, and
/// terrain meshing arrive in later milestones.
pub struct PlanetPlugin;

impl Plugin for PlanetPlugin {
    fn build(&self, _app: &mut App) {
        log::info!("PlanetPlugin loaded (data layer only)");
    }
}

#[cfg(test)]
mod plugin_tests {
    use super::*;

    #[test]
    fn plugin_adds_cleanly() {
        let mut app = App::new();
        app.add_plugin(PlanetPlugin);
    }
}

//! Latitude/longitude ↔ world-space conversions.
//!
//! Latitude is in radians, `-π/2..π/2` (south pole to north). Longitude
//! is `-π..π`. `altitude_m` is meters above the reference radius.

use ce_space::WorldPos;
use glam::DVec3;

use crate::planet::Planet;

/// Returns the galactic-frame position of a point on (or above) the
/// planet at `(lat, lon, altitude_m)`.
///
/// The sphere is aligned so the planet's `axis` is the north pole.
/// For the default axis = DVec3::Y, this reduces to the familiar
/// spherical mapping.
pub fn world_position(planet: &Planet, lat: f64, lon: f64, altitude_m: f64) -> WorldPos {
    let r = planet.radius_m + altitude_m;
    let cos_lat = lat.cos();
    // Build an orthonormal basis aligned to `axis`.
    let up = planet.axis.normalize_or_zero();
    let ref_vec = if up.x.abs() < 0.9 { DVec3::X } else { DVec3::Y };
    let east = up.cross(ref_vec).normalize_or_zero();
    let north_on_equator = east.cross(up).normalize_or_zero();

    let offset = up * (r * lat.sin())
        + east * (r * cos_lat * lon.sin())
        + north_on_equator * (r * cos_lat * lon.cos());

    planet.center + offset
}

/// Returns the `(latitude, longitude, altitude_m)` of `pos` relative to
/// `planet`. Altitude is signed: negative values are below the
/// reference sphere.
pub fn to_lat_lon_altitude(planet: &Planet, pos: WorldPos) -> (f64, f64, f64) {
    let delta = pos - planet.center;
    let distance = delta.length();
    let up = planet.axis.normalize_or_zero();
    let ref_vec = if up.x.abs() < 0.9 { DVec3::X } else { DVec3::Y };
    let east = up.cross(ref_vec).normalize_or_zero();
    let north_on_equator = east.cross(up).normalize_or_zero();

    if distance < 1e-9 {
        return (0.0, 0.0, -planet.radius_m);
    }
    let dir = delta / distance;
    let sin_lat = dir.dot(up).clamp(-1.0, 1.0);
    let lat = sin_lat.asin();
    let horiz_e = dir.dot(east);
    let horiz_n = dir.dot(north_on_equator);
    let lon = horiz_e.atan2(horiz_n);
    let altitude_m = distance - planet.radius_m;
    (lat, lon, altitude_m)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::planet::PlanetId;

    fn earth() -> Planet {
        Planet::earth_like(PlanetId(1), WorldPos::ZERO, 0)
    }

    #[test]
    fn equator_point_is_on_reference_sphere() {
        let p = earth();
        let pos = world_position(&p, 0.0, 0.0, 0.0);
        let d = (pos - p.center).length();
        assert!((d - p.radius_m).abs() < 1e-3);
    }

    #[test]
    fn north_pole_aligns_with_axis() {
        let p = earth();
        let pos = world_position(&p, std::f64::consts::FRAC_PI_2, 0.0, 0.0);
        let dir = (pos - p.center).normalize();
        // Axis is Y by default; pole sits on Y axis.
        assert!((dir.y - 1.0).abs() < 1e-6);
    }

    #[test]
    fn round_trip_preserves_coordinates() {
        let p = earth();
        for &(lat, lon) in &[
            (0.0, 0.0),
            (0.5, -1.0),
            (-1.2, 2.5),
            (std::f64::consts::FRAC_PI_3, 0.0),
        ] {
            let pos = world_position(&p, lat, lon, 1000.0);
            let (lat2, lon2, alt2) = to_lat_lon_altitude(&p, pos);
            assert!((lat - lat2).abs() < 1e-6, "lat {lat} ↔ {lat2}");
            assert!((lon - lon2).abs() < 1e-6, "lon {lon} ↔ {lon2}");
            assert!((alt2 - 1000.0).abs() < 1e-3);
        }
    }

    #[test]
    fn altitude_is_signed_correctly() {
        let p = earth();
        let above = world_position(&p, 0.0, 0.0, 500.0);
        let (_, _, alt) = to_lat_lon_altitude(&p, above);
        assert!((alt - 500.0).abs() < 1e-3);

        let below = world_position(&p, 0.0, 0.0, -500.0);
        let (_, _, alt) = to_lat_lon_altitude(&p, below);
        assert!((alt + 500.0).abs() < 1e-3);
    }

    #[test]
    fn to_lat_lon_at_center_is_graceful() {
        let p = earth();
        let (lat, lon, alt) = to_lat_lon_altitude(&p, p.center);
        assert!(lat.is_finite() && lon.is_finite() && alt.is_finite());
    }
}

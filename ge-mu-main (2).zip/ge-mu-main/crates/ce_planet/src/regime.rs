//! Scale regime — which "zone" of a planet an object is currently in.
//!
//! Used by rendering / physics / gameplay code to pick the right
//! update path (e.g. spherical terrain LOD vs orbital keplerian motion).

use ce_space::WorldPos;

use crate::coords::to_lat_lon_altitude;
use crate::planet::Planet;

/// The three scale regimes a player can be in relative to a planet.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ScaleRegime {
    /// Within a few meters of the surface — walk mode.
    OnSurface,
    /// Between surface and `atmosphere_top_m` — flight / re-entry.
    InAtmosphere,
    /// Above the atmosphere — orbital / space mode.
    InSpace,
}

/// How close (meters) to the surface counts as `OnSurface`.
pub const SURFACE_PROXIMITY_M: f64 = 2.0;

/// Returns the regime at `altitude_m` above the reference radius.
pub fn regime_at_altitude(planet: &Planet, altitude_m: f64) -> ScaleRegime {
    if altitude_m <= SURFACE_PROXIMITY_M {
        ScaleRegime::OnSurface
    } else if altitude_m < planet.atmosphere_top_m() {
        ScaleRegime::InAtmosphere
    } else {
        ScaleRegime::InSpace
    }
}

/// Convenience: regime for a world-space position.
pub fn regime_at(planet: &Planet, pos: WorldPos) -> ScaleRegime {
    let (_, _, alt) = to_lat_lon_altitude(planet, pos);
    regime_at_altitude(planet, alt)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::coords::world_position;
    use crate::planet::PlanetId;

    fn earth() -> Planet {
        Planet::earth_like(PlanetId(1), WorldPos::ZERO, 0)
    }

    #[test]
    fn sea_level_is_on_surface() {
        let p = earth();
        assert_eq!(regime_at_altitude(&p, 0.0), ScaleRegime::OnSurface);
    }

    #[test]
    fn stratosphere_is_in_atmosphere() {
        let p = earth();
        assert_eq!(regime_at_altitude(&p, 30_000.0), ScaleRegime::InAtmosphere);
    }

    #[test]
    fn above_karman_line_is_in_space() {
        let p = earth();
        assert_eq!(regime_at_altitude(&p, 200_000.0), ScaleRegime::InSpace);
    }

    #[test]
    fn regime_at_matches_regime_at_altitude() {
        let p = earth();
        let pos = world_position(&p, 0.0, 0.0, 50_000.0);
        assert_eq!(regime_at(&p, pos), ScaleRegime::InAtmosphere);
    }
}

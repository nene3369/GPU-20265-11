//! Deterministic hash-based value noise.
//!
//! Enough for surface heightfields; no external dependency. Not suited
//! for production-quality terrain — swap in a better Perlin/simplex
//! implementation later without changing the public API.

/// Cheap 64-bit hash used as the noise source. Mixes the coordinates
/// with the seed so different planets get different surfaces.
fn hash64(seed: u64, ix: i64, iy: i64, iz: i64) -> u64 {
    let mut h = seed.wrapping_mul(0x9E37_79B9_7F4A_7C15);
    h = h
        .wrapping_add(ix as u64)
        .wrapping_mul(0xBF58_476D_1CE4_E5B9);
    h = h
        .wrapping_add(iy as u64)
        .wrapping_mul(0x94D0_49BB_1331_11EB);
    h = h
        .wrapping_add(iz as u64)
        .wrapping_mul(0x2545_F491_4F6C_DD1D);
    h ^= h >> 33;
    h
}

/// Returns a deterministic pseudo-random float in `[0, 1]` for the
/// integer lattice point `(ix, iy, iz)`.
fn grid_random(seed: u64, ix: i64, iy: i64, iz: i64) -> f64 {
    let h = hash64(seed, ix, iy, iz);
    (h >> 11) as f64 / (1u64 << 53) as f64
}

fn smoothstep(t: f64) -> f64 {
    t * t * (3.0 - 2.0 * t)
}

fn lerp(a: f64, b: f64, t: f64) -> f64 {
    a + (b - a) * t
}

/// Trilinear value noise at `(x, y, z)` (grid spacing 1).
/// Returns a value in `[0, 1]`.
pub fn value_noise_3d(seed: u64, x: f64, y: f64, z: f64) -> f64 {
    let ix = x.floor() as i64;
    let iy = y.floor() as i64;
    let iz = z.floor() as i64;
    let fx = smoothstep(x - ix as f64);
    let fy = smoothstep(y - iy as f64);
    let fz = smoothstep(z - iz as f64);

    let c000 = grid_random(seed, ix, iy, iz);
    let c100 = grid_random(seed, ix + 1, iy, iz);
    let c010 = grid_random(seed, ix, iy + 1, iz);
    let c110 = grid_random(seed, ix + 1, iy + 1, iz);
    let c001 = grid_random(seed, ix, iy, iz + 1);
    let c101 = grid_random(seed, ix + 1, iy, iz + 1);
    let c011 = grid_random(seed, ix, iy + 1, iz + 1);
    let c111 = grid_random(seed, ix + 1, iy + 1, iz + 1);

    let c00 = lerp(c000, c100, fx);
    let c10 = lerp(c010, c110, fx);
    let c01 = lerp(c001, c101, fx);
    let c11 = lerp(c011, c111, fx);
    let c0 = lerp(c00, c10, fy);
    let c1 = lerp(c01, c11, fy);
    lerp(c0, c1, fz)
}

/// Fractal Brownian Motion: sum `octaves` octaves of value noise with
/// halving amplitude and doubling frequency. Normalized to `[0, 1]`.
pub fn fbm_3d(seed: u64, x: f64, y: f64, z: f64, octaves: u32) -> f64 {
    let mut sum = 0.0;
    let mut amplitude = 1.0;
    let mut frequency = 1.0;
    let mut total_amplitude = 0.0;
    for i in 0..octaves.max(1) {
        // Salt the seed per octave so octaves don't collapse on each other.
        let seed_i = seed.wrapping_add(i as u64);
        sum += value_noise_3d(seed_i, x * frequency, y * frequency, z * frequency) * amplitude;
        total_amplitude += amplitude;
        amplitude *= 0.5;
        frequency *= 2.0;
    }
    sum / total_amplitude
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn value_noise_is_in_unit_range() {
        for i in 0..50 {
            let v = value_noise_3d(42, i as f64 * 0.37, i as f64 * 0.71, i as f64 * 1.13);
            assert!(
                (0.0..=1.0).contains(&v),
                "value {v} outside [0, 1] on sample {i}"
            );
        }
    }

    #[test]
    fn value_noise_is_deterministic() {
        let a = value_noise_3d(1, 0.5, 0.5, 0.5);
        let b = value_noise_3d(1, 0.5, 0.5, 0.5);
        assert_eq!(a, b);
    }

    #[test]
    fn different_seeds_produce_different_noise() {
        let a = value_noise_3d(1, 0.5, 0.5, 0.5);
        let b = value_noise_3d(99, 0.5, 0.5, 0.5);
        assert_ne!(a, b);
    }

    #[test]
    fn fbm_is_in_unit_range() {
        for i in 0..20 {
            let v = fbm_3d(7, i as f64 * 0.1, 0.0, 0.0, 4);
            assert!(
                (0.0..=1.0).contains(&v),
                "fbm value {v} outside [0, 1] on sample {i}"
            );
        }
    }

    #[test]
    fn fbm_is_smooth_at_small_steps() {
        let a = fbm_3d(7, 0.0, 0.0, 0.0, 4);
        let b = fbm_3d(7, 1e-4, 0.0, 0.0, 4);
        assert!((a - b).abs() < 0.01);
    }

    #[test]
    fn value_noise_changes_between_lattice_points() {
        // Picking points with enough separation will usually differ;
        // the exact hash output matters only insofar as it's varied.
        let mut samples = Vec::new();
        for i in 0..10 {
            samples.push(value_noise_3d(3, i as f64, 0.0, 0.0));
        }
        let unique: std::collections::HashSet<_> =
            samples.iter().map(|v| (v * 1e6) as i64).collect();
        assert!(unique.len() > 1);
    }
}

//! `ce_base` — stations and planetary outposts.
//!
//! A `Base` is a faction-owned collection of `BaseModule`s with a
//! shared inventory. Production lines on refinery / lab modules tick
//! over time consuming inputs and producing outputs. All pure data +
//! pure-function ticks; rendering and spatial placement live upstream.

pub mod base;
pub mod module;

pub use base::{tick_production, Base, BaseId};
pub use module::{BaseModule, ModuleKind, ProductionLine};

use ce_app::{App, Plugin};

pub struct BasePlugin;

impl Plugin for BasePlugin {
    fn build(&self, _app: &mut App) {
        log::info!("BasePlugin loaded (data layer only)");
    }
}

#[cfg(test)]
mod plugin_tests {
    use super::*;

    #[test]
    fn plugin_adds_cleanly() {
        let mut app = App::new();
        app.add_plugin(BasePlugin);
    }
}

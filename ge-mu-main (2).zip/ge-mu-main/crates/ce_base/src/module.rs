//! Base modules — the building blocks of stations and planetary
//! outposts.
//!
//! Modules are coarser than ship blocks: each one is a gameplay-level
//! facility (refinery, turret, etc.) with its own power draw and
//! production behaviour. A [`Base`](crate::base::Base) bolts some
//! number of them together.

use ce_gameplay::ItemStack;

/// One facility a base can host.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ModuleKind {
    /// Consumes ingredients and emits refined output over time.
    Refinery,
    /// Docking bay for ships; enables trade + repair.
    Hangar,
    /// Defensive turret.
    Turret,
    /// Crew quarters — increases station morale and service cap.
    Quarters,
    /// Reactor that produces power budget.
    Power,
    /// Bulk cargo storage.
    Storage,
    /// Trade floor — required for a market to be accessible.
    Market,
    /// Research lab — speeds up crafting recipes.
    Lab,
}

impl ModuleKind {
    /// Base power draw (positive = consumes, negative = produces).
    pub fn power_draw(&self) -> i32 {
        match self {
            ModuleKind::Refinery => 20,
            ModuleKind::Hangar => 10,
            ModuleKind::Turret => 15,
            ModuleKind::Quarters => 5,
            ModuleKind::Power => -100,
            ModuleKind::Storage => 2,
            ModuleKind::Market => 8,
            ModuleKind::Lab => 12,
        }
    }

    pub fn is_power_source(&self) -> bool {
        self.power_draw() < 0
    }
}

/// One production line: a refinery recipe that ticks over time.
#[derive(Debug, Clone, PartialEq)]
pub struct ProductionLine {
    /// Required inputs per tick.
    pub inputs: Vec<ItemStack>,
    /// Outputs per tick.
    pub outputs: Vec<ItemStack>,
    /// Seconds required for one complete cycle.
    pub cycle_seconds: f32,
    /// Accumulated seconds toward the next cycle.
    pub progress_seconds: f32,
    /// When false the line is halted (no power, no inputs, manually
    /// disabled). Advancing progress skipped.
    pub active: bool,
}

impl ProductionLine {
    pub fn new(inputs: Vec<ItemStack>, outputs: Vec<ItemStack>, cycle_seconds: f32) -> Self {
        Self {
            inputs,
            outputs,
            cycle_seconds: cycle_seconds.max(0.001),
            progress_seconds: 0.0,
            active: true,
        }
    }
}

/// One concrete module instance on a base.
#[derive(Debug, Clone, PartialEq)]
pub struct BaseModule {
    pub kind: ModuleKind,
    /// Upgrade level; each level scales power draw + throughput by 1+.
    pub level: u32,
    /// When `false` the module is unpowered / disabled.
    pub powered: bool,
    /// Optional production line (only relevant for Refinery / Lab).
    pub production: Option<ProductionLine>,
}

impl BaseModule {
    pub fn new(kind: ModuleKind) -> Self {
        Self {
            kind,
            level: 1,
            powered: true,
            production: None,
        }
    }

    pub fn with_level(mut self, level: u32) -> Self {
        self.level = level.max(1);
        self
    }

    pub fn with_production(mut self, line: ProductionLine) -> Self {
        self.production = Some(line);
        self
    }

    /// Net power demand at the current level (signed; negative = source).
    pub fn power(&self) -> i32 {
        self.kind.power_draw() * (self.level as i32)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn power_source_has_negative_draw() {
        let p = BaseModule::new(ModuleKind::Power);
        assert!(p.power() < 0);
        assert!(ModuleKind::Power.is_power_source());
    }

    #[test]
    fn consumer_has_positive_draw() {
        let r = BaseModule::new(ModuleKind::Refinery);
        assert!(r.power() > 0);
    }

    #[test]
    fn level_scales_power() {
        let l1 = BaseModule::new(ModuleKind::Refinery);
        let l3 = BaseModule::new(ModuleKind::Refinery).with_level(3);
        assert_eq!(l3.power(), l1.power() * 3);
    }

    #[test]
    fn zero_or_negative_level_clamps_to_one() {
        let m = BaseModule::new(ModuleKind::Refinery).with_level(0);
        assert_eq!(m.level, 1);
    }

    #[test]
    fn production_line_defaults_to_active() {
        let line = ProductionLine::new(vec![], vec![], 5.0);
        assert!(line.active);
        assert_eq!(line.progress_seconds, 0.0);
    }

    #[test]
    fn production_line_clamps_min_cycle_seconds() {
        // Prevent divide-by-zero in downstream ticks.
        let line = ProductionLine::new(vec![], vec![], 0.0);
        assert!(line.cycle_seconds > 0.0);
    }
}

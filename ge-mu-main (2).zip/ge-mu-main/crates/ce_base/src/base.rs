//! The [`Base`] container — a station or planetary outpost.

use ce_faction::FactionId;
use ce_gameplay::Inventory;
use ce_space::SectorId;

use crate::module::{BaseModule, ModuleKind};

/// Identifier for a base.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct BaseId(pub u64);

/// A built base: metadata, modules, and a shared inventory the
/// production lines draw inputs from and deposit outputs to.
#[derive(Debug, Clone)]
pub struct Base {
    pub id: BaseId,
    pub name: String,
    pub sector: SectorId,
    pub owner: Option<FactionId>,
    /// Shared inventory of raw materials + refined outputs.
    pub inventory: Inventory,
    /// Modules by insertion order.
    modules: Vec<BaseModule>,
}

impl Base {
    pub fn new(id: BaseId, name: impl Into<String>, sector: SectorId) -> Self {
        Self {
            id,
            name: name.into(),
            sector,
            owner: None,
            inventory: Inventory::new(10_000),
            modules: Vec::new(),
        }
    }

    pub fn with_owner(mut self, owner: FactionId) -> Self {
        self.owner = Some(owner);
        self
    }

    pub fn push_module(&mut self, m: BaseModule) {
        self.modules.push(m);
    }

    pub fn modules(&self) -> &[BaseModule] {
        &self.modules
    }

    pub fn modules_mut(&mut self) -> &mut [BaseModule] {
        &mut self.modules
    }

    pub fn count_of(&self, kind: ModuleKind) -> usize {
        self.modules.iter().filter(|m| m.kind == kind).count()
    }

    /// Net power balance across modules. Positive = surplus,
    /// negative = deficit (consumers unpowered).
    pub fn power_balance(&self) -> i32 {
        // Note: ModuleKind::power_draw returns positive for consumers
        // and negative for sources. Balance = -sum(draw).
        -self.modules.iter().map(|m| m.power()).sum::<i32>()
    }

    pub fn has_market(&self) -> bool {
        self.count_of(ModuleKind::Market) > 0
    }

    pub fn docking_capacity(&self) -> u32 {
        self.modules
            .iter()
            .filter(|m| m.kind == ModuleKind::Hangar && m.powered)
            .map(|m| m.level * 2)
            .sum()
    }
}

/// Ticks every refinery / lab production line on `base`:
/// - Skip if module unpowered.
/// - Require `inputs` present in inventory to progress.
/// - After `cycle_seconds`, consume inputs (atomically) and deposit
///   outputs (overflow aborts the cycle, inputs returned).
pub fn tick_production(base: &mut Base, dt_seconds: f32) {
    for module in base.modules.iter_mut() {
        if !module.powered {
            continue;
        }
        let Some(line) = module.production.as_mut() else {
            continue;
        };
        if !line.active {
            continue;
        }
        // Gate progress on having the required inputs on hand.
        let have_inputs = line
            .inputs
            .iter()
            .all(|s| base.inventory.count(s.id) >= s.count);
        if !have_inputs {
            continue;
        }
        line.progress_seconds += dt_seconds;
        while line.progress_seconds >= line.cycle_seconds {
            // Complete one cycle: consume → produce. Atomic via a
            // snapshot clone of the inventory.
            let snapshot = base.inventory.clone();
            let mut ok = true;
            for input in &line.inputs {
                if base.inventory.remove(input.id, input.count).is_err() {
                    ok = false;
                    break;
                }
            }
            if ok {
                for output in &line.outputs {
                    if base.inventory.add(output.id, output.count).is_err() {
                        ok = false;
                        break;
                    }
                }
            }
            if !ok {
                // Roll back — inventory full.
                base.inventory = snapshot;
                line.active = false; // halt until player intervenes
                break;
            }
            line.progress_seconds -= line.cycle_seconds;
            // Re-check inputs for the next cycle; if missing, we stop
            // ticking and leave progress at zero-ish.
            let still_have = line
                .inputs
                .iter()
                .all(|s| base.inventory.count(s.id) >= s.count);
            if !still_have {
                break;
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::module::ProductionLine;
    use ce_gameplay::{ItemId, ItemStack};
    use ce_space::SectorId;

    const IRON: ItemId = ItemId::new("iron_ore");
    const INGOT: ItemId = ItemId::new("iron_ingot");
    const COAL: ItemId = ItemId::new("coal");

    fn seed_base() -> Base {
        let mut b = Base::new(BaseId(1), "Aurora", SectorId(0, 0, 0));
        b.push_module(BaseModule::new(ModuleKind::Power));
        b.push_module(
            BaseModule::new(ModuleKind::Refinery).with_production(ProductionLine::new(
                vec![ItemStack::new(IRON, 2), ItemStack::new(COAL, 1)],
                vec![ItemStack::new(INGOT, 1)],
                5.0,
            )),
        );
        b.push_module(BaseModule::new(ModuleKind::Storage));
        b
    }

    #[test]
    fn power_balance_surplus_with_power_module() {
        let b = seed_base();
        assert!(b.power_balance() > 0, "Power module covers consumers");
    }

    #[test]
    fn power_balance_deficit_without_power_module() {
        let mut b = seed_base();
        // Remove the Power module.
        b.modules_mut()[0] = BaseModule::new(ModuleKind::Storage);
        assert!(b.power_balance() < 0);
    }

    #[test]
    fn refinery_consumes_inputs_and_deposits_outputs() {
        let mut b = seed_base();
        b.inventory.add(IRON, 10).unwrap();
        b.inventory.add(COAL, 5).unwrap();
        tick_production(&mut b, 5.5); // completes one cycle
        assert_eq!(b.inventory.count(IRON), 8);
        assert_eq!(b.inventory.count(COAL), 4);
        assert_eq!(b.inventory.count(INGOT), 1);
    }

    #[test]
    fn refinery_without_inputs_does_not_progress() {
        let mut b = seed_base();
        // Only COAL, no IRON.
        b.inventory.add(COAL, 5).unwrap();
        tick_production(&mut b, 10.0);
        assert_eq!(b.inventory.count(INGOT), 0);
        // Progress not accumulated.
        let p = b.modules()[1].production.as_ref().unwrap().progress_seconds;
        assert_eq!(p, 0.0);
    }

    #[test]
    fn unpowered_refinery_does_not_progress() {
        let mut b = seed_base();
        b.inventory.add(IRON, 10).unwrap();
        b.inventory.add(COAL, 5).unwrap();
        b.modules_mut()[1].powered = false;
        tick_production(&mut b, 10.0);
        assert_eq!(b.inventory.count(INGOT), 0);
    }

    #[test]
    fn refinery_runs_multiple_cycles_with_enough_fuel() {
        let mut b = seed_base();
        b.inventory.add(IRON, 100).unwrap();
        b.inventory.add(COAL, 50).unwrap();
        // 16 seconds / 5s cycle = 3 completed cycles.
        tick_production(&mut b, 16.0);
        assert_eq!(b.inventory.count(INGOT), 3);
    }

    #[test]
    fn docking_capacity_reflects_hangar_levels() {
        let mut b = Base::new(BaseId(1), "X", SectorId(0, 0, 0));
        b.push_module(BaseModule::new(ModuleKind::Hangar));
        b.push_module(BaseModule::new(ModuleKind::Hangar).with_level(2));
        assert_eq!(b.docking_capacity(), 6); // 1*2 + 2*2
    }

    #[test]
    fn has_market_respects_module_presence() {
        let mut b = Base::new(BaseId(1), "X", SectorId(0, 0, 0));
        assert!(!b.has_market());
        b.push_module(BaseModule::new(ModuleKind::Market));
        assert!(b.has_market());
    }

    #[test]
    fn refinery_stops_when_output_inventory_full() {
        let mut b = seed_base();
        b.inventory.capacity = 12; // exactly what we start with
        b.inventory.add(IRON, 10).unwrap();
        b.inventory.add(COAL, 2).unwrap();
        // One cycle: -2 IRON -1 COAL +1 INGOT = -2 net → fits. So
        // tighten further: cap at current total (12), cycle needs +1
        // net room after removals. Actually cycle net is -2, so it
        // still fits. Use a recipe with positive net to trigger overflow.
        b.modules_mut()[1].production = Some(ProductionLine::new(
            vec![ItemStack::new(IRON, 1)],
            vec![ItemStack::new(INGOT, 5)],
            1.0,
        ));
        tick_production(&mut b, 2.0);
        // Production halted, line flagged inactive.
        assert!(!b.modules()[1].production.as_ref().unwrap().active);
    }
}

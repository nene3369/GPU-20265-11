//! Headless glTF loading smoke-test.
//!
//! Usage:
//!   cargo run -p asset_demo -- path/to/model.glb
//!
//! With no argument the demo synthesises a tiny triangle GLB in memory,
//! loads it, and prints the resulting mesh stats. This makes the demo
//! runnable anywhere (CI, Steam Deck, etc.) without shipping fixtures.

use std::env;
use std::path::PathBuf;

use ce_assets::{load_glb_slice, load_gltf};
use ce_render::mesh::Mesh;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    env_logger::init();

    let meshes: Vec<Mesh> = match env::args().nth(1) {
        Some(path) => {
            let path = PathBuf::from(path);
            println!("Loading glTF: {}", path.display());
            load_gltf(&path)?
        }
        None => {
            println!("No path given — loading embedded minimal triangle GLB.");
            load_glb_slice(&embedded_triangle_glb())?
        }
    };

    println!("Loaded {} mesh primitive(s):", meshes.len());
    for (i, m) in meshes.iter().enumerate() {
        let idx = match &m.indices {
            Some(v) => v.len() as i64,
            None => -1,
        };
        println!("  [{i}] vertices={}, indices={}", m.vertices.len(), idx);
        if let Some(v) = m.vertices.first() {
            println!(
                "       first vertex: pos={:?} color={:?}",
                v.position, v.color
            );
        }
    }

    Ok(())
}

/// Same minimal triangle GLB used by the ce_assets unit tests. Embedded
/// here so the demo needs no external file to prove the pipeline works.
fn embedded_triangle_glb() -> Vec<u8> {
    let positions: [[f32; 3]; 3] = [[0.0, 0.5, 0.0], [-0.5, -0.5, 0.0], [0.5, -0.5, 0.0]];
    let mut bin = Vec::with_capacity(36);
    for v in &positions {
        for c in v {
            bin.extend_from_slice(&c.to_le_bytes());
        }
    }

    let json = r#"{
  "asset": { "version": "2.0" },
  "buffers": [ { "byteLength": 36 } ],
  "bufferViews": [ { "buffer": 0, "byteLength": 36, "target": 34962 } ],
  "accessors": [ {
    "bufferView": 0, "componentType": 5126, "count": 3, "type": "VEC3",
    "min": [-0.5, -0.5, 0.0], "max": [0.5, 0.5, 0.0]
  } ],
  "meshes": [ { "primitives": [ { "attributes": { "POSITION": 0 } } ] } ]
}"#;

    let mut json_bytes = json.as_bytes().to_vec();
    while !json_bytes.len().is_multiple_of(4) {
        json_bytes.push(b' ');
    }
    while !bin.len().is_multiple_of(4) {
        bin.push(0);
    }

    let total_len = 12 + 8 + json_bytes.len() + 8 + bin.len();
    let mut glb = Vec::with_capacity(total_len);
    glb.extend_from_slice(b"glTF");
    glb.extend_from_slice(&2u32.to_le_bytes());
    glb.extend_from_slice(&(total_len as u32).to_le_bytes());
    glb.extend_from_slice(&(json_bytes.len() as u32).to_le_bytes());
    glb.extend_from_slice(b"JSON");
    glb.extend_from_slice(&json_bytes);
    glb.extend_from_slice(&(bin.len() as u32).to_le_bytes());
    glb.extend_from_slice(b"BIN\0");
    glb.extend_from_slice(&bin);
    glb
}

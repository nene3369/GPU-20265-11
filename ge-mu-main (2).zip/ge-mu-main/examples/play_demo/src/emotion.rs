//! NPC inner life — pure drift of `ce_ai::ThreePoisons` based on
//! what happened to (and around) the ship this tick.
//!
//! The `NpcShip` in `ce_npc` is intentionally behavioural — it has a
//! goal and a weapon and nothing else. This module offers two
//! alternatives for attaching inner state:
//!
//! - A [`SentientNpc`] wrapper struct for callers that want one
//!   owned bundle per citizen (clean but requires renaming).
//! - A direct [`drift_poisons`] over `&mut ThreePoisons` for callers
//!   that keep poisons in a sidecar map (what `play_demo` does).
//!
//! `poison_modifier` converts the dominant poison into a scale
//! factor the gameplay layer applies to `ship.engage_range` just
//! before `advance_npc`, without touching `ce_npc`.
//!
//! Everything in here is pure — no rendering, no RNG, no I/O — so
//! the drift can be unit-tested alongside `ce_worldpulse` as part of
//! the self-evolving world substrate.

// The `SentientNpc` wrapper + `is_isolated` helper are used by the
// test module below and by future callers that want an owned bundle
// per NPC; the current `play_demo` wiring uses the sidecar-map
// alternative (a `HashMap<NpcId, ThreePoisons>`).
#![allow(dead_code)]

use ce_ai::{PoisonType, ThreePoisons};
use ce_faction::FactionId;
use ce_math::Vec3;
use ce_npc::NpcShip;
use ce_worldpulse::WorldPulse;

/// An NPC ship with an inner state. The `ship` field is the original
/// `ce_npc::NpcShip` — `advance_npc` still applies to it unchanged.
/// `poisons` is mutated by [`drift_poisons`] each tick; the gameplay
/// layer reads `poison_modifier` to scale `ship` fields before
/// calling `advance_npc`.
#[derive(Debug, Clone)]
pub struct SentientNpc {
    pub ship: NpcShip,
    pub poisons: ThreePoisons,
}

impl SentientNpc {
    /// Wraps a freshly-spawned `NpcShip`. Starts from the virtuous
    /// baseline (small residual amounts of each poison) so newly
    /// spawned ships read as neutral.
    pub fn wrap(ship: NpcShip) -> Self {
        Self {
            ship,
            poisons: ThreePoisons::default(),
        }
    }

    pub fn is_alive(&self) -> bool {
        self.ship.is_alive()
    }

    /// Single-character glyph for HUD lines. `·` for neutral,
    /// `L`/`D`/`M` for the dominant poison.
    pub fn hud_glyph(&self) -> char {
        if self.poisons.total() < 0.15 {
            '·'
        } else {
            match self.poisons.dominant() {
                PoisonType::Lobha => 'L',
                PoisonType::Dosa => 'D',
                PoisonType::Moha => 'M',
            }
        }
    }
}

/// Events the gameplay layer records for one NPC in one tick. All
/// counts are accumulated and cleared after [`drift_poisons`] runs.
#[derive(Debug, Clone, Copy, Default, PartialEq)]
pub struct SentientEvents {
    /// Same-faction ships killed in view this tick. Inflames dosa.
    pub allies_lost: u32,
    /// Hostile-faction ships killed this tick. Stokes lobha.
    pub enemies_downed: u32,
    /// `true` when no same-faction ship is within the solitude
    /// radius — loneliness nudges moha upward slowly.
    pub isolated: bool,
    /// A player trade that closed near a station the ship can see.
    /// Feeds lobha (attachment to material flow).
    pub nearby_trade: bool,
}

impl SentientEvents {
    pub fn clear(&mut self) {
        *self = Self::default();
    }
}

/// Per-event impulse magnitudes. Tuned so one event is a nudge, a
/// handful moves the dominant poison, and a sustained stream
/// saturates it (the `ThreePoisons` fields are clamped in-place by
/// [`drift_poisons`]).
const ALLY_LOSS_DOSA: f64 = 0.08;
const ENEMY_DOWN_LOBHA: f64 = 0.04;
const ISOLATION_MOHA_PER_SEC: f64 = 0.03;
const TRADE_LOBHA: f64 = 0.02;

/// Natural decay of each poison back toward rest (no poison). A
/// world with high security decays faster — peace lets grudges
/// fade. A collapsed-security world keeps the stain.
const DECAY_PER_SEC_BASE: f64 = 0.01;

/// One-tick drift for a poison vector. Pure function: same
/// `(poisons, events, pulse, dt)` always yields the same next state.
/// Takes `&mut ThreePoisons` directly so callers that keep poisons
/// in a `HashMap` don't need to build a wrapper every frame.
pub fn drift_poisons(
    poisons: &mut ThreePoisons,
    events: &SentientEvents,
    pulse: &WorldPulse,
    dt: f32,
) {
    if !dt.is_finite() || dt <= 0.0 {
        return;
    }
    let dt64 = dt as f64;

    // Event-driven impulses.
    poisons.dosa += ALLY_LOSS_DOSA * events.allies_lost as f64;
    poisons.lobha += ENEMY_DOWN_LOBHA * events.enemies_downed as f64;
    if events.isolated {
        poisons.moha += ISOLATION_MOHA_PER_SEC * dt64;
    }
    if events.nearby_trade {
        poisons.lobha += TRADE_LOBHA;
    }

    // Decay toward zero, modulated by security. Low security → half
    // decay rate (grudges linger in unsafe sectors).
    let security = pulse.security.clamp(0.0, 1.0) as f64;
    let decay = DECAY_PER_SEC_BASE * (0.5 + security * 0.5) * dt64;
    poisons.lobha = (poisons.lobha - decay).max(0.0);
    poisons.dosa = (poisons.dosa - decay).max(0.0);
    poisons.moha = (poisons.moha - decay).max(0.0);

    // Clamp upward too so event storms can't overshoot 1.0.
    poisons.lobha = poisons.lobha.clamp(0.0, 1.0);
    poisons.dosa = poisons.dosa.clamp(0.0, 1.0);
    poisons.moha = poisons.moha.clamp(0.0, 1.0);
}

/// Multiplier on the ship's base `engage_range` derived from the
/// dominant poison. Dosa makes the ship aggressive (scan further);
/// Lobha keeps it focused on acquisition (baseline); Moha confuses
/// it (slightly shorter range). Neutral sentients return 1.0.
pub fn poison_modifier(poisons: &ThreePoisons) -> f32 {
    if poisons.total() < 0.15 {
        return 1.0;
    }
    match poisons.dominant() {
        PoisonType::Dosa => 1.0 + (poisons.dosa as f32 * 0.3),
        PoisonType::Lobha => 1.0,
        PoisonType::Moha => 1.0 - (poisons.moha as f32 * 0.15),
    }
}

/// Returns `true` when no same-faction ship (other than `self`) is
/// within `radius` of `origin`. Used to populate
/// [`SentientEvents::isolated`].
pub fn is_isolated(origin: Vec3, faction: FactionId, others: &[SentientNpc], radius: f32) -> bool {
    !others.iter().any(|o| {
        o.is_alive()
            && o.ship.faction == faction
            && o.ship.pos != origin
            && (o.ship.pos - origin).length() <= radius
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use ce_combat::{DamageType, Shield, WeaponStats};
    use ce_npc::{NpcId, NpcShip};

    const UNION: FactionId = FactionId::new("union");
    const PIRATE: FactionId = FactionId::new("pirate");

    fn sample_ship(faction: FactionId, pos: Vec3) -> NpcShip {
        NpcShip::new(
            NpcId::new(1),
            faction,
            "test",
            pos,
            100.0,
            Shield::new(50.0, 0.0, 0.0),
            WeaponStats {
                damage_type: DamageType::Energy,
                damage: 20.0,
                cooldown_seconds: 0.5,
                range_meters: 30.0,
                energy_cost: 2.0,
            },
        )
    }

    #[test]
    fn ally_loss_inflames_dosa() {
        let mut npc = SentientNpc::wrap(sample_ship(UNION, Vec3::ZERO));
        let before = npc.poisons.dosa;
        drift_poisons(
            &mut npc.poisons,
            &SentientEvents {
                allies_lost: 2,
                ..Default::default()
            },
            &WorldPulse::calm(),
            0.016,
        );
        assert!(npc.poisons.dosa > before);
    }

    #[test]
    fn enemy_down_feeds_lobha() {
        let mut npc = SentientNpc::wrap(sample_ship(UNION, Vec3::ZERO));
        let before = npc.poisons.lobha;
        drift_poisons(
            &mut npc.poisons,
            &SentientEvents {
                enemies_downed: 1,
                ..Default::default()
            },
            &WorldPulse::calm(),
            0.016,
        );
        assert!(npc.poisons.lobha > before);
    }

    #[test]
    fn isolation_grows_moha_over_time() {
        let mut npc = SentientNpc::wrap(sample_ship(UNION, Vec3::ZERO));
        // Zero out the residual default so we measure pure isolation
        // growth rather than default + drift.
        npc.poisons = ThreePoisons {
            lobha: 0.0,
            dosa: 0.0,
            moha: 0.0,
        };
        let before = npc.poisons.moha;
        for _ in 0..30 {
            drift_poisons(
                &mut npc.poisons,
                &SentientEvents {
                    isolated: true,
                    ..Default::default()
                },
                &WorldPulse::calm(),
                1.0,
            );
        }
        assert!(
            npc.poisons.moha > before + 0.03,
            "moha did not grow: {} (before {})",
            npc.poisons.moha,
            before
        );
    }

    #[test]
    fn poisons_decay_without_stimulus() {
        let mut npc = SentientNpc::wrap(sample_ship(UNION, Vec3::ZERO));
        npc.poisons.dosa = 0.6;
        for _ in 0..600 {
            drift_poisons(
                &mut npc.poisons,
                &SentientEvents::default(),
                &WorldPulse::calm(),
                0.1,
            );
        }
        assert!(
            npc.poisons.dosa < 0.3,
            "dosa did not decay enough: {}",
            npc.poisons.dosa
        );
    }

    #[test]
    fn low_security_slows_decay() {
        let mut peaceful = SentientNpc::wrap(sample_ship(UNION, Vec3::ZERO));
        peaceful.poisons.dosa = 0.6;
        let mut hostile = peaceful.clone();

        for _ in 0..200 {
            drift_poisons(
                &mut peaceful.poisons,
                &SentientEvents::default(),
                &WorldPulse::calm(),
                0.1,
            );
            drift_poisons(
                &mut hostile.poisons,
                &SentientEvents::default(),
                &WorldPulse {
                    security: 0.0,
                    ..WorldPulse::calm()
                },
                0.1,
            );
        }
        assert!(hostile.poisons.dosa > peaceful.poisons.dosa);
    }

    #[test]
    fn poison_modifier_returns_unity_when_neutral() {
        let mut npc = SentientNpc::wrap(sample_ship(UNION, Vec3::ZERO));
        assert!((poison_modifier(&npc.poisons) - 1.0).abs() < 1e-5);
        // Saturating dosa pushes the modifier above 1.
        npc.poisons.dosa = 1.0;
        npc.poisons.lobha = 0.0;
        npc.poisons.moha = 0.0;
        assert!(poison_modifier(&npc.poisons) > 1.15);
    }

    #[test]
    fn hud_glyph_reports_dominant() {
        let mut npc = SentientNpc::wrap(sample_ship(UNION, Vec3::ZERO));
        assert_eq!(npc.hud_glyph(), '·');
        npc.poisons.dosa = 0.9;
        assert_eq!(npc.hud_glyph(), 'D');
        npc.poisons.dosa = 0.0;
        npc.poisons.moha = 0.9;
        assert_eq!(npc.hud_glyph(), 'M');
        npc.poisons.moha = 0.0;
        npc.poisons.lobha = 0.9;
        assert_eq!(npc.hud_glyph(), 'L');
    }

    #[test]
    fn is_isolated_detects_lone_ship() {
        let me = sample_ship(UNION, Vec3::ZERO);
        let ally = SentientNpc::wrap(sample_ship(UNION, Vec3::new(5.0, 0.0, 0.0)));
        let enemy = SentientNpc::wrap(sample_ship(PIRATE, Vec3::new(5.0, 0.0, 0.0)));

        let enemy_only = std::slice::from_ref(&enemy);
        assert!(is_isolated(me.pos, UNION, enemy_only, 30.0));
        assert!(!is_isolated(me.pos, UNION, &[ally], 30.0));
        assert!(is_isolated(me.pos, UNION, enemy_only, 1.0));
    }

    #[test]
    fn drift_ignores_non_finite_dt() {
        let mut npc = SentientNpc::wrap(sample_ship(UNION, Vec3::ZERO));
        npc.poisons.dosa = 0.5;
        let before = npc.poisons;
        drift_poisons(
            &mut npc.poisons,
            &SentientEvents {
                allies_lost: 5,
                ..Default::default()
            },
            &WorldPulse::calm(),
            f32::NAN,
        );
        assert_eq!(npc.poisons.dosa, before.dosa);
    }
}

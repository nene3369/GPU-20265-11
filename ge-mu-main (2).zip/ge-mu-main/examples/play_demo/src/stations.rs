//! Builders for the three station-side `ce_base::Base`s that back
//! each `FactionBase` in the demo.
//!
//! The `FactionBase` type from `ce_npc` is a spatial / combat entity
//! (hull, shield, hit radius). The `Base` type from `ce_base` is an
//! industrial entity (modules, inventory, production lines). M43
//! runs them side by side: the NPC `FactionBase` is what projectiles
//! hit, the industrial `Base` is what ticks production each frame.
//! Destroying the former drops power on the latter.

use ce_base::{Base, BaseId, BaseModule, ModuleKind, ProductionLine};
use ce_faction::FactionId;
use ce_gameplay::{ItemId, ItemStack};
use ce_space::SectorId;

/// Placeholder sector for the single-sector demo. `ce_space` is
/// spatial infrastructure the wider project uses; the `Base` layer
/// just needs a stable identifier so the two-body attachment
/// survives save/load later.
pub const DEMO_SECTOR: SectorId = SectorId(0, 0, 0);

/// Ore inputs (match the IDs main.rs uses).
pub const IRON_ORE: ItemId = ItemId::new("iron_ore");
pub const PLATINUM_ORE: ItemId = ItemId::new("platinum_ore");
/// Third input required for iron refining. Not mined — stations
/// carry a buffer at spawn and restock via courier missions.
pub const COAL: ItemId = ItemId::new("coal");

/// Refined outputs stations produce.
pub const IRON_INGOT: ItemId = ItemId::new("iron_ingot");
pub const PLATINUM_PLATE: ItemId = ItemId::new("platinum_plate");
pub const CONTRABAND: ItemId = ItemId::new("contraband");

/// Builds the Protectorate Station: a lawful industrial anchor that
/// refines iron ore + coal into ingots. Lots of power, one market.
pub fn build_protectorate_station(faction: FactionId) -> Base {
    let mut b = Base::new(BaseId(1), "Protectorate Station", DEMO_SECTOR).with_owner(faction);
    b.push_module(BaseModule::new(ModuleKind::Power).with_level(2));
    b.push_module(
        BaseModule::new(ModuleKind::Refinery).with_production(ProductionLine::new(
            vec![ItemStack::new(IRON_ORE, 2), ItemStack::new(COAL, 1)],
            vec![ItemStack::new(IRON_INGOT, 1)],
            5.0,
        )),
    );
    b.push_module(BaseModule::new(ModuleKind::Storage).with_level(2));
    b.push_module(BaseModule::new(ModuleKind::Market));
    // Seed a coal buffer so the refinery can run without a supply
    // chain — mirrors "the sector has been up for 30 minutes".
    let _ = b.inventory.add(COAL, 40);
    b
}

/// Builds the Union Depot: a specialised platinum refinery. Long
/// cycle time, high-margin output.
pub fn build_union_depot(faction: FactionId) -> Base {
    let mut b = Base::new(BaseId(2), "Union Depot", DEMO_SECTOR).with_owner(faction);
    b.push_module(BaseModule::new(ModuleKind::Power));
    b.push_module(
        BaseModule::new(ModuleKind::Refinery).with_production(ProductionLine::new(
            vec![ItemStack::new(PLATINUM_ORE, 1)],
            vec![ItemStack::new(PLATINUM_PLATE, 1)],
            8.0,
        )),
    );
    b.push_module(BaseModule::new(ModuleKind::Market));
    b
}

/// Builds Reaver's Nest: a pirate refinery converting iron ore into
/// contraband at slower pace, no market (pirates fence through
/// missions instead).
pub fn build_reavers_nest(faction: FactionId) -> Base {
    let mut b = Base::new(BaseId(3), "Reaver's Nest", DEMO_SECTOR).with_owner(faction);
    b.push_module(BaseModule::new(ModuleKind::Power));
    b.push_module(
        BaseModule::new(ModuleKind::Refinery).with_production(ProductionLine::new(
            vec![ItemStack::new(IRON_ORE, 3)],
            vec![ItemStack::new(CONTRABAND, 1)],
            12.0,
        )),
    );
    b.push_module(BaseModule::new(ModuleKind::Storage));
    b
}

/// Flip every module's `powered` flag to match the parent
/// `FactionBase.destroyed` state so production lines stop when the
/// stronghold falls.
pub fn set_powered(base: &mut Base, powered: bool) {
    for m in base.modules_mut() {
        m.powered = powered;
    }
}

/// Apply `world_pulse.market_mood` to every production line's cycle
/// time: high mood shortens cycles, low mood drags them out. The
/// multiplier stays in `[0.7, 1.3]` so the simulation can't stall.
pub fn apply_mood_to_cycles(base: &mut Base, market_mood: f32) {
    let mood = if market_mood.is_finite() {
        market_mood.clamp(0.0, 1.0)
    } else {
        0.5
    };
    // At mood 1.0 cycles run at 0.7x (faster); at 0.0 they run at 1.3x.
    let multiplier = 1.3 - mood * 0.6;
    for m in base.modules_mut() {
        if let Some(line) = m.production.as_mut() {
            let base_cycle = match m.kind {
                ModuleKind::Refinery => {
                    if line.inputs.iter().any(|s| s.id == PLATINUM_ORE) {
                        8.0
                    } else if line.outputs.iter().any(|s| s.id == CONTRABAND) {
                        12.0
                    } else {
                        5.0
                    }
                }
                _ => line.cycle_seconds,
            };
            line.cycle_seconds = (base_cycle * multiplier).max(0.5);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const PROTECTORATE: FactionId = FactionId::new("protectorate");
    const UNION: FactionId = FactionId::new("union");
    const CRIMSON: FactionId = FactionId::new("crimson");

    #[test]
    fn protectorate_has_refinery_and_market() {
        let b = build_protectorate_station(PROTECTORATE);
        assert_eq!(b.count_of(ModuleKind::Refinery), 1);
        assert_eq!(b.count_of(ModuleKind::Market), 1);
        assert!(b.power_balance() > 0);
        assert_eq!(b.inventory.count(COAL), 40);
    }

    #[test]
    fn union_produces_platinum_plate() {
        let b = build_union_depot(UNION);
        let line = b.modules()[1].production.as_ref().unwrap();
        assert!(line.outputs.iter().any(|s| s.id == PLATINUM_PLATE));
    }

    #[test]
    fn reavers_has_no_market() {
        let b = build_reavers_nest(CRIMSON);
        assert_eq!(b.count_of(ModuleKind::Market), 0);
        assert_eq!(b.count_of(ModuleKind::Refinery), 1);
    }

    #[test]
    fn set_powered_toggles_every_module() {
        let mut b = build_protectorate_station(PROTECTORATE);
        set_powered(&mut b, false);
        assert!(b.modules().iter().all(|m| !m.powered));
        set_powered(&mut b, true);
        assert!(b.modules().iter().all(|m| m.powered));
    }

    #[test]
    fn mood_shortens_cycle_when_high() {
        let mut b = build_protectorate_station(PROTECTORATE);
        apply_mood_to_cycles(&mut b, 1.0);
        let fast = b.modules()[1].production.as_ref().unwrap().cycle_seconds;
        apply_mood_to_cycles(&mut b, 0.0);
        let slow = b.modules()[1].production.as_ref().unwrap().cycle_seconds;
        assert!(fast < slow);
    }
}

//! `play_demo` — windowed render of the procedural engine.
//!
//! Renders a small procedural scene (ship + earth-like planet +
//! asteroid) inside a real winit window, using wgpu. A procedural
//! starfield fills the background (code-generated WGSL from
//! `ce_shader_gen::build_starfield_shader`). The player ship responds
//! to WASD / Q / E thrust via `ce_flight::advance_linear`; the camera
//! follows the ship from a chase-cam.
//!
//! Controls
//! - WASD: ship-local strafe (forward/back, left/right)
//! - Q / E: down / up
//! - Arrow keys: yaw (←/→) and pitch (↑/↓)
//! - F: hold to fire mining beam (when an asteroid is in range)
//! - Space: hold to fire the forward laser cannon
//! - K: open / close the trade panel (must be in dock range of station)
//! - T: sell all ore at the station's market (trade panel must be open)
//! - Esc: quit

use std::mem;

use bytemuck::{Pod, Zeroable};
use ce_combat::{
    advance_projectile, apply_damage, projectile_hits_sphere, DamageType, Projectile, Shield,
    WeaponCooldown, WeaponStats,
};
mod emotion;
mod mission_gen;
mod offline;
mod stations;

use ce_ai::ThreePoisons;
use ce_base::tick_production;
use ce_economy::{
    restock_market_entry, sell_to_market, spread_with_mood, Market, MarketEntry, PriceModel, Wallet,
};
use ce_faction::{
    apply_kill_delta_weighted, decay_reputation, FactionId, FactionRegistry, Relation,
    ReputationMatrix, REP_FRIENDLY, REP_HOSTILE, REP_WAR,
};
use ce_flight::{advance_angular, advance_linear, FlightCommand};
use ce_gameplay::{Inventory, ItemId};
use ce_hud::{HudBatch, HudVertex};
use ce_math::{IVec3, Mat4, Quat, Vec3};
use ce_mesh_gen::{build_asteroid, build_planet_mesh, build_ship_mesh};
use ce_mining::{mine_tick, MineResult, MiningBeam, NodeId, ResourceNode};
use ce_mission::{
    complete as mission_complete, tick_log as mission_tick_log, LogEntry, MissionBoard, MissionId,
    MissionKind, MissionLog, MissionStatus,
};
use ce_npc::{
    advance_base, advance_npc, engage_range_with_security, faction_spawning_gated,
    BaseId as NpcBaseId, FactionBase, NpcGoal, NpcId, NpcShip, SlotKind, Threat,
};

use crate::emotion::{drift_poisons, poison_modifier, SentientEvents};
use crate::mission_gen::maybe_post_offer;
use ce_planet::{Planet, PlanetId};
use ce_render::mesh::{Mesh, Vertex};
use ce_shader_gen::{
    build_bloom_blur, build_bloom_extract, build_hud_overlay_shader, build_hull_shader,
    build_planet_shader, build_starfield_shader, build_tonemap_composite, HudOverlayParams,
    HullShaderParams, PlanetShaderParams, StarfieldParams,
};
use ce_ship::{
    compute_mass_properties, compute_thrust_budget, Block, BlockKind, BlockMaterial, Facing,
    MassProperties, ShipBlocks, ThrustBudget,
};
use ce_space::WorldPos;
use ce_worldclock::WorldClock;
use ce_worldpulse::{advance_pulse, pre_drift_pulse, PulseEvents, WorldPulse};
use wgpu::util::DeviceExt;
use winit::application::ApplicationHandler;
use winit::event::{ElementState, WindowEvent};
use winit::event_loop::{ActiveEventLoop, EventLoop};
use winit::keyboard::{Key, NamedKey};
use winit::window::{Window, WindowAttributes, WindowId};

const DEPTH_FORMAT: wgpu::TextureFormat = wgpu::TextureFormat::Depth32Float;

/// Offscreen render target used by the scene pass + bloom chain.
/// Float16 preserves HDR intensities above 1.0 so the ACES tonemap
/// can roll bright specular + stars into crisp highlights instead of
/// clipping them.
const HDR_FORMAT: wgpu::TextureFormat = wgpu::TextureFormat::Rgba16Float;

/// Divisor used to derive the half-resolution bloom textures from
/// the window size. Anything between 2 and 4 looks good; 2 gives a
/// crisper halo, 4 is cheaper but fuzzier.
const BLOOM_DIVISOR: u32 = 2;

// ---------------------------------------------------------------------
// Uniforms
// ---------------------------------------------------------------------

#[repr(C)]
#[derive(Copy, Clone, Pod, Zeroable)]
struct FrameUniform {
    view_proj: [[f32; 4]; 4],
    camera_pos: [f32; 4],
    light_dir: [f32; 4],
}

#[repr(C)]
#[derive(Copy, Clone, Pod, Zeroable)]
struct StarfieldUniform {
    inv_view_proj: [[f32; 4]; 4],
}

#[derive(Copy, Clone, Debug)]
enum MaterialKind {
    Planet,
    Hull,
}

// ---------------------------------------------------------------------
// Input state (digital thrust)
// ---------------------------------------------------------------------

#[derive(Default, Clone, Copy)]
struct ThrustInput {
    forward: bool,
    backward: bool,
    left: bool,
    right: bool,
    up: bool,
    down: bool,
    pitch_up: bool,
    pitch_down: bool,
    yaw_left: bool,
    yaw_right: bool,
    mine: bool,
    fire: bool,
}

/// Yaw / pitch rate while a single arrow key is held (rad/s).
const TURN_RATE: f32 = 1.5;

impl ThrustInput {
    fn to_command(self) -> FlightCommand {
        let x = (self.right as i32 - self.left as i32) as f32;
        let y = (self.up as i32 - self.down as i32) as f32;
        // FlightCommand convention: +Z is backward.
        let z = (self.backward as i32 - self.forward as i32) as f32;
        // Pitch around X: +X = nose up. Yaw around Y: +Y = nose left.
        let pitch = (self.pitch_up as i32 - self.pitch_down as i32) as f32 * TURN_RATE;
        let yaw = (self.yaw_left as i32 - self.yaw_right as i32) as f32 * TURN_RATE;
        FlightCommand::new()
            .with_linear(Vec3::new(x, y, z))
            .with_angular(Vec3::new(pitch, yaw, 0.0))
            .with_assist(true)
    }
}

// ---------------------------------------------------------------------
// Mesh upload
// ---------------------------------------------------------------------

struct GpuMesh {
    vertex_buffer: wgpu::Buffer,
    index_buffer: Option<wgpu::Buffer>,
    index_count: u32,
    vertex_count: u32,
    material: MaterialKind,
    /// When present, `vertex_buffer` is re-uploaded each frame from this
    /// base mesh translated by `origin`. Used for the moving ship.
    base_vertices: Option<Vec<Vertex>>,
    origin: Vec3,
}

fn bake_transform(mesh: &Mesh, model: Mat4) -> Vec<Vertex> {
    mesh.vertices
        .iter()
        .map(|v| {
            let p = model * ce_math::Vec4::new(v.position[0], v.position[1], v.position[2], 1.0);
            Vertex {
                position: [p.x, p.y, p.z],
                color: v.color,
            }
        })
        .collect()
}

impl GpuMesh {
    fn upload_static(
        device: &wgpu::Device,
        mesh: &Mesh,
        label: &str,
        model: Mat4,
        material: MaterialKind,
    ) -> Self {
        let world = bake_transform(mesh, model);
        let vertex_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some(&format!("{label} VB")),
            contents: bytemuck::cast_slice(&world),
            usage: wgpu::BufferUsages::VERTEX,
        });
        let (index_buffer, index_count) = match &mesh.indices {
            Some(ix) => {
                let buf = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                    label: Some(&format!("{label} IB")),
                    contents: bytemuck::cast_slice(ix),
                    usage: wgpu::BufferUsages::INDEX,
                });
                (Some(buf), ix.len() as u32)
            }
            None => (None, 0),
        };
        Self {
            vertex_buffer,
            index_buffer,
            index_count,
            vertex_count: world.len() as u32,
            material,
            base_vertices: None,
            origin: Vec3::ZERO,
        }
    }

    fn upload_dynamic(
        device: &wgpu::Device,
        mesh: &Mesh,
        label: &str,
        origin: Vec3,
        material: MaterialKind,
    ) -> Self {
        let base: Vec<Vertex> = mesh.vertices.clone();
        let vertex_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some(&format!("{label} dyn VB")),
            size: (std::mem::size_of::<Vertex>() * base.len()) as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let (index_buffer, index_count) = match &mesh.indices {
            Some(ix) => {
                let buf = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                    label: Some(&format!("{label} IB")),
                    contents: bytemuck::cast_slice(ix),
                    usage: wgpu::BufferUsages::INDEX,
                });
                (Some(buf), ix.len() as u32)
            }
            None => (None, 0),
        };
        Self {
            vertex_buffer,
            index_buffer,
            index_count,
            vertex_count: base.len() as u32,
            material,
            base_vertices: Some(base),
            origin,
        }
        // Caller must upload `world` immediately via write_buffer if
        // they want a valid first frame; we do so in the renderer.
    }
}

fn translate_vertices(base: &[Vertex], origin: Vec3) -> Vec<Vertex> {
    base.iter()
        .map(|v| Vertex {
            position: [
                v.position[0] + origin.x,
                v.position[1] + origin.y,
                v.position[2] + origin.z,
            ],
            color: v.color,
        })
        .collect()
}

fn transform_vertices(base: &[Vertex], origin: Vec3, orient: Quat) -> Vec<Vertex> {
    base.iter()
        .map(|v| {
            let local = Vec3::new(v.position[0], v.position[1], v.position[2]);
            let p = origin + orient * local;
            Vertex {
                position: [p.x, p.y, p.z],
                color: v.color,
            }
        })
        .collect()
}

// ---------------------------------------------------------------------
// Renderer
// ---------------------------------------------------------------------

struct Renderer {
    surface: wgpu::Surface<'static>,
    device: wgpu::Device,
    queue: wgpu::Queue,
    config: wgpu::SurfaceConfiguration,

    // Lit-mesh pipelines (share the frame bind group).
    planet_pipeline: wgpu::RenderPipeline,
    hull_pipeline: wgpu::RenderPipeline,
    frame_uniform: wgpu::Buffer,
    frame_bind_group: wgpu::BindGroup,

    // Starfield pipeline (separate bind group — different uniform).
    star_pipeline: wgpu::RenderPipeline,
    star_uniform: wgpu::Buffer,
    star_bind_group: wgpu::BindGroup,

    // HDR post-processing: scene renders into `hdr_view`; the bloom
    // chain ping-pongs between `bloom_a` and `bloom_b`; the final
    // tonemap pass reads `hdr_view + bloom_a` and writes into the
    // sRGB swap chain. All offscreen targets resize with the window.
    hdr_view: wgpu::TextureView,
    bloom_a_view: wgpu::TextureView,
    bloom_b_view: wgpu::TextureView,
    linear_sampler: wgpu::Sampler,
    postprocess_1tex_bgl: wgpu::BindGroupLayout,
    postprocess_2tex_bgl: wgpu::BindGroupLayout,
    bloom_extract_pipeline: wgpu::RenderPipeline,
    bloom_blur_h_pipeline: wgpu::RenderPipeline,
    bloom_blur_v_pipeline: wgpu::RenderPipeline,
    tonemap_pipeline: wgpu::RenderPipeline,
    bloom_extract_bg: wgpu::BindGroup,
    bloom_blur_h_bg: wgpu::BindGroup,
    bloom_blur_v_bg: wgpu::BindGroup,
    tonemap_bg: wgpu::BindGroup,

    // HUD pipeline (no uniforms, vertices already in NDC).
    hud_pipeline: wgpu::RenderPipeline,
    hud_vertex_buffer: wgpu::Buffer,
    hud_vertex_capacity: u64,
    hud_vertex_count: u32,

    depth_view: wgpu::TextureView,
    meshes: Vec<GpuMesh>,

    // Player ship state (world-space).
    ship_pos: Vec3,
    ship_vel: Vec3,
    ship_orient: Quat,
    ship_angular_vel: Vec3,
    ship_mass: MassProperties,
    ship_thrust: ThrustBudget,
    ship_mesh_index: usize,

    // Sun direction drifts slowly so shading is visible.
    time: f32,

    /// World-space points to render on the minimap, paired with the
    /// dot colour. Static objects (planet, asteroid) are seeded once
    /// at startup; moving ships would refresh per frame.
    minimap_targets: Vec<(Vec3, [f32; 4])>,

    // Mining state.
    mining_beam: MiningBeam,
    asteroid_nodes: Vec<ResourceNode>,
    /// Index into `asteroid_nodes` of the currently targeted body, or
    /// `None` if no node is in range.
    target_index: Option<usize>,
    inventory: Inventory,
    /// Most recent mining tick result, kept for HUD feedback.
    last_mine_result: Option<MineResult>,

    // Visual beam: a thin world-space quad rebuilt each frame while
    // mining; drawn through the hull pipeline.
    beam_vertex_buffer: wgpu::Buffer,
    beam_active: bool,

    // Trade.
    station_pos: Vec3,
    market: Market,
    wallet: Wallet,
    trade_panel_open: bool,
    last_trade_msg: Option<String>,

    // Combat.
    weapon_stats: WeaponStats,
    weapon_cooldown: WeaponCooldown,
    player_shield: Shield,
    player_hull: f32,
    player_hull_max: f32,
    player_dead: bool,
    player_death_timer: f32,
    bolts: Vec<Bolt>,
    proj_vertex_buffer: wgpu::Buffer,
    proj_vertex_capacity: u64,
    proj_vertex_count: u32,
    last_combat_msg: Option<String>,
    last_combat_msg_ttl: f32,

    // NPC world — sector budget, live ships, per-slot mesh back-pointers.
    #[allow(dead_code)]
    factions: FactionRegistry,
    reputation: ReputationMatrix,
    player_faction: FactionId,
    npcs: Vec<NpcShip>,
    npc_slots: Vec<NpcSlot>,
    next_npc_id: u32,

    // M39: faction strongholds. Destroying one gates its owner
    // faction's director; rebuild restores replenishment.
    bases: Vec<FactionBase>,
    /// Mesh index for each base in [`Self::bases`] (parallel Vec).
    base_mesh_indices: Vec<usize>,

    // M43: industrial Base mirror of each FactionBase. Production
    // lines run every tick; their inventory backs the station's
    // market stock so ore is refined, not restocked from thin air.
    faction_bases: Vec<ce_base::Base>,

    // M43: NPC inner life. Keyed by NpcId so respawns don't inherit
    // the previous incumbent's poisons.
    npc_poisons: std::collections::HashMap<NpcId, ThreePoisons>,

    // M43: world-authored contracts + player log, topped up every
    // tick by `mission_gen::maybe_post_offer`.
    mission_board: MissionBoard,
    mission_log: MissionLog,
    mission_next_id: u64,
    /// Running total of Hunt-mission kills resolved since session
    /// start, keyed by (mission id, target faction). Used by
    /// auto-complete to check whether the contract's quota is met.
    mission_kill_tally: std::collections::HashMap<MissionId, u32>,

    // M44: append-only history of significant events. Populated by
    // gameplay emit sites + offline catch-up; rendered in the
    // CHRONICLE HUD panel and the full-screen history view.
    chronicle: ce_chronicle::Chronicle,
    /// Screen-space toggle for the full-history overlay (H key).
    history_panel_open: bool,
    /// Last-seen pulse vector — used by the per-tick shift detector
    /// so only genuinely-new moods emit `PulseShift` events.
    last_pulse_snapshot: WorldPulse,
    /// Real-world UNIX time of the most recent save. Zero on first
    /// boot; set by `save_world` and consumed by `catch_up` on load.
    last_save_unix: u64,
    /// Mirror of each `FactionBase.destroyed` observed last tick so
    /// we can emit chronicle events only on transitions.
    last_base_destroyed: Vec<bool>,

    // World clock — the world has been running before the player
    // arrived; we seed it at a non-zero epoch and advance every frame.
    world_clock: WorldClock,

    // M41 meta-logic: mood vector the world updates itself, and the
    // event accumulator feeding it. Pulse is never saved — it's
    // rebuilt from the epoch at boot via `pre_drift_pulse`.
    world_pulse: WorldPulse,
    pulse_events: PulseEvents,

    // M41: cold-start phase so the world visibly runs for a moment
    // before the player's avatar appears. Drains to zero on the first
    // seconds of the session.
    cold_start_remaining: f32,

    // M38 reputation decay accumulator (whole-second ticks so the
    // i32 step stays stable under small dt).
    rep_decay_accum: f32,
}

/// Shared projectile wrapper that tags each bolt with its owner so hit
/// tests can skip friendly fire.
#[derive(Debug, Clone, Copy)]
struct Bolt {
    projectile: Projectile,
    owner: FactionId,
}

/// One "seat" reserved by the sector director. Identifies the role
/// and spawn anchor; when the incumbent dies the slot starts a
/// respawn cooldown and the director fills it again.
#[derive(Debug)]
struct NpcSlot {
    role: SlotKind,
    faction: FactionId,
    base_pos: Vec3,
    mesh_index: usize,
    hull_max: f32,
    occupant: Option<NpcId>,
    respawn_timer: f32,
    /// Per-slot name counter so directors can name successors — e.g.
    /// "Guard 02" when the first one dies.
    spawn_count: u32,
}

/// Role-specific baseline for an NPC's engagement range. The
/// security mood scales this up when the sector feels unsafe (see
/// [`ce_npc::engage_range_with_security`]); the base is re-used so
/// scaling never accumulates frame over frame.
fn base_engage_range_for_role(role: SlotKind) -> f32 {
    match role {
        SlotKind::Miner | SlotKind::Trader => 18.0,
        _ => 32.0,
    }
}

/// Look up an NPC's originating slot role via the director's
/// occupancy table. Defaults to `Patrol` for orphan ids (shouldn't
/// occur in practice but keeps the per-frame path total).
fn slot_role_for_npc(slots: &[NpcSlot], id: NpcId) -> SlotKind {
    slots
        .iter()
        .find(|s| s.occupant == Some(id))
        .map(|s| s.role)
        .unwrap_or(SlotKind::Patrol)
}

const BEAM_VERTEX_COUNT: u32 = 6;
// M40: the starter sector is now wider — 3× the old layout so
// territorial play (patrol zones, pirate hideout, union depot) has
// room to breathe without a sector-change system.
const STATION_POS: Vec3 = Vec3::new(0.0, 0.0, 36.0);
const STATION_DOCK_RANGE: f32 = 9.0;

const ASTEROID_A_POS: Vec3 = Vec3::new(-16.5, 3.0, -4.5);
const ASTEROID_B_POS: Vec3 = Vec3::new(25.5, -1.5, -9.0);
/// Third body — iron, far +x beyond the protectorate zone.
const ASTEROID_C_POS: Vec3 = Vec3::new(40.0, 5.0, 6.0);
/// Fourth body — platinum, deep in pirate territory.
const ASTEROID_D_POS: Vec3 = Vec3::new(-8.0, -2.0, -55.0);
/// Union depot — a second trade node near the mining fields.
const UNION_DEPOT_POS: Vec3 = Vec3::new(30.0, 1.0, -18.0);
/// Crimson Fang hideout — the pirate reinforcement source.
const CRIMSON_HIDEOUT_POS: Vec3 = Vec3::new(0.0, 2.0, -55.0);

const ORE: ItemId = ItemId::new("iron_ore");
const PLATINUM: ItemId = ItemId::new("platinum_ore");

/// Bolt muzzle speed (m/s). Fast enough to feel snappy, slow enough to
/// read visually over the ~25m combat stage.
const PROJECTILE_SPEED: f32 = 80.0;
/// Half-width of the rendered projectile quad in world units.
const PROJECTILE_HALF_WIDTH: f32 = 0.08;
/// How far the projectile spawns ahead of the ship nose along its
/// forward axis so it doesn't clip the cockpit.
const PROJECTILE_SPAWN_FORWARD: f32 = 2.0;

// -----------------------------------------------------------------
// Factions — the handful of citizens of the starter sector.
// -----------------------------------------------------------------
const F_PLAYER: FactionId = FactionId::new("ronin");
const F_PROTECTORATE: FactionId = FactionId::new("protectorate");
const F_UNION: FactionId = FactionId::new("union");
const F_CRIMSON: FactionId = FactionId::new("crimson");

/// Collision radius used for projectile hits against any ship.
const SHIP_HIT_RADIUS: f32 = 1.8;
/// Collision radius for the player ship.
const PLAYER_HIT_RADIUS: f32 = 1.5;
/// Bounding radius used to despawn bolts that strike an asteroid.
const ASTEROID_HIT_RADIUS: f32 = 1.5;
/// Director cooldown: how long a slot stays vacant before the AI
/// director spawns a fresh individual.
const NPC_RESPAWN_SECONDS: f32 = 8.0;
/// Player respawn countdown.
const PLAYER_RESPAWN_SECONDS: f32 = 3.0;

// -----------------------------------------------------------------
// World clock — the world exists before the player arrives.
// -----------------------------------------------------------------
/// Deterministic seed for the starter sector. Changing this reshuffles
/// every NPC's starting position, market drift, and asteroid wear.
const WORLD_SEED: u64 = 0x0C0F_FEE0_D15E_A5E0;
/// Initial world age at launch. Thirty in-universe minutes have
/// elapsed before the first frame the player ever sees.
const INITIAL_WORLD_EPOCH_SECONDS: f64 = 1_800.0;

/// How long the world runs without the player's avatar accepting
/// input at session start. The NPCs, bases, and pulse tick; the
/// player's ship is held off-screen until the timer drains. This
/// makes it viscerally clear that the world existed before the
/// player arrived.
const COLD_START_SECONDS: f32 = 3.0;

// Restock rates applied to the station's market at launch (for
// pre-drift) and live per frame. Tuned so 1800 s of pre-drift makes a
// visible dent without saturating to equilibrium.
const ORE_RESTOCK_PER_SECOND: f32 = 0.02;
const PLATINUM_RESTOCK_PER_SECOND: f32 = 0.008;

// Salts keep different subsystems' PRNG streams independent.
// Market drift is deterministic (rate * dt) and doesn't need a salt;
// the asteroid and NPC seeding paths do.
const SALT_ASTEROID: u64 = 0x2;
const SALT_NPC_SLOT_BASE: u64 = 0x100;
const SALT_NPC_RESPAWN_BASE: u64 = 0x200;

impl Renderer {
    fn new(window: &Window) -> Self {
        let size = window.inner_size();
        let instance = wgpu::Instance::new(&wgpu::InstanceDescriptor {
            backends: wgpu::Backends::all(),
            ..Default::default()
        });
        let surface: wgpu::Surface<'static> = unsafe {
            mem::transmute::<wgpu::Surface<'_>, wgpu::Surface<'static>>(
                instance.create_surface(window).expect("create surface"),
            )
        };
        let adapter = pollster::block_on(instance.request_adapter(&wgpu::RequestAdapterOptions {
            power_preference: wgpu::PowerPreference::HighPerformance,
            compatible_surface: Some(&surface),
            force_fallback_adapter: false,
        }))
        .expect("request_adapter");
        log::info!("GPU: {}", adapter.get_info().name);

        let (device, queue) = pollster::block_on(adapter.request_device(
            &wgpu::DeviceDescriptor {
                label: Some("play_demo device"),
                required_features: wgpu::Features::empty(),
                required_limits: wgpu::Limits::default(),
                memory_hints: wgpu::MemoryHints::default(),
            },
            None,
        ))
        .expect("request_device");

        let caps = surface.get_capabilities(&adapter);
        let format = caps
            .formats
            .iter()
            .find(|f| f.is_srgb())
            .copied()
            .unwrap_or(caps.formats[0]);
        let config = wgpu::SurfaceConfiguration {
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
            format,
            width: size.width.max(1),
            height: size.height.max(1),
            present_mode: wgpu::PresentMode::AutoVsync,
            alpha_mode: caps.alpha_modes[0],
            view_formats: vec![],
            desired_maximum_frame_latency: 2,
        };
        surface.configure(&device, &config);

        // --- Shared bind-group layout (single mat4 uniform) ---
        let uniform_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("uniform BGL"),
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::VERTEX | wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            }],
        });

        // --- Frame uniform (shared by planet + hull pipelines) ---
        let planet_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("planet shader"),
            source: wgpu::ShaderSource::Wgsl(
                build_planet_shader(PlanetShaderParams::default()).into(),
            ),
        });
        let hull_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("hull shader"),
            source: wgpu::ShaderSource::Wgsl(build_hull_shader(HullShaderParams::default()).into()),
        });
        let frame_uniform = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("frame UB"),
            size: mem::size_of::<FrameUniform>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let frame_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("frame BG"),
            layout: &uniform_bgl,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: frame_uniform.as_entire_binding(),
            }],
        });
        let mesh_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("mesh PL"),
            bind_group_layouts: &[&uniform_bgl],
            push_constant_ranges: &[],
        });
        let planet_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("planet pipeline"),
            layout: Some(&mesh_layout),
            vertex: wgpu::VertexState {
                module: &planet_shader,
                entry_point: Some("vs_main"),
                buffers: &[Vertex::desc()],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &planet_shader,
                entry_point: Some("fs_main"),
                targets: &[Some(wgpu::ColorTargetState {
                    format: HDR_FORMAT,
                    blend: Some(wgpu::BlendState::REPLACE),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState {
                topology: wgpu::PrimitiveTopology::TriangleList,
                strip_index_format: None,
                front_face: wgpu::FrontFace::Ccw,
                cull_mode: Some(wgpu::Face::Back),
                polygon_mode: wgpu::PolygonMode::Fill,
                unclipped_depth: false,
                conservative: false,
            },
            depth_stencil: Some(wgpu::DepthStencilState {
                format: DEPTH_FORMAT,
                depth_write_enabled: true,
                depth_compare: wgpu::CompareFunction::Less,
                stencil: wgpu::StencilState::default(),
                bias: wgpu::DepthBiasState::default(),
            }),
            multisample: wgpu::MultisampleState::default(),
            multiview: None,
            cache: None,
        });

        // --- Hull pipeline (share frame uniform + layout) ---
        let hull_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("hull pipeline"),
            layout: Some(&mesh_layout),
            vertex: wgpu::VertexState {
                module: &hull_shader,
                entry_point: Some("vs_main"),
                buffers: &[Vertex::desc()],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &hull_shader,
                entry_point: Some("fs_main"),
                targets: &[Some(wgpu::ColorTargetState {
                    format: HDR_FORMAT,
                    blend: Some(wgpu::BlendState::REPLACE),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState {
                topology: wgpu::PrimitiveTopology::TriangleList,
                strip_index_format: None,
                front_face: wgpu::FrontFace::Ccw,
                cull_mode: Some(wgpu::Face::Back),
                polygon_mode: wgpu::PolygonMode::Fill,
                unclipped_depth: false,
                conservative: false,
            },
            depth_stencil: Some(wgpu::DepthStencilState {
                format: DEPTH_FORMAT,
                depth_write_enabled: true,
                depth_compare: wgpu::CompareFunction::Less,
                stencil: wgpu::StencilState::default(),
                bias: wgpu::DepthBiasState::default(),
            }),
            multisample: wgpu::MultisampleState::default(),
            multiview: None,
            cache: None,
        });

        // --- Starfield pipeline (procedural fullscreen triangle) ---
        let star_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("starfield shader"),
            source: wgpu::ShaderSource::Wgsl(
                build_starfield_shader(StarfieldParams {
                    density: 0.9985,
                    intensity: 1.6,
                    seed: 0xBEEF_CAFE_u64,
                })
                .into(),
            ),
        });
        let star_uniform = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("star UB"),
            size: mem::size_of::<StarfieldUniform>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let star_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("star BG"),
            layout: &uniform_bgl,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: star_uniform.as_entire_binding(),
            }],
        });
        let star_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("star PL"),
            bind_group_layouts: &[&uniform_bgl],
            push_constant_ranges: &[],
        });
        let star_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("star pipeline"),
            layout: Some(&star_layout),
            vertex: wgpu::VertexState {
                module: &star_shader,
                entry_point: Some("vs_main"),
                buffers: &[], // full-screen triangle, no VB
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &star_shader,
                entry_point: Some("fs_main"),
                targets: &[Some(wgpu::ColorTargetState {
                    format: HDR_FORMAT,
                    blend: Some(wgpu::BlendState::REPLACE),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState {
                topology: wgpu::PrimitiveTopology::TriangleList,
                strip_index_format: None,
                front_face: wgpu::FrontFace::Ccw,
                cull_mode: None, // fullscreen
                polygon_mode: wgpu::PolygonMode::Fill,
                unclipped_depth: false,
                conservative: false,
            },
            depth_stencil: Some(wgpu::DepthStencilState {
                format: DEPTH_FORMAT,
                depth_write_enabled: false,
                depth_compare: wgpu::CompareFunction::LessEqual,
                stencil: wgpu::StencilState::default(),
                bias: wgpu::DepthBiasState::default(),
            }),
            multisample: wgpu::MultisampleState::default(),
            multiview: None,
            cache: None,
        });

        // --- HUD pipeline (screen-space coloured quads, alpha blended) ---
        let hud_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("hud shader"),
            source: wgpu::ShaderSource::Wgsl(build_hud_overlay_shader(HudOverlayParams).into()),
        });
        let hud_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("hud PL"),
            bind_group_layouts: &[],
            push_constant_ranges: &[],
        });
        let hud_vertex_layout = wgpu::VertexBufferLayout {
            array_stride: std::mem::size_of::<HudVertex>() as wgpu::BufferAddress,
            step_mode: wgpu::VertexStepMode::Vertex,
            attributes: &[
                wgpu::VertexAttribute {
                    offset: 0,
                    shader_location: 0,
                    format: wgpu::VertexFormat::Float32x3,
                },
                wgpu::VertexAttribute {
                    offset: std::mem::size_of::<[f32; 3]>() as u64,
                    shader_location: 1,
                    format: wgpu::VertexFormat::Float32x4,
                },
            ],
        };
        let hud_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("hud pipeline"),
            layout: Some(&hud_layout),
            vertex: wgpu::VertexState {
                module: &hud_shader,
                entry_point: Some("vs_main"),
                buffers: &[hud_vertex_layout],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &hud_shader,
                entry_point: Some("fs_main"),
                targets: &[Some(wgpu::ColorTargetState {
                    format,
                    blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState {
                topology: wgpu::PrimitiveTopology::TriangleList,
                strip_index_format: None,
                front_face: wgpu::FrontFace::Ccw,
                cull_mode: None,
                polygon_mode: wgpu::PolygonMode::Fill,
                unclipped_depth: false,
                conservative: false,
            },
            // HUD runs in its own pass after tonemap — no depth
            // attachment needed and the HUD always paints on top.
            depth_stencil: None,
            multisample: wgpu::MultisampleState::default(),
            multiview: None,
            cache: None,
        });
        let hud_vertex_capacity: u64 = 4096 * std::mem::size_of::<HudVertex>() as u64;
        let hud_vertex_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("hud VB"),
            size: hud_vertex_capacity,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        // World-space mining beam: a 6-vertex thin quad refreshed each
        // frame while the player is firing, rendered through the hull
        // pipeline since its vertex layout matches.
        let beam_vertex_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("beam VB"),
            size: (BEAM_VERTEX_COUNT as u64) * std::mem::size_of::<Vertex>() as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        // Dynamic projectile vertex buffer. 6 verts per bolt. Grows on
        // demand; the initial capacity holds 64 projectiles which is
        // plenty for a single laser at 2Hz with a 2s lifetime.
        let proj_vertex_capacity: u64 = 64 * 6 * std::mem::size_of::<Vertex>() as u64;
        let proj_vertex_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("projectile VB"),
            size: proj_vertex_capacity,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        let depth_view = create_depth_view(&device, &config);

        // --- HDR scene target + bloom ping-pong textures ---
        let hdr_view = create_hdr_view(&device, &config);
        let bloom_a_view = create_bloom_view(&device, &config, "bloom A");
        let bloom_b_view = create_bloom_view(&device, &config, "bloom B");

        let linear_sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            label: Some("linear clamp sampler"),
            address_mode_u: wgpu::AddressMode::ClampToEdge,
            address_mode_v: wgpu::AddressMode::ClampToEdge,
            address_mode_w: wgpu::AddressMode::ClampToEdge,
            mag_filter: wgpu::FilterMode::Linear,
            min_filter: wgpu::FilterMode::Linear,
            mipmap_filter: wgpu::FilterMode::Nearest,
            ..Default::default()
        });

        // --- Post-process bind-group layouts ---
        let postprocess_1tex_bgl =
            device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: Some("postprocess 1tex BGL"),
                entries: &[
                    wgpu::BindGroupLayoutEntry {
                        binding: 0,
                        visibility: wgpu::ShaderStages::FRAGMENT,
                        ty: wgpu::BindingType::Texture {
                            sample_type: wgpu::TextureSampleType::Float { filterable: true },
                            view_dimension: wgpu::TextureViewDimension::D2,
                            multisampled: false,
                        },
                        count: None,
                    },
                    wgpu::BindGroupLayoutEntry {
                        binding: 1,
                        visibility: wgpu::ShaderStages::FRAGMENT,
                        ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                        count: None,
                    },
                ],
            });
        let postprocess_2tex_bgl =
            device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: Some("postprocess 2tex BGL"),
                entries: &[
                    wgpu::BindGroupLayoutEntry {
                        binding: 0,
                        visibility: wgpu::ShaderStages::FRAGMENT,
                        ty: wgpu::BindingType::Texture {
                            sample_type: wgpu::TextureSampleType::Float { filterable: true },
                            view_dimension: wgpu::TextureViewDimension::D2,
                            multisampled: false,
                        },
                        count: None,
                    },
                    wgpu::BindGroupLayoutEntry {
                        binding: 1,
                        visibility: wgpu::ShaderStages::FRAGMENT,
                        ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                        count: None,
                    },
                    wgpu::BindGroupLayoutEntry {
                        binding: 2,
                        visibility: wgpu::ShaderStages::FRAGMENT,
                        ty: wgpu::BindingType::Texture {
                            sample_type: wgpu::TextureSampleType::Float { filterable: true },
                            view_dimension: wgpu::TextureViewDimension::D2,
                            multisampled: false,
                        },
                        count: None,
                    },
                    wgpu::BindGroupLayoutEntry {
                        binding: 3,
                        visibility: wgpu::ShaderStages::FRAGMENT,
                        ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                        count: None,
                    },
                ],
            });

        // --- Post-process shader modules + pipelines ---
        let bloom_extract_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("bloom extract shader"),
            source: wgpu::ShaderSource::Wgsl(build_bloom_extract().into()),
        });
        let bloom_blur_h_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("bloom blur H shader"),
            source: wgpu::ShaderSource::Wgsl(build_bloom_blur(true).into()),
        });
        let bloom_blur_v_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("bloom blur V shader"),
            source: wgpu::ShaderSource::Wgsl(build_bloom_blur(false).into()),
        });
        let tonemap_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("tonemap composite shader"),
            source: wgpu::ShaderSource::Wgsl(build_tonemap_composite().into()),
        });

        let postprocess_1tex_layout =
            device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                label: Some("postprocess 1tex PL"),
                bind_group_layouts: &[&postprocess_1tex_bgl],
                push_constant_ranges: &[],
            });
        let postprocess_2tex_layout =
            device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                label: Some("postprocess 2tex PL"),
                bind_group_layouts: &[&postprocess_2tex_bgl],
                push_constant_ranges: &[],
            });

        let make_postprocess_pipeline = |label: &'static str,
                                         shader: &wgpu::ShaderModule,
                                         layout: &wgpu::PipelineLayout,
                                         target_format: wgpu::TextureFormat|
         -> wgpu::RenderPipeline {
            device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
                label: Some(label),
                layout: Some(layout),
                vertex: wgpu::VertexState {
                    module: shader,
                    entry_point: Some("vs_main"),
                    buffers: &[],
                    compilation_options: Default::default(),
                },
                fragment: Some(wgpu::FragmentState {
                    module: shader,
                    entry_point: Some("fs_main"),
                    targets: &[Some(wgpu::ColorTargetState {
                        format: target_format,
                        blend: Some(wgpu::BlendState::REPLACE),
                        write_mask: wgpu::ColorWrites::ALL,
                    })],
                    compilation_options: Default::default(),
                }),
                primitive: wgpu::PrimitiveState {
                    topology: wgpu::PrimitiveTopology::TriangleList,
                    strip_index_format: None,
                    front_face: wgpu::FrontFace::Ccw,
                    cull_mode: None,
                    polygon_mode: wgpu::PolygonMode::Fill,
                    unclipped_depth: false,
                    conservative: false,
                },
                depth_stencil: None,
                multisample: wgpu::MultisampleState::default(),
                multiview: None,
                cache: None,
            })
        };

        let bloom_extract_pipeline = make_postprocess_pipeline(
            "bloom extract pipeline",
            &bloom_extract_shader,
            &postprocess_1tex_layout,
            HDR_FORMAT,
        );
        let bloom_blur_h_pipeline = make_postprocess_pipeline(
            "bloom blur H pipeline",
            &bloom_blur_h_shader,
            &postprocess_1tex_layout,
            HDR_FORMAT,
        );
        let bloom_blur_v_pipeline = make_postprocess_pipeline(
            "bloom blur V pipeline",
            &bloom_blur_v_shader,
            &postprocess_1tex_layout,
            HDR_FORMAT,
        );
        let tonemap_pipeline = make_postprocess_pipeline(
            "tonemap composite pipeline",
            &tonemap_shader,
            &postprocess_2tex_layout,
            format,
        );

        let bloom_extract_bg = create_1tex_bind_group(
            &device,
            &postprocess_1tex_bgl,
            &hdr_view,
            &linear_sampler,
            "bloom extract BG",
        );
        let bloom_blur_h_bg = create_1tex_bind_group(
            &device,
            &postprocess_1tex_bgl,
            &bloom_a_view,
            &linear_sampler,
            "bloom blur H BG",
        );
        let bloom_blur_v_bg = create_1tex_bind_group(
            &device,
            &postprocess_1tex_bgl,
            &bloom_b_view,
            &linear_sampler,
            "bloom blur V BG",
        );
        let tonemap_bg = create_2tex_bind_group(
            &device,
            &postprocess_2tex_bgl,
            &hdr_view,
            &bloom_a_view,
            &linear_sampler,
            "tonemap BG",
        );

        // --- Procedural meshes ---
        let ship = build_ship();
        let ship_mesh = build_ship_mesh(&ship);
        let planet = Planet::earth_like(PlanetId(1), WorldPos::ZERO, 42);
        let planet_mesh = build_planet_mesh(Some(&planet), 24);
        let asteroid_a_mesh = build_asteroid(0xA51E_0001, 1.2, 0.3, 10);
        let asteroid_b_mesh = build_asteroid(0xA51E_0042, 0.9, 0.4, 10);
        let asteroid_c_mesh = build_asteroid(0xA51E_0077, 1.5, 0.25, 11);
        let asteroid_d_mesh = build_asteroid(0xA51E_00AB, 0.7, 0.45, 9);
        let station_blocks = build_station();
        let station_mesh = build_ship_mesh(&station_blocks);
        let union_depot_mesh = build_ship_mesh(&build_union_depot());
        let crimson_hideout_mesh = build_ship_mesh(&build_crimson_hideout());
        // Three NPC mesh templates, baked once and shared by future
        // successors in the same slot. Tunable if we later want
        // per-individual variation.
        let patrol_mesh = build_ship_mesh(&build_npc_blocks(SlotKind::Patrol));
        let miner_mesh = build_ship_mesh(&build_npc_blocks(SlotKind::Miner));
        let pirate_mesh = build_ship_mesh(&build_npc_blocks(SlotKind::Pirate));

        let ship_start = Vec3::new(6.0, 0.5, 0.0);
        let ship_gpu =
            GpuMesh::upload_dynamic(&device, &ship_mesh, "ship", ship_start, MaterialKind::Hull);
        // Seed the ship VB with its first-frame positions.
        let seeded = translate_vertices(ship_gpu.base_vertices.as_ref().unwrap(), ship_start);
        queue.write_buffer(&ship_gpu.vertex_buffer, 0, bytemuck::cast_slice(&seeded));
        let meshes = vec![
            ship_gpu,
            GpuMesh::upload_static(
                &device,
                &planet_mesh,
                "planet",
                Mat4::from_scale(Vec3::splat(3.0)),
                MaterialKind::Planet,
            ),
            GpuMesh::upload_static(
                &device,
                &asteroid_a_mesh,
                "asteroid_a",
                Mat4::from_translation(ASTEROID_A_POS),
                MaterialKind::Hull,
            ),
            GpuMesh::upload_static(
                &device,
                &asteroid_b_mesh,
                "asteroid_b",
                Mat4::from_translation(ASTEROID_B_POS),
                MaterialKind::Hull,
            ),
            GpuMesh::upload_static(
                &device,
                &asteroid_c_mesh,
                "asteroid_c",
                Mat4::from_translation(ASTEROID_C_POS),
                MaterialKind::Hull,
            ),
            GpuMesh::upload_static(
                &device,
                &asteroid_d_mesh,
                "asteroid_d",
                Mat4::from_translation(ASTEROID_D_POS),
                MaterialKind::Hull,
            ),
            // Stronghold meshes are dynamic so we can hide them when
            // destroyed and re-place them on rebuild without burning
            // more pipelines.
            GpuMesh::upload_dynamic(
                &device,
                &station_mesh,
                "protectorate_station",
                STATION_POS,
                MaterialKind::Hull,
            ),
            GpuMesh::upload_dynamic(
                &device,
                &union_depot_mesh,
                "union_depot",
                UNION_DEPOT_POS,
                MaterialKind::Hull,
            ),
            GpuMesh::upload_dynamic(
                &device,
                &crimson_hideout_mesh,
                "crimson_hideout",
                CRIMSON_HIDEOUT_POS,
                MaterialKind::Hull,
            ),
            GpuMesh::upload_dynamic(
                &device,
                &patrol_mesh,
                "npc_patrol",
                Vec3::ZERO,
                MaterialKind::Hull,
            ),
            GpuMesh::upload_dynamic(
                &device,
                &miner_mesh,
                "npc_miner",
                Vec3::ZERO,
                MaterialKind::Hull,
            ),
            GpuMesh::upload_dynamic(
                &device,
                &pirate_mesh,
                "npc_pirate",
                Vec3::ZERO,
                MaterialKind::Hull,
            ),
        ];
        let patrol_mesh_index = meshes.len() - 3;
        let miner_mesh_index = meshes.len() - 2;
        let pirate_mesh_index = meshes.len() - 1;
        // Stronghold meshes sit three slots before the NPC meshes.
        let station_mesh_index = meshes.len() - 6;
        let depot_mesh_index = meshes.len() - 5;
        let hideout_mesh_index = meshes.len() - 4;

        // Seed NPC meshes offscreen until their slots are filled by
        // the director on the first frame.
        for idx in [patrol_mesh_index, miner_mesh_index, pirate_mesh_index] {
            let m = &meshes[idx];
            let seeded = translate_vertices(
                m.base_vertices.as_ref().unwrap(),
                Vec3::new(0.0, -10_000.0, 0.0),
            );
            queue.write_buffer(&m.vertex_buffer, 0, bytemuck::cast_slice(&seeded));
        }

        // Seed stronghold meshes at their anchor positions.
        for (idx, pos) in [
            (station_mesh_index, STATION_POS),
            (depot_mesh_index, UNION_DEPOT_POS),
            (hideout_mesh_index, CRIMSON_HIDEOUT_POS),
        ] {
            let m = &meshes[idx];
            let seeded = translate_vertices(m.base_vertices.as_ref().unwrap(), pos);
            queue.write_buffer(&m.vertex_buffer, 0, bytemuck::cast_slice(&seeded));
        }

        let ship_mass = compute_mass_properties(&ship);
        let ship_thrust = compute_thrust_budget(&ship);
        log::info!(
            "scene ready: ship mass={:.0}kg +x thrust={:.0}N, planet {}v, asteroid {}v",
            ship_mass.mass,
            ship_thrust.pos_x,
            meshes[1].vertex_count,
            meshes[2].vertex_count
        );

        // The world has been running before we started watching it.
        // Seed the clock at a non-zero epoch, then apply that epoch's
        // worth of drift to everything mutable the player can see.
        let world_clock = WorldClock::with_epoch(WORLD_SEED, INITIAL_WORLD_EPOCH_SECONDS);

        let mut market = build_station_market();
        pre_drift_market(&mut market, INITIAL_WORLD_EPOCH_SECONDS as f32);

        let mut asteroid_nodes = vec![
            ResourceNode::new(NodeId(1), world_pos_of(ASTEROID_A_POS), ORE, 500),
            ResourceNode::new(NodeId(2), world_pos_of(ASTEROID_B_POS), PLATINUM, 250)
                .with_hardness(2.0),
            ResourceNode::new(NodeId(3), world_pos_of(ASTEROID_C_POS), ORE, 650),
            ResourceNode::new(NodeId(4), world_pos_of(ASTEROID_D_POS), PLATINUM, 180)
                .with_hardness(2.5),
        ];
        pre_drift_asteroids(&mut asteroid_nodes, &world_clock);

        let mut r = Self {
            surface,
            device,
            queue,
            config,
            planet_pipeline,
            hull_pipeline,
            frame_uniform,
            frame_bind_group,
            star_pipeline,
            star_uniform,
            star_bind_group,
            hdr_view,
            bloom_a_view,
            bloom_b_view,
            linear_sampler,
            postprocess_1tex_bgl,
            postprocess_2tex_bgl,
            bloom_extract_pipeline,
            bloom_blur_h_pipeline,
            bloom_blur_v_pipeline,
            tonemap_pipeline,
            bloom_extract_bg,
            bloom_blur_h_bg,
            bloom_blur_v_bg,
            tonemap_bg,
            hud_pipeline,
            hud_vertex_buffer,
            hud_vertex_capacity,
            hud_vertex_count: 0,
            depth_view,
            meshes,
            ship_pos: ship_start,
            ship_vel: Vec3::ZERO,
            ship_orient: Quat::IDENTITY,
            ship_angular_vel: Vec3::ZERO,
            ship_mass,
            ship_thrust,
            ship_mesh_index: 0,
            time: 0.0,
            // Static dots: planet + asteroids. Stations and bases are
            // now added dynamically so destroyed ones disappear.
            minimap_targets: vec![
                (Vec3::ZERO, [0.4, 0.7, 1.0, 1.0]),
                (ASTEROID_A_POS, [0.9, 0.6, 0.3, 1.0]),
                (ASTEROID_B_POS, [0.7, 0.7, 0.95, 1.0]),
                (ASTEROID_C_POS, [0.9, 0.6, 0.3, 1.0]),
                (ASTEROID_D_POS, [0.7, 0.7, 0.95, 1.0]),
            ],
            mining_beam: MiningBeam::basic(),
            asteroid_nodes,
            target_index: None,
            inventory: Inventory::new(1_000),
            last_mine_result: None,
            beam_vertex_buffer,
            beam_active: false,
            station_pos: STATION_POS,
            market,
            wallet: Wallet::new(0),
            trade_panel_open: false,
            last_trade_msg: None,
            weapon_stats: WeaponStats::laser_turret(),
            weapon_cooldown: WeaponCooldown::new(),
            player_shield: Shield::new(200.0, 40.0, 3.0),
            player_hull: 400.0,
            player_hull_max: 400.0,
            player_dead: false,
            player_death_timer: 0.0,
            bolts: Vec::new(),
            proj_vertex_buffer,
            proj_vertex_capacity,
            proj_vertex_count: 0,
            last_combat_msg: None,
            last_combat_msg_ttl: 0.0,
            factions: build_faction_registry(),
            reputation: build_starter_reputation(),
            player_faction: F_PLAYER,
            npcs: Vec::new(),
            npc_slots: vec![
                NpcSlot {
                    role: SlotKind::Patrol,
                    faction: F_PROTECTORATE,
                    base_pos: STATION_POS + Vec3::new(0.0, 4.0, 0.0),
                    mesh_index: patrol_mesh_index,
                    hull_max: 180.0,
                    occupant: None,
                    respawn_timer: 0.5,
                    spawn_count: 0,
                },
                NpcSlot {
                    role: SlotKind::Miner,
                    faction: F_UNION,
                    base_pos: ASTEROID_B_POS + Vec3::new(2.5, 0.5, 1.0),
                    mesh_index: miner_mesh_index,
                    hull_max: 220.0,
                    occupant: None,
                    respawn_timer: 1.0,
                    spawn_count: 0,
                },
                NpcSlot {
                    role: SlotKind::Pirate,
                    faction: F_CRIMSON,
                    base_pos: Vec3::new(0.0, 3.0, -18.0),
                    mesh_index: pirate_mesh_index,
                    hull_max: 260.0,
                    occupant: None,
                    respawn_timer: 1.5,
                    spawn_count: 0,
                },
            ],
            next_npc_id: 1,
            bases: vec![
                FactionBase::new(
                    NpcBaseId(1),
                    F_PROTECTORATE,
                    "Protectorate Station",
                    STATION_POS,
                    1500.0,
                    Shield::new(500.0, 60.0, 3.0),
                )
                .with_hit_radius(5.0)
                .with_rebuild(120.0, 0.7),
                FactionBase::new(
                    NpcBaseId(2),
                    F_UNION,
                    "Union Depot",
                    UNION_DEPOT_POS,
                    600.0,
                    Shield::new(200.0, 30.0, 3.0),
                )
                .with_hit_radius(3.5)
                .with_rebuild(90.0, 0.6),
                FactionBase::new(
                    NpcBaseId(3),
                    F_CRIMSON,
                    "Reaver's Nest",
                    CRIMSON_HIDEOUT_POS,
                    800.0,
                    Shield::new(250.0, 25.0, 3.0),
                )
                .with_hit_radius(4.0)
                .with_rebuild(75.0, 0.5),
            ],
            base_mesh_indices: vec![station_mesh_index, depot_mesh_index, hideout_mesh_index],
            faction_bases: vec![
                stations::build_protectorate_station(F_PROTECTORATE),
                stations::build_union_depot(F_UNION),
                stations::build_reavers_nest(F_CRIMSON),
            ],
            npc_poisons: std::collections::HashMap::new(),
            mission_board: MissionBoard::new(),
            mission_log: MissionLog::new(),
            mission_next_id: 1,
            mission_kill_tally: std::collections::HashMap::new(),
            chronicle: ce_chronicle::Chronicle::default(),
            history_panel_open: false,
            last_pulse_snapshot: pre_drift_pulse(WORLD_SEED, INITIAL_WORLD_EPOCH_SECONDS),
            last_save_unix: 0,
            last_base_destroyed: vec![false; 3],
            world_clock,
            world_pulse: pre_drift_pulse(WORLD_SEED, INITIAL_WORLD_EPOCH_SECONDS),
            pulse_events: PulseEvents::default(),
            cold_start_remaining: COLD_START_SECONDS,
            rep_decay_accum: 0.0,
        };
        // M44: seed the chronicle with a world-born marker so even a
        // fresh session has a visible origin point on the timeline.
        r.chronicle.push(ce_chronicle::WorldEvent {
            timestamp_seconds: 0.0,
            kind: ce_chronicle::EventKind::WorldBorn { seed: WORLD_SEED },
        });
        if load_world_into(&mut r) {
            log::info!("loaded save from {}", SAVE_PATH);
            // M44: restore history from its sidecar file, then run
            // offline catch-up for the wall-clock delta since save.
            load_chronicle_into(&mut r);
            run_offline_catch_up(&mut r);
        }
        r
    }

    fn resize(&mut self, width: u32, height: u32) {
        if width == 0 || height == 0 {
            return;
        }
        self.config.width = width;
        self.config.height = height;
        self.surface.configure(&self.device, &self.config);
        self.depth_view = create_depth_view(&self.device, &self.config);

        // HDR + bloom targets are window-sized — rebuild them and the
        // bind groups that point at them.
        self.hdr_view = create_hdr_view(&self.device, &self.config);
        self.bloom_a_view = create_bloom_view(&self.device, &self.config, "bloom A");
        self.bloom_b_view = create_bloom_view(&self.device, &self.config, "bloom B");
        self.bloom_extract_bg = create_1tex_bind_group(
            &self.device,
            &self.postprocess_1tex_bgl,
            &self.hdr_view,
            &self.linear_sampler,
            "bloom extract BG",
        );
        self.bloom_blur_h_bg = create_1tex_bind_group(
            &self.device,
            &self.postprocess_1tex_bgl,
            &self.bloom_a_view,
            &self.linear_sampler,
            "bloom blur H BG",
        );
        self.bloom_blur_v_bg = create_1tex_bind_group(
            &self.device,
            &self.postprocess_1tex_bgl,
            &self.bloom_b_view,
            &self.linear_sampler,
            "bloom blur V BG",
        );
        self.tonemap_bg = create_2tex_bind_group(
            &self.device,
            &self.postprocess_2tex_bgl,
            &self.hdr_view,
            &self.bloom_a_view,
            &self.linear_sampler,
            "tonemap BG",
        );
    }

    fn update(&mut self, input: ThrustInput, dt: f32) {
        // During the cold-start window the player's controls are
        // ignored so the world visibly runs on its own for a beat.
        // NPCs, bases, and the pulse still tick normally.
        let in_cold_start = self.cold_start_remaining > 0.0;
        let effective_input = if in_cold_start {
            ThrustInput::default()
        } else {
            input
        };
        let cmd = effective_input.to_command();

        // Angular: snap-to-target with assist damping.
        self.ship_angular_vel = advance_angular(&cmd, self.ship_angular_vel, dt);
        if self.ship_angular_vel.length_squared() > 1e-10 {
            // Build incremental quaternion from per-axis rate * dt.
            let omega = self.ship_angular_vel * dt;
            let dq = Quat::from_axis_angle(omega.normalize(), omega.length());
            self.ship_orient = (self.ship_orient * dq).normalize();
        }

        // Linear thrust is in the ship-local frame; rotate into world.
        let local_vel = advance_linear(
            &cmd,
            &self.ship_thrust,
            &self.ship_mass,
            self.ship_orient.inverse() * self.ship_vel,
            dt,
        );
        self.ship_vel = self.ship_orient * local_vel;
        self.ship_pos += self.ship_vel * dt;
        self.time += dt;
        self.world_clock.tick(dt);
        self.cold_start_remaining = (self.cold_start_remaining - dt).max(0.0);

        // Re-upload the ship mesh transformed to its world pose.
        let ship = &mut self.meshes[self.ship_mesh_index];
        ship.origin = self.ship_pos;
        if let Some(base) = ship.base_vertices.as_ref() {
            let world = transform_vertices(base, self.ship_pos, self.ship_orient);
            self.queue
                .write_buffer(&ship.vertex_buffer, 0, bytemuck::cast_slice(&world));
        }

        // Target acquisition: nearest non-depleted node inside beam range.
        let shooter = world_pos_of(self.ship_pos);
        self.target_index =
            nearest_in_range(&self.asteroid_nodes, shooter, self.mining_beam.range_meters);

        // Mining tick against the acquired target.
        if input.mine {
            if let Some(idx) = self.target_index {
                self.last_mine_result = Some(mine_tick(
                    &self.mining_beam,
                    &mut self.asteroid_nodes[idx],
                    shooter,
                    &mut self.inventory,
                    dt,
                ));
            } else {
                self.last_mine_result = Some(MineResult::OutOfRange);
            }
        } else {
            self.last_mine_result = None;
        }

        // Refresh visual beam geometry when actively mining a target.
        self.beam_active = input.mine && self.target_index.is_some();
        if self.beam_active {
            let idx = self.target_index.unwrap();
            let target = &self.asteroid_nodes[idx];
            let target_pos = Vec3::new(
                target.position.0.x as f32,
                target.position.0.y as f32,
                target.position.0.z as f32,
            );
            // Emerge from just in front of the ship along its forward
            // axis so the beam doesn't intersect the cockpit.
            let start = self.ship_pos + self.ship_orient * Vec3::new(0.0, 0.0, -1.5);
            let beam_color = match self.last_mine_result {
                Some(MineResult::Extracted(_)) => [1.0, 0.85, 0.25, 1.0],
                _ => [1.0, 0.4, 0.3, 1.0],
            };
            let beam = build_beam_quad(start, target_pos, 0.06, beam_color);
            self.queue
                .write_buffer(&self.beam_vertex_buffer, 0, bytemuck::cast_slice(&beam));
        }

        self.tick_combat(effective_input.fire, dt);
    }

    /// One frame of the combat + NPC simulation: advance cooldowns,
    /// let NPCs act on their goals, resolve every bolt's hit test
    /// against every ship and asteroid, propagate deaths, and refill
    /// any slot the director has vacated.
    fn tick_combat(&mut self, fire_pressed: bool, dt: f32) {
        self.weapon_cooldown.tick(dt);
        self.player_shield.tick(dt);

        // Fade the transient combat message.
        if self.last_combat_msg_ttl > 0.0 {
            self.last_combat_msg_ttl = (self.last_combat_msg_ttl - dt).max(0.0);
            if self.last_combat_msg_ttl == 0.0 {
                self.last_combat_msg = None;
            }
        }

        // Player respawn gate — skip all player-driven behaviour while
        // dead. NPCs continue their routines: they are citizens of the
        // world, not stage hands waiting for the player to reappear.
        if self.player_dead {
            self.player_death_timer = (self.player_death_timer - dt).max(0.0);
            if self.player_death_timer == 0.0 {
                self.ship_pos = self.station_pos + Vec3::new(0.0, 1.5, -6.0);
                self.ship_vel = Vec3::ZERO;
                self.ship_angular_vel = Vec3::ZERO;
                self.ship_orient = Quat::IDENTITY;
                self.player_shield = Shield::new(200.0, 40.0, 3.0);
                self.player_hull = self.player_hull_max;
                self.player_dead = false;
                self.last_combat_msg = Some("RESPAWNED AT STATION".into());
                self.last_combat_msg_ttl = 2.5;
            }
        } else if fire_pressed && self.weapon_cooldown.try_fire(&self.weapon_stats) {
            let forward = self.ship_orient * Vec3::new(0.0, 0.0, -1.0);
            let muzzle = self.ship_pos + forward * PROJECTILE_SPAWN_FORWARD;
            let ttl = (self.weapon_stats.range_meters / PROJECTILE_SPEED).min(4.0);
            let p = Projectile::new(
                muzzle,
                forward * PROJECTILE_SPEED,
                self.weapon_stats.damage,
                self.weapon_stats.damage_type,
            )
            .with_ttl(ttl);
            self.bolts.push(Bolt {
                projectile: p,
                owner: self.player_faction,
            });
        }

        // Build this frame's threat list: every ship (player + NPCs).
        // NPCs filter out themselves by position equality, which is
        // fine given we keep positions distinct. The player is only
        // in the list when alive and past cold-start; during the
        // opening seconds the world runs without knowing the player
        // is there, so NPCs engage each other, not the empty seat.
        let player_visible = !self.player_dead && self.cold_start_remaining <= 0.0;
        let mut threats: Vec<Threat> = Vec::with_capacity(self.npcs.len() + 1);
        if player_visible {
            threats.push(Threat {
                faction: self.player_faction,
                pos: self.ship_pos,
                radius: PLAYER_HIT_RADIUS,
            });
        }
        for npc in &self.npcs {
            threats.push(Threat {
                faction: npc.faction,
                pos: npc.pos,
                radius: SHIP_HIT_RADIUS,
            });
        }

        // Advance each NPC. The filtering on self-threat is by
        // identity of (faction, pos); we reconstruct a per-NPC
        // filtered slice to avoid a ship regarding itself as a target.
        let reputation = self.reputation.clone();
        let mut npc_fires: Vec<(FactionId, ce_npc::FireIntent)> = Vec::new();
        let mut mined_platinum: u32 = 0;
        let security = self.world_pulse.security;
        // Snapshot of all NPCs for isolation / poison decisions —
        // lets the per-NPC loop consult the rest without re-borrowing.
        let npc_snapshot: Vec<(NpcId, FactionId, Vec3)> =
            self.npcs.iter().map(|n| (n.id, n.faction, n.pos)).collect();
        for npc in self.npcs.iter_mut() {
            let npc_pos = npc.pos;
            let npc_faction = npc.faction;
            let local_threats: Vec<Threat> = threats
                .iter()
                .copied()
                .filter(|t| !(t.pos == npc_pos && t.faction == npc_faction))
                .collect();
            // M41 pulse-fed feedback: when security falls, NPCs scan
            // further. Re-derived every frame from the role-based
            // baseline so there's no runaway multiplication.
            let role = slot_role_for_npc(&self.npc_slots, npc.id);
            let base_range = base_engage_range_for_role(role);
            let security_scaled = engage_range_with_security(base_range, security);
            // M43 inner-life feedback: the NPC's own poisons further
            // modulate engagement — dosa makes the ship aggressive,
            // moha makes it scan less.
            let poisons = self.npc_poisons.entry(npc.id).or_default();
            npc.engage_range = security_scaled * poison_modifier(poisons);
            let tick = advance_npc(npc, &reputation, &local_threats, dt);
            npc.pos += tick.desired_vel * dt;
            if let Some(fire) = tick.fire {
                npc_fires.push((npc.faction, fire));
            }
            if tick.mined_units > 0 && matches!(npc.goal, NpcGoal::Mine { .. }) {
                mined_platinum += tick.mined_units;
            }
        }
        // M43 emotion drift: loneliness poisoning runs every tick
        // regardless of events. Kill-driven shifts come later this
        // tick from the damage-resolution block.
        for (id, faction, pos) in &npc_snapshot {
            let isolated = !npc_snapshot
                .iter()
                .any(|(other_id, other_faction, other_pos)| {
                    other_id != id
                        && other_faction == faction
                        && (*other_pos - *pos).length() <= 30.0
                });
            if let Some(p) = self.npc_poisons.get_mut(id) {
                let events = SentientEvents {
                    isolated,
                    ..SentientEvents::default()
                };
                drift_poisons(p, &events, &self.world_pulse, dt);
            }
        }

        // Feed NPC mining back into the shared asteroid state — the
        // miner consumes real ore, so the player sees the stock drop.
        if mined_platinum > 0 {
            for node in self.asteroid_nodes.iter_mut() {
                if node.yields == PLATINUM {
                    let take = mined_platinum.min(node.units_remaining);
                    node.units_remaining = node.units_remaining.saturating_sub(take);
                    break;
                }
            }
        }

        // Spawn projectiles from NPC fire intents.
        for (owner, fire) in npc_fires {
            let to = fire.toward_pos - fire.from_pos;
            let dist = to.length().max(1e-4);
            let dir = to / dist;
            let speed = fire.speed_hint.max(1.0);
            let muzzle = fire.from_pos + dir * 1.5;
            let ttl = (dist / speed + 1.0).min(3.0);
            let p =
                Projectile::new(muzzle, dir * speed, fire.damage, fire.damage_type).with_ttl(ttl);
            self.bolts.push(Bolt {
                projectile: p,
                owner,
            });
        }

        // Advance bolts and resolve hits. Player ship, NPCs, and
        // asteroids can all stop a bolt; friendly fire is prevented
        // by comparing owner faction to target faction.
        let mut player_hit: Option<(f32, f32)> = None;
        let mut player_killed_by: Option<FactionId> = None;
        let player_pos = self.ship_pos;
        let player_faction = self.player_faction;
        let player_alive_now = !self.player_dead;

        // We can't easily mutate self inside retain_mut due to borrow
        // rules — collect effects, then apply.
        let mut npc_damage: Vec<(usize, f32, DamageType, FactionId)> = Vec::new();
        let mut base_damage: Vec<(usize, f32, DamageType, FactionId)> = Vec::new();
        // Explosions = every bolt-termination on something substantial
        // (ship, base, asteroid). Feeds `WorldPulse::space_density`.
        let mut explosions_this_tick: u32 = 0;
        let asteroid_positions: Vec<Vec3> = self
            .asteroid_nodes
            .iter()
            .map(|n| {
                Vec3::new(
                    n.position.0.x as f32,
                    n.position.0.y as f32,
                    n.position.0.z as f32,
                )
            })
            .collect();

        self.bolts.retain_mut(|b| {
            let prev = b.projectile.pos;
            if !advance_projectile(&mut b.projectile, dt) {
                return false;
            }
            // Player hit
            if player_alive_now
                && b.owner != player_faction
                && projectile_hits_sphere(prev, b.projectile.pos, player_pos, PLAYER_HIT_RADIUS)
            {
                player_hit = Some((b.projectile.damage, 0.0));
                player_killed_by = Some(b.owner);
                explosions_this_tick = explosions_this_tick.saturating_add(1);
                return false;
            }
            // NPC hits
            for (i, npc) in self.npcs.iter().enumerate() {
                if !npc.is_alive() {
                    continue;
                }
                if b.owner == npc.faction {
                    continue;
                }
                if projectile_hits_sphere(prev, b.projectile.pos, npc.pos, SHIP_HIT_RADIUS) {
                    npc_damage.push((i, b.projectile.damage, b.projectile.damage_type, b.owner));
                    explosions_this_tick = explosions_this_tick.saturating_add(1);
                    return false;
                }
            }
            // Base hits — friendly fire filtered, rebuilt bases are
            // tangible again.
            for (i, base) in self.bases.iter().enumerate() {
                if base.destroyed {
                    continue;
                }
                if b.owner == base.faction {
                    continue;
                }
                if projectile_hits_sphere(prev, b.projectile.pos, base.pos, base.hit_radius) {
                    base_damage.push((i, b.projectile.damage, b.projectile.damage_type, b.owner));
                    explosions_this_tick = explosions_this_tick.saturating_add(1);
                    return false;
                }
            }
            // Asteroid hits (bolt absorbs, M35-style feedback).
            for ac in &asteroid_positions {
                if projectile_hits_sphere(prev, b.projectile.pos, *ac, ASTEROID_HIT_RADIUS) {
                    explosions_this_tick = explosions_this_tick.saturating_add(1);
                    return false;
                }
            }
            true
        });

        // Apply collected NPC damage. Remember who dealt the killing
        // blow so M38 can propagate reputation shifts.
        let mut npc_kills: Vec<(FactionId, FactionId)> = Vec::new();
        for (idx, dmg, dtype, attacker) in npc_damage {
            if let Some(npc) = self.npcs.get_mut(idx) {
                let was_alive = npc.is_alive();
                apply_damage(&mut npc.shield, &mut npc.hull, dtype, dmg);
                if was_alive && !npc.is_alive() {
                    npc_kills.push((attacker, npc.faction));
                }
            }
        }

        // Apply collected base damage. A base death gates its faction's
        // director (no replenishments until rebuild).
        for (idx, dmg, dtype, attacker) in base_damage {
            if let Some(base) = self.bases.get_mut(idx) {
                let was_alive = base.is_alive();
                let (sd, hd) = apply_damage(&mut base.shield, &mut base.hull, dtype, dmg);
                if was_alive && base.hull <= 0.0 {
                    base.mark_destroyed();
                    self.pulse_events.bases_destroyed =
                        self.pulse_events.bases_destroyed.saturating_add(1);
                    let base_name = base.display_name.clone();
                    let base_mesh_index = self.base_mesh_indices[idx];
                    let base_faction = base.faction;
                    self.last_combat_msg = Some(format!("{} DESTROYED", base_name.to_uppercase()));
                    self.last_combat_msg_ttl = 4.0;
                    // Hide the mesh.
                    let mesh = &self.meshes[base_mesh_index];
                    if let Some(base_verts) = mesh.base_vertices.as_ref() {
                        let world = translate_vertices(base_verts, Vec3::new(0.0, -10_000.0, 0.0));
                        self.queue.write_buffer(
                            &mesh.vertex_buffer,
                            0,
                            bytemuck::cast_slice(&world),
                        );
                    }
                    // Attacking a base counts as a kill for rep
                    // purposes — the faction loses a member.
                    npc_kills.push((attacker, base_faction));
                } else if was_alive {
                    let _ = (sd, hd); // Could surface per-shot damage in HUD later.
                }
            }
        }

        // Apply player damage properly — the shortcut above only knew
        // the raw damage; redo it by walking the remaining bolts' owner
        // information through a dedicated damage application.
        if let Some((dmg, _)) = player_hit {
            // We lost the damage_type in the shortcut. Use Energy as a
            // reasonable default for laser bolts; if NPCs ever wield
            // kinetic weapons this needs to pipe through. Acceptable
            // for M34 where every faction uses energy.
            let (sd, hd) = apply_damage(
                &mut self.player_shield,
                &mut self.player_hull,
                DamageType::Energy,
                dmg,
            );
            self.last_combat_msg = Some(format!("HIT TAKEN  SH -{:>3.0} HL -{:>3.0}", sd, hd));
            self.last_combat_msg_ttl = 1.5;
            if self.player_hull <= 0.0 {
                self.player_dead = true;
                self.player_death_timer = PLAYER_RESPAWN_SECONDS;
                let attacker = player_killed_by
                    .and_then(|f| self.factions.get(f))
                    .map(|f| f.display_name.clone())
                    .unwrap_or_else(|| "Unknown".into());
                self.last_combat_msg = Some(format!("KILLED BY {}", attacker.to_uppercase()));
                self.last_combat_msg_ttl = PLAYER_RESPAWN_SECONDS;
                // Player death counts for reputation too — the faction
                // that felled the player earns grudges from lawful
                // observers.
                if let Some(killer) = player_killed_by {
                    npc_kills.push((killer, self.player_faction));
                }
            }
        }

        // M38 + M41: propagate every death as a reputation event,
        // weighted by the world's current tension. Same rule applies
        // to NPC-vs-NPC kills, player kills, and player death — the
        // world has one political mechanism, not two, and its bite
        // depends on the mood.
        if !npc_kills.is_empty() {
            let observers: Vec<FactionId> = [F_PLAYER, F_PROTECTORATE, F_UNION, F_CRIMSON].to_vec();
            // Tension saturates at 1.0 → grudges hit 1.6x; peace → 1.0x.
            let weight = 1.0 + self.world_pulse.tension * 0.6;
            self.pulse_events.kills = self
                .pulse_events
                .kills
                .saturating_add(npc_kills.len() as u32);
            for (killer, victim) in &npc_kills {
                apply_kill_delta_weighted(
                    &mut self.reputation,
                    *killer,
                    *victim,
                    &observers,
                    weight,
                );
                // M44: record the kill in the chronicle so the
                // timeline HUD can show what happened this second.
                self.chronicle.push(ce_chronicle::WorldEvent {
                    timestamp_seconds: self.world_clock.epoch_seconds,
                    kind: ce_chronicle::EventKind::Kill {
                        killer: *killer,
                        victim: *victim,
                    },
                });
                // M43: nearby same-faction NPCs absorb this as dosa,
                // opposing NPCs as lobha (a small gain from an
                // enemy's death). Skip player kills from this —
                // player is not a sentient in the map.
                for npc in &self.npcs {
                    if !npc.is_alive() {
                        continue;
                    }
                    let Some(poisons) = self.npc_poisons.get_mut(&npc.id) else {
                        continue;
                    };
                    let rel_ally = npc.faction == *victim;
                    let rel_enemy = npc.faction == *killer && *killer != self.player_faction;
                    let ev = SentientEvents {
                        allies_lost: rel_ally as u32,
                        enemies_downed: rel_enemy as u32,
                        ..SentientEvents::default()
                    };
                    // Pass dt=0 so decay doesn't run again here; this
                    // is an instantaneous event impulse on top of the
                    // earlier per-tick drift. A tiny positive dt lets
                    // the pure-function guard accept it.
                    drift_poisons(poisons, &ev, &self.world_pulse, 1e-4);
                }
                // Surface player-visible shifts prominently.
                if *killer == self.player_faction || *victim == self.player_faction {
                    let killer_name = self
                        .factions
                        .get(*killer)
                        .map(|f| f.display_name.as_str())
                        .unwrap_or("?");
                    let victim_name = self
                        .factions
                        .get(*victim)
                        .map(|f| f.display_name.as_str())
                        .unwrap_or("?");
                    self.last_combat_msg = Some(format!("REP: {} -> {}", killer_name, victim_name));
                    self.last_combat_msg_ttl = 2.5;
                }
                // M43 Hunt mission tally: count every kill whose
                // victim matches an accepted Hunt contract's target.
                for entry in self.mission_log.iter() {
                    if entry.status != MissionStatus::Accepted {
                        continue;
                    }
                    if let MissionKind::Hunt { target_faction, .. } = &entry.mission.kind {
                        if *target_faction == *victim && *killer == self.player_faction {
                            let counter =
                                self.mission_kill_tally.entry(entry.mission.id).or_insert(0);
                            *counter += 1;
                        }
                    }
                }
            }
        }

        // Handle NPC deaths: log, free slot, start respawn cooldown.
        let mut i = 0;
        while i < self.npcs.len() {
            if !self.npcs[i].is_alive() {
                let dead = self.npcs.remove(i);
                // M43: retire the dead NPC's inner life. The next
                // incumbent of this slot starts clean.
                self.npc_poisons.remove(&dead.id);
                if let Some(slot) = self
                    .npc_slots
                    .iter_mut()
                    .find(|s| s.occupant == Some(dead.id))
                {
                    slot.occupant = None;
                    slot.respawn_timer = NPC_RESPAWN_SECONDS;
                    let msg = format!("{} DOWN", dead.display_name.to_uppercase());
                    self.last_combat_msg = Some(msg);
                    self.last_combat_msg_ttl = 2.5;
                    // Park the mesh off-screen so it disappears visually.
                    let mesh_index = slot.mesh_index;
                    let mesh = &mut self.meshes[mesh_index];
                    if let Some(base) = mesh.base_vertices.as_ref() {
                        let world = translate_vertices(base, Vec3::new(0.0, -10_000.0, 0.0));
                        self.queue.write_buffer(
                            &mesh.vertex_buffer,
                            0,
                            bytemuck::cast_slice(&world),
                        );
                    }
                }
                continue;
            }
            i += 1;
        }

        // Director: spawn any vacant slot whose cooldown has elapsed
        // AND whose faction still has at least one living base. A
        // faction with every stronghold destroyed cannot reinforce —
        // the sector politically shifts until rebuild.
        for slot_idx in 0..self.npc_slots.len() {
            let slot_faction = self.npc_slots[slot_idx].faction;
            let gated = faction_spawning_gated(&self.bases, slot_faction);
            let need_spawn = {
                let slot = &mut self.npc_slots[slot_idx];
                if slot.occupant.is_some() {
                    false
                } else if gated {
                    // Hold the respawn clock — once the base rebuilds
                    // the timer keeps whatever it was at, so the slot
                    // doesn't instantly refill.
                    false
                } else {
                    slot.respawn_timer = (slot.respawn_timer - dt).max(0.0);
                    slot.respawn_timer == 0.0
                }
            };
            if need_spawn {
                self.spawn_slot(slot_idx);
            }
        }

        // Record explosions for the mood vector before the bolts are
        // forgotten.
        if explosions_this_tick > 0 {
            self.pulse_events.explosions = self
                .pulse_events
                .explosions
                .saturating_add(explosions_this_tick);
        }

        // Advance each stronghold (shield regen + rebuild timer). When
        // a base rebuilds we re-upload its mesh back into the scene.
        for idx in 0..self.bases.len() {
            let rebuilt = advance_base(&mut self.bases[idx], dt);
            if rebuilt {
                let base = &self.bases[idx];
                let pos = base.pos;
                let name = base.display_name.clone();
                let mesh_index = self.base_mesh_indices[idx];
                let mesh = &self.meshes[mesh_index];
                if let Some(verts) = mesh.base_vertices.as_ref() {
                    let world = translate_vertices(verts, pos);
                    self.queue
                        .write_buffer(&mesh.vertex_buffer, 0, bytemuck::cast_slice(&world));
                }
                self.last_combat_msg = Some(format!("{} REBUILT", name.to_uppercase()));
                self.last_combat_msg_ttl = 3.0;
                // M44: record the rebuild in the chronicle.
                self.chronicle.push(ce_chronicle::WorldEvent {
                    timestamp_seconds: self.world_clock.epoch_seconds,
                    kind: ce_chronicle::EventKind::BaseRebuilt {
                        name,
                        faction: base.faction,
                    },
                });
            }
        }
        // M44: detect fresh `destroyed` transitions and chronicle them.
        // `last_base_destroyed` is a parallel vector tracking state
        // across ticks so we only emit on the rising edge.
        if self.last_base_destroyed.len() != self.bases.len() {
            self.last_base_destroyed = vec![false; self.bases.len()];
        }
        for (idx, base) in self.bases.iter().enumerate() {
            if base.destroyed && !self.last_base_destroyed[idx] {
                self.chronicle.push(ce_chronicle::WorldEvent {
                    timestamp_seconds: self.world_clock.epoch_seconds,
                    kind: ce_chronicle::EventKind::BaseDestroyed {
                        name: base.display_name.clone(),
                        faction: base.faction,
                    },
                });
            }
            self.last_base_destroyed[idx] = base.destroyed;
        }

        // M38: decay reputation toward neutral. We accumulate dt into
        // a whole-second counter so the i32 step function actually
        // makes progress each real second.
        self.rep_decay_accum += dt;
        if self.rep_decay_accum >= 1.0 {
            let whole = self.rep_decay_accum as i32;
            self.rep_decay_accum -= whole as f32;
            // Rate = 1 unit per second — grudges relax visibly over
            // a few minutes, but don't vanish in a firefight.
            decay_reputation(&mut self.reputation, 1.0, whole as f32);
        }

        // Sync NPC mesh transforms to live NpcShip poses.
        let mut occupant_positions: Vec<(usize, Vec3, Quat)> = Vec::new();
        for slot in &self.npc_slots {
            if let Some(id) = slot.occupant {
                if let Some(npc) = self.npcs.iter().find(|n| n.id == id) {
                    occupant_positions.push((slot.mesh_index, npc.pos, npc.orient));
                }
            }
        }
        for (mesh_index, pos, orient) in occupant_positions {
            let mesh = &self.meshes[mesh_index];
            if let Some(base) = mesh.base_vertices.as_ref() {
                let world = transform_vertices(base, pos, orient);
                self.queue
                    .write_buffer(&mesh.vertex_buffer, 0, bytemuck::cast_slice(&world));
            }
        }

        self.upload_projectile_vertices();

        // M43: industrial tick. Each FactionBase's Base runs its
        // production lines and feeds the station market's stock.
        // Destroyed strongholds power-gate production, rebuilt ones
        // restore it.
        for (i, base) in self.bases.iter().enumerate() {
            if i < self.faction_bases.len() {
                stations::set_powered(&mut self.faction_bases[i], !base.destroyed);
            }
        }
        for fb in self.faction_bases.iter_mut() {
            stations::apply_mood_to_cycles(fb, self.world_pulse.market_mood);
            tick_production(fb, dt);
        }
        // Sync Protectorate Station market stock from the industrial
        // Base's inventory. Only iron_ingot for now — the station's
        // market UI already lists ORE + PLATINUM, but those come
        // from asteroids; the refined ingot is the new commodity.
        if let (Some(pbase), Some(entry)) = (
            self.faction_bases.first(),
            self.market.entry_mut(stations::IRON_INGOT),
        ) {
            entry.stock = pbase.inventory.count(stations::IRON_INGOT);
        }

        // M43: mission board — let every living FactionBase post
        // fresh offers; expire old ones; tick the player's log.
        let _expired_offers = self.mission_board.tick(dt);
        for (i, base) in self.bases.iter().enumerate() {
            if base.destroyed {
                continue;
            }
            let issuer = base.faction;
            let salt = 0x4D15_5100_4E00_0000u64.wrapping_add(i as u64);
            let mut rng = self.world_clock.deterministic_rng(salt);
            let posted = maybe_post_offer(
                &mut self.mission_board,
                issuer,
                &self.world_pulse,
                &mut rng,
                stations::IRON_ORE,
                dt,
                &mut self.mission_next_id,
            );
            if let Some(id) = posted {
                // M44: chronicle the post. Label carries the archetype
                // so the timeline line is self-describing.
                let kind_label = self
                    .mission_board
                    .get(id)
                    .map(|m| match &m.kind {
                        MissionKind::Hunt { count, .. } => format!("Hunt x{count}"),
                        MissionKind::Courier { count, .. } => format!("Courier x{count}"),
                        MissionKind::Mine { count, .. } => format!("Mine x{count}"),
                        MissionKind::Escort { .. } => "Escort".into(),
                        MissionKind::Patrol { .. } => "Patrol".into(),
                    })
                    .unwrap_or_else(|| "Mission".into());
                self.chronicle.push(ce_chronicle::WorldEvent {
                    timestamp_seconds: self.world_clock.epoch_seconds,
                    kind: ce_chronicle::EventKind::MissionPosted {
                        id: id.0,
                        kind_label,
                        issuer,
                    },
                });
            }
        }
        let failed = mission_tick_log(
            &mut self.mission_log,
            &mut self.reputation,
            self.player_faction,
            dt,
        );
        if !failed.is_empty() {
            self.pulse_events.missions_failed = self
                .pulse_events
                .missions_failed
                .saturating_add(failed.len() as u32);
            for id in &failed {
                self.mission_kill_tally.remove(id);
                // M44: chronicle the failure.
                self.chronicle.push(ce_chronicle::WorldEvent {
                    timestamp_seconds: self.world_clock.epoch_seconds,
                    kind: ce_chronicle::EventKind::MissionFailed { id: id.0 },
                });
            }
        }
        // Auto-complete Hunt / Mine contracts whose objectives are met.
        self.try_auto_complete_missions();

        // M41: advance the world mood vector with whatever this tick
        // stirred up, then clear the accumulator for the next frame.
        // Pulse is never persisted — at load time we rebuild it from
        // the seed + epoch via `pre_drift_pulse`.
        let before_pulse = self.world_pulse;
        self.world_pulse = advance_pulse(self.world_pulse, &self.pulse_events, dt);
        self.pulse_events.clear();
        // M44: chronicle a pulse shift when any axis moves more than
        // `PULSE_SHIFT_EPSILON` since the last snapshot.
        let d_t = (self.world_pulse.tension - self.last_pulse_snapshot.tension).abs();
        let d_m = (self.world_pulse.market_mood - self.last_pulse_snapshot.market_mood).abs();
        let d_s = (self.world_pulse.security - self.last_pulse_snapshot.security).abs();
        if d_t.max(d_m).max(d_s) > ce_chronicle::PULSE_SHIFT_EPSILON {
            self.chronicle.push(ce_chronicle::WorldEvent {
                timestamp_seconds: self.world_clock.epoch_seconds,
                kind: ce_chronicle::EventKind::PulseShift {
                    tension: self.world_pulse.tension,
                    market_mood: self.world_pulse.market_mood,
                    security: self.world_pulse.security,
                },
            });
            self.last_pulse_snapshot = self.world_pulse;
        }
        let _ = before_pulse;
    }

    /// Scans the player's mission log and auto-completes any
    /// accepted contract whose in-world objective is met (Hunt kill
    /// count tallied, Mine inventory threshold reached). Wallet /
    /// reputation updates run through the existing `mission_complete`
    /// function so the reputation coupling stays in one place.
    fn try_auto_complete_missions(&mut self) {
        let completable: Vec<MissionId> = self
            .mission_log
            .iter()
            .filter_map(|entry: &LogEntry| {
                if entry.status != MissionStatus::Accepted {
                    return None;
                }
                let meets = match &entry.mission.kind {
                    MissionKind::Hunt { count, .. } => {
                        self.mission_kill_tally
                            .get(&entry.mission.id)
                            .copied()
                            .unwrap_or(0)
                            >= *count
                    }
                    MissionKind::Mine { resource, count } => {
                        self.inventory.count(*resource) >= *count
                    }
                    _ => false,
                };
                if meets {
                    Some(entry.mission.id)
                } else {
                    None
                }
            })
            .collect();
        for id in completable {
            let result = mission_complete(
                &mut self.mission_log,
                &mut self.wallet,
                &mut self.reputation,
                self.player_faction,
                id,
            );
            if let Ok(reward) = result {
                self.pulse_events.missions_completed =
                    self.pulse_events.missions_completed.saturating_add(1);
                self.mission_kill_tally.remove(&id);
                self.last_combat_msg = Some(format!("MISSION CLEAR  +{} CR", reward / 100));
                self.last_combat_msg_ttl = 3.0;
                // M44: chronicle the completion — credits go through
                // `reward`, by_player is always true here because the
                // auto-complete only fires for player-accepted log entries.
                self.chronicle.push(ce_chronicle::WorldEvent {
                    timestamp_seconds: self.world_clock.epoch_seconds,
                    kind: ce_chronicle::EventKind::MissionCompleted {
                        id: id.0,
                        by_player: true,
                        reward_credits: reward,
                    },
                });
            }
        }
    }

    /// Spawns a fresh NPC for the given slot index. Assigns a new
    /// NpcId (incremented monotonically so dead individuals are never
    /// reused — permadeath respected by identity) and wires a
    /// role-appropriate goal.
    fn spawn_slot(&mut self, slot_idx: usize) {
        let (slot_role, slot_faction, slot_pos, slot_mesh_index, slot_hull_max, slot_label) = {
            let slot = &mut self.npc_slots[slot_idx];
            slot.spawn_count += 1;
            let label_prefix = match slot.role {
                SlotKind::Patrol => "Guard",
                SlotKind::Miner => "Miner",
                SlotKind::Trader => "Hauler",
                SlotKind::Pirate => "Reaver",
            };
            let label = format!("{} {:02}", label_prefix, slot.spawn_count);
            (
                slot.role,
                slot.faction,
                slot.base_pos,
                slot.mesh_index,
                slot.hull_max,
                label,
            )
        };

        let id = NpcId::new(self.next_npc_id);
        self.next_npc_id += 1;

        let shield = match slot_role {
            SlotKind::Patrol => Shield::new(80.0, 20.0, 2.5),
            SlotKind::Miner => Shield::new(60.0, 15.0, 3.0),
            SlotKind::Trader => Shield::new(40.0, 10.0, 3.0),
            SlotKind::Pirate => Shield::new(120.0, 25.0, 2.5),
        };
        let weapon = WeaponStats {
            damage_type: DamageType::Energy,
            damage: match slot_role {
                SlotKind::Patrol => 18.0,
                SlotKind::Miner => 8.0,
                SlotKind::Trader => 6.0,
                SlotKind::Pirate => 22.0,
            },
            cooldown_seconds: 0.7,
            range_meters: 45.0,
            energy_cost: 2.0,
        };

        // Draw from the world clock's PRNG so every NPC that spawns
        // into this world starts mid-route. The salt distinguishes the
        // fresh-session sprinkle (SALT_NPC_SLOT_BASE) from after-death
        // replacements (SALT_NPC_RESPAWN_BASE + spawn_count) so an
        // individual's history is traceable by seed alone.
        let spawn_count = self.npc_slots[slot_idx].spawn_count;
        let salt = if spawn_count <= 1 {
            SALT_NPC_SLOT_BASE + slot_idx as u64
        } else {
            SALT_NPC_RESPAWN_BASE + slot_idx as u64 + (spawn_count as u64) * 17
        };
        let mut rng = self.world_clock.deterministic_rng(salt);

        let (goal, spawn_pos, spawn_orient) =
            seed_goal_from_rng(slot_role, slot_pos, self.station_pos, &mut rng);

        let ship = NpcShip::new(
            id,
            slot_faction,
            slot_label.clone(),
            spawn_pos,
            slot_hull_max,
            shield,
            weapon,
        )
        .with_goal(goal)
        .with_max_speed(match slot_role {
            SlotKind::Patrol => 8.0,
            SlotKind::Miner => 4.0,
            SlotKind::Trader => 6.0,
            SlotKind::Pirate => 9.0,
        })
        .with_engage_range(base_engage_range_for_role(slot_role));
        let mut ship = ship;
        ship.orient = spawn_orient;
        self.npcs.push(ship);

        let slot = &mut self.npc_slots[slot_idx];
        slot.occupant = Some(id);

        // Seed the mesh at its spawn pose.
        let mesh = &self.meshes[slot_mesh_index];
        if let Some(base) = mesh.base_vertices.as_ref() {
            let world = transform_vertices(base, spawn_pos, spawn_orient);
            self.queue
                .write_buffer(&mesh.vertex_buffer, 0, bytemuck::cast_slice(&world));
        }

        self.last_combat_msg = Some(format!("{} ONLINE", slot_label.to_uppercase()));
        self.last_combat_msg_ttl = 2.0;
    }

    /// Builds the projectile vertex batch for this frame. Player bolts
    /// render yellow; NPC bolts take a colour derived from the owner's
    /// disposition toward the player so an incoming pirate bolt reads
    /// red at a glance.
    fn upload_projectile_vertices(&mut self) {
        if self.bolts.is_empty() {
            self.proj_vertex_count = 0;
            return;
        }
        let mut verts: Vec<Vertex> = Vec::with_capacity(self.bolts.len() * 6);
        for b in &self.bolts {
            let vel_len = b.projectile.vel.length();
            if vel_len < 1e-6 {
                continue;
            }
            let dir = b.projectile.vel / vel_len;
            let half_length = 0.6;
            let start = b.projectile.pos - dir * half_length;
            let end = b.projectile.pos + dir * half_length;
            let color = bolt_color(b.owner, self.player_faction, &self.reputation);
            let quad = build_beam_quad(start, end, PROJECTILE_HALF_WIDTH, color);
            verts.extend_from_slice(&quad);
        }
        let bytes: &[u8] = bytemuck::cast_slice(&verts);
        let needed = bytes.len() as u64;
        if needed > self.proj_vertex_capacity {
            self.proj_vertex_buffer = self.device.create_buffer(&wgpu::BufferDescriptor {
                label: Some("projectile VB (grown)"),
                size: needed,
                usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            });
            self.proj_vertex_capacity = needed;
        }
        if !verts.is_empty() {
            self.queue.write_buffer(&self.proj_vertex_buffer, 0, bytes);
        }
        self.proj_vertex_count = verts.len() as u32;
    }

    fn camera_view_proj(&self) -> Mat4 {
        // Chase camera in the ship's local frame: slightly above and
        // behind the cockpit, oriented with the ship so banking is
        // visible.
        let eye = self.ship_pos + self.ship_orient * Vec3::new(0.0, 4.0, 12.0);
        let target = self.ship_pos + self.ship_orient * Vec3::new(0.0, 0.0, -2.0);
        let up = self.ship_orient * Vec3::Y;
        let view = look_at_rh(eye, target, up);
        let aspect = self.config.width as f32 / self.config.height as f32;
        let proj = perspective_rh(std::f32::consts::FRAC_PI_3, aspect.max(0.01), 0.05, 500.0);
        proj * view
    }

    fn render(&mut self) -> Result<(), wgpu::SurfaceError> {
        let vp = self.camera_view_proj();
        let inv_vp = vp.inverse();
        let eye = self.ship_pos + self.ship_orient * Vec3::new(0.0, 4.0, 12.0);

        // Sun drifts slowly so the planet rim / hull shading has
        // something visible to react to.
        let sun = Vec3::new(self.time.cos() * 0.8, 0.4, self.time.sin() * 0.8).normalize();

        // Build this frame's HUD and upload its vertex stream.
        self.upload_hud();

        // Upload per-frame uniforms.
        self.queue.write_buffer(
            &self.star_uniform,
            0,
            bytemuck::bytes_of(&StarfieldUniform {
                inv_view_proj: inv_vp.to_cols_array_2d(),
            }),
        );
        self.queue.write_buffer(
            &self.frame_uniform,
            0,
            bytemuck::bytes_of(&FrameUniform {
                view_proj: vp.to_cols_array_2d(),
                camera_pos: [eye.x, eye.y, eye.z, 1.0],
                light_dir: [sun.x, sun.y, sun.z, 0.0],
            }),
        );

        let output = self.surface.get_current_texture()?;
        let view = output
            .texture
            .create_view(&wgpu::TextureViewDescriptor::default());
        let mut encoder = self
            .device
            .create_command_encoder(&wgpu::CommandEncoderDescriptor {
                label: Some("frame encoder"),
            });

        // Pass 1: scene into HDR. Every lit pipeline now outputs
        // linear HDR colour; pixels can legitimately exceed 1.0.
        {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("scene HDR pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &self.hdr_view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color::BLACK),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                    view: &self.depth_view,
                    depth_ops: Some(wgpu::Operations {
                        load: wgpu::LoadOp::Clear(1.0),
                        store: wgpu::StoreOp::Store,
                    }),
                    stencil_ops: None,
                }),
                timestamp_writes: None,
                occlusion_query_set: None,
            });

            // Starfield first, depth-test LessEqual so it sits at the far plane.
            pass.set_pipeline(&self.star_pipeline);
            pass.set_bind_group(0, &self.star_bind_group, &[]);
            pass.draw(0..3, 0..1);

            // Lit meshes on top. Same uniform bind group for planet+hull.
            pass.set_bind_group(0, &self.frame_bind_group, &[]);
            for mesh in &self.meshes {
                match mesh.material {
                    MaterialKind::Planet => pass.set_pipeline(&self.planet_pipeline),
                    MaterialKind::Hull => pass.set_pipeline(&self.hull_pipeline),
                }
                pass.set_vertex_buffer(0, mesh.vertex_buffer.slice(..));
                if let Some(ib) = &mesh.index_buffer {
                    pass.set_index_buffer(ib.slice(..), wgpu::IndexFormat::Uint32);
                    pass.draw_indexed(0..mesh.index_count, 0, 0..1);
                } else {
                    pass.draw(0..mesh.vertex_count, 0..1);
                }
            }

            // Mining beam (world-space, hull pipeline + frame uniform
            // already bound).
            if self.beam_active {
                pass.set_pipeline(&self.hull_pipeline);
                pass.set_vertex_buffer(0, self.beam_vertex_buffer.slice(..));
                pass.draw(0..BEAM_VERTEX_COUNT, 0..1);
            }

            // Projectiles — rebuilt every frame from the live list.
            if self.proj_vertex_count > 0 {
                pass.set_pipeline(&self.hull_pipeline);
                pass.set_vertex_buffer(0, self.proj_vertex_buffer.slice(..));
                pass.draw(0..self.proj_vertex_count, 0..1);
            }
        }

        // Pass 2: threshold-extract bright pixels from HDR into
        // bloom_a (half res). The knee at 1.0 produces a soft halo
        // seed rather than a hard clipped edge.
        {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("bloom extract pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &self.bloom_a_view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color::BLACK),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                timestamp_writes: None,
                occlusion_query_set: None,
            });
            pass.set_pipeline(&self.bloom_extract_pipeline);
            pass.set_bind_group(0, &self.bloom_extract_bg, &[]);
            pass.draw(0..3, 0..1);
        }

        // Pass 3: separable blur, horizontal (bloom_a → bloom_b).
        {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("bloom blur H pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &self.bloom_b_view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color::BLACK),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                timestamp_writes: None,
                occlusion_query_set: None,
            });
            pass.set_pipeline(&self.bloom_blur_h_pipeline);
            pass.set_bind_group(0, &self.bloom_blur_h_bg, &[]);
            pass.draw(0..3, 0..1);
        }

        // Pass 4: separable blur, vertical (bloom_b → bloom_a).
        {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("bloom blur V pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &self.bloom_a_view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color::BLACK),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                timestamp_writes: None,
                occlusion_query_set: None,
            });
            pass.set_pipeline(&self.bloom_blur_v_pipeline);
            pass.set_bind_group(0, &self.bloom_blur_v_bg, &[]);
            pass.draw(0..3, 0..1);
        }

        // Pass 5: tonemap composite (HDR + blurred bloom) into the
        // sRGB swap-chain. The surface is sRGB so the GPU linearly
        // encodes our ACES output.
        {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("tonemap composite pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color::BLACK),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                timestamp_writes: None,
                occlusion_query_set: None,
            });
            pass.set_pipeline(&self.tonemap_pipeline);
            pass.set_bind_group(0, &self.tonemap_bg, &[]);
            pass.draw(0..3, 0..1);
        }

        // Pass 6: HUD on top of the tonemapped swap-chain. Alpha
        // blended, no depth, vertices already in NDC.
        if self.hud_vertex_count > 0 {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("hud pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Load,
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                timestamp_writes: None,
                occlusion_query_set: None,
            });
            pass.set_pipeline(&self.hud_pipeline);
            pass.set_vertex_buffer(0, self.hud_vertex_buffer.slice(..));
            pass.draw(0..self.hud_vertex_count, 0..1);
        }

        self.queue.submit(std::iter::once(encoder.finish()));
        output.present();
        Ok(())
    }

    fn ship_in_dock_range(&self) -> bool {
        (self.ship_pos - self.station_pos).length() <= STATION_DOCK_RANGE
    }

    fn toggle_trade_panel(&mut self) {
        if self.ship_in_dock_range() {
            self.trade_panel_open = !self.trade_panel_open;
            self.last_trade_msg = None;
        } else {
            self.last_trade_msg = Some("OUT OF DOCK RANGE".into());
        }
    }

    /// Pulls the earliest-expiring offer off the board and moves it
    /// to the player's log. Player must be within dock range so the
    /// mercenary contract carries the usual "at a station" fiction.
    fn accept_next_mission(&mut self) {
        if !self.ship_in_dock_range() {
            self.last_combat_msg = Some("NEED DOCK RANGE FOR MISSIONS".into());
            self.last_combat_msg_ttl = 2.0;
            return;
        }
        // Pick the offer with the smallest deadline so the player
        // sees the "hottest" contract first.
        let pick = self
            .mission_board
            .offers()
            .min_by(|a, b| {
                a.deadline_seconds
                    .partial_cmp(&b.deadline_seconds)
                    .unwrap_or(std::cmp::Ordering::Equal)
            })
            .map(|m| m.id);
        let Some(id) = pick else {
            self.last_combat_msg = Some("NO MISSIONS AVAILABLE".into());
            self.last_combat_msg_ttl = 2.0;
            return;
        };
        let result = ce_mission::accept(
            &mut self.mission_board,
            &mut self.mission_log,
            &self.reputation,
            self.player_faction,
            id,
        );
        self.last_combat_msg = Some(match result {
            Ok(_) => "MISSION ACCEPTED".into(),
            Err(ce_mission::MissionError::InsufficientReputation) => {
                "REP TOO LOW FOR THIS MISSION".into()
            }
            Err(_) => "MISSION ACCEPT FAILED".into(),
        });
        self.last_combat_msg_ttl = 2.5;
    }

    fn sell_all_ore(&mut self) {
        if !self.trade_panel_open || !self.ship_in_dock_range() {
            return;
        }
        // M41: mood-adjusted spread. Stations widen their margins
        // when the sector feels bad (pessimistic mood) and tighten
        // them in good times. We swap the entry's spread in, sell,
        // then restore — keeps the atomicity of `sell_to_market`
        // without changing its signature.
        let mood = self.world_pulse.market_mood;
        let mut total_payout: i64 = 0;
        let mut total_units: u32 = 0;
        for ore in [ORE, PLATINUM] {
            let count = self.inventory.count(ore);
            if count == 0 {
                continue;
            }
            let saved_spread = self.market.get(ore).map(|e| e.price_model.spread);
            if let Some(entry) = self.market.entry_mut(ore) {
                entry.price_model.spread = spread_with_mood(entry.price_model.spread, mood);
            }
            let result = sell_to_market(
                &mut self.market,
                &mut self.wallet,
                &mut self.inventory,
                ore,
                count,
            );
            if let (Some(s), Some(entry)) = (saved_spread, self.market.entry_mut(ore)) {
                entry.price_model.spread = s;
            }
            if let Ok(payout) = result {
                total_payout += payout;
                total_units += count;
                // Feed the mood vector so successive trades tighten
                // / widen the spread as sentiment moves.
                self.pulse_events.trades_value += payout as f32;
            }
        }
        self.last_trade_msg = Some(if total_units > 0 {
            format!("SOLD {} U  +{} CR", total_units, total_payout / 100)
        } else {
            "NOTHING TO SELL".into()
        });
    }

    /// Builds the HUD batch for this frame and uploads its vertices.
    /// The layout — top speed bar + three thrust-axis bars + position
    /// indicator — matches the committed golden in `ce_hud`.
    fn upload_hud(&mut self) {
        let screen_w = self.config.width as f32;
        let screen_h = self.config.height as f32;

        let speed = self.ship_vel.length();
        let speed_fill = (speed / 50.0).clamp(0.0, 1.0);
        let axis_fill = |v: f32| -> f32 { (v.abs() / 25.0).clamp(0.0, 1.0) };

        let bar_bg = [0.08, 0.10, 0.14, 0.7];
        let speed_fg = [0.2, 0.85, 1.0, 1.0];
        let thrust_fg = [1.0, 0.8, 0.2, 1.0];

        let mut batch = HudBatch::new();
        let label_color = [0.85, 0.9, 1.0, 1.0];
        let value_color = [1.0, 1.0, 1.0, 1.0];
        let text_scale = 2.0;

        // --- Top: speed label + numeric readout + bar ---
        batch.push_text([16.0, 16.0], text_scale, label_color, "SPD");
        let spd_num = format!("{:>5.1}", speed);
        batch.push_text([56.0, 16.0], text_scale, value_color, &spd_num);
        batch.push_bar(
            [112.0, 18.0],
            [screen_w - 128.0, 6.0],
            speed_fill,
            speed_fg,
            bar_bg,
        );

        // --- Row: position readout ---
        let pos = self.ship_pos;
        let pos_line = format!("POS {:>5.1} {:>5.1} {:>5.1}", pos.x, pos.y, pos.z);
        batch.push_text([16.0, 34.0], text_scale, value_color, &pos_line);

        // --- Row: per-axis thrust magnitude bars ---
        let axis_y = 50.0;
        let axis_w = (screen_w - 48.0) / 3.0;
        let axis_labels = ["X", "Y", "Z"];
        let axis_values = [self.ship_vel.x, self.ship_vel.y, self.ship_vel.z];
        for (i, (label, v)) in axis_labels.iter().zip(axis_values.iter()).enumerate() {
            let x = 16.0 + (i as f32) * (axis_w + 8.0);
            batch.push_text([x, axis_y], text_scale, label_color, label);
            batch.push_bar(
                [x + 16.0, axis_y + 2.0],
                [axis_w - 16.0, 4.0],
                axis_fill(*v),
                thrust_fg,
                bar_bg,
            );
        }

        // --- Row: cargo readout (totals across all yielded ore types) ---
        let iron = self.inventory.count(ORE);
        let plat = self.inventory.count(PLATINUM);
        batch.push_text(
            [16.0, 66.0],
            text_scale,
            value_color,
            &format!("FE {:>4}  PT {:>4}", iron, plat),
        );

        // --- Row: target acquisition + mining status ---
        let mining_color = match self.last_mine_result {
            Some(MineResult::Extracted(_)) => [0.6, 1.0, 0.6, 1.0],
            Some(MineResult::OutOfRange) => [1.0, 0.5, 0.4, 1.0],
            Some(MineResult::Depleted) => [0.6, 0.6, 0.6, 1.0],
            Some(MineResult::InventoryFull) => [1.0, 0.7, 0.2, 1.0],
            None => label_color,
        };
        let target_text = match self.target_index {
            Some(i) => {
                let node = &self.asteroid_nodes[i];
                format!(
                    "TGT {} {:>4}",
                    if i == 0 { "FE" } else { "PT" },
                    node.units_remaining
                )
            }
            None => "TGT NONE".to_string(),
        };
        batch.push_text([16.0, 82.0], text_scale, mining_color, &target_text);
        if let Some(r) = self.last_mine_result {
            let tag = match r {
                MineResult::Extracted(_) => "MINING",
                MineResult::OutOfRange => "OUT OF RANGE",
                MineResult::Depleted => "DEPLETED",
                MineResult::InventoryFull => "HOLD FULL",
            };
            batch.push_text([176.0, 82.0], text_scale, mining_color, tag);
        }

        // --- Wallet + dock indicator ---
        batch.push_text(
            [16.0, 98.0],
            text_scale,
            value_color,
            &format!("CR {:>6}", self.wallet.credits / 100),
        );
        if self.ship_in_dock_range() {
            batch.push_text(
                [176.0, 98.0],
                text_scale,
                [0.4, 1.0, 0.4, 1.0],
                "DOCK READY [K]",
            );
        }
        if let Some(msg) = &self.last_trade_msg {
            batch.push_text([16.0, 114.0], text_scale, [1.0, 0.85, 0.4, 1.0], msg);
        }

        // --- Player shield + hull bars (left, just under the cargo row) ---
        let shield_fg = [0.35, 0.7, 1.0, 1.0];
        let hull_fg = [1.0, 0.55, 0.35, 1.0];
        let sh_fill = (self.player_shield.current / self.player_shield.max).clamp(0.0, 1.0);
        let hl_fill = (self.player_hull / self.player_hull_max).clamp(0.0, 1.0);
        batch.push_text([16.0, 130.0], text_scale, label_color, "SH");
        batch.push_bar([40.0, 132.0], [200.0, 6.0], sh_fill, shield_fg, bar_bg);
        batch.push_text(
            [248.0, 130.0],
            text_scale,
            value_color,
            &format!("{:>3.0}", self.player_shield.current),
        );
        batch.push_text([16.0, 146.0], text_scale, label_color, "HL");
        batch.push_bar([40.0, 148.0], [200.0, 6.0], hl_fill, hull_fg, bar_bg);
        batch.push_text(
            [248.0, 146.0],
            text_scale,
            value_color,
            &format!("{:>3.0}", self.player_hull),
        );

        // --- Contact roster (centred top): one line per live NPC ---
        let panel_x = screen_w * 0.5 - 150.0;
        batch.push_text(
            [panel_x, 16.0],
            text_scale,
            [0.85, 0.9, 1.0, 1.0],
            "CONTACTS",
        );
        for (i, npc) in self.npcs.iter().enumerate() {
            let y = 32.0 + (i as f32) * 14.0;
            let relation = self.reputation.relation(self.player_faction, npc.faction);
            let color = relation_color(relation);
            let rel_tag = relation_tag(relation);
            let dist = (npc.pos - self.ship_pos).length();
            let faction_label = self
                .factions
                .get(npc.faction)
                .map(|f| f.display_name.as_str())
                .unwrap_or("?");
            // M43: dominant poison glyph so the NPC's inner state
            // reads at a glance. `·` = neutral, `L`/`D`/`M` = lobha/
            // dosa/moha dominant.
            let poison_glyph = self
                .npc_poisons
                .get(&npc.id)
                .map(|p| {
                    if p.total() < 0.15 {
                        '·'
                    } else {
                        match p.dominant() {
                            ce_ai::PoisonType::Lobha => 'L',
                            ce_ai::PoisonType::Dosa => 'D',
                            ce_ai::PoisonType::Moha => 'M',
                        }
                    }
                })
                .unwrap_or('·');
            batch.push_text(
                [panel_x, y],
                text_scale,
                color,
                &format!(
                    "{:<10} {:<11} {} {:>4.0}m SH{:>3.0} HL{:>3.0} {}",
                    npc.display_name,
                    faction_label,
                    rel_tag,
                    dist,
                    npc.shield.current,
                    npc.hull,
                    poison_glyph,
                ),
            );
        }

        // Weapon readiness indicator + transient combat message.
        let weapon_tag = if self.weapon_cooldown.is_ready() {
            "LASER READY [SPACE]"
        } else {
            "LASER CHARGING..."
        };
        let weapon_color = if self.weapon_cooldown.is_ready() {
            [0.5, 1.0, 0.6, 1.0]
        } else {
            [1.0, 0.85, 0.4, 1.0]
        };
        batch.push_text([16.0, 162.0], text_scale, weapon_color, weapon_tag);
        if let Some(msg) = &self.last_combat_msg {
            batch.push_text([16.0, 178.0], text_scale, [1.0, 0.75, 0.4, 1.0], msg);
        }

        // Player death overlay: big centred countdown + message.
        if self.player_dead {
            let overlay_w = 320.0;
            let overlay_h = 60.0;
            let ox = (screen_w - overlay_w) * 0.5;
            let oy = (screen_h - overlay_h) * 0.5;
            batch.push_rect(ce_hud::Rect {
                x: ox,
                y: oy,
                w: overlay_w,
                h: overlay_h,
                color: [0.15, 0.02, 0.04, 0.88],
            });
            batch.push_text(
                [ox + 16.0, oy + 12.0],
                3.0,
                [1.0, 0.4, 0.4, 1.0],
                "CRITICAL DAMAGE",
            );
            batch.push_text(
                [ox + 16.0, oy + 36.0],
                2.0,
                [1.0, 0.85, 0.5, 1.0],
                &format!("RESPAWN IN {:>3.1}s", self.player_death_timer),
            );
        }

        // --- Top-right: minimap (top-down ship-local view) ---
        let mut dots = self.minimap_targets.clone();
        for npc in &self.npcs {
            let relation = self.reputation.relation(self.player_faction, npc.faction);
            dots.push((npc.pos, relation_color(relation)));
        }
        for base in &self.bases {
            if base.destroyed {
                continue;
            }
            let relation = self.reputation.relation(self.player_faction, base.faction);
            let mut c = relation_color(relation);
            c[3] = 0.6; // slightly dimmer than ships so ships stand out
            dots.push((base.pos, c));
        }
        push_minimap(&mut batch, screen_w, self.ship_pos, self.ship_orient, &dots);

        // --- World age — small line below the minimap. Confirms the
        // world has been running before the player opened the app.
        let (h, m, s) = self.world_clock.age_hms();
        batch.push_text(
            [
                screen_w - MINIMAP_SIZE - MINIMAP_MARGIN,
                MINIMAP_MARGIN + MINIMAP_SIZE + 4.0,
            ],
            text_scale,
            [0.8, 0.9, 1.0, 0.9],
            &format!("WORLD AGE {:02}:{:02}:{:02}", h, m, s),
        );

        // --- Strongholds panel (left, under weapon + combat msg) ---
        let bases_y_start = 200.0;
        batch.push_text(
            [16.0, bases_y_start],
            text_scale,
            [0.85, 0.9, 1.0, 1.0],
            "STRONGHOLDS",
        );
        for (i, base) in self.bases.iter().enumerate() {
            let y = bases_y_start + 14.0 + (i as f32) * 14.0;
            let (color, status) = if base.destroyed {
                (
                    [1.0, 0.4, 0.4, 1.0],
                    format!("DOWN  {:>4.0}s", base.rebuild_timer),
                )
            } else {
                let frac = (base.hull / base.hull_max).clamp(0.0, 1.0);
                let c = if frac < 0.3 {
                    [1.0, 0.55, 0.4, 1.0]
                } else if frac < 0.7 {
                    [1.0, 0.85, 0.4, 1.0]
                } else {
                    [0.6, 1.0, 0.6, 1.0]
                };
                (c, format!("HL {:>4.0}/{:>4.0}", base.hull, base.hull_max))
            };
            batch.push_text(
                [16.0, y],
                text_scale,
                color,
                &format!("{:<20} {}", base.display_name, status),
            );
        }

        // --- WORLD PULSE panel (left, under strongholds) ---
        // Four short bars visualise the world's meta-state: rising
        // tension bar under sustained kills, security dip after a
        // base falls, market mood drifting with trade volume, and
        // space density ringing on each hit.
        let pulse_y_start = bases_y_start + 14.0 + (self.bases.len() as f32) * 14.0 + 12.0;
        batch.push_text(
            [16.0, pulse_y_start],
            text_scale,
            [0.85, 0.9, 1.0, 1.0],
            "WORLD PULSE",
        );
        let pulse_bar_bg = [0.08, 0.1, 0.12, 0.9];
        let pulse_bars: [(&str, f32, [f32; 4]); 4] = [
            ("TEN", self.world_pulse.tension, [1.0, 0.45, 0.4, 1.0]),
            ("SEC", self.world_pulse.security, [0.55, 0.9, 1.0, 1.0]),
            ("MOD", self.world_pulse.market_mood, [0.9, 0.85, 0.4, 1.0]),
            ("DEN", self.world_pulse.space_density, [0.8, 0.6, 1.0, 1.0]),
        ];
        for (i, (label, value, color)) in pulse_bars.iter().enumerate() {
            let y = pulse_y_start + 14.0 + (i as f32) * 12.0;
            batch.push_text([16.0, y], text_scale, *color, label);
            batch.push_bar([52.0, y + 2.0], [120.0, 5.0], *value, *color, pulse_bar_bg);
        }

        if self.cold_start_remaining > 0.0 {
            batch.push_text(
                [
                    16.0,
                    pulse_y_start + 14.0 + (pulse_bars.len() as f32) * 12.0 + 4.0,
                ],
                text_scale,
                [0.9, 0.8, 0.55, 1.0],
                &format!("WORLD RUNNING SOLO  {:>3.1}s", self.cold_start_remaining),
            );
        }

        // --- MISSIONS panel (left, under WORLD PULSE) ---
        let missions_y_start = pulse_y_start + 14.0 + (pulse_bars.len() as f32) * 12.0 + 24.0;
        batch.push_text(
            [16.0, missions_y_start],
            text_scale,
            [0.85, 0.9, 1.0, 1.0],
            &format!(
                "MISSIONS  board:{:>2}  log:{:>2}",
                self.mission_board.len(),
                self.mission_log.count_status(MissionStatus::Accepted),
            ),
        );
        let mut row = 0;
        for entry in self.mission_log.iter() {
            if entry.status != MissionStatus::Accepted {
                continue;
            }
            if row >= 3 {
                break;
            }
            let y = missions_y_start + 14.0 + (row as f32) * 12.0;
            let kind_label = match &entry.mission.kind {
                MissionKind::Hunt { count, .. } => format!(
                    "Hunt {}/{}",
                    self.mission_kill_tally
                        .get(&entry.mission.id)
                        .copied()
                        .unwrap_or(0),
                    count,
                ),
                MissionKind::Courier { item, count, .. } => {
                    format!("Courier {} x{}", llull_item_name(*item), count)
                }
                MissionKind::Mine { resource, count } => {
                    format!(
                        "Mine {} {}/{}",
                        llull_item_name(*resource),
                        self.inventory.count(*resource),
                        count
                    )
                }
                MissionKind::Escort { .. } => "Escort".to_string(),
                MissionKind::Patrol { .. } => "Patrol".to_string(),
            };
            batch.push_text(
                [16.0, y],
                text_scale,
                [0.85, 0.9, 0.75, 1.0],
                &format!(
                    "{:<14} +{:>4}CR {:>4.0}s",
                    kind_label,
                    entry.mission.reward / 100,
                    entry.mission.deadline_seconds,
                ),
            );
            row += 1;
        }

        // --- CHRONICLE panel (bottom-left): newest 5 events ---
        let chronicle_y_top = screen_h - 90.0;
        batch.push_text(
            [16.0, chronicle_y_top],
            text_scale,
            [0.85, 0.9, 1.0, 1.0],
            &format!(
                "CHRONICLE  {:>4} events    [H] history",
                self.chronicle.len(),
            ),
        );
        for (i, ev) in self.chronicle.recent(5).iter().enumerate() {
            let y = chronicle_y_top + 14.0 + (i as f32) * 12.0;
            batch.push_text(
                [16.0, y],
                text_scale,
                [0.82, 0.86, 0.78, 1.0],
                &format_event_line(ev),
            );
        }

        // --- Trade panel (modal-ish, centred) when docked ---
        if self.trade_panel_open && self.ship_in_dock_range() {
            push_trade_panel(
                &mut batch,
                screen_w,
                screen_h,
                &self.market,
                &self.inventory,
            );
        }

        // --- History overlay (H) — fullscreen-ish dim with up to 30 events ---
        if self.history_panel_open {
            let overlay_w = (screen_w - 80.0).max(400.0);
            let overlay_h = (screen_h - 80.0).max(300.0);
            let ox = (screen_w - overlay_w) * 0.5;
            let oy = (screen_h - overlay_h) * 0.5;
            batch.push_rect(ce_hud::Rect {
                x: ox,
                y: oy,
                w: overlay_w,
                h: overlay_h,
                color: [0.05, 0.06, 0.08, 0.9],
            });
            batch.push_text(
                [ox + 16.0, oy + 16.0],
                text_scale,
                [0.9, 0.95, 1.0, 1.0],
                "WORLD CHRONICLE  [H to close]",
            );
            let visible = self.chronicle.recent(30);
            for (i, ev) in visible.iter().enumerate() {
                let y = oy + 36.0 + (i as f32) * 12.0;
                batch.push_text(
                    [ox + 16.0, y],
                    text_scale,
                    [0.82, 0.86, 0.78, 1.0],
                    &format_event_line(ev),
                );
            }
        }

        let vertices = batch.finish(screen_w, screen_h);
        let bytes = bytemuck::cast_slice(&vertices);
        let needed = bytes.len() as u64;
        if needed > self.hud_vertex_capacity {
            self.hud_vertex_buffer = self.device.create_buffer(&wgpu::BufferDescriptor {
                label: Some("hud VB (grown)"),
                size: needed,
                usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            });
            self.hud_vertex_capacity = needed;
        }
        if !vertices.is_empty() {
            self.queue.write_buffer(&self.hud_vertex_buffer, 0, bytes);
        }
        self.hud_vertex_count = vertices.len() as u32;
    }
}

// ---------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------

fn world_pos_of(v: Vec3) -> ce_space::WorldPos {
    ce_space::WorldPos::new(v.x as f64, v.y as f64, v.z as f64)
}

fn build_station_market() -> Market {
    let mut m = Market::new();
    // Iron is common, low margin. Platinum is scarce, premium price.
    m.insert(ORE, MarketEntry::new(120, 200, PriceModel::new(150, 0.6)));
    m.insert(
        PLATINUM,
        MarketEntry::new(20, 60, PriceModel::new(900, 1.0)),
    );
    m
}

/// Builds a thin world-space quad (6 verts, 2 triangles) from `start`
/// to `end`. Width is given in world units; the quad is rotated to
/// stay perpendicular to the camera-up axis (Y), which keeps it
/// visible from the chase camera under most ship orientations.
fn build_beam_quad(start: Vec3, end: Vec3, half_width: f32, color: [f32; 4]) -> [Vertex; 6] {
    let dir = end - start;
    // Pick a perpendicular axis. Using world Y as a reference is fine
    // since the chase camera's up is roughly world Y plus a tilt.
    let mut perp = dir.cross(Vec3::Y);
    if perp.length_squared() < 1e-6 {
        // Beam is parallel to Y; fall back to X.
        perp = dir.cross(Vec3::X);
    }
    let r = perp.normalize() * half_width;
    let v = |p: Vec3| Vertex {
        position: [p.x, p.y, p.z],
        color,
    };
    let a = start - r;
    let b = start + r;
    let c = end + r;
    let d = end - r;
    // Two CCW triangles.
    [v(a), v(c), v(b), v(a), v(d), v(c)]
}

fn nearest_in_range(
    nodes: &[ResourceNode],
    shooter: ce_space::WorldPos,
    range: f64,
) -> Option<usize> {
    nodes
        .iter()
        .enumerate()
        .filter(|(_, n)| !n.is_depleted())
        .map(|(i, n)| (i, shooter.distance(n.position)))
        .filter(|(_, d)| *d <= range)
        .min_by(|a, b| a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal))
        .map(|(i, _)| i)
}

/// Centred trade panel — shows market prices and inventory levels for
/// the two ores we mine, plus a SELL hint.
fn push_trade_panel(
    batch: &mut HudBatch,
    screen_w: f32,
    screen_h: f32,
    market: &Market,
    inventory: &Inventory,
) {
    let panel_w = 280.0;
    let panel_h = 110.0;
    let x = (screen_w - panel_w) * 0.5;
    let y = (screen_h - panel_h) * 0.5;
    batch.push_rect(ce_hud::Rect {
        x,
        y,
        w: panel_w,
        h: panel_h,
        color: [0.04, 0.06, 0.10, 0.92],
    });
    let label = [0.85, 0.9, 1.0, 1.0];
    let value = [1.0, 1.0, 1.0, 1.0];
    let scale = 2.0;
    batch.push_text([x + 12.0, y + 8.0], scale, label, "STATION MARKET");
    // M48: display the Llull token alongside the short mnemonic so the
    // trade screen reads as "one of the world's commodities, not one
    // the developer hard-coded".
    let lines = [(ORE, "FE"), (PLATINUM, "PT")];
    for (i, (id, tag)) in lines.iter().enumerate() {
        let row_y = y + 32.0 + (i as f32) * 18.0;
        let stock = inventory.count(*id);
        let buy = market.get(*id).map(|e| e.buy_price()).unwrap_or(0);
        let sell = market.get(*id).map(|e| e.sell_price()).unwrap_or(0);
        batch.push_text(
            [x + 12.0, row_y],
            scale,
            value,
            &format!(
                "{:<8} {} HOLD {:>4}  BUY {:>5}  SELL {:>5}",
                llull_item_name(*id),
                tag,
                stock,
                buy / 100,
                sell / 100,
            ),
        );
    }
    batch.push_text(
        [x + 12.0, y + panel_h - 18.0],
        scale,
        [1.0, 0.85, 0.4, 1.0],
        "[T] SELL ALL    [K] CLOSE",
    );
}

/// Top-down ship-local minimap. Forward (-Z) sits at the top.
const MINIMAP_SIZE: f32 = 96.0;
const MINIMAP_MARGIN: f32 = 16.0;
const MINIMAP_RANGE: f32 = 80.0;

fn push_minimap(
    batch: &mut HudBatch,
    screen_w: f32,
    ship_pos: Vec3,
    ship_orient: Quat,
    targets: &[(Vec3, [f32; 4])],
) {
    let x0 = screen_w - MINIMAP_SIZE - MINIMAP_MARGIN;
    let y0 = MINIMAP_MARGIN;
    // Background panel.
    batch.push_rect(ce_hud::Rect {
        x: x0,
        y: y0,
        w: MINIMAP_SIZE,
        h: MINIMAP_SIZE,
        color: [0.05, 0.07, 0.10, 0.7],
    });
    // Crosshair to anchor the eye.
    let cx = x0 + MINIMAP_SIZE * 0.5;
    let cy = y0 + MINIMAP_SIZE * 0.5;
    let crosshair = [0.4, 0.5, 0.6, 0.6];
    batch.push_rect(ce_hud::Rect {
        x: x0,
        y: cy - 0.5,
        w: MINIMAP_SIZE,
        h: 1.0,
        color: crosshair,
    });
    batch.push_rect(ce_hud::Rect {
        x: cx - 0.5,
        y: y0,
        w: 1.0,
        h: MINIMAP_SIZE,
        color: crosshair,
    });

    // Half-extent in pixels.
    let half = MINIMAP_SIZE * 0.5;
    let scale = half / MINIMAP_RANGE;
    let inv_orient = ship_orient.inverse();

    for (world, color) in targets {
        // Ship-local horizontal projection: x is right, z is forward.
        let local = inv_orient * (*world - ship_pos);
        // Map (local.x, local.z) into the minimap. Forward (-z) → top.
        let mx = cx + local.x * scale;
        let my = cy + local.z * scale;
        // Clamp to a 2-pixel inner border so dots don't bleed past
        // the panel edge.
        if mx < x0 + 1.0 || mx > x0 + MINIMAP_SIZE - 3.0 {
            continue;
        }
        if my < y0 + 1.0 || my > y0 + MINIMAP_SIZE - 3.0 {
            continue;
        }
        batch.push_rect(ce_hud::Rect {
            x: mx - 1.5,
            y: my - 1.5,
            w: 3.0,
            h: 3.0,
            color: *color,
        });
    }

    // Player heading: a small triangle proxy made of two rects pointing
    // up (ship-local forward).
    let heading = [0.95, 0.95, 0.4, 1.0];
    batch.push_rect(ce_hud::Rect {
        x: cx - 0.5,
        y: cy - 4.0,
        w: 1.0,
        h: 4.0,
        color: heading,
    });
    batch.push_rect(ce_hud::Rect {
        x: cx - 1.5,
        y: cy - 1.5,
        w: 3.0,
        h: 3.0,
        color: heading,
    });
}

fn create_depth_view(
    device: &wgpu::Device,
    config: &wgpu::SurfaceConfiguration,
) -> wgpu::TextureView {
    let texture = device.create_texture(&wgpu::TextureDescriptor {
        label: Some("depth texture"),
        size: wgpu::Extent3d {
            width: config.width,
            height: config.height,
            depth_or_array_layers: 1,
        },
        mip_level_count: 1,
        sample_count: 1,
        dimension: wgpu::TextureDimension::D2,
        format: DEPTH_FORMAT,
        usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
        view_formats: &[],
    });
    texture.create_view(&wgpu::TextureViewDescriptor::default())
}

/// Creates the HDR offscreen colour target the scene renders into
/// before tone-mapping. `rgba16float` preserves intensities above
/// 1.0 so the tonemap can roll them into highlights.
fn create_hdr_view(
    device: &wgpu::Device,
    config: &wgpu::SurfaceConfiguration,
) -> wgpu::TextureView {
    let texture = device.create_texture(&wgpu::TextureDescriptor {
        label: Some("hdr scene"),
        size: wgpu::Extent3d {
            width: config.width,
            height: config.height,
            depth_or_array_layers: 1,
        },
        mip_level_count: 1,
        sample_count: 1,
        dimension: wgpu::TextureDimension::D2,
        format: HDR_FORMAT,
        usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING,
        view_formats: &[],
    });
    texture.create_view(&wgpu::TextureViewDescriptor::default())
}

/// Creates one half-resolution HDR texture for the bloom chain. The
/// scene pipeline ping-pongs between two of these during the blur.
fn create_bloom_view(
    device: &wgpu::Device,
    config: &wgpu::SurfaceConfiguration,
    label: &'static str,
) -> wgpu::TextureView {
    let w = (config.width / BLOOM_DIVISOR).max(1);
    let h = (config.height / BLOOM_DIVISOR).max(1);
    let texture = device.create_texture(&wgpu::TextureDescriptor {
        label: Some(label),
        size: wgpu::Extent3d {
            width: w,
            height: h,
            depth_or_array_layers: 1,
        },
        mip_level_count: 1,
        sample_count: 1,
        dimension: wgpu::TextureDimension::D2,
        format: HDR_FORMAT,
        usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING,
        view_formats: &[],
    });
    texture.create_view(&wgpu::TextureViewDescriptor::default())
}

/// Bind group connecting one sampled texture (+ its sampler) to the
/// single-input postprocess pipelines (bloom extract, bloom blur).
fn create_1tex_bind_group(
    device: &wgpu::Device,
    layout: &wgpu::BindGroupLayout,
    view: &wgpu::TextureView,
    sampler: &wgpu::Sampler,
    label: &'static str,
) -> wgpu::BindGroup {
    device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: Some(label),
        layout,
        entries: &[
            wgpu::BindGroupEntry {
                binding: 0,
                resource: wgpu::BindingResource::TextureView(view),
            },
            wgpu::BindGroupEntry {
                binding: 1,
                resource: wgpu::BindingResource::Sampler(sampler),
            },
        ],
    })
}

/// Bind group connecting the HDR scene + bloom result (+ samplers)
/// to the tonemap composite pipeline.
fn create_2tex_bind_group(
    device: &wgpu::Device,
    layout: &wgpu::BindGroupLayout,
    hdr: &wgpu::TextureView,
    bloom: &wgpu::TextureView,
    sampler: &wgpu::Sampler,
    label: &'static str,
) -> wgpu::BindGroup {
    device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: Some(label),
        layout,
        entries: &[
            wgpu::BindGroupEntry {
                binding: 0,
                resource: wgpu::BindingResource::TextureView(hdr),
            },
            wgpu::BindGroupEntry {
                binding: 1,
                resource: wgpu::BindingResource::Sampler(sampler),
            },
            wgpu::BindGroupEntry {
                binding: 2,
                resource: wgpu::BindingResource::TextureView(bloom),
            },
            wgpu::BindGroupEntry {
                binding: 3,
                resource: wgpu::BindingResource::Sampler(sampler),
            },
        ],
    })
}

fn build_ship() -> ShipBlocks {
    let mut ship = ShipBlocks::new();
    for x in 0..5 {
        ship.insert(
            IVec3::new(x, 0, 0),
            Block::new(BlockKind::Hull, BlockMaterial::Iron),
        );
    }
    for y in 0..2 {
        ship.insert(
            IVec3::new(2, y + 1, 0),
            Block::new(BlockKind::Hull, BlockMaterial::Titanium),
        );
    }
    ship.insert(
        IVec3::new(-1, 0, 0),
        Block::new(BlockKind::Thruster, BlockMaterial::Iron).with_facing(Facing::East),
    );
    ship.insert(
        IVec3::new(-1, 0, 1),
        Block::new(BlockKind::Thruster, BlockMaterial::Iron).with_facing(Facing::East),
    );
    // Symmetric thrusters so +x / -x / +z / -z are all available.
    ship.insert(
        IVec3::new(6, 0, 0),
        Block::new(BlockKind::Thruster, BlockMaterial::Iron).with_facing(Facing::West),
    );
    ship.insert(
        IVec3::new(2, -1, 0),
        Block::new(BlockKind::Thruster, BlockMaterial::Iron).with_facing(Facing::Up),
    );
    ship.insert(
        IVec3::new(2, 3, 0),
        Block::new(BlockKind::Thruster, BlockMaterial::Iron).with_facing(Facing::Down),
    );
    ship.insert(
        IVec3::new(2, 0, -1),
        Block::new(BlockKind::Thruster, BlockMaterial::Iron).with_facing(Facing::South),
    );
    ship.insert(
        IVec3::new(2, 0, 1),
        Block::new(BlockKind::Thruster, BlockMaterial::Iron).with_facing(Facing::North),
    );
    ship.insert(
        IVec3::new(5, 0, 0),
        Block::new(BlockKind::Weapon, BlockMaterial::Tungsten).with_facing(Facing::North),
    );
    ship
}

/// Colour a projectile bolt by what its owner means to the viewer
/// (the player). Own-faction bolts read yellow, friendly bolts blue,
/// hostile bolts red.
fn bolt_color(owner: FactionId, player: FactionId, rep: &ReputationMatrix) -> [f32; 4] {
    if owner == player {
        return [1.0, 0.9, 0.4, 1.0];
    }
    match rep.relation(player, owner) {
        Relation::Ally | Relation::Friendly => [0.4, 0.8, 1.0, 1.0],
        Relation::Neutral => [0.8, 0.8, 0.85, 1.0],
        Relation::Hostile | Relation::War => [1.0, 0.35, 0.35, 1.0],
    }
}

fn relation_color(r: Relation) -> [f32; 4] {
    match r {
        Relation::Ally => [0.4, 1.0, 0.7, 1.0],
        Relation::Friendly => [0.6, 1.0, 0.6, 1.0],
        Relation::Neutral => [0.85, 0.9, 1.0, 1.0],
        Relation::Hostile => [1.0, 0.55, 0.4, 1.0],
        Relation::War => [1.0, 0.3, 0.3, 1.0],
    }
}

fn relation_tag(r: Relation) -> &'static str {
    match r {
        Relation::Ally => "ALLY",
        Relation::Friendly => "FRND",
        Relation::Neutral => "NTRL",
        Relation::Hostile => "HOST",
        Relation::War => "WAR ",
    }
}

/// NPC ship silhouettes — one template per role. Material choice
/// doubles as visual faction marker since the hull shader modulates
/// colour by material:
/// - Patrol (Protectorate): slender titanium dart.
/// - Miner  (Union):        wide iron barge with a cargo block.
/// - Pirate (Crimson):      predatory tungsten wings.
fn build_npc_blocks(role: SlotKind) -> ShipBlocks {
    let mut s = ShipBlocks::new();
    match role {
        SlotKind::Patrol => {
            for z in -2..=0 {
                s.insert(
                    IVec3::new(0, 0, z),
                    Block::new(BlockKind::Hull, BlockMaterial::Titanium),
                );
            }
            s.insert(
                IVec3::new(0, 1, -1),
                Block::new(BlockKind::Hull, BlockMaterial::Titanium),
            );
            s.insert(
                IVec3::new(0, 0, -3),
                Block::new(BlockKind::Weapon, BlockMaterial::Tungsten),
            );
        }
        SlotKind::Miner => {
            for x in -1..=1 {
                for z in 0..=1 {
                    s.insert(
                        IVec3::new(x, 0, z),
                        Block::new(BlockKind::Hull, BlockMaterial::Iron),
                    );
                }
            }
            s.insert(
                IVec3::new(0, 1, 0),
                Block::new(BlockKind::Hull, BlockMaterial::Iron),
            );
            s.insert(
                IVec3::new(0, 0, -1),
                Block::new(BlockKind::Weapon, BlockMaterial::Tungsten),
            );
        }
        SlotKind::Pirate => {
            for z in -1..=1 {
                s.insert(
                    IVec3::new(0, 0, z),
                    Block::new(BlockKind::Hull, BlockMaterial::Tungsten),
                );
            }
            for x in [-1, 1] {
                s.insert(
                    IVec3::new(x, 0, 0),
                    Block::new(BlockKind::Hull, BlockMaterial::Tungsten),
                );
                s.insert(
                    IVec3::new(x, 0, -1),
                    Block::new(BlockKind::Weapon, BlockMaterial::Tungsten),
                );
            }
            s.insert(
                IVec3::new(0, 1, 0),
                Block::new(BlockKind::Hull, BlockMaterial::Iron),
            );
        }
        SlotKind::Trader => {
            // Unused in the starter sector; minimal placeholder.
            for z in 0..=1 {
                s.insert(
                    IVec3::new(0, 0, z),
                    Block::new(BlockKind::Hull, BlockMaterial::Iron),
                );
            }
        }
    }
    s
}

/// Starter-sector faction roster. Flavour strings are placeholders —
/// the point is to establish a canonical ID for each citizen kind.
// ------------------------------------------------------------------
// Save / load — minimal text format. The world is "one that kept
// turning" regardless of the player; saves let the player close the
// app without erasing what they changed. Only the state the player
// can mutate persists — NPC identities are re-seeded from the world
// clock on load, because "the crew changes while you're away" is
// fine within the design.
// ------------------------------------------------------------------
const SAVE_PATH: &str = "gemu_save.txt";
const CHRONICLE_PATH: &str = "gemu_chronicle.txt";
const SAVE_VERSION: u32 = 2;

/// Render a `WorldEvent` as a single HUD line. Timestamps are
/// shown in `HH:MM:SS` world-age form (same as WORLD AGE).
fn format_event_line(ev: &ce_chronicle::WorldEvent) -> String {
    let total = ev.timestamp_seconds.max(0.0) as u64;
    let h = total / 3600;
    let m = (total % 3600) / 60;
    let s = total % 60;
    let ts = format!("{h:02}:{m:02}:{s:02}");
    match &ev.kind {
        ce_chronicle::EventKind::WorldBorn { seed } => {
            format!("[{ts}] world born  seed={seed}")
        }
        ce_chronicle::EventKind::EpochSkipped { from, to, capped } => {
            let span_h = ((to - from) / 3600.0) as u64;
            let tag = if *capped { " (capped)" } else { "" };
            format!("[{ts}] time skipped  {span_h}h{tag}")
        }
        ce_chronicle::EventKind::Kill { killer, victim } => {
            format!("[{ts}] {} downed by {}", victim.as_str(), killer.as_str())
        }
        ce_chronicle::EventKind::BaseDestroyed { name, faction } => {
            format!("[{ts}] {name} destroyed ({})", faction.as_str())
        }
        ce_chronicle::EventKind::BaseRebuilt { name, faction } => {
            format!("[{ts}] {name} rebuilt ({})", faction.as_str())
        }
        ce_chronicle::EventKind::MissionPosted {
            kind_label,
            issuer,
            id,
        } => {
            format!(
                "[{ts}] mission #{id} posted: {kind_label} by {}",
                issuer.as_str()
            )
        }
        ce_chronicle::EventKind::MissionCompleted {
            id, reward_credits, ..
        } => {
            format!("[{ts}] mission #{id} clear  +{}CR", reward_credits / 100)
        }
        ce_chronicle::EventKind::MissionFailed { id } => {
            format!("[{ts}] mission #{id} failed")
        }
        ce_chronicle::EventKind::Trade { value_credits } => {
            format!("[{ts}] trade  {value_credits}CR")
        }
        ce_chronicle::EventKind::PulseShift {
            tension,
            market_mood,
            security,
        } => {
            format!("[{ts}] pulse shift  T={tension:.2} M={market_mood:.2} S={security:.2}")
        }
        ce_chronicle::EventKind::Unknown { raw } => format!("[{ts}] ?{raw}"),
    }
}

fn save_world(r: &Renderer) -> std::io::Result<()> {
    use std::fmt::Write as _;
    let mut out = String::new();
    let _ = writeln!(out, "# gemu save v{}", SAVE_VERSION);
    let _ = writeln!(out, "version={}", SAVE_VERSION);
    let now_unix = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    let _ = writeln!(out, "last_save_unix={}", now_unix);
    let _ = writeln!(out, "epoch_seconds={}", r.world_clock.epoch_seconds);
    let _ = writeln!(out, "next_npc_id={}", r.next_npc_id);
    let _ = writeln!(out, "player_credits={}", r.wallet.credits);
    let _ = writeln!(out, "player_hull={}", r.player_hull);
    let _ = writeln!(out, "player_iron={}", r.inventory.count(ORE));
    let _ = writeln!(out, "player_platinum={}", r.inventory.count(PLATINUM));
    for (a, b, v) in r.reputation.iter() {
        let _ = writeln!(out, "rep={},{},{}", a.as_str(), b.as_str(), v);
    }
    for (i, base) in r.bases.iter().enumerate() {
        let _ = writeln!(
            out,
            "base={},{},{},{},{}",
            i,
            base.hull,
            if base.destroyed { 1 } else { 0 },
            base.rebuild_timer,
            base.shield.current,
        );
    }
    for (i, slot) in r.npc_slots.iter().enumerate() {
        let _ = writeln!(out, "slot_spawn_count={},{}", i, slot.spawn_count);
    }
    std::fs::write(SAVE_PATH, out)?;
    // M44: chronicle lives in its own sidecar so the main save stays
    // line-based and compact. Each session appends the in-memory ring
    // and the disk file keeps growing — rotation is a later concern.
    let chronicle_text = ce_chronicle::serialize_text(&r.chronicle);
    std::fs::write(CHRONICLE_PATH, chronicle_text)
}

/// M44: read the chronicle sidecar and splice it into `r.chronicle`.
/// Errors are swallowed — a missing / partial history file just means
/// the player has fewer past moments to browse.
fn load_chronicle_into(r: &mut Renderer) {
    if let Ok(text) = std::fs::read_to_string(CHRONICLE_PATH) {
        let cap = r.chronicle.capacity();
        r.chronicle = ce_chronicle::deserialize_text(&text, cap);
    }
}

/// M44: if the save carried a `last_save_unix`, compute the wall
/// delta and fast-forward the simulation through it. Emits the
/// `EpochSkipped` chronicle event as a side effect.
fn run_offline_catch_up(r: &mut Renderer) {
    if r.last_save_unix == 0 {
        return;
    }
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    if now <= r.last_save_unix {
        return;
    }
    let delta = (now - r.last_save_unix) as f64;
    if delta < 1.0 {
        return;
    }
    let base_factions: Vec<FactionId> = r.bases.iter().map(|b| b.faction).collect();
    let mut tick = offline::OfflineTick {
        world_clock: &mut r.world_clock,
        world_pulse: &mut r.world_pulse,
        reputation: &mut r.reputation,
        player_faction: r.player_faction,
        market: &mut r.market,
        mission_board: &mut r.mission_board,
        mission_log: &mut r.mission_log,
        mission_next_id: &mut r.mission_next_id,
        faction_bases: &mut r.faction_bases,
        base_factions: &base_factions,
        chronicle: &mut r.chronicle,
    };
    let span = offline::catch_up(&mut tick, delta);
    // Surface the advance in the transient banner so the player sees
    // "the world moved while you were away".
    let hours = (span / 3600.0) as u64;
    let mins = ((span % 3600.0) / 60.0) as u64;
    r.last_combat_msg = Some(format!("WORLD ADVANCED  {}h {}m", hours, mins));
    r.last_combat_msg_ttl = 4.0;
}

/// Apply contents of `SAVE_PATH` onto `r`. Called after the fresh
/// pre-existing-seed setup; any keys present override the defaults.
/// Silently tolerates malformed lines so an old or partial save still
/// brings back what it can.
fn load_world_into(r: &mut Renderer) -> bool {
    let text = match std::fs::read_to_string(SAVE_PATH) {
        Ok(t) => t,
        Err(_) => return false,
    };
    let mut loaded = false;
    for raw in text.lines() {
        let line = raw.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let Some((key, value)) = line.split_once('=') else {
            continue;
        };
        match key {
            "version" => {
                // Future-proof: refuse incompatible saves. For now one
                // version exists so we just keep going.
                let _ = value.parse::<u32>();
            }
            "epoch_seconds" => {
                if let Ok(v) = value.parse::<f64>() {
                    r.world_clock.epoch_seconds = v;
                    loaded = true;
                }
            }
            "last_save_unix" => {
                if let Ok(v) = value.parse::<u64>() {
                    r.last_save_unix = v;
                }
            }
            "next_npc_id" => {
                if let Ok(v) = value.parse::<u32>() {
                    r.next_npc_id = v;
                }
            }
            "player_credits" => {
                if let Ok(v) = value.parse::<i64>() {
                    r.wallet.credits = v;
                }
            }
            "player_hull" => {
                if let Ok(v) = value.parse::<f32>() {
                    r.player_hull = v.clamp(0.0, r.player_hull_max);
                }
            }
            "player_iron" => {
                if let Ok(v) = value.parse::<u32>() {
                    // Write-through via clear+add so bounds hold.
                    let _ = r.inventory.remove(ORE, r.inventory.count(ORE));
                    let _ = r.inventory.add(ORE, v);
                }
            }
            "player_platinum" => {
                if let Ok(v) = value.parse::<u32>() {
                    let _ = r.inventory.remove(PLATINUM, r.inventory.count(PLATINUM));
                    let _ = r.inventory.add(PLATINUM, v);
                }
            }
            "rep" => {
                let mut it = value.splitn(3, ',');
                let a = it.next().map(str::to_string);
                let b = it.next().map(str::to_string);
                let v = it.next().and_then(|s| s.parse::<i32>().ok());
                if let (Some(a), Some(b), Some(v)) = (a, b, v) {
                    // FactionId needs &'static str. Intern via our
                    // known-factions table; unknown faction ids are
                    // ignored (the save is from another world shape).
                    if let (Some(fa), Some(fb)) = (intern_faction(&a), intern_faction(&b)) {
                        r.reputation.set(fa, fb, v);
                    }
                }
            }
            "base" => {
                let mut parts = value.split(',');
                let idx = parts.next().and_then(|s| s.parse::<usize>().ok());
                let hull = parts.next().and_then(|s| s.parse::<f32>().ok());
                let destroyed = parts.next().and_then(|s| s.parse::<u32>().ok());
                let rebuild = parts.next().and_then(|s| s.parse::<f32>().ok());
                let shield = parts.next().and_then(|s| s.parse::<f32>().ok());
                if let (Some(idx), Some(hull), Some(destroyed), Some(rebuild), Some(shield)) =
                    (idx, hull, destroyed, rebuild, shield)
                {
                    if let Some(base) = r.bases.get_mut(idx) {
                        base.hull = hull.clamp(0.0, base.hull_max);
                        base.destroyed = destroyed != 0;
                        base.rebuild_timer = rebuild.max(0.0);
                        base.shield.current = shield.clamp(0.0, base.shield.max);
                        if base.destroyed {
                            // Hide the mesh to match the persisted
                            // state.
                            let mesh_index = r.base_mesh_indices[idx];
                            let mesh = &r.meshes[mesh_index];
                            if let Some(verts) = mesh.base_vertices.as_ref() {
                                let world =
                                    translate_vertices(verts, Vec3::new(0.0, -10_000.0, 0.0));
                                r.queue.write_buffer(
                                    &mesh.vertex_buffer,
                                    0,
                                    bytemuck::cast_slice(&world),
                                );
                            }
                        }
                    }
                }
            }
            "slot_spawn_count" => {
                let mut parts = value.split(',');
                let idx = parts.next().and_then(|s| s.parse::<usize>().ok());
                let count = parts.next().and_then(|s| s.parse::<u32>().ok());
                if let (Some(idx), Some(count)) = (idx, count) {
                    if let Some(slot) = r.npc_slots.get_mut(idx) {
                        slot.spawn_count = count;
                    }
                }
            }
            _ => {}
        }
    }
    loaded
}

/// Translate a save-file faction id back to its interned `'static`
/// equivalent. Returns `None` for names the current build doesn't
/// know (e.g. an old save referring to a removed faction).
fn intern_faction(s: &str) -> Option<FactionId> {
    match s {
        "ronin" => Some(F_PLAYER),
        "protectorate" => Some(F_PROTECTORATE),
        "union" => Some(F_UNION),
        "crimson" => Some(F_CRIMSON),
        _ => None,
    }
}

fn build_faction_registry() -> FactionRegistry {
    let mut r = FactionRegistry::new();
    r.insert(ce_faction::Faction::new(
        F_PLAYER,
        llull_faction_name(F_PLAYER),
    ));
    r.insert(ce_faction::Faction::new(
        F_PROTECTORATE,
        llull_faction_name(F_PROTECTORATE),
    ));
    r.insert(ce_faction::Faction::new(
        F_UNION,
        llull_faction_name(F_UNION),
    ));
    r.insert(ce_faction::Faction::new(
        F_CRIMSON,
        llull_faction_name(F_CRIMSON),
    ));
    r
}

/// M48: maps each faction to its Llull token.
///
/// The token carries the faction's flavour structurally: world prefix
/// (intellectual / celestial / material) and dominant dignity suffix
/// (truth / justice / love / equanimity). The english "flavour tail"
/// is kept as a short parenthetical so the player can still read who
/// they're dealing with — the HUD shows both.
fn llull_faction_name(faction: FactionId) -> String {
    use ce_llull::{generate_name, DignityVector, World};
    let (vector, world, seed, tail) = match faction {
        f if f == F_PLAYER => (
            DignityVector::new(0.5, 0.0, 0.0, 0.5),
            World::Intellectual,
            0xC0DE_CAFE,
            "Rōnin",
        ),
        f if f == F_PROTECTORATE => (
            DignityVector::new(0.2, 0.6, 0.1, 0.1),
            World::Celestial,
            0xDEAD_BEEF,
            "Protectorate",
        ),
        f if f == F_UNION => (
            DignityVector::new(0.1, 0.2, 0.6, 0.1),
            World::Material,
            0x1DEA_F00D,
            "Union",
        ),
        f if f == F_CRIMSON => (
            DignityVector::new(0.6, 0.3, 0.1, 0.0),
            World::Material,
            0xFADE_B12B,
            "Crimson Fang",
        ),
        _ => return faction.as_str().to_string(),
    };
    let token = generate_name(&vector, Some(world), seed)
        .map(|t| t.canonical)
        .unwrap_or_else(|_| faction.as_str().to_string());
    format!("{token} ({tail})")
}

/// M48: Llull-style display name for items, keyed by the ItemId's
/// canonical string. Internal IDs stay unchanged so all tests,
/// inventory saves, and crafting paths continue to work — only the
/// player-facing label swaps to the combinatorial form.
fn llull_item_name(id: ItemId) -> &'static str {
    match id.as_str() {
        "iron_ore" => "okadaly",
        "platinum_ore" => "okelody",
        "coal" => "oktody",
        "iron_ingot" => "okodedy",
        "platinum_plate" => "okotoly",
        "contraband" => "okyaly",
        other => other,
    }
}

/// Initial reputation matrix. Pirates are at war with everyone who
/// upholds the law; the union trusts patrol; the player starts
/// neutral-to-friendly with lawful factions and hostile to pirates,
/// because that is the shape of the world this sector belongs to.
fn build_starter_reputation() -> ReputationMatrix {
    let mut m = ReputationMatrix::new();
    m.set(F_CRIMSON, F_PROTECTORATE, REP_WAR);
    m.set(F_CRIMSON, F_UNION, REP_HOSTILE - 100);
    m.set(F_CRIMSON, F_PLAYER, REP_HOSTILE - 100);
    m.set(F_PROTECTORATE, F_UNION, REP_FRIENDLY + 100);
    m.set(F_PROTECTORATE, F_PLAYER, 50);
    m.set(F_UNION, F_PLAYER, REP_FRIENDLY + 50);
    m
}

/// Pre-drift the station's market by the world age so stock levels
/// don't read as the exact numbers a human typed. Rates are picked so
/// 1800 s of drift lands well short of equilibrium — the world is
/// running, not saturated.
fn pre_drift_market(market: &mut Market, elapsed_seconds: f32) {
    if let Some(e) = market.get(ORE).copied() {
        let mut e = e;
        restock_market_entry(&mut e, ORE_RESTOCK_PER_SECOND, elapsed_seconds);
        market.insert(ORE, e);
    }
    if let Some(e) = market.get(PLATINUM).copied() {
        let mut e = e;
        restock_market_entry(&mut e, PLATINUM_RESTOCK_PER_SECOND, elapsed_seconds);
        market.insert(PLATINUM, e);
    }
}

/// Decrement each asteroid's `units_remaining` by 5-25% so their ore
/// stocks look like bodies that have already been worked on.
fn pre_drift_asteroids(nodes: &mut [ResourceNode], clock: &WorldClock) {
    let mut rng = clock.deterministic_rng(SALT_ASTEROID);
    for node in nodes.iter_mut() {
        let frac = 0.05 + rng.next_f32_unit() * 0.20;
        let lost = (node.units_remaining as f32 * frac) as u32;
        node.units_remaining = node.units_remaining.saturating_sub(lost);
    }
}

/// Pick an already-in-progress goal + starting pose for the given role.
/// Pulls every random choice from `rng` so the same seed reproduces the
/// same world. Returns `(goal, spawn_pos, spawn_orient)`.
fn seed_goal_from_rng(
    role: SlotKind,
    slot_base_pos: Vec3,
    station_pos: Vec3,
    rng: &mut ce_worldclock::DeterministicRng,
) -> (NpcGoal, Vec3, Quat) {
    fn look_along(dir: Vec3) -> Quat {
        let forward = -Vec3::Z;
        let d = dir.length();
        if d < 1e-4 {
            return Quat::IDENTITY;
        }
        let dir = dir / d;
        let dot = forward.dot(dir).clamp(-1.0, 1.0);
        if dot > 0.9999 {
            return Quat::IDENTITY;
        }
        if dot < -0.9999 {
            return Quat::from_axis_angle(Vec3::Y, std::f32::consts::PI);
        }
        let axis = forward.cross(dir).normalize();
        Quat::from_axis_angle(axis, dot.acos())
    }

    match role {
        SlotKind::Patrol => {
            // Patrol route now circles the Protectorate station at
            // the expanded radius.
            let waypoints = vec![
                station_pos + Vec3::new(16.0, 4.0, 0.0),
                station_pos + Vec3::new(0.0, 4.0, -16.0),
                station_pos + Vec3::new(-16.0, 4.0, 0.0),
                station_pos + Vec3::new(0.0, 4.0, 16.0),
            ];
            let n = waypoints.len();
            let cursor = rng.range_u32(0, n as u32) as usize;
            let prev = (cursor + n - 1) % n;
            let t = rng.next_f32_unit();
            let pos = waypoints[prev] * (1.0 - t) + waypoints[cursor] * t;
            let dir = waypoints[cursor] - waypoints[prev];
            let orient = look_along(dir);
            let goal = NpcGoal::Patrol {
                waypoints,
                cursor,
                arrive_radius: 1.5,
            };
            (goal, pos, orient)
        }
        SlotKind::Miner => {
            let target = ASTEROID_B_POS + Vec3::new(2.5, 0.5, 1.0);
            let already_mined = rng.range_u32(0, 41);
            let tick_accum = rng.next_f32_unit() * 1.2;
            let goal = NpcGoal::Mine {
                target,
                mine_radius: 3.0,
                tick_seconds: 1.2,
                tick_accum,
                units_left: 200u32.saturating_sub(already_mined),
            };
            let orient = look_along(target - slot_base_pos);
            (goal, slot_base_pos, orient)
        }
        SlotKind::Trader => {
            let from = STATION_POS + Vec3::new(0.0, 2.0, 0.0);
            let to = Vec3::new(0.0, 0.0, -20.0);
            let heading_back = rng.bool();
            let t = rng.next_f32_unit();
            let pos = from * (1.0 - t) + to * t;
            let active = if heading_back { from } else { to };
            let orient = look_along(active - pos);
            let goal = NpcGoal::Trade {
                from,
                to,
                heading_back,
                arrive_radius: 2.0,
            };
            (goal, pos, orient)
        }
        SlotKind::Pirate => {
            // Reavers prowl between the hideout, asteroid D (platinum
            // they can raid from the Union miner), and open space at
            // the far edge of the expanded sector.
            let waypoints = vec![
                CRIMSON_HIDEOUT_POS + Vec3::new(10.0, 0.0, 8.0),
                ASTEROID_D_POS + Vec3::new(4.0, 0.0, 3.0),
                Vec3::new(-20.0, 3.0, -30.0),
                Vec3::new(15.0, 3.0, -40.0),
            ];
            let n = waypoints.len();
            let cursor = rng.range_u32(0, n as u32) as usize;
            let prev = (cursor + n - 1) % n;
            let t = rng.next_f32_unit();
            let pos = waypoints[prev] * (1.0 - t) + waypoints[cursor] * t;
            let dir = waypoints[cursor] - waypoints[prev];
            let orient = look_along(dir);
            let goal = NpcGoal::Patrol {
                waypoints,
                cursor,
                arrive_radius: 1.5,
            };
            (goal, pos, orient)
        }
    }
}

/// Industrial-looking trade station: a wide hull plate with a central
/// tower of titanium blocks. Built from voxel blocks so we can reuse
/// build_ship_mesh and the hull pipeline directly.
fn build_station() -> ShipBlocks {
    let mut s = ShipBlocks::new();
    // Base plate (5x1x5 of iron).
    for x in -2..=2 {
        for z in -2..=2 {
            s.insert(
                IVec3::new(x, 0, z),
                Block::new(BlockKind::Hull, BlockMaterial::Iron),
            );
        }
    }
    // Central tower (3 tall, titanium for visual contrast).
    for y in 1..=3 {
        s.insert(
            IVec3::new(0, y, 0),
            Block::new(BlockKind::Hull, BlockMaterial::Titanium),
        );
    }
    // Antenna tip (tungsten).
    s.insert(
        IVec3::new(0, 4, 0),
        Block::new(BlockKind::Weapon, BlockMaterial::Tungsten),
    );
    s
}

/// Union depot — smaller structure for the trader faction, built of
/// iron with a wider landing pad so it reads "industrial" rather
/// than "military".
fn build_union_depot() -> ShipBlocks {
    let mut s = ShipBlocks::new();
    for x in -1..=1 {
        for z in -2..=2 {
            s.insert(
                IVec3::new(x, 0, z),
                Block::new(BlockKind::Hull, BlockMaterial::Iron),
            );
        }
    }
    // Two low storage pods.
    for z in [-1, 1] {
        s.insert(
            IVec3::new(0, 1, z),
            Block::new(BlockKind::Hull, BlockMaterial::Iron),
        );
    }
    s
}

/// Crimson hideout — jagged tungsten outcrop with defensive turrets.
/// Reads predatory compared to the clean station and depot shapes.
fn build_crimson_hideout() -> ShipBlocks {
    let mut s = ShipBlocks::new();
    // Central core.
    for y in 0..=1 {
        s.insert(
            IVec3::new(0, y, 0),
            Block::new(BlockKind::Hull, BlockMaterial::Tungsten),
        );
    }
    // Wings reaching out.
    for x in [-2, -1, 1, 2] {
        s.insert(
            IVec3::new(x, 0, 0),
            Block::new(BlockKind::Hull, BlockMaterial::Tungsten),
        );
    }
    // Defensive spars.
    for x in [-2, 2] {
        s.insert(
            IVec3::new(x, 0, -1),
            Block::new(BlockKind::Weapon, BlockMaterial::Tungsten),
        );
        s.insert(
            IVec3::new(x, 0, 1),
            Block::new(BlockKind::Weapon, BlockMaterial::Tungsten),
        );
    }
    s
}

fn look_at_rh(eye: Vec3, target: Vec3, up: Vec3) -> Mat4 {
    let f = (target - eye).normalize();
    let r = f.cross(up).normalize();
    let u = r.cross(f);
    Mat4::from_cols_array_2d(&[
        [r.x, u.x, -f.x, 0.0],
        [r.y, u.y, -f.y, 0.0],
        [r.z, u.z, -f.z, 0.0],
        [-r.dot(eye), -u.dot(eye), f.dot(eye), 1.0],
    ])
}

fn perspective_rh(fov_y: f32, aspect: f32, near: f32, far: f32) -> Mat4 {
    let f = 1.0 / (fov_y * 0.5).tan();
    let nf = 1.0 / (near - far);
    Mat4::from_cols_array_2d(&[
        [f / aspect, 0.0, 0.0, 0.0],
        [0.0, f, 0.0, 0.0],
        [0.0, 0.0, (far + near) * nf, -1.0],
        [0.0, 0.0, 2.0 * far * near * nf, 0.0],
    ])
}

// ---------------------------------------------------------------------
// Application
// ---------------------------------------------------------------------

struct App {
    window: Option<Window>,
    renderer: Option<Renderer>,
    last_frame: Option<std::time::Instant>,
    input: ThrustInput,
}

impl App {
    fn new() -> Self {
        Self {
            window: None,
            renderer: None,
            last_frame: None,
            input: ThrustInput::default(),
        }
    }
}

impl ApplicationHandler for App {
    fn resumed(&mut self, event_loop: &ActiveEventLoop) {
        if self.window.is_some() {
            return;
        }
        let attrs = WindowAttributes::default()
            .with_title("ChemEngine — play_demo")
            .with_inner_size(winit::dpi::LogicalSize::new(1280.0, 720.0));
        let window = event_loop.create_window(attrs).expect("create window");
        let renderer = Renderer::new(&window);
        self.window = Some(window);
        self.renderer = Some(renderer);
        self.last_frame = Some(std::time::Instant::now());
    }

    fn window_event(
        &mut self,
        event_loop: &ActiveEventLoop,
        _window_id: WindowId,
        event: WindowEvent,
    ) {
        match event {
            WindowEvent::CloseRequested => {
                if let Some(r) = self.renderer.as_ref() {
                    let _ = save_world(r);
                }
                event_loop.exit();
            }
            WindowEvent::KeyboardInput { event: key, .. } => {
                let pressed = key.state == ElementState::Pressed;
                match key.logical_key.as_ref() {
                    Key::Named(NamedKey::Escape) if pressed => {
                        if let Some(r) = self.renderer.as_ref() {
                            let _ = save_world(r);
                        }
                        event_loop.exit();
                    }
                    Key::Named(NamedKey::F5) if pressed => {
                        if let Some(r) = self.renderer.as_mut() {
                            match save_world(r) {
                                Ok(()) => {
                                    r.last_combat_msg = Some("WORLD SAVED [F5]".into());
                                    r.last_combat_msg_ttl = 2.0;
                                }
                                Err(e) => {
                                    r.last_combat_msg = Some(format!("SAVE FAILED: {}", e));
                                    r.last_combat_msg_ttl = 3.0;
                                }
                            }
                        }
                    }
                    Key::Character("w") | Key::Character("W") => self.input.forward = pressed,
                    Key::Character("s") | Key::Character("S") => self.input.backward = pressed,
                    Key::Character("a") | Key::Character("A") => self.input.left = pressed,
                    Key::Character("d") | Key::Character("D") => self.input.right = pressed,
                    Key::Character("e") | Key::Character("E") => self.input.up = pressed,
                    Key::Character("q") | Key::Character("Q") => self.input.down = pressed,
                    Key::Named(NamedKey::ArrowUp) => self.input.pitch_up = pressed,
                    Key::Named(NamedKey::ArrowDown) => self.input.pitch_down = pressed,
                    Key::Named(NamedKey::ArrowLeft) => self.input.yaw_left = pressed,
                    Key::Named(NamedKey::ArrowRight) => self.input.yaw_right = pressed,
                    Key::Character("f") | Key::Character("F") => self.input.mine = pressed,
                    Key::Named(NamedKey::Space) => self.input.fire = pressed,
                    Key::Character("k") | Key::Character("K") if pressed => {
                        if let Some(r) = self.renderer.as_mut() {
                            r.toggle_trade_panel();
                        }
                    }
                    Key::Character("t") | Key::Character("T") if pressed => {
                        if let Some(r) = self.renderer.as_mut() {
                            r.sell_all_ore();
                        }
                    }
                    // M43: one-key accept for the next available
                    // mission when the player is docked. Picks the
                    // earliest-expiring offer so the player can make
                    // a judgement about taking it.
                    Key::Character("m") | Key::Character("M") if pressed => {
                        if let Some(r) = self.renderer.as_mut() {
                            r.accept_next_mission();
                        }
                    }
                    // M44: toggle the full-history overlay.
                    Key::Character("h") | Key::Character("H") if pressed => {
                        if let Some(r) = self.renderer.as_mut() {
                            r.history_panel_open = !r.history_panel_open;
                        }
                    }
                    _ => {}
                }
            }
            WindowEvent::Resized(sz) => {
                if let Some(r) = self.renderer.as_mut() {
                    r.resize(sz.width, sz.height);
                }
            }
            WindowEvent::RedrawRequested => {
                if let Some(r) = self.renderer.as_mut() {
                    let now = std::time::Instant::now();
                    let dt = self
                        .last_frame
                        .map(|t| now.duration_since(t).as_secs_f32().min(0.1))
                        .unwrap_or(0.016);
                    self.last_frame = Some(now);
                    r.update(self.input, dt);
                    match r.render() {
                        Ok(()) => {}
                        Err(wgpu::SurfaceError::Lost | wgpu::SurfaceError::Outdated) => {
                            let (w, h) = (r.config.width, r.config.height);
                            r.resize(w, h);
                        }
                        Err(e) => log::warn!("surface error: {e:?}"),
                    }
                }
                if let Some(w) = self.window.as_ref() {
                    w.request_redraw();
                }
            }
            _ => {}
        }
    }
}

fn main() {
    env_logger::init();
    log::info!("play_demo starting");
    let event_loop = EventLoop::new().expect("event loop");
    let mut app = App::new();
    event_loop.run_app(&mut app).expect("event loop run");
}

//! Offline catch-up — fast-forward the world by the real-time delta
//! between the last save and startup.
//!
//! When the player returns after closing the game, we don't want the
//! world to resume frozen from the last frame. Instead: each time the
//! save is written we stamp it with the wall-clock `last_save_unix`;
//! on load we compute `now_unix - last_save_unix` and run a cheap
//! pure-function simulation for that many seconds, pushing synthetic
//! events into `ce_chronicle` along the way. The player walks in to a
//! sector that actually moved while they were away.
//!
//! What runs during catch-up (all pure, no rendering, no NPC motion):
//! - `WorldClock::tick`
//! - `ce_base::tick_production` per station (mood-modulated)
//! - `ce_mission::MissionBoard::tick` + `tick_log`
//! - `mission_gen::maybe_post_offer` per station
//! - `ce_economy::restock_market_entry` per market entry (tiny drift)
//! - `ce_worldpulse::advance_pulse` with the accumulated `PulseEvents`
//! - `ce_faction::decay_reputation` in one-second buckets
//!
//! What does **not** run:
//! - NPC movement / firing — M37's design is that NPC individuals are
//!   re-seeded from WorldClock at any observation point, so their
//!   positions during offline are undefined rather than tracked.
//! - Rendering, input, audio.

use ce_chronicle::{Chronicle, EventKind, WorldEvent};
use ce_economy::Market;
use ce_faction::{decay_reputation, ReputationMatrix};
use ce_mission::{tick_log as mission_tick_log, MissionBoard, MissionLog};
use ce_worldclock::WorldClock;
use ce_worldpulse::{advance_pulse, PulseEvents, WorldPulse};

use crate::mission_gen::maybe_post_offer;
use crate::stations;

/// One fast-tick step in simulated seconds. Small enough that
/// production cycles (5-12 s) resolve at roughly the right cadence;
/// large enough that 7 days × 86400 s / 60 s ≈ 10 080 steps finishes
/// in a fraction of a second.
pub const FAST_STEP_SECONDS: f32 = 60.0;

/// Upper bound on the real-time delta we'll simulate through in one
/// startup. 7 days. Beyond this the delta is truncated and the
/// corresponding `EpochSkipped` event is flagged `capped: true`.
pub const MAX_OFFLINE_SECONDS: f64 = 7.0 * 86_400.0;

/// State the fast-tick loop reads and writes. Pure data — no
/// rendering handles, no wgpu. The play_demo gathers pointers to
/// live state into one of these, runs `fast_advance`, then unpacks.
pub struct OfflineTick<'a> {
    pub world_clock: &'a mut WorldClock,
    pub world_pulse: &'a mut WorldPulse,
    pub reputation: &'a mut ReputationMatrix,
    pub player_faction: ce_faction::FactionId,
    pub market: &'a mut Market,
    pub mission_board: &'a mut MissionBoard,
    pub mission_log: &'a mut MissionLog,
    pub mission_next_id: &'a mut u64,
    pub faction_bases: &'a mut [ce_base::Base],
    /// Parallel faction identifier for each industrial base — used to
    /// seed mission issuers per tick.
    pub base_factions: &'a [ce_faction::FactionId],
    pub chronicle: &'a mut Chronicle,
}

/// Run one fast step. Emits chronicle events for any expired
/// missions, completed production cycles (not tracked individually —
/// only the aggregate shift shows up as a `PulseShift`), or pulse
/// axes that moved by more than `PULSE_SHIFT_EPSILON`.
pub fn fast_advance(tick: &mut OfflineTick<'_>, dt: f32) {
    if !dt.is_finite() || dt <= 0.0 {
        return;
    }

    tick.world_clock.tick(dt);

    // Production + market sync. Same pattern as tick_combat but
    // without the NPC / mesh updates.
    for fb in tick.faction_bases.iter_mut() {
        stations::apply_mood_to_cycles(fb, tick.world_pulse.market_mood);
        ce_base::tick_production(fb, dt);
    }
    if let (Some(pbase), Some(entry)) = (
        tick.faction_bases.first(),
        tick.market.entry_mut(stations::IRON_INGOT),
    ) {
        entry.stock = pbase.inventory.count(stations::IRON_INGOT);
    }

    // Mission lifecycle. Expired offers silently drop; expired
    // accepted contracts flip Failed and charge reputation.
    let _expired_offers = tick.mission_board.tick(dt);
    let failed = mission_tick_log(tick.mission_log, tick.reputation, tick.player_faction, dt);
    let ts = tick.world_clock.epoch_seconds;
    for id in &failed {
        tick.chronicle.push(WorldEvent {
            timestamp_seconds: ts,
            kind: EventKind::MissionFailed { id: id.0 },
        });
    }
    // Offer posting: one deterministic roll per base per step.
    for (i, faction) in tick.base_factions.iter().enumerate() {
        let salt = 0x4D15_5100_4E00_0000u64.wrapping_add(i as u64);
        let mut rng = tick.world_clock.deterministic_rng(salt);
        let _ = maybe_post_offer(
            tick.mission_board,
            *faction,
            tick.world_pulse,
            &mut rng,
            stations::IRON_ORE,
            dt,
            tick.mission_next_id,
        );
    }

    // Reputation decay: standard rate is one unit per second toward
    // zero. The helper clamps on its own so large dt is safe.
    decay_reputation(tick.reputation, 1.0, dt);

    // Pulse advance with empty events — fast-forward is intentionally
    // "quiet" (no kills). Pulse still evolves from its own decay
    // terms which is enough to show the world was breathing.
    let before = *tick.world_pulse;
    *tick.world_pulse = advance_pulse(*tick.world_pulse, &PulseEvents::default(), dt);
    let delta_t = (tick.world_pulse.tension - before.tension).abs();
    let delta_m = (tick.world_pulse.market_mood - before.market_mood).abs();
    let delta_s = (tick.world_pulse.security - before.security).abs();
    if delta_t.max(delta_m).max(delta_s) > ce_chronicle::PULSE_SHIFT_EPSILON {
        tick.chronicle.push(WorldEvent {
            timestamp_seconds: ts,
            kind: EventKind::PulseShift {
                tension: tick.world_pulse.tension,
                market_mood: tick.world_pulse.market_mood,
                security: tick.world_pulse.security,
            },
        });
    }
}

/// Run a full catch-up loop over `real_delta_seconds`. Returns the
/// actual simulated span (after capping). Pushes one
/// `EpochSkipped` event with the final `from → to` span and the
/// `capped` flag.
pub fn catch_up(tick: &mut OfflineTick<'_>, real_delta_seconds: f64) -> f64 {
    if !real_delta_seconds.is_finite() || real_delta_seconds <= 0.0 {
        return 0.0;
    }
    let capped = real_delta_seconds > MAX_OFFLINE_SECONDS;
    let span = real_delta_seconds.min(MAX_OFFLINE_SECONDS);
    let from = tick.world_clock.epoch_seconds;

    let mut remaining = span;
    while remaining > 0.0 {
        let step = remaining.min(FAST_STEP_SECONDS as f64) as f32;
        fast_advance(tick, step);
        remaining -= step as f64;
    }

    let to = tick.world_clock.epoch_seconds;
    tick.chronicle.push(WorldEvent {
        timestamp_seconds: to,
        kind: EventKind::EpochSkipped { from, to, capped },
    });
    span
}

#[cfg(test)]
mod tests {
    use super::*;
    use ce_economy::{MarketEntry, PriceModel};
    use ce_faction::FactionId;
    use ce_gameplay::ItemId;

    const UNION: FactionId = FactionId::new("union");
    const IRON_ORE: ItemId = ItemId::new("iron_ore");

    #[allow(clippy::type_complexity)]
    fn blank_tick_state() -> (
        WorldClock,
        WorldPulse,
        ReputationMatrix,
        Market,
        MissionBoard,
        MissionLog,
        u64,
        Vec<ce_base::Base>,
        Vec<FactionId>,
        Chronicle,
    ) {
        let mut market = Market::new();
        market.insert(
            IRON_ORE,
            MarketEntry::new(50, 500, PriceModel::new(100, 0.02)),
        );
        let fb = stations::build_protectorate_station(UNION);
        (
            WorldClock::with_epoch(7, 1800.0),
            WorldPulse::calm(),
            ReputationMatrix::new(),
            market,
            MissionBoard::new(),
            MissionLog::new(),
            1,
            vec![fb],
            vec![UNION],
            Chronicle::new(64),
        )
    }

    #[test]
    fn fast_advance_ignores_non_positive_dt() {
        let (mut wc, mut wp, mut rep, mut mk, mut mb, mut ml, mut nid, mut fbs, bfs, mut ch) =
            blank_tick_state();
        let before = wc.epoch_seconds;
        let mut tick = OfflineTick {
            world_clock: &mut wc,
            world_pulse: &mut wp,
            reputation: &mut rep,
            player_faction: FactionId::new("player"),
            market: &mut mk,
            mission_board: &mut mb,
            mission_log: &mut ml,
            mission_next_id: &mut nid,
            faction_bases: &mut fbs,
            base_factions: &bfs,
            chronicle: &mut ch,
        };
        fast_advance(&mut tick, 0.0);
        fast_advance(&mut tick, -5.0);
        fast_advance(&mut tick, f32::NAN);
        assert_eq!(wc.epoch_seconds, before);
    }

    #[test]
    fn catch_up_advances_clock() {
        let (mut wc, mut wp, mut rep, mut mk, mut mb, mut ml, mut nid, mut fbs, bfs, mut ch) =
            blank_tick_state();
        let before = wc.epoch_seconds;
        {
            let mut tick = OfflineTick {
                world_clock: &mut wc,
                world_pulse: &mut wp,
                reputation: &mut rep,
                player_faction: FactionId::new("player"),
                market: &mut mk,
                mission_board: &mut mb,
                mission_log: &mut ml,
                mission_next_id: &mut nid,
                faction_bases: &mut fbs,
                base_factions: &bfs,
                chronicle: &mut ch,
            };
            let span = catch_up(&mut tick, 3_600.0);
            assert!((span - 3_600.0).abs() < 1.0);
        }
        assert!(wc.epoch_seconds > before + 3_500.0);
    }

    #[test]
    fn catch_up_caps_at_max_offline() {
        let (mut wc, mut wp, mut rep, mut mk, mut mb, mut ml, mut nid, mut fbs, bfs, mut ch) =
            blank_tick_state();
        {
            let mut tick = OfflineTick {
                world_clock: &mut wc,
                world_pulse: &mut wp,
                reputation: &mut rep,
                player_faction: FactionId::new("player"),
                market: &mut mk,
                mission_board: &mut mb,
                mission_log: &mut ml,
                mission_next_id: &mut nid,
                faction_bases: &mut fbs,
                base_factions: &bfs,
                chronicle: &mut ch,
            };
            let span = catch_up(&mut tick, 30.0 * 86_400.0); // 30 days
            assert!((span - MAX_OFFLINE_SECONDS).abs() < 1.0);
        }
        let events: Vec<_> = ch.iter().collect();
        let epoch_skipped = events
            .iter()
            .find(|e| matches!(e.kind, EventKind::EpochSkipped { .. }));
        match epoch_skipped.map(|e| &e.kind) {
            Some(EventKind::EpochSkipped { capped, .. }) => assert!(*capped),
            _ => panic!("expected capped EpochSkipped event"),
        }
    }

    #[test]
    fn catch_up_runs_production() {
        let (mut wc, mut wp, mut rep, mut mk, mut mb, mut ml, mut nid, mut fbs, bfs, mut ch) =
            blank_tick_state();
        // Seed iron ore so the refinery actually runs.
        let _ = fbs[0].inventory.add(stations::IRON_ORE, 50);
        let before_ingots = fbs[0].inventory.count(stations::IRON_INGOT);
        {
            let mut tick = OfflineTick {
                world_clock: &mut wc,
                world_pulse: &mut wp,
                reputation: &mut rep,
                player_faction: FactionId::new("player"),
                market: &mut mk,
                mission_board: &mut mb,
                mission_log: &mut ml,
                mission_next_id: &mut nid,
                faction_bases: &mut fbs,
                base_factions: &bfs,
                chronicle: &mut ch,
            };
            catch_up(&mut tick, 600.0);
        }
        let after_ingots = fbs[0].inventory.count(stations::IRON_INGOT);
        assert!(
            after_ingots > before_ingots,
            "production did not advance: {before_ingots} -> {after_ingots}"
        );
    }

    #[test]
    fn catch_up_negligible_delta_is_noop() {
        let (mut wc, mut wp, mut rep, mut mk, mut mb, mut ml, mut nid, mut fbs, bfs, mut ch) =
            blank_tick_state();
        let before = wc.epoch_seconds;
        let chron_before = ch.len();
        {
            let mut tick = OfflineTick {
                world_clock: &mut wc,
                world_pulse: &mut wp,
                reputation: &mut rep,
                player_faction: FactionId::new("player"),
                market: &mut mk,
                mission_board: &mut mb,
                mission_log: &mut ml,
                mission_next_id: &mut nid,
                faction_bases: &mut fbs,
                base_factions: &bfs,
                chronicle: &mut ch,
            };
            let span = catch_up(&mut tick, 0.0);
            assert_eq!(span, 0.0);
        }
        assert_eq!(wc.epoch_seconds, before);
        assert_eq!(ch.len(), chron_before);
    }
}

//! Pulse-driven mission generator.
//!
//! The world, not the player, authors missions. Each station's
//! [`MissionBoard`] is topped up every tick based on the current
//! `WorldPulse` state: a tense sector favours Hunt contracts, a
//! pessimistic-mood sector favours Courier contracts (to restart
//! trade), a low-security sector favours Escort contracts. The
//! generator takes a `DeterministicRng` from the `WorldClock` so
//! save/load can replay mission offers bit-for-bit.

use ce_economy::Credits;
use ce_faction::FactionId;
use ce_gameplay::ItemId;
use ce_mission::{Mission, MissionBoard, MissionId, MissionKind};
use ce_worldclock::DeterministicRng;
use ce_worldpulse::WorldPulse;

/// Per-issuer spawn chance per tick (probability). Low enough that
/// a single board keeps 2-4 offers over a typical play session.
const BASE_SPAWN_CHANCE_PER_SEC: f32 = 0.02;

/// Cap on concurrent offers per board. Older offers expire via
/// `MissionBoard::tick` before new ones pile up past this limit.
const MAX_OFFERS_PER_BOARD: usize = 4;

/// Baseline reward in credit-cents. Mood and kind scale this.
const BASE_REWARD: Credits = 6_000;

/// Pure function: decide which mission archetype the board wants
/// this tick, given the current pulse. Returns `None` when the
/// world is calm enough that the board should not post. Extracted
/// for direct unit testing.
pub fn choose_kind(
    issuer: FactionId,
    pulse: &WorldPulse,
    rng: &mut DeterministicRng,
    ore_id: ItemId,
) -> Option<MissionKind> {
    // Weighted roll. Weights driven by pulse fields:
    //   tension   → Hunt
    //   1-mood    → Courier (economy revival)
    //   1-security→ Escort (danger keeps cargo alive)
    // The 0.1 floor keeps every archetype reachable.
    let w_hunt = (pulse.tension * 2.0 + 0.1).max(0.1);
    let w_courier = ((1.0 - pulse.market_mood) * 1.5 + 0.1).max(0.1);
    let w_escort = ((1.0 - pulse.security) * 1.2 + 0.1).max(0.1);
    let w_mine = 0.6;
    let total = w_hunt + w_courier + w_escort + w_mine;
    let pick = rng.next_f32_unit() * total;

    if pick < w_hunt {
        // Hunt any non-issuer faction — keeps it simple; the
        // gameplay layer picks a specific enemy via reputation
        // when generating the final mission.
        let _ = issuer;
        Some(MissionKind::Hunt {
            target_faction: FactionId::new("crimson"),
            count: 1 + rng.range_u32(0, 3),
        })
    } else if pick < w_hunt + w_courier {
        Some(MissionKind::Courier {
            destination: "Station".into(),
            item: ore_id,
            count: 4 + rng.range_u32(0, 8),
        })
    } else if pick < w_hunt + w_courier + w_escort {
        Some(MissionKind::Escort {
            escortee: "Hauler".into(),
            destination: "Station".into(),
        })
    } else {
        Some(MissionKind::Mine {
            resource: ore_id,
            count: 10 + rng.range_u32(0, 15),
        })
    }
}

/// Try to post one mission on `board` for `issuer`. Called per-tick
/// from the gameplay loop. Noop when the board is already at
/// capacity or when the random roll fails the spawn chance.
pub fn maybe_post_offer(
    board: &mut MissionBoard,
    issuer: FactionId,
    pulse: &WorldPulse,
    rng: &mut DeterministicRng,
    ore_id: ItemId,
    dt: f32,
    next_id: &mut u64,
) -> Option<MissionId> {
    if board.len() >= MAX_OFFERS_PER_BOARD {
        return None;
    }
    if !dt.is_finite() || dt <= 0.0 {
        return None;
    }
    // Higher tension also raises the rate of offer generation.
    let pressure = (1.0 + pulse.tension * 1.5).clamp(1.0, 3.0);
    let chance = BASE_SPAWN_CHANCE_PER_SEC * pressure * dt;
    if rng.next_f32_unit() >= chance {
        return None;
    }

    let kind = choose_kind(issuer, pulse, rng, ore_id)?;
    let id = MissionId(*next_id);
    *next_id = next_id.wrapping_add(1);

    // Reward scales with perceived risk — lower security = bigger
    // payouts. Tension above 0.5 adds a combat premium.
    let risk_bonus = (1.0 - pulse.security) * 0.6 + pulse.tension * 0.4;
    let reward = (BASE_REWARD as f32 * (1.0 + risk_bonus)).round() as Credits;

    let mut m = Mission::new(id, kind, issuer, reward);
    // Missions expire faster when the sector is hot — the board
    // wants these tasks closed quickly.
    let deadline = (300.0 - pulse.tension * 120.0).max(120.0);
    m.deadline_seconds = deadline;
    board.post(m);
    Some(id)
}

#[cfg(test)]
mod tests {
    use super::*;
    use ce_worldclock::DeterministicRng;

    const UNION: FactionId = FactionId::new("union");
    const IRON_ORE: ItemId = ItemId::new("iron_ore");

    #[test]
    fn choose_kind_returns_something_for_any_pulse() {
        let mut rng = DeterministicRng::from_parts(1, 1, 1);
        let kind = choose_kind(UNION, &WorldPulse::calm(), &mut rng, IRON_ORE);
        assert!(kind.is_some());
    }

    #[test]
    fn high_tension_bias_toward_hunt() {
        let pulse = WorldPulse {
            tension: 0.95,
            security: 1.0,
            market_mood: 0.5,
            space_density: 0.0,
        };
        let mut hunt_count = 0;
        for salt in 0..200 {
            let mut rng = DeterministicRng::from_parts(42, 0, salt);
            if let Some(MissionKind::Hunt { .. }) = choose_kind(UNION, &pulse, &mut rng, IRON_ORE) {
                hunt_count += 1;
            }
        }
        // With tension 0.95, roughly >50% of rolls should be Hunt.
        assert!(
            hunt_count > 100,
            "expected >100 hunts out of 200, got {}",
            hunt_count
        );
    }

    #[test]
    fn low_mood_bias_toward_courier() {
        let pulse = WorldPulse {
            tension: 0.0,
            security: 1.0,
            market_mood: 0.0,
            space_density: 0.0,
        };
        let mut courier_count = 0;
        for salt in 0..200 {
            let mut rng = DeterministicRng::from_parts(7, 0, salt);
            if let Some(MissionKind::Courier { .. }) =
                choose_kind(UNION, &pulse, &mut rng, IRON_ORE)
            {
                courier_count += 1;
            }
        }
        assert!(
            courier_count > 60,
            "expected >60 couriers out of 200, got {}",
            courier_count
        );
    }

    #[test]
    fn maybe_post_respects_board_capacity() {
        let mut board = MissionBoard::new();
        let mut next_id: u64 = 100;
        // Pre-fill the board to capacity.
        for _ in 0..MAX_OFFERS_PER_BOARD {
            let kind = MissionKind::Hunt {
                target_faction: FactionId::new("crimson"),
                count: 1,
            };
            board.post(Mission::new(MissionId(next_id), kind, UNION, 1000));
            next_id += 1;
        }
        let mut rng = DeterministicRng::from_parts(1, 1, 1);
        // 10-second dt for high spawn probability.
        let posted = maybe_post_offer(
            &mut board,
            UNION,
            &WorldPulse::calm(),
            &mut rng,
            IRON_ORE,
            10.0,
            &mut next_id,
        );
        assert_eq!(posted, None);
        assert_eq!(board.len(), MAX_OFFERS_PER_BOARD);
    }

    #[test]
    fn maybe_post_ignores_non_finite_dt() {
        let mut board = MissionBoard::new();
        let mut next_id: u64 = 0;
        let mut rng = DeterministicRng::from_parts(1, 1, 1);
        let posted = maybe_post_offer(
            &mut board,
            UNION,
            &WorldPulse::calm(),
            &mut rng,
            IRON_ORE,
            f32::NAN,
            &mut next_id,
        );
        assert_eq!(posted, None);
    }

    #[test]
    fn posted_mission_has_tension_scaled_deadline() {
        let mut board = MissionBoard::new();
        let mut next_id: u64 = 0;
        // Large dt guarantees at least one post.
        let mut rng = DeterministicRng::from_parts(1, 1, 1);
        let hot_pulse = WorldPulse {
            tension: 1.0,
            ..WorldPulse::calm()
        };
        let _ = maybe_post_offer(
            &mut board,
            UNION,
            &hot_pulse,
            &mut rng,
            IRON_ORE,
            60.0,
            &mut next_id,
        );
        let deadline = board.offers().next().map(|m| m.deadline_seconds);
        if let Some(d) = deadline {
            assert!(d <= 200.0, "deadline too long under tension: {}", d);
        }
    }
}

//! Vertical-slice demo for ChemEngine.
//!
//! A narrative-style headless run that drives every gameplay-domain
//! crate end-to-end, proving they compose. Useful as living
//! documentation, smoke regression test in CI, and a starting point
//! for the first windowed example.
//!
//! `cargo run -p space_demo`

use ce_combat::{apply_damage, DamageType, Shield, WeaponCooldown, WeaponStats};
use ce_diplomacy::{declare_war, sign_treaty, TreatyKind, TreatyRegistry, WarRegistry};
use ce_economy::{buy_from_market, sell_to_market, Market, MarketEntry, PriceModel, Wallet};
use ce_faction::{Faction, FactionId, FactionRegistry, ReputationMatrix};
use ce_flight::{advance_linear, begin_warp, step_warp, FlightCommand, WarpEvent, WarpState};
use ce_gameplay::{
    craft_once, tick_avatar, AvatarEnvironment, AvatarStats, DecayRates, Inventory, ItemId,
    ItemStack, Recipe, RecipeBook, RecipeId,
};
use ce_math::{IVec3, Vec3};
use ce_mission::{
    accept as mission_accept, complete as mission_complete, Mission, MissionBoard, MissionId,
    MissionKind, MissionLog,
};
use ce_net::{ClientId, NetRole, HOST_CLIENT_ID};
use ce_planet::{classify_at, Planet, PlanetId, ScaleRegime};
use ce_save::{decode, encode, SaveManager, SaveMetadata, SaveSlot};
use ce_ship::{
    compute_mass_properties, compute_thrust_budget, Block, BlockKind, BlockMaterial, Facing,
    ShipBlocks,
};
use ce_space::{SectorGraph, SectorId};
use ce_worldgen::{generate_galaxy, Galaxy, GalaxyConfig};

use ce_audio::{AudioClip, AudioEvent, AudioQueue, MixerState};
use ce_base::{tick_production, Base, BaseId, BaseModule, ModuleKind, ProductionLine};
use ce_mesh_gen::{build_asteroid, build_planet_mesh, build_ship_mesh};
use ce_mining::{mine_tick, MineResult, MiningBeam, NodeId as MiningNodeId, ResourceNode};
use ce_shader_gen::all_default_shaders;

/// Item ids used throughout the demo.
const IRON_ORE: ItemId = ItemId::new("iron_ore");
const COAL: ItemId = ItemId::new("coal");
const IRON_INGOT: ItemId = ItemId::new("iron_ingot");

/// Faction ids.
const PLAYER: FactionId = FactionId::new("player");
const UNION: FactionId = FactionId::new("union");
const PIRATES: FactionId = FactionId::new("pirates");

fn main() {
    env_logger::init();
    println!("=== ChemEngine Vertical Slice ===\n");

    // 1. Multiplayer role + galaxy bootstrap ─────────────────────────
    let role = NetRole::Server { max_clients: 10 };
    println!(
        "[Net]    role = {role:?}, host client = {:?}",
        HOST_CLIENT_ID
    );
    let mut clients: Vec<ClientId> = (1..=3).map(ClientId).collect();
    clients.insert(0, HOST_CLIENT_ID);
    println!(
        "[Net]    {} session slots, {} occupied",
        role.capacity(),
        clients.len()
    );

    // Procedurally generate a small 6-sector galaxy with 2 factions
    // and 3 commodities. Single master seed ⇒ byte-identical galaxy
    // every run for the demo.
    let galaxy: Galaxy = generate_galaxy(&GalaxyConfig {
        seed: 0x6E3E_DE30u64,
        sector_count: 6,
        planets_per_sector_min: 1,
        planets_per_sector_max: 3,
        factions: vec![UNION, PIRATES],
        commodities: vec![IRON_ORE, COAL, IRON_INGOT],
    });
    let sectors: &SectorGraph = &galaxy.sectors;
    // Use the first two generated sectors as the "starter" and "target"
    // for this demo's warp.
    let mut sector_ids: Vec<SectorId> = sectors.sectors().map(|s| s.id).collect();
    // SectorId is Hash + Eq but not Ord; sort by its coordinates.
    sector_ids.sort_by_key(|s| (s.0, s.1, s.2));
    let starter_id = sector_ids[0];
    let mining_id = sector_ids[1];
    let frontier_id = sector_ids[sector_ids.len() - 1];
    let starter = sectors.get(starter_id).expect("generated").clone();
    let mining = sectors.get(mining_id).expect("generated").clone();
    let frontier = sectors.get(frontier_id).expect("generated").clone();
    println!(
        "[Space]  galaxy seeded: {} sectors, {} planets, {} stations",
        galaxy.sector_count(),
        galaxy.planet_count(),
        galaxy.station_count()
    );
    println!(
        "[Space]  chosen sectors: starter={:?} ({}), mining={:?} ({}), frontier={:?} ({})",
        starter_id,
        starter.name.as_deref().unwrap_or("?"),
        mining_id,
        mining.name.as_deref().unwrap_or("?"),
        frontier_id,
        frontier.name.as_deref().unwrap_or("?"),
    );

    // 2. Politics: factions + reputation + diplomacy ─────────────────
    let mut factions = FactionRegistry::new();
    factions.insert(Faction::new(UNION, "Trade Union").with_blurb("Patrols Sol-Starter."));
    factions.insert(Faction::new(PIRATES, "Free Fleet").with_blurb("Raids the Rim."));
    factions.insert(Faction::new(PLAYER, "Independent"));
    let mut rep = ReputationMatrix::new();
    let mut treaties = TreatyRegistry::new();
    let mut wars = WarRegistry::new();

    sign_treaty(
        &mut treaties,
        &mut rep,
        TreatyKind::TradeAccord,
        PLAYER,
        UNION,
    );
    declare_war(&mut treaties, &mut wars, &mut rep, UNION, PIRATES);
    println!(
        "[Faction] {} factions; player↔union rep = {}, union↔pirates relation = {:?}",
        factions.len(),
        rep.get(PLAYER, UNION),
        rep.relation(UNION, PIRATES)
    );

    // 3. Build a small ship out of blocks ────────────────────────────
    let mut ship = ShipBlocks::new();
    // 3-cell hull spine + 2 thrusters facing east + 1 weapon facing north.
    for x in 0..3 {
        ship.insert(
            IVec3::new(x, 0, 0),
            Block::new(BlockKind::Hull, BlockMaterial::Iron),
        );
    }
    ship.insert(
        IVec3::new(-1, 0, 0),
        Block::new(BlockKind::Thruster, BlockMaterial::Iron).with_facing(Facing::East),
    );
    ship.insert(
        IVec3::new(-1, 1, 0),
        Block::new(BlockKind::Thruster, BlockMaterial::Iron).with_facing(Facing::East),
    );
    ship.insert(
        IVec3::new(3, 0, 0),
        Block::new(BlockKind::Weapon, BlockMaterial::Titanium).with_facing(Facing::North),
    );
    let mass = compute_mass_properties(&ship);
    let thrust = compute_thrust_budget(&ship);
    println!(
        "[Ship]   {} blocks, mass = {:.0} kg, +x thrust = {:.0} N, weapons = {}",
        ship.len(),
        mass.mass,
        thrust.pos_x,
        ship.iter_kind(BlockKind::Weapon).count()
    );
    assert!(ship.is_structurally_connected(), "ship must be one piece");

    // 4. Flight — burn east for 2s ───────────────────────────────────
    let cmd = FlightCommand::new().with_linear(Vec3::new(1.0, 0.0, 0.0));
    let mut velocity = Vec3::ZERO;
    for _ in 0..120 {
        velocity = advance_linear(&cmd, &thrust, &mass, velocity, 1.0 / 60.0);
    }
    println!(
        "[Flight] after 2s of full +x thrust: vel = ({:.2}, {:.2}, {:.2}) m/s",
        velocity.x, velocity.y, velocity.z
    );
    assert!(velocity.x > 0.0);

    // 5. Warp jump from Sol-Starter to Vega-Mines ────────────────────
    let mut warp = WarpState::Idle;
    begin_warp(&mut warp, mining.center());
    let mut total_time = 0.0_f32;
    let mut events = Vec::new();
    while !matches!(warp, WarpState::Idle) {
        if let Some(ev) = step_warp(&mut warp, 0.5) {
            events.push(ev);
        }
        total_time += 0.5;
        if total_time > 30.0 {
            break;
        }
    }
    println!(
        "[Warp]   reached {:?} in {:.1}s, events = {:?}",
        sectors.get(mining.id).and_then(|s| s.name.as_deref()),
        total_time,
        events
    );
    assert!(events.contains(&WarpEvent::Arrived(mining.center())));

    // 6. Avatar ticks under realistic vacuum then breathable air ─────
    let mut avatar = AvatarStats::full();
    let rates = DecayRates::default();
    // Brief vacuum dash — survivable.
    tick_avatar(
        &mut avatar,
        AvatarEnvironment {
            breathable_air: false,
            sprinting: true,
            temperature_delta: -0.2,
        },
        &rates,
        20.0,
    );
    println!(
        "[Avatar] 20s outside: hp = {:.2}, o2 = {:.2}, stamina = {:.2}",
        avatar.hp, avatar.oxygen, avatar.stamina
    );
    // Back inside — regen kicks in.
    tick_avatar(&mut avatar, AvatarEnvironment::default(), &rates, 5.0);
    println!(
        "[Avatar] +5s in cabin: hp = {:.2}, o2 = {:.2}, stamina = {:.2}",
        avatar.hp, avatar.oxygen, avatar.stamina
    );
    assert!(!avatar.is_dead(), "avatar should survive a 20s spacewalk");
    assert!(avatar.oxygen > 0.95, "oxygen should regen close to full");

    // 7. Inventory + crafting (smelt iron) ───────────────────────────
    let mut inventory = Inventory::new(64);
    inventory
        .add_stack(ItemStack::new(IRON_ORE, 6))
        .expect("inventory has space for ore");
    inventory
        .add_stack(ItemStack::new(COAL, 3))
        .expect("inventory has space for coal");
    let mut book = RecipeBook::new();
    book.insert(Recipe {
        id: RecipeId::new("smelt_iron"),
        inputs: vec![ItemStack::new(IRON_ORE, 2), ItemStack::new(COAL, 1)],
        outputs: vec![ItemStack::new(IRON_INGOT, 1)],
        work_seconds: 5.0,
    });
    craft_once(&mut inventory, &book, RecipeId::new("smelt_iron"))
        .expect("first smelt should succeed");
    craft_once(&mut inventory, &book, RecipeId::new("smelt_iron"))
        .expect("second smelt should succeed");
    println!(
        "[Craft]  inventory: ore = {}, coal = {}, ingots = {}",
        inventory.count(IRON_ORE),
        inventory.count(COAL),
        inventory.count(IRON_INGOT)
    );

    // 8. Trade at the Vega-Mines station market ──────────────────────
    // The generator may have placed a station in the mining sector —
    // show a summary. The buy/sell demo below uses a hand-tuned market
    // so the numbers stay readable regardless of seed.
    // Surface one generated station so the reader can see the
    // procedural data flow to stations + markets.
    if let Some(station) = galaxy.stations_iter().next() {
        println!(
            "[Gen]    generated station example: {} in sector {:?} (owner = {:?}, {} listings)",
            station.name,
            station.sector,
            station.owner,
            station.market.len()
        );
    }
    let mut market = Market::new();
    // Slight oversupply (r = 1.2) so buy price is 80% of base — visibly
    // non-zero, but cheaper than the rare ingots.
    market.insert(
        IRON_ORE,
        MarketEntry::new(120, 100, PriceModel::new(50, 1.0)),
    );
    market.insert(
        IRON_INGOT,
        MarketEntry::new(20, 100, PriceModel::new(400, 1.0)),
    );
    let mut wallet = Wallet::new(50_000);
    let bought = buy_from_market(&mut market, &mut wallet, &mut inventory, IRON_ORE, 5)
        .expect("ore in stock and credits available");
    let sold = sell_to_market(&mut market, &mut wallet, &mut inventory, IRON_INGOT, 2)
        .expect("two ingots sit in inventory");
    println!(
        "[Market] bought 5 ore for {} cr, sold 2 ingots for {} cr; balance = {} cr",
        bought, sold, wallet.credits
    );

    // 9. Mission: bounty hunt, accepted then completed ───────────────
    let mut board = MissionBoard::new();
    let mut log = MissionLog::new();
    let mission = Mission::new(
        MissionId(7),
        MissionKind::Hunt {
            target_faction: PIRATES,
            count: 1,
        },
        UNION,
        12_500,
    );
    board.post(mission);
    mission_accept(&mut board, &mut log, &rep, PLAYER, MissionId(7))
        .expect("player meets reputation bar");
    println!("[Quest]  accepted: hunt 1 pirate ship for the Union");

    // 10. Combat: a single railgun salvo against a pirate target ─────
    let stats = WeaponStats::railgun();
    let mut cooldown = WeaponCooldown::new();
    assert!(cooldown.try_fire(&stats));
    let mut target_shield = Shield::new(150.0, 0.0, 0.0);
    let mut target_hull = 800.0;
    let (sd, hd) = apply_damage(
        &mut target_shield,
        &mut target_hull,
        DamageType::Kinetic,
        stats.damage,
    );
    println!(
        "[Combat] railgun: shield -{:.0} (down: {}), hull -{:.0} → {:.0}",
        sd,
        target_shield.is_down(),
        hd,
        target_hull
    );

    // 11. Mark mission complete; pay reward + bump reputation ────────
    let mut rep_mut = rep.clone();
    let reward = mission_complete(&mut log, &mut wallet, &mut rep_mut, PLAYER, MissionId(7))
        .expect("mission was accepted");
    println!(
        "[Quest]  completed: +{} cr, player↔union rep = {}",
        reward,
        rep_mut.get(PLAYER, UNION)
    );

    // 11a. Mining: strip-mine an asteroid node ──────────────────────
    let beam = MiningBeam::industrial();
    let mut node = ResourceNode::new(
        MiningNodeId(1),
        mining.center() + glam::DVec3::new(500.0, 0.0, 0.0),
        IRON_ORE,
        40,
    )
    .with_hardness(1.5);
    let mut mined_total = 0u32;
    let ship_pos = mining.center() + glam::DVec3::new(100.0, 0.0, 0.0);
    for _ in 0..30 {
        match mine_tick(&beam, &mut node, ship_pos, &mut inventory, 1.0) {
            MineResult::Extracted(n) => mined_total += n,
            MineResult::Depleted => break,
            _ => break,
        }
    }
    println!(
        "[Mining] stripped {} units of ore, node remaining = {}",
        mined_total, node.units_remaining
    );
    assert!(mined_total > 0);

    // 11b. Base: refinery turns raw ore into ingots ─────────────────
    let mut outpost = Base::new(BaseId(42), "Aurora Depot", mining.id).with_owner(UNION);
    outpost.push_module(BaseModule::new(ModuleKind::Power));
    outpost.push_module(BaseModule::new(ModuleKind::Refinery).with_production(
        ProductionLine::new(
            vec![ItemStack::new(IRON_ORE, 2), ItemStack::new(COAL, 1)],
            vec![ItemStack::new(IRON_INGOT, 1)],
            2.0,
        ),
    ));
    outpost.push_module(BaseModule::new(ModuleKind::Storage));
    outpost.push_module(BaseModule::new(ModuleKind::Market));
    outpost.inventory.add(IRON_ORE, 10).expect("seed ore");
    outpost.inventory.add(COAL, 5).expect("seed coal");
    tick_production(&mut outpost, 6.5); // ~3 cycles
    println!(
        "[Base]   {} (power_balance={}): ore={}, coal={}, ingots={}; market={}, docking_cap={}",
        outpost.name,
        outpost.power_balance(),
        outpost.inventory.count(IRON_ORE),
        outpost.inventory.count(COAL),
        outpost.inventory.count(IRON_INGOT),
        outpost.has_market(),
        outpost.docking_capacity(),
    );
    assert!(outpost.inventory.count(IRON_INGOT) >= 3);

    // 11c. Mesh gen: ship, planet, asteroid meshes from code ────────
    let ship_mesh = build_ship_mesh(&ship);
    let planet_for_mesh = Planet::earth_like(PlanetId(99), frontier.center(), frontier.seed);
    let planet_mesh = build_planet_mesh(Some(&planet_for_mesh), 12);
    let asteroid_mesh = build_asteroid(0xA51E_0001, 12.0, 0.25, 6);
    println!(
        "[Mesh]   ship = {}v/{}i, planet(subdiv=12) = {}v/{}i, asteroid = {}v/{}i",
        ship_mesh.vertices.len(),
        ship_mesh.indices.as_ref().map(|i| i.len()).unwrap_or(0),
        planet_mesh.vertices.len(),
        planet_mesh.indices.as_ref().map(|i| i.len()).unwrap_or(0),
        asteroid_mesh.vertices.len(),
        asteroid_mesh.indices.as_ref().map(|i| i.len()).unwrap_or(0),
    );
    assert!(!ship_mesh.vertices.is_empty());
    assert!(!planet_mesh.vertices.is_empty());
    assert!(!asteroid_mesh.vertices.is_empty());

    // 11cc. Shader gen: WGSL modules for every generated mesh kind ─
    let shaders = all_default_shaders();
    let shader_total_bytes: usize = shaders.iter().map(|(_, s)| s.len()).sum();
    let names: Vec<&str> = shaders.iter().map(|(n, _)| *n).collect();
    println!(
        "[Shader] {} WGSL modules ({} bytes): {:?}",
        shaders.len(),
        shader_total_bytes,
        names
    );
    for (name, src) in &shaders {
        assert!(
            src.contains("@vertex") && src.contains("@fragment"),
            "{name} shader missing entry points"
        );
    }

    // 11d. Audio: queue cues for the actions above ──────────────────
    let mixer = MixerState::new();
    let mut audio = AudioQueue::new();
    audio.push(AudioEvent::play(AudioClip::ThrusterLoop));
    audio.push(AudioEvent::play(AudioClip::WarpEnter).with_volume(0.9));
    audio.push(AudioEvent::play(AudioClip::RailgunFire));
    audio.push(AudioEvent::play(AudioClip::CreditsEarned));
    audio.push(AudioEvent::play(AudioClip::CraftDone).with_pitch(1.2));
    let gain_credits = mixer.effective_gain(AudioClip::CreditsEarned, 1.0);
    println!(
        "[Audio]  queued {} events; credits-earned effective gain = {:.2}",
        audio.len(),
        gain_credits
    );
    let drained = audio.drain();
    assert_eq!(drained.len(), 5);

    // 12. Planet survey: pick a coordinate on Frontier-2's planet ────
    let planet = Planet::earth_like(PlanetId(1), frontier.center(), frontier.seed);
    let biome = classify_at(&planet, 0.5, 1.2);
    let regime_orbital = ce_planet::regime_at_altitude(&planet, 250_000.0);
    println!(
        "[Planet] {} biome at (lat 0.5, lon 1.2) = {:?}; 250 km altitude = {:?}",
        sectors
            .get(frontier.id)
            .and_then(|s| s.name.as_deref())
            .unwrap_or("?"),
        biome,
        regime_orbital
    );
    assert_eq!(regime_orbital, ScaleRegime::InSpace);

    // 13. Save the session and reload it ─────────────────────────────
    let scratch = std::env::temp_dir().join(format!(
        "space_demo_save_{}_{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos(),
    ));
    let manager = SaveManager::new(&scratch);
    let payload = serialize_summary(
        wallet.credits,
        avatar,
        inventory.count(IRON_INGOT),
        rep_mut.get(PLAYER, UNION),
    );
    let meta = SaveMetadata {
        player_name: "Shion".into(),
        sector: sectors
            .get(mining.id)
            .and_then(|s| s.name.clone())
            .unwrap_or_else(|| "?".into()),
        playtime_seconds: 60,
        created_at: 1_700_000_000,
    };
    let bytes = encode(&meta, &payload);
    manager
        .save(SaveSlot(0), &meta, &payload)
        .expect("scratch dir is writable");
    let (loaded_meta, loaded_payload) = manager.load(SaveSlot(0)).expect("we just wrote it");
    let _ = decode(&bytes).expect("envelope round-trip"); // sanity
    println!(
        "[Save]   wrote {} bytes for slot 0 ({}); reloaded {} bytes for {} in {}",
        bytes.len(),
        meta.sector,
        loaded_payload.len(),
        loaded_meta.player_name,
        loaded_meta.sector
    );
    let _ = std::fs::remove_dir_all(&scratch);

    println!("\n=== Done. All {} crates composed cleanly. ===", 16);
}

/// Tiny ad-hoc payload encoder so the demo doesn't pull in serde just
/// to write a few numbers.
fn serialize_summary(credits: i64, avatar: AvatarStats, ingots: u32, rep: i32) -> Vec<u8> {
    let mut out = Vec::new();
    out.extend_from_slice(&credits.to_le_bytes());
    out.extend_from_slice(&avatar.hp.to_le_bytes());
    out.extend_from_slice(&avatar.oxygen.to_le_bytes());
    out.extend_from_slice(&avatar.suit_integrity.to_le_bytes());
    out.extend_from_slice(&avatar.hunger.to_le_bytes());
    out.extend_from_slice(&avatar.thirst.to_le_bytes());
    out.extend_from_slice(&avatar.temperature.to_le_bytes());
    out.extend_from_slice(&avatar.stamina.to_le_bytes());
    out.extend_from_slice(&ingots.to_le_bytes());
    out.extend_from_slice(&rep.to_le_bytes());
    out
}

//! Headless offscreen renderer — writes three PPM files showing the
//! procedural meshes from `ce_mesh_gen`:
//!
//! - `ship.ppm` — a small block ship
//! - `planet.ppm` — an earth-like planet with biome colouring
//! - `asteroid.ppm` — a noise-deformed asteroid
//!
//! CI-safe: pure CPU rasterizer, no window, no GPU driver required.

use std::env;
use std::path::PathBuf;

use ce_math::{IVec3, Mat4, Vec3};
use ce_mesh_gen::{build_asteroid, build_planet_mesh, build_ship_mesh};
use ce_planet::{Planet, PlanetId};
use ce_ship::{Block, BlockKind, BlockMaterial, Facing, ShipBlocks};
use ce_softraster::{render_mesh, save_ppm, Framebuffer};
use ce_space::WorldPos;

const W: u32 = 256;
const H: u32 = 256;

fn main() {
    env_logger::init();

    let out_dir: PathBuf = env::args()
        .nth(1)
        .map(PathBuf::from)
        .unwrap_or_else(|| std::env::temp_dir().join("ge_mu_render_demo"));
    std::fs::create_dir_all(&out_dir).expect("create output dir");
    println!("writing PPM files to {}", out_dir.display());

    render_ship(&out_dir);
    render_planet(&out_dir);
    render_asteroid(&out_dir);
}

fn build_ship() -> ShipBlocks {
    let mut ship = ShipBlocks::new();
    for x in 0..5 {
        ship.insert(
            IVec3::new(x, 0, 0),
            Block::new(BlockKind::Hull, BlockMaterial::Iron),
        );
    }
    for y in 0..2 {
        ship.insert(
            IVec3::new(2, y + 1, 0),
            Block::new(BlockKind::Hull, BlockMaterial::Titanium),
        );
    }
    ship.insert(
        IVec3::new(-1, 0, 0),
        Block::new(BlockKind::Thruster, BlockMaterial::Iron).with_facing(Facing::East),
    );
    ship.insert(
        IVec3::new(5, 0, 0),
        Block::new(BlockKind::Weapon, BlockMaterial::Tungsten).with_facing(Facing::North),
    );
    ship
}

fn render_ship(out_dir: &std::path::Path) {
    let ship = build_ship();
    let mesh = build_ship_mesh(&ship);
    let mut fb = Framebuffer::new(W, H);
    fb.clear([16, 20, 32, 255]);
    // Look at the ship from an off-axis camera.
    let eye = Vec3::new(6.0, 5.0, 9.0);
    let target = Vec3::new(1.5, 0.5, 0.5);
    let vp = view_proj(eye, target);
    let tris = render_mesh(&mesh, vp, &mut fb);
    let path = out_dir.join("ship.ppm");
    save_ppm(&fb, &path).expect("write ship.ppm");
    println!(
        "ship    → {}v/{}i mesh, {} tris rasterised",
        mesh.vertices.len(),
        mesh.indices.as_ref().map(|i| i.len()).unwrap_or(0),
        tris
    );
}

fn render_planet(out_dir: &std::path::Path) {
    let planet = Planet::earth_like(PlanetId(1), WorldPos::ZERO, 42);
    let mesh = build_planet_mesh(Some(&planet), 24);
    let mut fb = Framebuffer::new(W, H);
    fb.clear([4, 6, 14, 255]);
    let eye = Vec3::new(0.0, 0.4, 2.6);
    let target = Vec3::ZERO;
    let vp = view_proj(eye, target);
    let tris = render_mesh(&mesh, vp, &mut fb);
    let path = out_dir.join("planet.ppm");
    save_ppm(&fb, &path).expect("write planet.ppm");
    println!(
        "planet  → {}v/{}i mesh, {} tris rasterised",
        mesh.vertices.len(),
        mesh.indices.as_ref().map(|i| i.len()).unwrap_or(0),
        tris
    );
}

fn render_asteroid(out_dir: &std::path::Path) {
    let mesh = build_asteroid(0xA51E_0007, 1.2, 0.35, 10);
    let mut fb = Framebuffer::new(W, H);
    fb.clear([12, 14, 22, 255]);
    let eye = Vec3::new(0.8, 1.2, 3.0);
    let target = Vec3::ZERO;
    let vp = view_proj(eye, target);
    let tris = render_mesh(&mesh, vp, &mut fb);
    let path = out_dir.join("asteroid.ppm");
    save_ppm(&fb, &path).expect("write asteroid.ppm");
    println!(
        "asteroid→ {}v/{}i mesh, {} tris rasterised",
        mesh.vertices.len(),
        mesh.indices.as_ref().map(|i| i.len()).unwrap_or(0),
        tris
    );
}

fn view_proj(eye: Vec3, target: Vec3) -> Mat4 {
    let up = Vec3::new(0.0, 1.0, 0.0);
    let view = look_at(eye, target, up);
    let proj = perspective_rh(std::f32::consts::FRAC_PI_3, 1.0, 0.1, 100.0);
    proj * view
}

/// Right-handed look-at matching the demo's world convention.
fn look_at(eye: Vec3, target: Vec3, up: Vec3) -> Mat4 {
    let f = (target - eye).normalize();
    let r = f.cross(up).normalize();
    let u = r.cross(f);
    Mat4::from_cols_array_2d(&[
        [r.x, u.x, -f.x, 0.0],
        [r.y, u.y, -f.y, 0.0],
        [r.z, u.z, -f.z, 0.0],
        [-r.dot(eye), -u.dot(eye), f.dot(eye), 1.0],
    ])
}

fn perspective_rh(fov_y: f32, aspect: f32, near: f32, far: f32) -> Mat4 {
    let f = 1.0 / (fov_y * 0.5).tan();
    let nf = 1.0 / (near - far);
    Mat4::from_cols_array_2d(&[
        [f / aspect, 0.0, 0.0, 0.0],
        [0.0, f, 0.0, 0.0],
        [0.0, 0.0, (far + near) * nf, -1.0],
        [0.0, 0.0, 2.0 * far * near * nf, 0.0],
    ])
}

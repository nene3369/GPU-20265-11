//! TAAU upscale demo.
//!
//! Renders a spinning cube at an internal resolution (e.g. 1280×720)
//! with color, depth, and motion vector MRT, then runs `TaauPass`
//! to produce an output-resolution (e.g. 1920×1080) image that is
//! presented to the swapchain.
//!
//! Controls:
//!   U       — toggle upscale on/off (when off, bilinear-upscales raw lowres)
//!   +/-     — adjust sharpness
//!   Esc     — quit
//!
//! Environment variables:
//!   UPSCALE_OUTPUT_W, UPSCALE_OUTPUT_H — override default 1920×1080
//!   UPSCALE_SCALE                      — override default 0.667

use std::sync::Arc;

use ce_math::{Mat4, Vec3};
use ce_render::{RenderGraph, TaauInputs, TaauPass, UpscaleSettings};
use wgpu::util::DeviceExt;
use winit::application::ApplicationHandler;
use winit::event::{ElementState, KeyEvent, WindowEvent};
use winit::event_loop::{ActiveEventLoop, EventLoop};
use winit::keyboard::{Key, NamedKey, SmolStr};
use winit::window::{Window, WindowAttributes, WindowId};

// ---------------------------------------------------------------------------
// Constants & scene data
// ---------------------------------------------------------------------------

const HDR_FORMAT: wgpu::TextureFormat = wgpu::TextureFormat::Rgba16Float;
const MOTION_FORMAT: wgpu::TextureFormat = wgpu::TextureFormat::Rg16Float;
const DEPTH_FORMAT: wgpu::TextureFormat = wgpu::TextureFormat::Depth32Float;

#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct Vertex {
    pos: [f32; 3],
    color: [f32; 3],
}

/// Unit cube, 8 vertices, 36 indices, colored per-face.
fn cube_mesh() -> (Vec<Vertex>, Vec<u16>) {
    // For per-face colors we duplicate vertices — 24 verts total.
    let f = 0.5;
    let faces: [(Vec3, Vec3, Vec3, Vec3, [f32; 3]); 6] = [
        // +X (red)
        (
            Vec3::new(f, -f, -f),
            Vec3::new(f, f, -f),
            Vec3::new(f, f, f),
            Vec3::new(f, -f, f),
            [0.9, 0.3, 0.3],
        ),
        // -X (green)
        (
            Vec3::new(-f, -f, f),
            Vec3::new(-f, f, f),
            Vec3::new(-f, f, -f),
            Vec3::new(-f, -f, -f),
            [0.3, 0.9, 0.3],
        ),
        // +Y (blue)
        (
            Vec3::new(-f, f, -f),
            Vec3::new(-f, f, f),
            Vec3::new(f, f, f),
            Vec3::new(f, f, -f),
            [0.3, 0.3, 0.9],
        ),
        // -Y (yellow)
        (
            Vec3::new(-f, -f, f),
            Vec3::new(-f, -f, -f),
            Vec3::new(f, -f, -f),
            Vec3::new(f, -f, f),
            [0.9, 0.9, 0.3],
        ),
        // +Z (cyan)
        (
            Vec3::new(f, -f, f),
            Vec3::new(f, f, f),
            Vec3::new(-f, f, f),
            Vec3::new(-f, -f, f),
            [0.3, 0.9, 0.9],
        ),
        // -Z (magenta)
        (
            Vec3::new(-f, -f, -f),
            Vec3::new(-f, f, -f),
            Vec3::new(f, f, -f),
            Vec3::new(f, -f, -f),
            [0.9, 0.3, 0.9],
        ),
    ];

    let mut verts = Vec::with_capacity(24);
    let mut idxs = Vec::with_capacity(36);
    for (a, b, c, d, col) in faces {
        let base = verts.len() as u16;
        for p in [a, b, c, d] {
            verts.push(Vertex {
                pos: [p.x, p.y, p.z],
                color: col,
            });
        }
        idxs.extend_from_slice(&[base, base + 1, base + 2, base, base + 2, base + 3]);
    }
    (verts, idxs)
}

// ---------------------------------------------------------------------------
// Uniform layout for scene pass (matches scene_mrt.wgsl)
// ---------------------------------------------------------------------------

#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable, Default)]
struct SceneUniforms {
    cur_mvp_jittered: [[f32; 4]; 4],
    cur_mvp_unjittered: [[f32; 4]; 4],
    prev_mvp_unjittered: [[f32; 4]; 4],
}

// ---------------------------------------------------------------------------
// Present shader (sample history -> swapchain, tonemap)
// ---------------------------------------------------------------------------

const PRESENT_SHADER: &str = r#"
@group(0) @binding(0) var src: texture_2d<f32>;
@group(0) @binding(1) var samp: sampler;

struct VsOut {
    @builtin(position) pos: vec4<f32>,
    @location(0) uv: vec2<f32>,
};

@vertex
fn vs_main(@builtin(vertex_index) vid: u32) -> VsOut {
    var o: VsOut;
    let x = f32((vid << 1u) & 2u);
    let y = f32(vid & 2u);
    o.pos = vec4<f32>(x * 2.0 - 1.0, 1.0 - y * 2.0, 0.0, 1.0);
    o.uv  = vec2<f32>(x, y);
    return o;
}

@fragment
fn fs_main(in: VsOut) -> @location(0) vec4<f32> {
    let c = textureSample(src, samp, in.uv).rgb;
    // Simple Reinhard — inputs are near 0..1 already (demo scene).
    let tone = c / (c + vec3<f32>(1.0));
    return vec4<f32>(tone, 1.0);
}
"#;

// ---------------------------------------------------------------------------
// Lowres render targets (allocated together; recreated on resize)
// ---------------------------------------------------------------------------

struct LowresTargets {
    color: wgpu::Texture,
    color_view: wgpu::TextureView,
    // `depth` and `motion` are kept alive for their TextureViews' sake; wgpu
    // does not retain the parent resource internally, so dropping these would
    // invalidate the views on the next frame.
    #[allow(dead_code)]
    depth: wgpu::Texture,
    depth_view: wgpu::TextureView,
    #[allow(dead_code)]
    motion: wgpu::Texture,
    motion_view: wgpu::TextureView,
}

impl LowresTargets {
    fn new(device: &wgpu::Device, extent: wgpu::Extent3d) -> Self {
        let color = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("lowres_color"),
            size: extent,
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: HDR_FORMAT,
            usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::RENDER_ATTACHMENT,
            view_formats: &[],
        });
        let motion = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("lowres_motion"),
            size: extent,
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: MOTION_FORMAT,
            usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::RENDER_ATTACHMENT,
            view_formats: &[],
        });
        let depth = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("lowres_depth"),
            size: extent,
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: DEPTH_FORMAT,
            usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::RENDER_ATTACHMENT,
            view_formats: &[],
        });
        let color_view = color.create_view(&Default::default());
        let motion_view = motion.create_view(&Default::default());
        let depth_view = depth.create_view(&Default::default());
        Self {
            color,
            color_view,
            depth,
            depth_view,
            motion,
            motion_view,
        }
    }
}

// ---------------------------------------------------------------------------
// GpuState
// ---------------------------------------------------------------------------

struct GpuState {
    surface: wgpu::Surface<'static>,
    device: wgpu::Device,
    queue: wgpu::Queue,
    config: wgpu::SurfaceConfiguration,

    // Scene pass
    scene_pipeline: wgpu::RenderPipeline,
    scene_bgl: wgpu::BindGroupLayout,
    scene_uniform_buf: wgpu::Buffer,
    vertex_buf: wgpu::Buffer,
    index_buf: wgpu::Buffer,
    index_count: u32,

    // Present pass
    present_pipeline: wgpu::RenderPipeline,
    present_bgl: wgpu::BindGroupLayout,
    present_sampler: wgpu::Sampler,

    // Lowres targets + TAAU
    lowres: LowresTargets,
    taau: TaauPass,

    // State
    output_extent: wgpu::Extent3d,
    frame_index: u64,
    prev_mvp_unjittered: Mat4,
    start_time: std::time::Instant,
    upscale_enabled: bool,
}

impl GpuState {
    fn new(window: Arc<Window>) -> Self {
        let size = window.inner_size();

        // --- wgpu setup ---
        let instance = wgpu::Instance::new(&wgpu::InstanceDescriptor {
            backends: wgpu::Backends::all(),
            ..Default::default()
        });

        let surface: wgpu::Surface<'static> =
            instance.create_surface(window.clone()).expect("surface");

        let adapter = pollster::block_on(instance.request_adapter(&wgpu::RequestAdapterOptions {
            power_preference: wgpu::PowerPreference::HighPerformance,
            compatible_surface: Some(&surface),
            force_fallback_adapter: false,
        }))
        .expect("adapter");

        log::info!("GPU: {}", adapter.get_info().name);

        let (device, queue) = pollster::block_on(adapter.request_device(
            &wgpu::DeviceDescriptor {
                label: Some("taau_demo_device"),
                required_features: wgpu::Features::empty(),
                required_limits: wgpu::Limits::default(),
                memory_hints: Default::default(),
            },
            None,
        ))
        .expect("device");

        let caps = surface.get_capabilities(&adapter);
        let surface_format = caps
            .formats
            .iter()
            .find(|f| f.is_srgb())
            .copied()
            .unwrap_or(caps.formats[0]);

        let config = wgpu::SurfaceConfiguration {
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
            format: surface_format,
            width: size.width.max(1),
            height: size.height.max(1),
            present_mode: wgpu::PresentMode::AutoVsync,
            alpha_mode: caps.alpha_modes[0],
            view_formats: vec![],
            desired_maximum_frame_latency: 2,
        };
        surface.configure(&device, &config);

        let output_extent = wgpu::Extent3d {
            width: config.width,
            height: config.height,
            depth_or_array_layers: 1,
        };

        // --- TAAU pass ---
        let scale = std::env::var("UPSCALE_SCALE")
            .ok()
            .and_then(|s| s.parse().ok())
            .unwrap_or(0.667_f32);
        let settings = UpscaleSettings {
            internal_scale: scale,
            sharpness: 0.4,
        };
        let taau = TaauPass::new(&device, HDR_FORMAT, output_extent, settings);
        log::info!(
            "internal_extent = {}x{} (scale={}), output = {}x{}",
            taau.internal_extent().width,
            taau.internal_extent().height,
            scale,
            output_extent.width,
            output_extent.height,
        );

        let lowres = LowresTargets::new(&device, taau.internal_extent());

        // --- Scene mesh ---
        let (verts, idxs) = cube_mesh();
        let vertex_buf = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("cube_vb"),
            contents: bytemuck::cast_slice(&verts),
            usage: wgpu::BufferUsages::VERTEX,
        });
        let index_buf = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("cube_ib"),
            contents: bytemuck::cast_slice(&idxs),
            usage: wgpu::BufferUsages::INDEX,
        });
        let index_count = idxs.len() as u32;

        // --- Scene pipeline ---
        let scene_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("scene_mrt"),
            source: wgpu::ShaderSource::Wgsl(
                include_str!("../../../crates/ce_render/src/shaders/scene_mrt.wgsl").into(),
            ),
        });

        let scene_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("scene_bgl"),
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::VERTEX,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            }],
        });

        let scene_uniform_buf = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("scene_uniform"),
            size: std::mem::size_of::<SceneUniforms>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        let scene_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("scene_pl"),
            bind_group_layouts: &[&scene_bgl],
            push_constant_ranges: &[],
        });

        let scene_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("scene_pipeline"),
            layout: Some(&scene_layout),
            vertex: wgpu::VertexState {
                module: &scene_shader,
                entry_point: Some("vs_main"),
                buffers: &[wgpu::VertexBufferLayout {
                    array_stride: std::mem::size_of::<Vertex>() as u64,
                    step_mode: wgpu::VertexStepMode::Vertex,
                    attributes: &[
                        wgpu::VertexAttribute {
                            format: wgpu::VertexFormat::Float32x3,
                            offset: 0,
                            shader_location: 0,
                        },
                        wgpu::VertexAttribute {
                            format: wgpu::VertexFormat::Float32x3,
                            offset: 12,
                            shader_location: 1,
                        },
                    ],
                }],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &scene_shader,
                entry_point: Some("fs_main"),
                targets: &[
                    Some(wgpu::ColorTargetState {
                        format: HDR_FORMAT,
                        blend: None,
                        write_mask: wgpu::ColorWrites::ALL,
                    }),
                    Some(wgpu::ColorTargetState {
                        format: MOTION_FORMAT,
                        blend: None,
                        write_mask: wgpu::ColorWrites::ALL,
                    }),
                ],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState {
                topology: wgpu::PrimitiveTopology::TriangleList,
                strip_index_format: None,
                front_face: wgpu::FrontFace::Ccw,
                cull_mode: Some(wgpu::Face::Back),
                polygon_mode: wgpu::PolygonMode::Fill,
                unclipped_depth: false,
                conservative: false,
            },
            depth_stencil: Some(wgpu::DepthStencilState {
                format: DEPTH_FORMAT,
                depth_write_enabled: true,
                depth_compare: wgpu::CompareFunction::Less,
                stencil: Default::default(),
                bias: Default::default(),
            }),
            multisample: wgpu::MultisampleState::default(),
            multiview: None,
            cache: None,
        });

        // --- Present pipeline ---
        let present_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("present"),
            source: wgpu::ShaderSource::Wgsl(PRESENT_SHADER.into()),
        });
        let present_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("present_bgl"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Float { filterable: true },
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 1,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                    count: None,
                },
            ],
        });
        let present_sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            label: Some("present_sampler"),
            address_mode_u: wgpu::AddressMode::ClampToEdge,
            address_mode_v: wgpu::AddressMode::ClampToEdge,
            address_mode_w: wgpu::AddressMode::ClampToEdge,
            mag_filter: wgpu::FilterMode::Linear,
            min_filter: wgpu::FilterMode::Linear,
            mipmap_filter: wgpu::FilterMode::Nearest,
            ..Default::default()
        });
        let present_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("present_pl"),
            bind_group_layouts: &[&present_bgl],
            push_constant_ranges: &[],
        });
        let present_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("present_pipeline"),
            layout: Some(&present_layout),
            vertex: wgpu::VertexState {
                module: &present_shader,
                entry_point: Some("vs_main"),
                buffers: &[],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &present_shader,
                entry_point: Some("fs_main"),
                targets: &[Some(wgpu::ColorTargetState {
                    format: surface_format,
                    blend: None,
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState::default(),
            depth_stencil: None,
            multisample: wgpu::MultisampleState::default(),
            multiview: None,
            cache: None,
        });

        // --- Log graph structure (for documentation purposes) ---
        let mut graph = RenderGraph::new();
        let scene = graph.add_pass("scene_mrt");
        graph.set_pass_writes(scene, &["lowres_color", "lowres_depth", "lowres_motion"]);
        let _up = ce_render::add_upscale_pass(&mut graph, settings);
        let present = graph.add_pass("present");
        graph.set_pass_reads(present, &["upscaled_color"]);
        graph.compile().expect("graph compile");
        log::info!(
            "graph execution order: {:?}",
            graph.execution_order().unwrap()
        );

        Self {
            surface,
            device,
            queue,
            config,
            scene_pipeline,
            scene_bgl,
            scene_uniform_buf,
            vertex_buf,
            index_buf,
            index_count,
            present_pipeline,
            present_bgl,
            present_sampler,
            lowres,
            taau,
            output_extent,
            frame_index: 0,
            prev_mvp_unjittered: Mat4::IDENTITY,
            start_time: std::time::Instant::now(),
            upscale_enabled: true,
        }
    }

    fn resize(&mut self, w: u32, h: u32) {
        if w == 0 || h == 0 {
            return;
        }
        self.config.width = w;
        self.config.height = h;
        self.surface.configure(&self.device, &self.config);

        self.output_extent = wgpu::Extent3d {
            width: w,
            height: h,
            depth_or_array_layers: 1,
        };
        self.taau.resize(&self.device, self.output_extent);
        self.lowres = LowresTargets::new(&self.device, self.taau.internal_extent());
        self.prev_mvp_unjittered = Mat4::IDENTITY;
        self.frame_index = 0;
    }

    fn update_and_render(&mut self) -> Result<(), wgpu::SurfaceError> {
        let t = self.start_time.elapsed().as_secs_f32();
        let internal = self.taau.internal_extent();

        // --- Camera & model matrices ---
        let aspect = internal.width as f32 / internal.height as f32;
        let proj = perspective_wgpu(60f32.to_radians(), aspect, 0.1, 100.0);
        let view = look_at_rh(
            Vec3::new(2.5 * (t * 0.4).cos(), 1.2, 2.5 * (t * 0.4).sin()),
            Vec3::ZERO,
            Vec3::Y,
        );
        let model = Mat4::from_rotation_y(t * 0.9) * Mat4::from_rotation_x(t * 0.6);
        let mvp_unjittered = proj * view * model;

        // Jitter applied to projection (classical TAAU pattern):
        // offset principal point by jitter pixels -> constant NDC-XY shift.
        let jitter_px = self.taau.jitter_for_frame(self.frame_index);
        let jx_ndc = 2.0 * jitter_px[0] / internal.width as f32;
        let jy_ndc = 2.0 * jitter_px[1] / internal.height as f32;
        let mut proj_j = proj;
        proj_j.z_axis.x = jx_ndc;
        proj_j.z_axis.y = jy_ndc;
        let mvp_jittered = proj_j * view * model;

        let uniforms = SceneUniforms {
            cur_mvp_jittered: mvp_jittered.to_cols_array_2d(),
            cur_mvp_unjittered: mvp_unjittered.to_cols_array_2d(),
            prev_mvp_unjittered: self.prev_mvp_unjittered.to_cols_array_2d(),
        };
        self.queue
            .write_buffer(&self.scene_uniform_buf, 0, bytemuck::bytes_of(&uniforms));

        let scene_bg = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("scene_bg"),
            layout: &self.scene_bgl,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: self.scene_uniform_buf.as_entire_binding(),
            }],
        });

        // --- Acquire swapchain ---
        let surface_tex = self.surface.get_current_texture()?;
        let surface_view = surface_tex
            .texture
            .create_view(&wgpu::TextureViewDescriptor::default());

        let mut encoder = self
            .device
            .create_command_encoder(&wgpu::CommandEncoderDescriptor {
                label: Some("frame_encoder"),
            });

        // --- 1. Scene pass at low resolution with MRT ---
        {
            let mut rp = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("scene_pass"),
                color_attachments: &[
                    Some(wgpu::RenderPassColorAttachment {
                        view: &self.lowres.color_view,
                        resolve_target: None,
                        ops: wgpu::Operations {
                            load: wgpu::LoadOp::Clear(wgpu::Color {
                                r: 0.03,
                                g: 0.04,
                                b: 0.07,
                                a: 1.0,
                            }),
                            store: wgpu::StoreOp::Store,
                        },
                    }),
                    Some(wgpu::RenderPassColorAttachment {
                        view: &self.lowres.motion_view,
                        resolve_target: None,
                        ops: wgpu::Operations {
                            load: wgpu::LoadOp::Clear(wgpu::Color::TRANSPARENT),
                            store: wgpu::StoreOp::Store,
                        },
                    }),
                ],
                depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                    view: &self.lowres.depth_view,
                    depth_ops: Some(wgpu::Operations {
                        load: wgpu::LoadOp::Clear(1.0),
                        store: wgpu::StoreOp::Store,
                    }),
                    stencil_ops: None,
                }),
                timestamp_writes: None,
                occlusion_query_set: None,
            });
            rp.set_pipeline(&self.scene_pipeline);
            rp.set_bind_group(0, &scene_bg, &[]);
            rp.set_vertex_buffer(0, self.vertex_buf.slice(..));
            rp.set_index_buffer(self.index_buf.slice(..), wgpu::IndexFormat::Uint16);
            rp.draw_indexed(0..self.index_count, 0, 0..1);
        }

        // --- 2. TAAU upscale (or skip to raw lowres) ---
        let source_view = if self.upscale_enabled {
            let inputs = TaauInputs {
                lowres_color_view: &self.lowres.color_view,
                lowres_depth_view: &self.lowres.depth_view,
                lowres_motion_view: &self.lowres.motion_view,
            };
            self.taau.execute(
                &self.device,
                &self.queue,
                &mut encoder,
                self.frame_index,
                &inputs,
            );
            self.taau.output_view(self.frame_index).clone()
        } else {
            self.lowres
                .color
                .create_view(&wgpu::TextureViewDescriptor::default())
        };

        // --- 3. Present ---
        let present_bg = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("present_bg"),
            layout: &self.present_bgl,
            entries: &[
                wgpu::BindGroupEntry {
                    binding: 0,
                    resource: wgpu::BindingResource::TextureView(&source_view),
                },
                wgpu::BindGroupEntry {
                    binding: 1,
                    resource: wgpu::BindingResource::Sampler(&self.present_sampler),
                },
            ],
        });

        {
            let mut rp = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("present_pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &surface_view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color::BLACK),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                timestamp_writes: None,
                occlusion_query_set: None,
            });
            rp.set_pipeline(&self.present_pipeline);
            rp.set_bind_group(0, &present_bg, &[]);
            rp.draw(0..3, 0..1);
        }

        self.queue.submit(std::iter::once(encoder.finish()));
        surface_tex.present();

        self.prev_mvp_unjittered = mvp_unjittered;
        self.frame_index = self.frame_index.wrapping_add(1);
        Ok(())
    }

    fn toggle_upscale(&mut self) {
        self.upscale_enabled = !self.upscale_enabled;
        log::info!(
            "upscale {}",
            if self.upscale_enabled { "ON" } else { "OFF" }
        );
    }

    fn nudge_sharpness(&mut self, delta: f32) {
        let mut s = self.taau.settings();
        s.sharpness = (s.sharpness + delta).clamp(0.0, 1.0);
        log::info!("sharpness = {:.2}", s.sharpness);
        self.taau.set_settings(s);
    }
}

// ---------------------------------------------------------------------------
// Math helpers — RH, Wgpu clip-space ([0,1] depth, Y-down after Mat4*(NDC))
// ---------------------------------------------------------------------------

fn perspective_wgpu(fov_y: f32, aspect: f32, z_near: f32, z_far: f32) -> Mat4 {
    // glam::Mat4::perspective_rh targets z in [0,1], matching wgpu.
    Mat4::perspective_rh(fov_y, aspect, z_near, z_far)
}

fn look_at_rh(eye: Vec3, center: Vec3, up: Vec3) -> Mat4 {
    Mat4::look_at_rh(eye, center, up)
}

// ---------------------------------------------------------------------------
// Application (winit 0.30)
// ---------------------------------------------------------------------------

struct App {
    window: Option<Arc<Window>>,
    gpu: Option<GpuState>,
}

impl App {
    fn new() -> Self {
        Self {
            window: None,
            gpu: None,
        }
    }
}

impl ApplicationHandler for App {
    fn resumed(&mut self, event_loop: &ActiveEventLoop) {
        if self.window.is_some() {
            return;
        }
        let w = std::env::var("UPSCALE_OUTPUT_W")
            .ok()
            .and_then(|s| s.parse().ok())
            .unwrap_or(1920u32);
        let h = std::env::var("UPSCALE_OUTPUT_H")
            .ok()
            .and_then(|s| s.parse().ok())
            .unwrap_or(1080u32);

        let attr = WindowAttributes::default()
            .with_title("TAAU Upscale Demo — U: toggle | +/-: sharpness | Esc: quit")
            .with_inner_size(winit::dpi::PhysicalSize::new(w, h));
        let win = Arc::new(
            event_loop
                .create_window(attr)
                .expect("window creation failed"),
        );
        let gpu = GpuState::new(win.clone());
        self.window = Some(win);
        self.gpu = Some(gpu);
    }

    fn window_event(&mut self, event_loop: &ActiveEventLoop, _id: WindowId, event: WindowEvent) {
        let Some(gpu) = self.gpu.as_mut() else {
            return;
        };
        match event {
            WindowEvent::CloseRequested => event_loop.exit(),
            WindowEvent::Resized(size) => gpu.resize(size.width, size.height),
            WindowEvent::KeyboardInput {
                event:
                    KeyEvent {
                        logical_key,
                        state: ElementState::Pressed,
                        repeat: false,
                        ..
                    },
                ..
            } => match logical_key {
                Key::Named(NamedKey::Escape) => event_loop.exit(),
                Key::Character(c) => {
                    let s: &SmolStr = &c;
                    match s.as_str() {
                        "u" | "U" => gpu.toggle_upscale(),
                        "+" | "=" => gpu.nudge_sharpness(0.05),
                        "-" | "_" => gpu.nudge_sharpness(-0.05),
                        _ => {}
                    }
                }
                _ => {}
            },
            WindowEvent::RedrawRequested => {
                if let Err(e) = gpu.update_and_render() {
                    log::warn!("render error: {e:?}");
                    let size = self.window.as_ref().unwrap().inner_size();
                    gpu.resize(size.width, size.height);
                }
                if let Some(w) = &self.window {
                    w.request_redraw();
                }
            }
            _ => {}
        }
    }
}

fn main() {
    env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("info")).init();
    let event_loop = EventLoop::new().unwrap();
    event_loop.set_control_flow(winit::event_loop::ControlFlow::Poll);
    let mut app = App::new();
    event_loop.run_app(&mut app).unwrap();
}

# ge-mu — Steam 宇宙ゲーム（chemengine ベース）

## プロジェクトの意図

Avorion（ブロック式建造）+ No Man's Sky（プロシージャル惑星探索）+ X シリーズ
（経済・政治）の融合した Steam 販売向け宇宙ゲーム。**完全コード生成主義**：
メッシュ・シェーダ・テクスチャ・サウンド・全部コードから生成。アセットファイル
を持たない。**MCP 不使用**（オフライン完結）。

ターゲット: Windows + Linux/Steam Deck + SteamVR(継続ストレッチ)、10P PvE。

## アーキテクチャ概要

**HGC 5 層**: L0 Laws（ce_laws） / L1 Phenomena（physics, chemistry） /
L2 Intent（ce_ai, ce_diplomacy） / L3 Structure（ce_worldgen, ce_planet,
ce_ship） / L4 Observation（ce_render, ce_hud）。

36 クレートのワークスペース、`Cargo.toml` を見れば全リスト。代表:

| 領域 | 主要クレート |
|---|---|
| 基盤 | `ce_core`, `ce_math`, `ce_ecs`, `ce_app` |
| 座標・空間 | `ce_space` (f64 WorldPos + FloatingOrigin) |
| 船体・飛行 | `ce_ship` (voxel blocks + mass + thrust), `ce_flight` (advance_linear/angular, warp) |
| ワールド | `ce_planet`, `ce_worldgen`, `ce_mesh_gen` |
| レンダ | `ce_render` (wgpu 24, winit 0.30), `ce_shader_gen` (WGSL 生成), `ce_softraster` (CPU + golden test), `ce_hud` (3x5 font + bars + minimap) |
| ゲームプレイ | `ce_gameplay` (avatar/inventory/crafting), `ce_mining`, `ce_economy` |
| ロジック | `ce_combat`, `ce_faction`, `ce_mission`, `ce_diplomacy`, `ce_base`, `ce_save` |
| ネット/AI | `ce_net`, `ce_ai` (consciousness model SMA28) |

**playable demo**: `examples/play_demo/src/main.rs` — windowed wgpu。これが
現状の実プレイ可能な唯一の出口。すべての新機能はここに配線して可視化する。

## 現在のプレイアブル状態（M0-M40）

**操作**:
- WASD: 船体ローカル前後左右 / Q E: 上下 / 矢印: ヨー・ピッチ
- F: 採掘ビーム（範囲内・最近傍ターゲット自動）
- Space: 船首レーザー発射（cooldown 0.5s、laser_turret ステータス）
- K: 交易パネル開閉（ステーション dock 範囲のみ）
- T: 全鉱石売却
- F5: 手動セーブ（`./gemu_save.txt` に書き出す）
- Esc: 自動セーブしてから終了

**世界観（重要）**:
プレイヤーは「もう一つの世界」に入り込んだ訪問者。世界はプレイヤーに関係なく
回り続ける。`WorldClock` は起動時点で既に 1800 秒（30 分）進んでいて、NPC
は経路の途中、市場在庫はドリフト済み、小惑星は既に削れている。NPC は
permadeath、後任は派閥から補充されるが、**派閥の基地（stronghold）を潰せば
その派閥の director は停止**する（基地が rebuild されるまで）。派閥関係は
殺し合いで動的に変化し、時間でゆっくり中立へ減衰する。プレイヤーも NPC も
同じ rep ルールが適用される。セーブは `./gemu_save.txt` に：world_clock /
reputation / player credits・hull・inventory / base hull・destroyed 状態 /
slot spawn_count を永続化。

**シーン（M40 で 3 倍に拡張された単一セクター）**:
- 地球風惑星（中心、scale 3、planet shader）
- 小惑星 4 つ: A FE(-16,3,-4) / B PT(25,-1,-9) / C FE(40,5,6) / D PT(-8,-2,-55)
- 船体（IronBlock + Titanium、6DoF、回転、hull triplanar shader）
- **派閥基地 3 つ（`ce_npc::FactionBase`）**: Protectorate Station(+36z) /
  Union Depot(+30,+1,-18) / Reaver's Nest(0,+2,-55)。それぞれ hull 1500 /
  600 / 800、destroyed 時 director が gated、rebuild 時間は 120/90/75 s
- **4 派閥**: Rōnin / Protectorate / Union / Crimson Fang
- **3 NPC スロット**: Guard（station 周回）/ Miner（asteroid B 採掘）/
  Reaver（hideout〜asteroid D〜遠方を巡回）
- HUD: SPD/POS/FE/PT/CR/TGT/SH/HL + CONTACTS + STRONGHOLDS（基地 hull）+
  LASER 状態 + 死亡オーバーレイ + WORLD AGE 時計
- 3D 採掘ビーム + 共有 projectile ダッシュ群（owner faction 別色）

**完成したループ**: 採掘 → 飛行 → 入港 → 売却 → 残高。戦闘：射撃 → 弾は
敵味方・小惑星・基地に判定 → NPC/base 撃破 → director 補充 or gating。
政治：殺し合いが reputation を動かす（player kill も NPC kill も同ルール、
時間で減衰）。永続化：Esc/F5 でセーブ、起動時に自動ロード。

## 開発コンベンション

- **Rust 1.95.0** をローカルで使う（`cargo +1.95.0 ...`）。CI も同じ stable
- 毎コミット前に必ず:
  - `cargo +1.95.0 fmt --all`
  - `RUSTFLAGS="-D warnings" cargo +1.95.0 clippy --workspace --all-targets -- -D warnings`
  - `cargo +1.95.0 test --workspace`（現状 929+ tests, 全て pass 必須）
- main に直接 push（PR フローは PR #2 マージ後やめた）
- 新クレート追加は `Cargo.toml` の workspace.members + workspace.dependencies 両方更新
- ビジュアル変更は **golden test** で守る（`crates/ce_softraster::assert_golden`、`UPDATE_GOLDENS=1` で baseline 更新）
- ファイル先頭の doc コメントは英語、コミットメッセージも英語、ユーザー対話は日本語

## CI と請求の状況

- `.github/workflows/ci.yml.disabled` にリネームして**CI オフ中**
- 理由: プライベートリポの GitHub Actions 無料枠（2,000 分/月）を使い切り、
  spending limit 未設定のため job が startup で失敗
- 復活手順: `git mv .github/workflows/ci.yml.disabled .github/workflows/ci.yml` &
  Public 化 OR Pro 契約 OR 無料枠リセット待ち。コードは健全（ローカル全緑）

## 直近の到達点（M25-M40）

- M25 HUD バー overlay（screen-space WGSL + alpha blending）
- M26 3x5 ピクセルフォント + 数値ラベル
- M27 船体回転（Quat + advance_angular）+ チェイスカメラ追従
- M28 ミニマップ（船体ローカル俯瞰）
- M29 採掘ループ（mine_tick 配線）
- M30 2 番目の小惑星 + 最近傍ターゲティング
- M31 3D 採掘ビーム（hull pipeline 共有）
- M32 ステーション + マーケット + 売却 UI（初の完全ループ）
- M33 戦闘初期化：`ce_combat::projectile` 追加（Projectile / advance_projectile /
  projectile_hits_sphere、7 tests）、play_demo に Space レーザー + 停止敵艇 +
  shield/hull HUD + 撃破 → 5s respawn を配線
- M34-M36 生きた世界：新クレート `ce_npc`（NpcShip / NpcGoal /
  advance_npc / SectorBudget、20 tests）。play_demo に 4 派閥 +
  reputation matrix + 3 NPC スロット（patrol / miner / pirate）+
  共有 Bolt プール（owner faction 付きで誤射防止、projectile↔asteroid
  判定も）+ プレイヤー死 → station 3s respawn + NPC permadeath →
  director が 8s 後に後任を送る。CONTACTS HUD は全生存 NPC を
  リスト表示（派閥・関係・距離・SH/HL）
- M37 世界時刻と「既に進行中」の種生成：新クレート `ce_worldclock`
  （`WorldClock` + splitmix64 `DeterministicRng`、10 tests）。
  `ce_economy::restock_market_entry` 追加（5 tests）で市場在庫ドリフト。
  play_demo は起動時に `WorldClock` を epoch=1800s で初期化し、市場
  在庫・小惑星残量・NPC 目標状態を同じ seed から決定的にプリドリフト。
  NPC は waypoint 0 に置かれず経路途中に現れ、死後の補充も同じ経路
  ランダムから引く。HUD 右上ミニマップ下に `WORLD AGE HH:MM:SS`。
- M37.5 永続化（最小）：`./gemu_save.txt` text format。Esc または F5 で
  world_clock / reputation / player credits・hull・inventory / base hull・
  destroyed 状態 / slot spawn_count を保存。次回起動時に自動読み込み、
  pre-existing-seed のデフォルトを上書き。NPC 個体の位置は保存せず
  world_clock から再シード（「別の乗員が今のシフトに入っている」設計）。
- M38 動的 reputation：`ce_faction::politics` 追加（9 tests）。
  `apply_kill_delta(rep, killer, victim, observers)` を撃墜ごとに呼び、
  直接マイナス + 第三者の反応（victim の友人は冷え、敵は温まる）。
  `decay_reputation` で毎秒 1 単位ずつ 0 へ減衰、grudge は数分で解ける。
  NPC 同士の殺害も player kill も同ルール。
- M39 派閥基地：`ce_npc::base::FactionBase`（8 tests）。destroyable +
  shield + rebuild timer。`faction_spawning_gated` で全基地 destroyed
  の派閥は director が補充停止。play_demo に Protectorate Station /
  Union Depot / Reaver's Nest を配置、HUD 左の STRONGHOLDS パネルに
  hull / rebuild timer を表示、destroyed 中はメッシュを画面外に退避。
- M40 単一セクター拡張：ポジション 3 倍スケール、小惑星 2 個追加
  （C FE / D PT）、基地 3 個配置、patrol 経路を広げ、minimap range を
  30→80 m に拡張。

## 次のマイルストーン候補

世界側の延長:
- M41 NPC が互いに積荷を奪う / 撃沈後のデブリ回収（Flee ゴール導入、
  Drop / Salvage goal 追加）
- M42 派閥間ミッション自動発生（`ce_mission` × dynamic reputation。
  プレイヤーは受注可能 / 断っても NPC は遂行）
- M43 派閥基地の建設（新規 hideout を敵対派閥が建てる、地理も流動化）
- M44 多セクター＋背景シミュレーション（ここはユーザーが単一セクター
  拡張を選んだので保留）

システム側:
1. 本格 Save/Load（`ce_save` の envelope を使った binary 保存、複数
   スロット、メタデータ）
2. 音響（手続き的 BGM / SFX、`ce_audio`）
3. Steamworks 連携（`ce_steam` 新設）
4. ローカライズ（JP/EN）
5. Vertical Slice（2 時間プレイ通し）→ Early Access 申請

## 命令的な注意

- ユーザーは**計画・創造担当**、AI は**実装担当**。設計の枝分かれは必ず聞く、
  実装詳細は聞かない
- AI は画面が見えない → **ゴールデン画像テスト**で視覚リグレッションを単独検知
- ユーザーは英語が読めない → 出力は日本語、コードコメントとコミットは英語
- フィードバックは「半日で終わるよ」など速度感重視。冗長な計画より動く実装
- `play_demo` で動かないなら作ってない扱い。小さくとも視覚化することを優先

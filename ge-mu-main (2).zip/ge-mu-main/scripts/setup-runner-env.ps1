﻿#Requires -Version 5.1
<#
setup-runner-env.ps1
  NETWORK SERVICE が走らせる runner 向けに system-wide ツールを整備する:
    1) PowerShell Core (pwsh) を winget or MSI でインストール
    2) Rust toolchain を system-wide にコピー (C:\rust, C:\cargo)
    3) Machine 環境変数: CARGO_HOME, RUSTUP_HOME, RUSTC_WRAPPER, SCCACHE_*, VULKAN_SDK, PATH追加
    4) sccache cache dir を NETWORK SERVICE 書き込み可能に
    5) runner service 再起動
#>
$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'

$logDir = "$env:TEMP\ge-mu-runner-setup"
$log = "$logDir\env.log"
function L([string]$m) {
    $line = "{0} {1}" -f (Get-Date -Format 'HH:mm:ss'), $m
    Add-Content $log -Value $line -Encoding UTF8
    Write-Host $line
}

L "=== ENV START ==="
$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
L "admin=$admin"
if (-not $admin) { L "[fatal] not admin"; exit 1 }

# ─────────────────────────────────────────────
# 1. PowerShell Core (pwsh)
# ─────────────────────────────────────────────
L "--- [1] pwsh ---"
$pwshCmd = Get-Command pwsh -ErrorAction SilentlyContinue
if ($pwshCmd) {
    L "[skip] pwsh already: $($pwshCmd.Source)"
} else {
    # winget が利用可能か確認
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if ($winget) {
        L "[winget] installing Microsoft.PowerShell"
        & winget install --id Microsoft.PowerShell --exact --silent --accept-source-agreements --accept-package-agreements 2>&1 | ForEach-Object { L "  $_" }
    } else {
        # MSI 直接インストール
        $pwshUrl = 'https://github.com/PowerShell/PowerShell/releases/download/v7.4.6/PowerShell-7.4.6-win-x64.msi'
        $pwshMsi = "$logDir\pwsh.msi"
        L "[dl] $pwshUrl"
        try {
            Invoke-WebRequest -Uri $pwshUrl -OutFile $pwshMsi -UseBasicParsing -TimeoutSec 300
            L "[install] msiexec /i pwsh.msi /quiet"
            $p = Start-Process -FilePath 'msiexec.exe' -ArgumentList "/i", $pwshMsi, "/quiet", "/norestart", "ADD_PATH=1" -Wait -PassThru
            L "  exit=$($p.ExitCode)"
        } catch { L "[dl-fail] $_" }
    }
    # PATH 再読み込み
    $env:PATH = [Environment]::GetEnvironmentVariable('PATH','Machine') + ';' + [Environment]::GetEnvironmentVariable('PATH','User')
    $pwshCmd = Get-Command pwsh -ErrorAction SilentlyContinue
    if ($pwshCmd) { L "[ok] pwsh installed: $($pwshCmd.Source)" } else { L "[WARN] pwsh still not found - workflow 側で shell: powershell に変える手もある" }
}

# ─────────────────────────────────────────────
# 2. Rust toolchain を system-wide にコピー
# ─────────────────────────────────────────────
L "--- [2] Rust system-wide copy ---"
$srcCargo = 'C:\Users\TOUYA\.cargo'
$srcRustup = 'C:\Users\TOUYA\.rustup'
$dstCargo = 'C:\cargo'
$dstRustup = 'C:\rustup'

if (-not (Test-Path $srcCargo)) {
    L "[fatal] source .cargo missing: $srcCargo"
    exit 1
}

if (Test-Path $dstCargo) { L "[clean] removing existing $dstCargo"; Remove-Item $dstCargo -Recurse -Force -ErrorAction SilentlyContinue }
if (Test-Path $dstRustup) { L "[clean] removing existing $dstRustup"; Remove-Item $dstRustup -Recurse -Force -ErrorAction SilentlyContinue }

L "[copy] $srcCargo -> $dstCargo"
# robocopy: /MIR=mirror, /NFL /NDL = no file list
& robocopy $srcCargo $dstCargo /E /R:1 /W:1 /NFL /NDL /NJH /NJS | Out-Null
L "[copy] $srcRustup -> $dstRustup"
& robocopy $srcRustup $dstRustup /E /R:1 /W:1 /NFL /NDL /NJH /NJS | Out-Null

# NETWORK SERVICE に読み取り権限付与 (既定で Users が読めるはずだが念のため)
$acl = Get-Acl $dstCargo
$rule = New-Object System.Security.AccessControl.FileSystemAccessRule("NT AUTHORITY\NETWORK SERVICE","ReadAndExecute","ContainerInherit,ObjectInherit","None","Allow")
$acl.SetAccessRule($rule)
Set-Acl -Path $dstCargo -AclObject $acl
$acl2 = Get-Acl $dstRustup
$acl2.SetAccessRule($rule)
Set-Acl -Path $dstRustup -AclObject $acl2
L "[ok] ACL: NETWORK SERVICE read/execute"

# ─────────────────────────────────────────────
# 3. Machine env vars
# ─────────────────────────────────────────────
L "--- [3] Machine env vars ---"
[Environment]::SetEnvironmentVariable('CARGO_HOME', $dstCargo, 'Machine')
[Environment]::SetEnvironmentVariable('RUSTUP_HOME', $dstRustup, 'Machine')
[Environment]::SetEnvironmentVariable('RUSTC_WRAPPER', "$dstCargo\bin\sccache.exe", 'Machine')

$vk = Get-ChildItem 'C:\VulkanSDK' -Directory | Sort-Object Name -Descending | Select-Object -First 1
if ($vk) {
    [Environment]::SetEnvironmentVariable('VULKAN_SDK', $vk.FullName, 'Machine')
    L "  VULKAN_SDK=$($vk.FullName)"
}
[Environment]::SetEnvironmentVariable('SCCACHE_DIR', 'C:\sccache-cache', 'Machine')
[Environment]::SetEnvironmentVariable('SCCACHE_CACHE_SIZE', '50G', 'Machine')
[Environment]::SetEnvironmentVariable('WGPU_BACKEND', 'vulkan', 'Machine')

# PATH に C:\cargo\bin, VulkanSDK\Bin, OpenXR loader dir を追加 (Machine)
$mp = [Environment]::GetEnvironmentVariable('PATH','Machine')
$toAdd = @("$dstCargo\bin")
if ($vk) { $toAdd += (Join-Path $vk.FullName 'Bin') }
$xrDll = Get-ChildItem 'C:\openxr-loader' -Filter 'openxr_loader.dll' -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
if ($xrDll) { $toAdd += $xrDll.DirectoryName }
foreach ($a in $toAdd) {
    if ($mp -notlike "*$a*") { $mp = "$mp;$a"; L "  PATH+= $a" }
}
[Environment]::SetEnvironmentVariable('PATH', $mp, 'Machine')

# ─────────────────────────────────────────────
# 4. sccache cache dir に NETWORK SERVICE 書き込み権限
# ─────────────────────────────────────────────
L "--- [4] sccache cache ACL ---"
$sccacheDir = 'C:\sccache-cache'
if (-not (Test-Path $sccacheDir)) { New-Item -ItemType Directory -Path $sccacheDir -Force | Out-Null }
$acl3 = Get-Acl $sccacheDir
$rule3 = New-Object System.Security.AccessControl.FileSystemAccessRule("NT AUTHORITY\NETWORK SERVICE","Modify","ContainerInherit,ObjectInherit","None","Allow")
$acl3.SetAccessRule($rule3)
Set-Acl -Path $sccacheDir -AclObject $acl3
L "[ok] sccache-cache: NETWORK SERVICE modify"

# ─────────────────────────────────────────────
# 5. actions-runner _work に NETWORK SERVICE 書き込み権限 (既に設定されてるが確認)
# ─────────────────────────────────────────────
L "--- [5] runner _work ACL check ---"
$workDir = 'C:\actions-runner\_work'
if (Test-Path $workDir) {
    icacls $workDir /grant "NT AUTHORITY\NETWORK SERVICE:(OI)(CI)M" /T /Q 2>&1 | ForEach-Object { L "  $_" } | Out-Null
}

# ─────────────────────────────────────────────
# 6. runner service 再起動 (新しい env vars を反映)
# ─────────────────────────────────────────────
L "--- [6] service restart ---"
$svc = Get-Service 'actions.runner.*' -ErrorAction SilentlyContinue
if ($svc) {
    L "[service] $($svc.Name) status=$($svc.Status) — restarting"
    Restart-Service $svc.Name -Force
    Start-Sleep -Seconds 5
    $s2 = Get-Service $svc.Name
    L "[service] after restart: $($s2.Status)"
}

# ─────────────────────────────────────────────
# 7. 検証
# ─────────────────────────────────────────────
L "--- [7] verify ---"
$env:CARGO_HOME = $dstCargo
$env:RUSTUP_HOME = $dstRustup
$env:PATH = "$dstCargo\bin;" + $env:PATH
$rustver = & "$dstCargo\bin\cargo.exe" --version 2>&1
L "  cargo: $rustver"
$rustcver = & "$dstCargo\bin\rustup.exe" run 1.95.0 rustc --version 2>&1
L "  rustc(via rustup): $rustcver"
$pwshVer = & pwsh -NoLogo -Command '$PSVersionTable.PSVersion.ToString()' 2>&1
L "  pwsh: $pwshVer"
$sccache = & "$dstCargo\bin\sccache.exe" --version 2>&1
L "  sccache: $sccache"

L "=== ENV END ==="

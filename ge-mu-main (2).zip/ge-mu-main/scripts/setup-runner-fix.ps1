﻿$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
$logDir = "$env:TEMP\ge-mu-runner-setup"
$log = "$logDir\fix.log"
function L($m) {
    $line = "{0} {1}" -f (Get-Date -Format 'HH:mm:ss'), $m
    Add-Content $log $line -Encoding UTF8
    Write-Host $line
}
L "=== FIX START ==="

# 1. pwsh MSI
L "--- [1] pwsh MSI ---"
$msi = "$env:TEMP\pwsh.msi"
if (Test-Path 'C:\Program Files\PowerShell\7\pwsh.exe') {
    L "[skip] pwsh already: C:\Program Files\PowerShell\7\pwsh.exe"
} elseif (Test-Path $msi) {
    L "[install] msiexec /i $msi /quiet ADD_PATH=1"
    $p = Start-Process -FilePath 'msiexec.exe' -ArgumentList '/i', $msi, '/quiet', '/norestart', 'ADD_PATH=1', 'ENABLE_PSREMOTING=0' -Wait -PassThru
    L "  exit=$($p.ExitCode)"
    if (Test-Path 'C:\Program Files\PowerShell\7\pwsh.exe') {
        L "[ok] pwsh installed"
    } else {
        L "[FAIL] pwsh still not found"
    }
}

# 2. OpenXR loader
L "--- [2] OpenXR loader ---"
$xrDir = 'C:\openxr-loader'
if (-not (Test-Path (Join-Path $xrDir 'openxr_loader.dll')) -and -not (Test-Path (Join-Path $xrDir 'x64'))) {
    New-Item -ItemType Directory -Path $xrDir -Force | Out-Null
    $xrNuget = Join-Path $logDir 'openxr.nupkg'
    $urls = @(
        'https://www.nuget.org/api/v2/package/OpenXR.Loader/1.1.41',
        'https://globalcdn.nuget.org/packages/openxr.loader.1.1.41.nupkg'
    )
    foreach ($u in $urls) {
        L "[dl] $u"
        try {
            Invoke-WebRequest -Uri $u -OutFile $xrNuget -UseBasicParsing -TimeoutSec 120
            if ((Get-Item $xrNuget).Length -gt 100KB) { L "  [ok] size=$((Get-Item $xrNuget).Length)"; break }
        } catch { L "  [err] $_" }
    }
    if ((Test-Path $xrNuget) -and (Get-Item $xrNuget).Length -gt 100KB) {
        Expand-Archive -Path $xrNuget -DestinationPath $xrDir -Force
        L "[ok] extracted"
        Get-ChildItem $xrDir -Filter 'openxr_loader.dll' -Recurse | ForEach-Object { L "  found: $($_.FullName)" }
    }
}
$xrDll = Get-ChildItem $xrDir -Filter 'openxr_loader.dll' -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
if ($xrDll) {
    L "[ok] openxr_loader.dll = $($xrDll.FullName)"
    # Add to Machine PATH
    $mp = [Environment]::GetEnvironmentVariable('PATH','Machine')
    if ($mp -notlike "*$($xrDll.DirectoryName)*") {
        [Environment]::SetEnvironmentVariable('PATH', "$mp;$($xrDll.DirectoryName)", 'Machine')
        L "  PATH += $($xrDll.DirectoryName)"
    }
}

# 3. Vulkan vulkaninfo symlink (vulkaninfoSDK.exe → vulkaninfo.exe)
L "--- [3] vulkaninfo alias ---"
$vkBin = 'C:\VulkanSDK\1.3.290.0\Bin'
if (Test-Path "$vkBin\vulkaninfoSDK.exe") {
    if (-not (Test-Path "$vkBin\vulkaninfo.exe")) {
        Copy-Item "$vkBin\vulkaninfoSDK.exe" "$vkBin\vulkaninfo.exe" -Force
        L "[ok] copied vulkaninfoSDK.exe -> vulkaninfo.exe"
    } else {
        L "[skip] vulkaninfo.exe already exists"
    }
}

# 4. Also add pwsh to Machine PATH
L "--- [4] PATH finalize ---"
$mp = [Environment]::GetEnvironmentVariable('PATH','Machine')
$pwshDir = 'C:\Program Files\PowerShell\7'
if ((Test-Path "$pwshDir\pwsh.exe") -and ($mp -notlike "*$pwshDir*")) {
    [Environment]::SetEnvironmentVariable('PATH', "$mp;$pwshDir", 'Machine')
    L "  PATH += $pwshDir"
}

# 5. Restart runner service to pick up new PATH
L "--- [5] service restart ---"
$svc = Get-Service 'actions.runner.*' -ErrorAction SilentlyContinue
if ($svc) {
    Restart-Service $svc.Name -Force
    Start-Sleep -Seconds 5
    $s2 = Get-Service $svc.Name
    L "  service=$($s2.Name) status=$($s2.Status)"
}

# 6. Verify
L "--- [6] verify ---"
L "  pwsh: $(if (Test-Path 'C:\Program Files\PowerShell\7\pwsh.exe') { 'YES' } else { 'NO' })"
L "  openxr_loader.dll: $(if (Get-ChildItem 'C:\openxr-loader' -Filter 'openxr_loader.dll' -Recurse -EA SilentlyContinue) { 'YES' } else { 'NO' })"
L "  vulkaninfo.exe: $(if (Test-Path 'C:\VulkanSDK\1.3.290.0\Bin\vulkaninfo.exe') { 'YES' } else { 'NO' })"
L "  cargo.exe: $(if (Test-Path 'C:\cargo\bin\cargo.exe') { 'YES' } else { 'NO' })"

L "=== FIX END ==="
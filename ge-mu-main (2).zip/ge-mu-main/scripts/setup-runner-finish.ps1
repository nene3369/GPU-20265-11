﻿#Requires -Version 5.1
<#
setup-runner-finish.ps1
  recover 最終段（runner 展開 + 登録 + service化）だけを実行する。
  ExtractToDirectory の3引数オーバーロードが .NET Framework 4.x に存在しないバグを
  Expand-Archive 経由で回避。
#>
[CmdletBinding()]
param(
    [string]$LogDir = (Join-Path $env:TEMP 'ge-mu-runner-setup'),
    [string]$RunnerDir = 'C:\actions-runner',
    [string]$Repo = 'nene3369/ge-mu',
    [string]$RegTokenFile = (Join-Path $env:TEMP 'ge-mu-runner-token.txt')
)
$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'

$log = Join-Path $LogDir 'finish.log'
function L([string]$msg) {
    $line = "{0} {1}" -f (Get-Date -Format 'HH:mm:ss'), $msg
    Add-Content -Path $log -Value $line -Encoding UTF8
    Write-Host $line
}

L "=== FINISH START ==="
L "admin=$(([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator))"

# 1. runner zip 展開
$runnerZip = Join-Path $LogDir 'actions-runner.zip'
if (-not (Test-Path $runnerZip)) {
    L "[fatal] zip not found: $runnerZip"
    exit 1
}
L "[extract] $runnerZip -> $RunnerDir"
if (Test-Path $RunnerDir) {
    Remove-Item $RunnerDir -Recurse -Force -ErrorAction SilentlyContinue
}
New-Item -ItemType Directory -Path $RunnerDir -Force | Out-Null
try {
    Expand-Archive -Path $runnerZip -DestinationPath $RunnerDir -Force
    L "[ok] extracted"
} catch {
    L "[extract-fail] $_"
    exit 1
}

if (-not (Test-Path (Join-Path $RunnerDir 'config.cmd'))) {
    L "[fatal] config.cmd missing after extract"
    Get-ChildItem $RunnerDir -Recurse -Depth 1 | ForEach-Object { L "  $_" }
    exit 1
}
L "[ok] config.cmd present"

# 2. token 読み込み
if (-not (Test-Path $RegTokenFile)) { L "[fatal] token file missing"; exit 1 }
$token = (Get-Content $RegTokenFile -Raw).Trim()
if ($token.Length -lt 16) { L "[fatal] token too short"; exit 1 }
L "[token] len=$($token.Length) (prefix redacted)"

# 3. config.cmd --unattended --runasservice
Push-Location $RunnerDir
$cfgArgs = @(
    '--unattended',
    '--url', "https://github.com/$Repo",
    '--token', $token,
    '--name', "$env:COMPUTERNAME-rtx4060ti",
    '--labels', 'self-hosted,windows,gpu,rtx4060ti,wgpu24,openxr',
    '--work', '_work',
    '--runasservice',
    '--windowslogonaccount', "$env:USERDOMAIN\$env:USERNAME"
)
L "[register] url=https://github.com/$Repo name=$env:COMPUTERNAME-rtx4060ti (token redacted)"
& .\config.cmd @cfgArgs 2>&1 | ForEach-Object {
    $s = $_.ToString()
    # config.cmd が token をエコーしても log に残らないよう redact
    $safe = $s -replace [regex]::Escape($token), '<TOKEN>'
    Add-Content -Path $log -Value ("    " + $safe) -Encoding UTF8
    Write-Host ("    " + $safe)
}
$cfgExit = $LASTEXITCODE
Pop-Location
L "[config exit=$cfgExit]"

# config.cmd の exit code は厳格に検査する。
# 非0で continue すると「登録失敗だが script は exit 0」の偽緑になり、
# 自動化では runner 未登録のままリカバリー成功扱いになる。
if ($cfgExit -ne 0) {
    L "[fatal] config.cmd exited $cfgExit — runner NOT registered"
    exit $cfgExit
}

# 4. service 起動
Start-Sleep -Seconds 3
$svc = Get-Service 'actions.runner.*' -ErrorAction SilentlyContinue
if (-not $svc) {
    # config.cmd が exit 0 を返したのにサービスが存在しない = 異常。fail-fast。
    L "[fatal] config.cmd succeeded but no actions.runner.* service exists"
    Get-Service | Where-Object { $_.Name -like '*runner*' -or $_.Name -like '*action*' } | ForEach-Object {
        L "  candidate: $($_.Name) ($($_.Status))"
    }
    exit 1
}
L "[service] found: $($svc.Name) status=$($svc.Status)"
if ($svc.Status -ne 'Running') {
    try {
        Start-Service $svc.Name -ErrorAction Stop
        Start-Sleep -Seconds 2
        $svc2 = Get-Service $svc.Name
        L "[service] started: status=$($svc2.Status)"
        if ($svc2.Status -ne 'Running') {
            L "[fatal] service $($svc.Name) did not reach Running (status=$($svc2.Status))"
            exit 1
        }
    } catch {
        L "[fatal] Start-Service failed for $($svc.Name): $_"
        exit 1
    }
}

L "=== FINISH END ==="

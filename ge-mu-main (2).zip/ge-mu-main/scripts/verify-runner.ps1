﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Self-hosted runner ヘルスチェック + ge-mu ビルド疎通確認

.DESCRIPTION
    ・Rust / wgpu / Vulkan / OpenXR の動作テスト
    ・cargo build + golden test の最小セット
    ・失敗箇所を色分けで可視化。終了コード 0 = All Green

.EXAMPLE
    pwsh -File .\scripts\verify-runner.ps1 -RepoPath "C:\actions-runner\_work\ge-mu\ge-mu"
#>

[CmdletBinding()]
param(
    [string]$RepoPath = (Join-Path $PSScriptRoot "..")
)

$ErrorActionPreference = "Continue"
$failures = @()
function Check {
    param([string]$Name, [scriptblock]$Body)
    Write-Host "`n[CHK] $Name" -ForegroundColor Cyan
    try {
        & $Body
        if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) { throw "exit $LASTEXITCODE" }
        Write-Host "  OK" -ForegroundColor Green
    } catch {
        Write-Host "  FAIL: $_" -ForegroundColor Red
        $script:failures += $Name
    }
}

Check "rustc 1.95.0"          { $v = rustc --version; if ($v -notmatch "1\.95\.0") { throw $v } else { $v } }
Check "cargo"                  { cargo --version }
Check "MSVC linker (link.exe)" { where.exe link.exe | Select-Object -First 1 }
Check "clang (bindgen)"        { clang --version | Select-Object -First 1 }
Check "cmake"                  { cmake --version | Select-Object -First 1 }
Check "git"                    { git --version }
Check "sccache"                { sccache --version }
Check "Vulkan SDK"             { & "$env:VULKAN_SDK\Bin\vulkaninfo.exe" --summary | Select-Object -First 6 }
Check "NVIDIA driver"          { & "C:\Windows\System32\nvidia-smi.exe" --query-gpu=name,driver_version --format=csv,noheader }
Check "Runner service running" {
    $svc = Get-Service -Name "actions.runner.*" -ErrorAction Stop | Select-Object -First 1
    if ($svc.Status -ne "Running") { throw "status=$($svc.Status)" } else { $svc.Name }
}

if (Test-Path (Join-Path $RepoPath "Cargo.toml")) {
    Push-Location $RepoPath
    try {
        Check "cargo fmt --check"       { cargo fmt --all -- --check }
        Check "cargo check (workspace)" { cargo check --workspace --all-targets }
        Check "golden: ce_softraster"   { cargo test -p ce_softraster --tests --no-fail-fast }
        Check "golden: ce_hud"          { cargo test -p ce_hud --tests --no-fail-fast }
    } finally { Pop-Location }
} else {
    Write-Host "`n[SKIP] ge-mu ソースチェック - RepoPath=$RepoPath に Cargo.toml 無し" -ForegroundColor Yellow
}

Write-Host "`n====== 結果 ======" -ForegroundColor Cyan
if ($failures.Count -eq 0) {
    Write-Host "ALL GREEN - runner は本番投入可能" -ForegroundColor Green
    exit 0
} else {
    Write-Host "FAILURES:" -ForegroundColor Red
    $failures | ForEach-Object { Write-Host "  - $_" -ForegroundColor Red }
    exit 1
}

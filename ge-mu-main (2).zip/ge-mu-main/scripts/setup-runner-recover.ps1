﻿#Requires -Version 5.1
<#
setup-runner-recover.ps1
  setup-runner.ps1 が cargo install (line 189) で早期終了した状況からの復旧スクリプト。
  $ErrorActionPreference = 'Continue' で native の stderr 由来 NativeCommandError を黙殺する。
  詳細ログは $LogDir\recover.log に追記され、mcp__Windows-MCP__PowerShell 側から tail できる。
#>
[CmdletBinding()]
param(
    [string]$LogDir = (Join-Path $env:TEMP 'ge-mu-runner-setup'),
    [string]$RunnerDir = 'C:\actions-runner',
    [string]$XrLoaderDir = 'C:\openxr-loader',
    [string]$Repo = 'nene3369/ge-mu',
    [string]$RegTokenFile = (Join-Path $env:TEMP 'ge-mu-runner-token.txt'),
    # CI での「偽緑」を防ぐため、デフォルトで critical phase の失敗時に exit 1。
    # 対話的な復旧で最後まで走らせたい時は -AllowPartialSuccess を付ける。
    [switch]$AllowPartialSuccess
)

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
$VerbosePreference = 'Continue'

New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
$log = Join-Path $LogDir 'recover.log'
$state = Join-Path $LogDir 'recover.state.json'

function L([string]$msg) {
    $line = "{0} {1}" -f (Get-Date -Format 'HH:mm:ss'), $msg
    Add-Content -Path $log -Value $line -Encoding UTF8
    Write-Host $line
}
function SetState([string]$k, $v) {
    $obj = if (Test-Path $state) { Get-Content $state -Raw | ConvertFrom-Json } else { [pscustomobject]@{} }
    $obj | Add-Member -NotePropertyName $k -NotePropertyValue $v -Force
    $obj | ConvertTo-Json -Compress | Set-Content -Path $state -Encoding UTF8
}

# PS 5.1 (.NET Framework 4.x) で安全に ZIP を展開する。
# ZipFile::ExtractToDirectory(src, dst, overwrite:bool) は .NET Core 3.0+/Std 2.1 以降の
# 3-arg オーバーロードなので Windows PowerShell 5.1 では例外になる。
# Expand-Archive -Force は PS 5.0+ の組込コマンドで、.NET Framework でも動作する。
function Expand-ZipSafe {
    param(
        [Parameter(Mandatory)][string]$Zip,
        [Parameter(Mandatory)][string]$Destination
    )
    if (-not (Test-Path $Zip)) { throw "Expand-ZipSafe: zip not found: $Zip" }
    New-Item -ItemType Directory -Path $Destination -Force | Out-Null
    Expand-Archive -Path $Zip -DestinationPath $Destination -Force -ErrorAction Stop
}

# critical phase 失敗時の終了ハンドラ
function Fail([string]$msg, [int]$code = 1) {
    L "[FATAL] $msg"
    SetState 'fatal' $msg
    if ($AllowPartialSuccess) {
        L "[FATAL-ignored] -AllowPartialSuccess specified, continuing"
        return
    }
    L "=== RECOVER ABORTED ==="
    exit $code
}

L "=== RECOVER START ==="
L "user=$env:USERNAME admin=$(([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator))"

# ─────────────────────────────────────────────
# 1. cargo subcommands（最低限 nextest／残りはベストエフォート）
# ─────────────────────────────────────────────
L "--- [1] cargo subcommands ---"
$env:PATH = "$env:USERPROFILE\.cargo\bin;$env:PATH"

$cargoCrates = @('cargo-nextest', 'cargo-hack', 'cargo-deny', 'cargo-about', 'sccache')
foreach ($c in $cargoCrates) {
    $binName = if ($c -eq 'sccache') { 'sccache.exe' } else { ($c + '.exe') }
    $binPath = Join-Path "$env:USERPROFILE\.cargo\bin" $binName
    if (Test-Path $binPath) {
        L "  [skip] $c (already installed)"
        continue
    }
    L "  [install] $c ..."
    $out = & cargo install --locked $c 2>&1 | Out-String
    if ($LASTEXITCODE -eq 0) {
        L "  [ok] $c"
    } else {
        L "  [fail $LASTEXITCODE] $c -- trying without --locked"
        $out2 = & cargo install $c 2>&1 | Out-String
        if ($LASTEXITCODE -eq 0) { L "  [ok-nolock] $c" } else { L "  [FAIL] $c :: $($out2 -split "`n" | Select-Object -Last 5 | Out-String)" }
    }
}
SetState 'phase1_cargo' 'done'

# ─────────────────────────────────────────────
# 2. Vulkan SDK
# ─────────────────────────────────────────────
L "--- [2] Vulkan SDK ---"
$vkExisting = Get-ChildItem 'C:\VulkanSDK' -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
if ($vkExisting) {
    L "  [skip] VulkanSDK exists: $($vkExisting.FullName)"
} else {
    $vkUrl = 'https://sdk.lunarg.com/sdk/download/1.3.290.0/windows/VulkanSDK-1.3.290.0-Installer.exe'
    $vkInst = Join-Path $LogDir 'VulkanSDK-Installer.exe'
    if (-not (Test-Path $vkInst)) {
        L "  [dl] $vkUrl"
        try { Invoke-WebRequest -Uri $vkUrl -OutFile $vkInst -UseBasicParsing -TimeoutSec 900 } catch { L "  [dl-fail] $_" }
    }
    if (Test-Path $vkInst) {
        L "  [install] silent (needs admin elevation)"
        $p = Start-Process -FilePath $vkInst -ArgumentList '--accept-licenses','--default-answer','--confirm-command','install' -Wait -PassThru
        L "  [installer exit=$($p.ExitCode)]"
    } else {
        L "  [SKIP] installer missing"
    }
}
$vk = Get-ChildItem 'C:\VulkanSDK' -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
if ($vk) {
    [Environment]::SetEnvironmentVariable('VULKAN_SDK', $vk.FullName, 'Machine')
    $env:VULKAN_SDK = $vk.FullName
    $binPath = Join-Path $vk.FullName 'Bin'
    $userPath = [Environment]::GetEnvironmentVariable('PATH', 'User')
    if ($userPath -notlike "*$binPath*") {
        [Environment]::SetEnvironmentVariable('PATH', "$userPath;$binPath", 'User')
    }
    L "  [ok] VULKAN_SDK=$($vk.FullName)"
    SetState 'phase2_vulkan' $vk.FullName
} else {
    L "  [FAIL] Vulkan not installed"
    SetState 'phase2_vulkan' 'FAIL'
}

# ─────────────────────────────────────────────
# 3. OpenXR loader
# ─────────────────────────────────────────────
L "--- [3] OpenXR loader ---"
$xrLoaderDll = Join-Path $XrLoaderDir 'openxr_loader.dll'
if (-not (Test-Path $xrLoaderDll)) {
    New-Item -ItemType Directory -Path $XrLoaderDir -Force | Out-Null
    $xrVer = '1.1.41'
    $xrZip = Join-Path $LogDir "openxr_loader.zip"
    $urls = @(
        "https://github.com/KhronosGroup/OpenXR-SDK-Source/releases/download/release-$xrVer/openxr_loader_windows-$xrVer.zip",
        "https://github.com/KhronosGroup/OpenXR-SDK/releases/download/release-$xrVer/openxr_loader_windows-$xrVer.zip"
    )
    $dlOk = $false
    foreach ($u in $urls) {
        L "  [dl] $u"
        try { Invoke-WebRequest -Uri $u -OutFile $xrZip -UseBasicParsing -TimeoutSec 300; if ((Get-Item $xrZip).Length -gt 1000) { $dlOk=$true; break } } catch { L "  [dl-fail] $_" }
    }
    if ($dlOk) {
        try {
            Expand-ZipSafe -Zip $xrZip -Destination $XrLoaderDir
            L "  [ok] extracted to $XrLoaderDir"
        } catch {
            # OpenXR は SteamVR loader で代替可能なので non-fatal。
            L "  [WARN] OpenXR extract failed: $($_.Exception.Message)"
        }
    } else {
        L "  [WARN] OpenXR DL failed (SteamVR loaderで代替可)"
    }
}
$foundXr = Get-ChildItem -Path $XrLoaderDir -Filter 'openxr_loader.dll' -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
if ($foundXr) {
    $userPath = [Environment]::GetEnvironmentVariable('PATH', 'User')
    if ($userPath -notlike "*$($foundXr.DirectoryName)*") {
        [Environment]::SetEnvironmentVariable('PATH', "$userPath;$($foundXr.DirectoryName)", 'User')
    }
    L "  [ok] openxr_loader.dll = $($foundXr.FullName)"
    SetState 'phase3_openxr' $foundXr.FullName
} else {
    SetState 'phase3_openxr' 'NOT_FOUND'
}

# ─────────────────────────────────────────────
# 4. sccache global config
# ─────────────────────────────────────────────
L "--- [4] sccache config ---"
$sc = Get-Command sccache -ErrorAction SilentlyContinue
if ($sc) {
    $sccacheDir = 'C:\sccache-cache'
    New-Item -ItemType Directory -Path $sccacheDir -Force | Out-Null
    [Environment]::SetEnvironmentVariable('SCCACHE_DIR', $sccacheDir, 'Machine')
    [Environment]::SetEnvironmentVariable('SCCACHE_CACHE_SIZE', '50G', 'Machine')
    [Environment]::SetEnvironmentVariable('RUSTC_WRAPPER', 'sccache', 'Machine')
    L "  [ok] sccache=$($sc.Source) dir=$sccacheDir size=50G"
    SetState 'phase4_sccache' $sc.Source
} else {
    L "  [SKIP] sccache not installed"
    SetState 'phase4_sccache' 'MISSING'
}

# ─────────────────────────────────────────────
# 5. actions-runner 配置
# ─────────────────────────────────────────────
L "--- [5] actions-runner ---"
if (-not (Test-Path (Join-Path $RunnerDir 'config.cmd'))) {
    $runnerVer = '2.329.0'
    $runnerZip = Join-Path $LogDir "actions-runner.zip"
    if (-not (Test-Path $runnerZip)) {
        $u = "https://github.com/actions/runner/releases/download/v$runnerVer/actions-runner-win-x64-$runnerVer.zip"
        L "  [dl] $u"
        try { Invoke-WebRequest -Uri $u -OutFile $runnerZip -UseBasicParsing -TimeoutSec 600 } catch { L "  [dl-fail] $_" }
    }
    if (Test-Path $runnerZip) {
        New-Item -ItemType Directory -Path $RunnerDir -Force | Out-Null
        try {
            Expand-ZipSafe -Zip $runnerZip -Destination $RunnerDir
            L "  [ok] extracted to $RunnerDir"
        } catch {
            Fail "runner zip extract failed: $($_.Exception.Message)"
        }
    } else {
        Fail "runner zip not present (download failed or blocked)"
    }
}
$hasCfg = Test-Path (Join-Path $RunnerDir 'config.cmd')
SetState 'phase5_runner_placed' $hasCfg
if (-not $hasCfg) {
    # config.cmd が無い = runner 本体が未配置。Phase 6 に進んでも何もできない。
    # CI では「偽緑」を避けるため明示的に abort する。
    Fail "config.cmd not found under $RunnerDir after phase 5"
}

# ─────────────────────────────────────────────
# 6. runner register + service install
#   - config.cmd の exit code は厳格に検査する。非0で abort (CI の偽緑防止)。
#   - 登録成功後もサービスが生成されなかった場合は fail。
#   - 対話復旧で token 未配置のまま手動で進めたい場合は -AllowPartialSuccess。
# ─────────────────────────────────────────────
L "--- [6] runner register + service ---"
$svc = Get-Service 'actions.runner.*' -ErrorAction SilentlyContinue
if ($svc) {
    L "  [skip] service exists: $($svc.Name) status=$($svc.Status)"
    SetState 'phase6_runner_registered' $svc.Name
}
elseif (-not $hasCfg) {
    # phase 5 で Fail 済みだが防御的に二重チェック
    Fail "phase 6 unreachable: config.cmd missing"
}
elseif (-not (Test-Path $RegTokenFile)) {
    # token file 無しは「未設定」なので CI では fail 扱い、対話では -AllowPartialSuccess で続行。
    Fail "registration-token file missing: $RegTokenFile (要: gh api repos/$Repo/actions/runners/registration-token → $RegTokenFile)"
}
else {
    $token = (Get-Content $RegTokenFile -Raw).Trim()
    if ($token.Length -lt 16) {
        Fail "registration token too short (len=$($token.Length)) — file may be corrupted or empty"
    }
    else {
        L "  [register] repo=$Repo (token len=$($token.Length), redacted)"
        Push-Location $RunnerDir
        $cfgArgs = @(
            '--unattended',
            '--url', "https://github.com/$Repo",
            '--token', $token,
            '--name', "$env:COMPUTERNAME-rtx4060ti",
            '--labels', 'self-hosted,windows,gpu,rtx4060ti,wgpu24,openxr',
            '--work', '_work',
            '--runasservice',
            '--replace'
        )
        # token をログに残さないために出力を redact しながら流す
        & .\config.cmd @cfgArgs 2>&1 | ForEach-Object {
            $s = $_.ToString()
            $safe = $s -replace [regex]::Escape($token), '<TOKEN>'
            Add-Content -Path (Join-Path $LogDir 'runner-config.log') -Value $safe -Encoding UTF8
            L "    $safe"
        }
        $cfgExit = $LASTEXITCODE
        Pop-Location
        L "  [config exit=$cfgExit]"

        if ($cfgExit -ne 0) {
            # ここで abort しないと「config.cmd が失敗しても recover 全体が exit 0」になり、
            # CI 自動化では runner 未登録のまま偽緑 (fake green) のリカバリーランが成立する。
            Fail "config.cmd exited $cfgExit — runner NOT registered"
        }

        Start-Sleep -Seconds 3
        $svc2 = Get-Service 'actions.runner.*' -ErrorAction SilentlyContinue
        if (-not $svc2) {
            Fail "config.cmd reported success (exit 0) but no actions.runner.* service was created"
        }
        try {
            Start-Service $svc2.Name -ErrorAction Stop
        } catch {
            Fail "Start-Service failed for $($svc2.Name): $($_.Exception.Message)"
        }
        Start-Sleep -Seconds 2
        $svc3 = Get-Service $svc2.Name
        if ($svc3.Status -ne 'Running') {
            Fail "service $($svc2.Name) did not reach Running state (status=$($svc3.Status))"
        }
        SetState 'phase6_runner_registered' $svc2.Name
        L "  [ok] service started: $($svc2.Name) status=$($svc3.Status)"
    }
}

L "=== RECOVER END ==="

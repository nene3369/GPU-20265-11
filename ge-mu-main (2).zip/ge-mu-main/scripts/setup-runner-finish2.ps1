#Requires -Version 5.1
<#
setup-runner-finish2.ps1
  --windowslogonaccount を外して LocalSystem/NetworkService で service 化し直す。
  既に registered / .runner 書き込み済みの状態から --replace で再構成する。

SECURITY (v2):
  - PAT はソースに書かない。env:GH_PAT もしくは -PAT 引数から取る。
  - ランナー削除は「このマシンに紐づく名前」に限定する。
    既存の別マシンの runner を誤って巻き添えにしないため。
#>
[CmdletBinding()]
param(
    [string]$LogDir          = (Join-Path $env:TEMP 'ge-mu-runner-setup'),
    [string]$RunnerDir       = 'C:\actions-runner',
    [string]$Repo            = 'nene3369/ge-mu',
    # PAT はデフォルト値を持たせない。環境変数 GH_PAT から取る。
    [string]$PAT             = $env:GH_PAT,
    # このマシンを識別する runner 名プレフィクス。
    # 削除ループはこの prefix に一致するものだけを対象にする。
    [string]$RunnerNamePrefix = "$env:COMPUTERNAME",
    # 削除対象を事前に確認したい場合 -WhatIfDeletes を渡す (実際には削除しない)。
    [switch]$WhatIfDeletes
)
$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'

if (-not $PAT) {
    Write-Error "PAT is empty. Set `$env:GH_PAT or pass -PAT '<token>'. Never hardcode."
    exit 2
}
if (-not $RunnerNamePrefix) {
    Write-Error "RunnerNamePrefix is empty. Cannot safely scope deletions."
    exit 2
}

if (-not (Test-Path $LogDir)) {
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
}
$log = Join-Path $LogDir 'finish2.log'
function L([string]$msg) {
    $line = "{0} {1}" -f (Get-Date -Format 'HH:mm:ss'), $msg
    Add-Content -Path $log -Value $line -Encoding UTF8
    Write-Host $line
}

L "=== FINISH2 START ==="
L "RunnerNamePrefix='$RunnerNamePrefix' Repo='$Repo' WhatIfDeletes=$WhatIfDeletes"
$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
L "admin=$admin cwd=$(Get-Location)"
if (-not $admin) { L "[fatal] not admin"; exit 1 }

# Step 1: 残存 runner を API で削除 — ただし self (COMPUTERNAME prefix 一致) のみ
$h = @{ Authorization = "token $PAT"; Accept = 'application/vnd.github+json'; 'X-GitHub-Api-Version' = '2022-11-28' }
try {
    $rs = Invoke-RestMethod -Uri "https://api.github.com/repos/$Repo/actions/runners" -Headers $h -Method Get
    L "[api] existing runners total=$($rs.total_count)"
    foreach ($r in $rs.runners) {
        # 安全ガード: 他マシン名の runner は絶対に触らない。
        if ($r.name -notlike "$RunnerNamePrefix*") {
            L "  -> SKIP runner id=$($r.id) name=$($r.name) (prefix '$RunnerNamePrefix' mismatch)"
            continue
        }
        if ($WhatIfDeletes) {
            L "  -> [WhatIf] would delete runner id=$($r.id) name=$($r.name)"
            continue
        }
        L "  -> delete runner id=$($r.id) name=$($r.name)"
        try {
            Invoke-RestMethod -Uri "https://api.github.com/repos/$Repo/actions/runners/$($r.id)" -Headers $h -Method Delete | Out-Null
            L "     deleted"
        } catch { L "     delete-err: $_" }
    }
} catch { L "[api-err] $_" }

# Step 2: ローカルの .runner / .credentials を掃除
$files = @('.runner','.credentials','.credentials_rsaparams','.service')
Push-Location $RunnerDir
foreach ($f in $files) {
    if (Test-Path $f) {
        Remove-Item $f -Force -ErrorAction SilentlyContinue
        L "[clean] removed $f"
    }
}
Pop-Location

# Step 3: 新しい registration token
try {
    $tok = Invoke-RestMethod -Uri "https://api.github.com/repos/$Repo/actions/runners/registration-token" -Headers $h -Method Post
    $token = $tok.token
    L "[token] len=$($token.Length) expires=$($tok.expires_at)"
} catch {
    L "[fatal] can't get fresh token: $_"
    exit 1
}

# Step 4: config.cmd（--windowslogonaccount 外す → LocalSystem/NetworkService で installed）
Push-Location $RunnerDir
$runnerName = "$env:COMPUTERNAME-rtx4060ti"
$cfgArgs = @(
    '--unattended',
    '--url', "https://github.com/$Repo",
    '--token', $token,
    '--name', $runnerName,
    '--labels', 'self-hosted,windows,gpu,rtx4060ti,wgpu24,openxr',
    '--work', '_work',
    '--runasservice',
    '--replace'
)
# ログに token を生で書き出さない: 置換表示のみ
L "[register] name=$runnerName url=https://github.com/$Repo (token redacted, len=$($token.Length))"
& .\config.cmd @cfgArgs 2>&1 | ForEach-Object {
    $s = $_.ToString()
    # ログファイル側でも token が流れないように念のため redact
    $safe = $s -replace [regex]::Escape($token), '<TOKEN>'
    Add-Content -Path $log -Value ("    " + $safe) -Encoding UTF8
    Write-Host ("    " + $safe)
}
$cfgExit = $LASTEXITCODE
Pop-Location
L "[config exit=$cfgExit]"

# config.cmd の exit code を厳格チェック。
# 非0で終了せずに続けると「登録失敗だが recover は exit 0」の偽緑を生む。
if ($cfgExit -ne 0) {
    L "[fatal] config.cmd exited $cfgExit — runner NOT registered"
    exit $cfgExit
}

# Step 5: サービス確認＋起動
Start-Sleep -Seconds 3
$svc = Get-Service 'actions.runner.*' -ErrorAction SilentlyContinue
if (-not $svc) {
    # config.cmd が exit 0 なのに service が無い = 異常。黙殺すると偽緑。
    L "[fatal] config.cmd reported success but no actions.runner.* service exists"
    exit 1
}
L "[service] $($svc.Name) status=$($svc.Status)"
if ($svc.Status -ne 'Running') {
    try {
        Start-Service $svc.Name -ErrorAction Stop
        Start-Sleep -Seconds 3
        $s2 = Get-Service $svc.Name
        L "[service] after start: status=$($s2.Status)"
        if ($s2.Status -ne 'Running') {
            L "[fatal] service $($svc.Name) did not reach Running (status=$($s2.Status))"
            exit 1
        }
    } catch {
        L "[fatal] Start-Service failed for $($svc.Name): $_"
        exit 1
    }
}

# Step 6: GitHub 側の runner 状態 (全件は参照のみ、破壊操作しない)
try {
    $rs = Invoke-RestMethod -Uri "https://api.github.com/repos/$Repo/actions/runners" -Headers $h -Method Get
    foreach ($r in $rs.runners) {
        $mine = if ($r.name -like "$RunnerNamePrefix*") { '*' } else { ' ' }
        L "[github] $mine id=$($r.id) name=$($r.name) status=$($r.status) busy=$($r.busy) labels=$(($r.labels.name) -join ',')"
    }
} catch { L "[api-err] $_" }

L "=== FINISH2 END ==="

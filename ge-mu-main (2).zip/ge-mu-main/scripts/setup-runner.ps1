﻿#Requires -Version 5.1
#Requires -RunAsAdministrator
<#
.SYNOPSIS
    ge-mu 自宅 GitHub Actions Self-Hosted Runner 一括セットアップ
    (Windows 11 + RTX 4060 Ti + Rust 1.95.0 + wgpu24 + OpenXR + Golden Test)

.DESCRIPTION
    Idempotent セットアップ。再実行しても壊れない設計。

    実行順:
      0. 環境検査 (Admin / Windows / GPU)
      1. Windows 長いパス有効化
      2. 基盤パッケージ (winget) : VS2022 Build Tools, Git, CMake, LLVM, 7zip, Python, Node, NSIS
      3. Rust 1.95.0 (rustup)
      4. wgpu 向け Vulkan SDK (LunarG)
      5. GPU/VR ランタイム検査 (nvidia-smi / OpenXR)
      6. sccache + cargo config (ビルド高速化)
      7. GitHub Actions Runner v2.329.0 を C:\actions-runner に配置
      8. Runner 登録 + Windows サービス化
      9. 最終ヘルスチェック

.PARAMETER GitHubOwner
    GitHub organization またはユーザー名 (例: howitzer-gun212)

.PARAMETER GitHubRepo
    リポジトリ名 (例: ge-mu)

.PARAMETER RegistrationToken
    GitHub の Settings > Actions > Runners > New self-hosted runner で取得する一回限りトークン

.PARAMETER RunnerLabels
    カンマ区切りラベル。既定は RTX4060Ti/wgpu/vr/golden を表現

.PARAMETER RunnerName
    Runner 名。既定はホスト名

.PARAMETER SkipRunnerRegister
    ツール類だけインストールし、Runner 登録はスキップ

.EXAMPLE
    .\setup-runner.ps1 -GitHubOwner "howitzer-gun212" -GitHubRepo "ge-mu" -RegistrationToken "AXXXXXXXXXXXXXXXX"

.NOTES
    Project : ge-mu (Steam 販売用 宇宙生成ゲーム)
    Targets : windows-latest self-hosted runner with NVIDIA GPU
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)] [string]  $GitHubOwner       = "howitzer-gun212",
    [Parameter(Mandatory = $false)] [string]  $GitHubRepo        = "ge-mu",
    [Parameter(Mandatory = $false)] [string]  $RegistrationToken = "",
    # NOTE: self-hosted/Windows/X64 は config.cmd が既定ラベルとして自動付与する。
    # ここでは重複を避け、ge-mu 固有のラベルだけ指定する。
    [Parameter(Mandatory = $false)] [string]  $RunnerLabels      = "gpu,nvidia,cuda,rtx4060ti,vulkan,wgpu,vr,openxr,golden",
    [Parameter(Mandatory = $false)] [string]  $RunnerName        = $env:COMPUTERNAME,
    [Parameter(Mandatory = $false)] [string]  $RunnerRoot        = "C:\actions-runner",
    [Parameter(Mandatory = $false)] [string]  $RunnerVersion     = "2.329.0",
    [Parameter(Mandatory = $false)] [string]  $RustToolchain     = "1.95.0",
    [Parameter(Mandatory = $false)] [switch]  $SkipRunnerRegister
)

# ──────────────────────────────────────────────────────────
# 0. 環境 & ヘルパ
# ──────────────────────────────────────────────────────────
$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Write-Step    ($m) { Write-Host "`n==> $m" -ForegroundColor Cyan }
function Write-Ok      ($m) { Write-Host "  OK  $m" -ForegroundColor Green }
function Write-Warn    ($m) { Write-Host "  !!  $m" -ForegroundColor Yellow }
function Write-Fail    ($m) { Write-Host "  XX  $m" -ForegroundColor Red }

function Test-Admin {
    $p = [Security.Principal.WindowsPrincipal]::new(
            [Security.Principal.WindowsIdentity]::GetCurrent())
    $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Invoke-Winget {
    param([string]$Id, [string]$Name = $Id, [string[]]$Extra = @())
    Write-Step "winget install: $Name"
    $list = winget list --id $Id --exact --accept-source-agreements 2>$null
    if ($LASTEXITCODE -eq 0 -and ($list -match [regex]::Escape($Id))) {
        Write-Ok "already installed: $Id"
        return
    }
    # NOTE: $args は PowerShell の自動変数なので衝突回避のため $wgArgs を使う
    $wgArgs = @("install","--id",$Id,"--exact","--silent","--accept-package-agreements","--accept-source-agreements") + $Extra
    winget @wgArgs
    if ($LASTEXITCODE -ne 0) { throw "winget install failed: $Id" }
    Write-Ok "installed: $Id"
}

function Add-UserPath {
    param([string]$Path)
    $cur = [Environment]::GetEnvironmentVariable("Path","Machine")
    if ($cur -split ";" -notcontains $Path) {
        [Environment]::SetEnvironmentVariable("Path", ($cur.TrimEnd(';') + ";$Path"), "Machine")
        Write-Ok "PATH += $Path"
    }
    # 現プロセスにも反映
    if ($env:Path -split ";" -notcontains $Path) { $env:Path += ";$Path" }
}

# ──────────────────────────────────────────────────────────
# 0-1. 前提検査
# ──────────────────────────────────────────────────────────
Write-Step "0) 事前検査"
if (-not (Test-Admin)) { throw "管理者権限が必要です。PowerShell を『管理者として実行』してください。" }

$os = Get-CimInstance Win32_OperatingSystem
Write-Ok "OS: $($os.Caption) $($os.Version)"

$gpu = Get-CimInstance Win32_VideoController | Where-Object { $_.Name -match "NVIDIA" } | Select-Object -First 1
if ($gpu) { Write-Ok "GPU: $($gpu.Name)  VRAM=$([math]::Round($gpu.AdapterRAM/1GB,1))GB" }
else      { Write-Warn "NVIDIA GPU が検出できません (RTX 4060 Ti 想定)" }

if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    throw "winget が無いです。Microsoft Store から『App Installer』を入れてください。"
}

# ──────────────────────────────────────────────────────────
# 1. 長いパス有効化 (Cargo target が深くなる対策)
# ──────────────────────────────────────────────────────────
Write-Step "1) Windows 長いパス有効化"
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem" `
    -Name "LongPathsEnabled" -Value 1 -PropertyType DWord -Force | Out-Null
Write-Ok "LongPathsEnabled = 1"

# ──────────────────────────────────────────────────────────
# 2. 基盤パッケージ
# ──────────────────────────────────────────────────────────
Write-Step "2) 基盤パッケージ (winget)"

# Visual Studio 2022 Build Tools - MSVC + Windows SDK + CMake は必須
# （wgpu の dxcompiler / bindgen / blake3 / ring などで C/C++ が要る）
# --override に渡す文字列はクォート無しで 1 つの配列要素にする
# (winget が内部で適切にクォートして VS インストーラへ渡す)
$vsOverride = @(
    "--quiet --wait --norestart --nocache",
    "--add Microsoft.VisualStudio.Workload.VCTools",
    "--add Microsoft.VisualStudio.Component.VC.Tools.x86.x64",
    "--add Microsoft.VisualStudio.Component.Windows11SDK.22621",
    "--add Microsoft.VisualStudio.Component.VC.CMake.Project",
    "--add Microsoft.VisualStudio.Component.VC.Llvm.Clang",
    "--add Microsoft.VisualStudio.Component.VC.ATL",
    "--includeRecommended"
) -join " "
$vsArgs = @("--override", $vsOverride)
Invoke-Winget -Id "Microsoft.VisualStudio.2022.BuildTools" -Name "VS2022 Build Tools" -Extra $vsArgs

Invoke-Winget -Id "Git.Git"              -Name "Git"
Invoke-Winget -Id "Kitware.CMake"        -Name "CMake"
Invoke-Winget -Id "LLVM.LLVM"            -Name "LLVM (clang for bindgen)"
Invoke-Winget -Id "7zip.7zip"            -Name "7-Zip"
Invoke-Winget -Id "Python.Python.3.12"   -Name "Python 3.12 (cargo build-script 用)"
Invoke-Winget -Id "OpenJS.NodeJS.LTS"    -Name "Node.js LTS (Actions / GH CLI 連携)"
Invoke-Winget -Id "GitHub.cli"           -Name "GitHub CLI"
Invoke-Winget -Id "NSIS.NSIS"            -Name "NSIS (Steam 配布前インストーラ用)"

# LIBCLANG_PATH を bindgen 向けに固定
$clangDll = "C:\Program Files\LLVM\bin"
if (Test-Path (Join-Path $clangDll "libclang.dll")) {
    [Environment]::SetEnvironmentVariable("LIBCLANG_PATH", $clangDll, "Machine")
    $env:LIBCLANG_PATH = $clangDll   # 現セッションにも反映
    Write-Ok "LIBCLANG_PATH = $clangDll"
}

# ──────────────────────────────────────────────────────────
# 3. Rust 1.95.0
# ──────────────────────────────────────────────────────────
Write-Step "3) Rust $RustToolchain (rustup)"
if (-not (Get-Command rustup -ErrorAction SilentlyContinue)) {
    $rustupInit = Join-Path $env:TEMP "rustup-init.exe"
    Invoke-WebRequest "https://win.rustup.rs/x86_64" -OutFile $rustupInit
    & $rustupInit -y --default-toolchain none --profile minimal
    Add-UserPath "$env:USERPROFILE\.cargo\bin"
}
rustup toolchain install $RustToolchain --profile default
rustup default $RustToolchain
rustup component add rustfmt clippy rust-src rust-analyzer --toolchain $RustToolchain
# wgpu のシェーダ静的解析 / cross-compile に備えて Windows ターゲットを明示
rustup target add x86_64-pc-windows-msvc --toolchain $RustToolchain
Write-Ok "rustc = $(rustc --version)"

# cargo 拡張: 最低限
cargo install --locked cargo-nextest cargo-hack cargo-deny cargo-about --force 2>$null | Out-Null
Write-Ok "cargo-nextest / cargo-hack / cargo-deny / cargo-about"

# ──────────────────────────────────────────────────────────
# 4. Vulkan SDK (wgpu + openxr_loader)
# ──────────────────────────────────────────────────────────
Write-Step "4) Vulkan SDK (LunarG)"
Invoke-Winget -Id "KhronosGroup.VulkanSDK" -Name "Vulkan SDK"
$vk = Get-ChildItem "C:\VulkanSDK" -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
if ($vk) {
    [Environment]::SetEnvironmentVariable("VULKAN_SDK", $vk.FullName, "Machine")
    $env:VULKAN_SDK = $vk.FullName   # 現セッションにも反映
    Add-UserPath (Join-Path $vk.FullName "Bin")
    Write-Ok "VULKAN_SDK = $($vk.FullName)"
}

# ──────────────────────────────────────────────────────────
# 4-b. OpenXR loader DLL 配置 (ce_xr 依存)
# ──────────────────────────────────────────────────────────
Write-Step "4-b) OpenXR loader (ce_xr 必須)"
$xrLoaderDir = "C:\openxr-loader"
$xrLoaderDll = Join-Path $xrLoaderDir "openxr_loader.dll"
if (-not (Test-Path $xrLoaderDll)) {
    # Khronos 公式 OpenXR-SDK リリースから loader を取得
    # (SteamVR が入っていれば SteamVR 側の loader が使われるが、CI 用に独立配置)
    $xrVer = "1.1.41"
    $xrZip = Join-Path $env:TEMP "openxr-loader.zip"
    $xrUrl = "https://github.com/KhronosGroup/OpenXR-SDK/releases/download/release-$xrVer/openxr_loader_windows-$xrVer.zip"
    try {
        New-Item -ItemType Directory -Path $xrLoaderDir -Force | Out-Null
        Invoke-WebRequest $xrUrl -OutFile $xrZip -UseBasicParsing
        # Expand-Archive -Force は PS 5.1 (.NET Framework 4.x) で動作し、
        # ZipFile::ExtractToDirectory(2-arg) のように既存ファイルで throw しない。
        Expand-Archive -Path $xrZip -DestinationPath $xrLoaderDir -Force -ErrorAction Stop
        Write-Ok "OpenXR loader 展開: $xrLoaderDir"
    } catch {
        Write-Warn "OpenXR loader DL 失敗: $_ (SteamVR / WMR が入っていれば問題なし)"
    }
}
$foundXrDll = Get-ChildItem -Path $xrLoaderDir -Filter "openxr_loader.dll" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
if ($foundXrDll) {
    Add-UserPath $foundXrDll.DirectoryName
    Write-Ok "openxr_loader.dll: $($foundXrDll.FullName)"
}

# ──────────────────────────────────────────────────────────
# 5. GPU / VR ランタイム
# ──────────────────────────────────────────────────────────
Write-Step "5) GPU / VR ランタイム検査"
try {
    $smi = & "C:\Windows\System32\nvidia-smi.exe" --query-gpu=name,driver_version,memory.total --format=csv,noheader 2>$null
    if ($smi) { Write-Ok "nvidia-smi: $smi" } else { Write-Warn "nvidia-smi 無し - GeForce 最新ドライバを GeForce Experience から入れてください" }
} catch { Write-Warn "nvidia-smi 実行失敗: $_" }

# OpenXR runtime 検査
$xrKey = "HKLM:\SOFTWARE\Khronos\OpenXR\1"
$xrRt  = (Get-ItemProperty -Path $xrKey -Name ActiveRuntime -ErrorAction SilentlyContinue).ActiveRuntime
if ($xrRt) { Write-Ok "OpenXR Runtime: $xrRt" }
else {
    Write-Warn "OpenXR アクティブランタイム未設定"
    Write-Warn "  -> 実機 VR テストには SteamVR (Steam.Steam) か WMR を別途インストール + アクティブ化してください"
    Write-Warn "  -> CI の単体テストは Mock runtime で動作するため必須ではない"
}

# Steam (OpenXR 実機テスト用 / 任意)
# Invoke-Winget -Id "Valve.Steam" -Name "Steam (SteamVR 用, 任意)"

# ──────────────────────────────────────────────────────────
# 6. sccache + cargo config
# ──────────────────────────────────────────────────────────
Write-Step "6) sccache (ビルド高速化)"
cargo install --locked sccache --force 2>$null | Out-Null
[Environment]::SetEnvironmentVariable("SCCACHE_DIR",         "$env:LOCALAPPDATA\sccache", "Machine")
[Environment]::SetEnvironmentVariable("SCCACHE_CACHE_SIZE",  "50G", "Machine")
[Environment]::SetEnvironmentVariable("RUSTC_WRAPPER",       "sccache", "Machine")
# 現セッションにも反映 (後続のヘルスチェックが失敗しないように)
$env:SCCACHE_DIR        = "$env:LOCALAPPDATA\sccache"
$env:SCCACHE_CACHE_SIZE = "50G"
$env:RUSTC_WRAPPER      = "sccache"
Write-Ok "sccache 環境変数セット"

$cargoConfigDir  = "$env:USERPROFILE\.cargo"
New-Item -ItemType Directory -Path $cargoConfigDir -Force | Out-Null
$cargoConfigPath = Join-Path $cargoConfigDir "config.toml"
if (-not (Test-Path $cargoConfigPath) -or -not ((Get-Content $cargoConfigPath -Raw) -match "sccache")) {
@'
# ge-mu self-hosted runner 向け cargo 設定
[build]
jobs = 0                       # 物理コア
rustc-wrapper = "sccache"

[target.x86_64-pc-windows-msvc]
linker = "link.exe"
rustflags = ["-C", "target-cpu=x86-64-v3"]

[net]
retry = 5
git-fetch-with-cli = true

[profile.release]
lto = "thin"
codegen-units = 1
'@ | Set-Content -Encoding UTF8 $cargoConfigPath
    Write-Ok "cargo config 更新"
} else { Write-Ok "cargo config は既に構成済み" }

# ──────────────────────────────────────────────────────────
# 7. GitHub Actions Runner 配置
# ──────────────────────────────────────────────────────────
Write-Step "7) GitHub Actions Runner v$RunnerVersion"
New-Item -ItemType Directory -Path $RunnerRoot -Force | Out-Null

$runnerZipName = "actions-runner-win-x64-$RunnerVersion.zip"
$runnerZipPath = Join-Path $RunnerRoot $runnerZipName
if (-not (Test-Path (Join-Path $RunnerRoot "config.cmd"))) {
    if (-not (Test-Path $runnerZipPath)) {
        $url = "https://github.com/actions/runner/releases/download/v$RunnerVersion/$runnerZipName"
        Write-Step "Runner zip ダウンロード: $url"
        Invoke-WebRequest -Uri $url -OutFile $runnerZipPath -UseBasicParsing
    }
    Write-Step "Runner zip 展開 -> $RunnerRoot"
    # Expand-Archive -Force を使うことで PS 5.1 互換と、再実行時の上書きの両方を満たす。
    Expand-Archive -Path $runnerZipPath -DestinationPath $RunnerRoot -Force -ErrorAction Stop
    Write-Ok "Runner 展開完了"
} else {
    Write-Ok "Runner は既に配置済み"
}

# ──────────────────────────────────────────────────────────
# 8. Runner 登録 (config.cmd) + Windows サービス化
# ──────────────────────────────────────────────────────────
Write-Step "8) Runner 登録 & サービス化"
if ($SkipRunnerRegister) {
    Write-Warn "SkipRunnerRegister 指定のため登録はスキップ"
} else {
    if ([string]::IsNullOrWhiteSpace($RegistrationToken)) {
        Write-Warn "RegistrationToken 未指定"
        Write-Warn "GitHub -> Settings > Actions > Runners > New self-hosted runner から取得して再実行してください"
    } else {
        Push-Location $RunnerRoot
        try {
            $runnerUrl = "https://github.com/$GitHubOwner/$GitHubRepo"

            if (Test-Path (Join-Path $RunnerRoot ".runner")) {
                Write-Warn "既に登録済み (.runner 発見)。再登録するには .\config.cmd remove --token <REMOVE_TOKEN> を先に実行してください"
            } else {
                .\config.cmd `
                    --unattended `
                    --url    $runnerUrl `
                    --token  $RegistrationToken `
                    --name   $RunnerName `
                    --labels $RunnerLabels `
                    --work   "_work" `
                    --replace
                if ($LASTEXITCODE -ne 0) { throw "runner config 失敗 ($LASTEXITCODE)" }
                Write-Ok "Runner 登録成功: $RunnerName ($RunnerLabels)"
            }

            # Windows サービスとして常駐
            if (-not (Get-Service -Name "actions.runner.*" -ErrorAction SilentlyContinue)) {
                .\svc.cmd install
                .\svc.cmd start
                Write-Ok "Runner サービス開始"
            } else {
                Write-Ok "Runner サービス既存"
            }
        } finally { Pop-Location }
    }
}

# ──────────────────────────────────────────────────────────
# 9. 最終ヘルスチェック
# ──────────────────────────────────────────────────────────
Write-Step "9) ヘルスチェック"
$checks = @(
  @{ Name = "rustc";    Cmd = "rustc --version" }
  @{ Name = "cargo";    Cmd = "cargo --version" }
  @{ Name = "cmake";    Cmd = "cmake --version" }
  @{ Name = "git";      Cmd = "git --version" }
  @{ Name = "clang";    Cmd = "clang --version" }
  @{ Name = "sccache";  Cmd = "sccache --version" }
  @{ Name = "link.exe"; Cmd = "where.exe link.exe" }
)
foreach ($c in $checks) {
    try {
        $out = & cmd /c $c.Cmd 2>&1 | Select-Object -First 1
        Write-Ok ("{0,-10} -> {1}" -f $c.Name, $out)
    } catch { Write-Fail "$($c.Name) not available" }
}

# Vulkan / OpenXR 固定
$vkOk = Test-Path "$env:VULKAN_SDK\Bin\vulkaninfo.exe"
if ($vkOk) { Write-Ok "Vulkan SDK 動作確認 OK" } else { Write-Warn "Vulkan SDK パスが解決しません" }

Write-Host "`n=== セットアップ完了 ===" -ForegroundColor Green
Write-Host "次のステップ:" -ForegroundColor Green
Write-Host "  1. GitHub -> Settings > Actions > Runners で $RunnerName が Idle 表示になっているか確認" -ForegroundColor Green
Write-Host "  2. .github/workflows/selfhosted.yml (同梱) を main に push" -ForegroundColor Green
Write-Host "  3. cd $env:USERPROFILE\dev\ge-mu ; cargo test --workspace で golden テストが通るか検証" -ForegroundColor Green

# ge-mu Self-Hosted Runner セットアップ手順書

Windows 11 + NVIDIA RTX 4060 Ti + Rust 1.95.0 + wgpu 24 + OpenXR 0.19 + Golden Test
を GitHub Actions self-hosted runner として常駐させるための手順。

---

## 0. 前提 / 何が入るか

| カテゴリ | 入るもの | 用途 |
|---|---|---|
| コンパイラ | Rust 1.95.0 (rustup, `rust-toolchain.toml` で固定) | workspace 共通 |
| ビルドチェーン | VS2022 Build Tools (MSVC + Win11 SDK + CMake) / LLVM (libclang) | MSVC link.exe / bindgen |
| GPU | NVIDIA driver (既存) + Vulkan SDK (LunarG) | `wgpu 24` Vulkan バックエンド |
| VR | OpenXR ランタイム検査 + `openxr 0.19` loader | `ce_xr` / `vr_stereo_demo` |
| 高速化 | sccache (50GB) + cargo config | ビルド時間 1/3 目安 |
| テスト | cargo-nextest / cargo-hack / cargo-deny / cargo-about | CI 品質ゲート |
| Runner | actions/runner v2.329.0 を `C:\actions-runner`、Windows サービス化 | 24/7 常駐 |

---

## 1. 事前準備 (GitHub 側)

1. **registration token** を発行する
   - `https://github.com/<owner>/<repo>/settings/actions/runners/new` を開く
   - 表示される `./config.cmd ... --token AXXXX...` の `AXXXX...` をコピー
   - **60 分で失効**するので、スクリプト実行直前に取得する
2. Runner 用 PAT は不要 (registration token で足りる)
3. `Settings > Actions > General` で **"Allow specified actions and reusable workflows"** を確認
   - `actions/checkout@v4` / `actions/upload-artifact@v4` は許可リストに入れる

---

## 2. セットアップ実行 (PC 側)

```powershell
# PowerShell を "管理者として実行" で起動
cd C:\Users\TOUYA\Downloads\ge-mu-main

# 実行ポリシー一時解除
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

# すべて入れて runner 登録まで一気通貫 (推奨)
.\scripts\setup-runner.ps1 `
    -GitHubOwner       "howitzer-gun212" `
    -GitHubRepo        "ge-mu" `
    -RegistrationToken "AXXXXXXXXXXXXXXXX"
```

`RegistrationToken` を後で入れたい場合はツール類のみ先に:

```powershell
.\scripts\setup-runner.ps1 -SkipRunnerRegister
```

完了後、トークンを取り直して runner 登録だけ実行:

```powershell
cd C:\actions-runner
.\config.cmd --unattended `
    --url    https://github.com/howitzer-gun212/ge-mu `
    --token  AXXXXXXXXXXXXXXXX `
    --name   $env:COMPUTERNAME `
    --labels "self-hosted,Windows,X64,gpu,nvidia,cuda,rtx4060ti,vulkan,wgpu,vr,openxr,golden" `
    --work   _work `
    --replace
.\svc.cmd install
.\svc.cmd start
```

---

## 3. 動作確認

```powershell
# ツールチェイン + golden 疎通
.\scripts\verify-runner.ps1 -RepoPath "C:\actions-runner\_work\ge-mu\ge-mu"
```

ブラウザで
`https://github.com/howitzer-gun212/ge-mu/settings/actions/runners` を開き、
自分のホスト名が **Idle (緑)** になっていれば登録 OK。

---

## 4. ワークフローの配線

`.github/workflows/selfhosted.yml` (同梱) を main / develop に push すると
次の 5 ジョブが RTX 4060 Ti の自宅 runner で走る。

| ジョブ | ラベル | 目的 |
|---|---|---|
| gpu-test      | gpu, wgpu  | `ce_render` / `ce_compute` の wgpu 実機テスト |
| golden-test   | golden     | `ce_softraster` + `ce_hud` の PPM 回帰テスト |
| vr-build      | vr, openxr | `ce_xr` + `vr_stereo_demo` のビルド + 単体テスト |
| release-bench | gpu        | `cargo build --release` + `examples/benchmark` |
| sccache-stats | -          | キャッシュ統計 (任意) |

既存 `ci.yml.disabled` を復活させると `ubuntu-latest` / `windows-latest`
(GitHub-hosted) と **共存**する。
Lint / unit test は GitHub-hosted、GPU / VR / Golden は自宅 runner、の分担を推奨。

---

## 5. トラブルシューティング

### 5-1. `link.exe` が見つからない
VS2022 Build Tools の VC コンポーネントが未インストール。

```powershell
winget install Microsoft.VisualStudio.2022.BuildTools --override "--wait --quiet `
  --add Microsoft.VisualStudio.Workload.VCTools `
  --add Microsoft.VisualStudio.Component.VC.Tools.x86.x64 `
  --add Microsoft.VisualStudio.Component.Windows11SDK.22621"
# 新シェルを開き直すこと (PATH 反映)
```

### 5-2. `vulkaninfo` が無い / wgpu が DX12 に落ちる
Vulkan SDK の Path が通っていない。

```powershell
$vk = (Get-ChildItem C:\VulkanSDK | Sort-Object Name -Descending | Select-Object -First 1).FullName
[Environment]::SetEnvironmentVariable("VULKAN_SDK", $vk, "Machine")
[Environment]::SetEnvironmentVariable("Path", "$env:Path;$vk\Bin", "Machine")
```

### 5-3. `openxr_loader` リンクエラー
実機 VR を使わない CI でも openxr 0.19 はローダー必須。
Steam (SteamVR) か Windows Mixed Reality を入れておくのが楽。
CI 単体テストでヘッドセット無しで通したい場合は `ce_xr` 側で `#[cfg(feature = "mock")]` を導入し、`cargo test --features mock` する。

### 5-4. Runner が Offline になった
Windows サービスを確認する。

```powershell
Get-Service actions.runner.* | Format-Table Name, Status
Restart-Service  actions.runner.*
# ログ: C:\actions-runner\_diag\*.log
```

### 5-5. ビルドが遅い
sccache が効いていない可能性。

```powershell
sccache --show-stats
# ゼロだったら RUSTC_WRAPPER 環境変数が渡っていない。
setx RUSTC_WRAPPER sccache /M
```

### 5-6. ディスク圧迫
`C:\actions-runner\_work\**\target` と `%LOCALAPPDATA%\sccache` が膨らみやすい。
月次で以下を実行。

```powershell
sccache --zero-stats
cargo install --list | Out-Null  # cargo キャッシュ GC 代わり
Remove-Item C:\actions-runner\_work\_tool -Recurse -Force -ErrorAction SilentlyContinue
```

---

## 6. セキュリティ注意

- **self-hosted runner は public repo では使用禁止** (untrusted PR が任意コード実行できる)
  本 repo が private なら問題なし。public 化するときは runner を切り離す or org 内専用に組み替える。
- Runner サービスは `NT AUTHORITY\NetworkService` で動く。ホーム配下に book-keeping ファイルを置かない。
- registration token は 1 回限り / 1 時間で失効。ログに残さない。

---

## 7. 拡張ポイント

| やりたいこと | 追加設定 |
|---|---|
| CUDA カーネル | CUDA Toolkit 12.x を winget で追加し、`features = ["cuda"]` を有効化 |
| DirectStorage | DirectStorage SDK を展開して `ce_assets` に feature gate を足す |
| Steam 配布 | `steamworks-rs` を wrap する `ce_steam` crate を作り、本 workflow に packaging job を追加 |
| Linux (Steam Deck) | WSL2 + `x86_64-unknown-linux-gnu` target (rust-toolchain.toml 既設定) |

---

## 参考

- Rust 1.95.0 リリースノート: https://blog.rust-lang.org/2026/04/16/Rust-1.95.0/
- actions/runner v2.329.0: https://github.com/actions/runner/releases/tag/v2.329.0
- Self-hosted runners docs: https://docs.github.com/actions/hosting-your-own-runners
